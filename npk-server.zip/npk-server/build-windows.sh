#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
FRONTEND_DIR="$SCRIPT_DIR/frontend"

# 确保 ffmpeg.exe 在 embed 源目录中
FFMPEG_SRC="$BACKEND_DIR/cmd/server/assets/tools/ffmpeg/ffmpeg.exe"
if [ ! -f "$FFMPEG_SRC" ]; then
    echo "ERROR: 需要 ffmpeg.exe 放在 embed 源目录:"
    echo "  $FFMPEG_SRC"
    echo ""
    echo "请从 https://www.gyan.dev/ffmpeg/builds/ 下载 ffmpeg-git-full.7z"
    echo "解压后将 ffmpeg.exe 放到上述路径"
    exit 1
fi

echo "=== Step 1: Build frontend ==="
cd "$FRONTEND_DIR"
npm run build

echo ""
echo "=== Step 2: Copy web dist ==="
cd "$BACKEND_DIR"
rm -rf internal/web/dist
cp -r web internal/web/dist

echo ""
echo "=== Step 3: Build Go backend (windows/amd64) ==="
cd "$BACKEND_DIR"
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -ldflags="-s -w" -o bin/npk-server-windows-embed.exe ./cmd/server

echo ""
echo "=== Done ==="
echo "Output: bin/npk-server-windows-embed.exe ($(ls -lh bin/npk-server-windows-embed.exe | awk '{print $5}'))"
echo ""
echo "ffmpeg.exe 已编译进 exe，首次运行自动释放到 ./tools/ffmpeg/"
echo "部署只需: npk-server-windows-embed.exe + config.json"
