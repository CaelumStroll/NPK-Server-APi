package web

import "embed"

//go:embed all:dist
var DistFS embed.FS

// DistDir 是嵌入的前端文件系统目录
const DistDir = "dist"
