package websocket

import (
	"encoding/json"
	"log"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

// Hub WebSocket 连接中心
type Hub struct {
	mu          sync.RWMutex
	connections map[string]*Connection
	broadcast   chan *Message
	register    chan *Connection
	unregister  chan *Connection
}

// Connection WebSocket 连接
type Connection struct {
	ID       string
	conn     *websocket.Conn
	send     chan []byte
	hub      *Hub
	metadata map[string]interface{}
}

// Message WebSocket 消息
type Message struct {
	Type    string                 `json:"type"`
	Payload map[string]interface{} `json:"payload"`
	Target  string                 `json:"target,omitempty"`
}

// NewHub 创建 Hub
func NewHub() *Hub {
	return &Hub{
		connections: make(map[string]*Connection),
		broadcast:   make(chan *Message, 256),
		register:    make(chan *Connection),
		unregister:  make(chan *Connection),
	}
}

// Run 运行 Hub
func (h *Hub) Run() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case conn := <-h.register:
			h.mu.Lock()
			h.connections[conn.ID] = conn
			h.mu.Unlock()
			log.Printf("WebSocket 连接: %s, 当前连接数: %d", conn.ID, len(h.connections))

		case conn := <-h.unregister:
			h.mu.Lock()
			if _, ok := h.connections[conn.ID]; ok {
				delete(h.connections, conn.ID)
				close(conn.send)
			}
			h.mu.Unlock()
			log.Printf("WebSocket 断开: %s, 当前连接数: %d", conn.ID, len(h.connections))

		case message := <-h.broadcast:
			h.mu.RLock()
			data, err := json.Marshal(message)
			if err != nil {
				h.mu.RUnlock()
				continue
			}

			if message.Target != "" {
				// 发送给特定连接
				if conn, ok := h.connections[message.Target]; ok {
					select {
					case conn.send <- data:
					default:
						close(conn.send)
						delete(h.connections, conn.ID)
					}
				}
			} else {
				// 广播给所有连接
				for _, conn := range h.connections {
					select {
					case conn.send <- data:
					default:
						close(conn.send)
						delete(h.connections, conn.ID)
					}
				}
			}
			h.mu.RUnlock()

		case <-ticker.C:
			// 发送心跳
			h.Broadcast(&Message{
				Type: "ping",
				Payload: map[string]interface{}{
					"timestamp": time.Now().Unix(),
				},
			})
		}
	}
}

// Register 注册连接
func (h *Hub) Register(conn *Connection) {
	h.register <- conn
}

// Unregister 注销连接
func (h *Hub) Unregister(conn *Connection) {
	h.unregister <- conn
}

// Broadcast 广播消息
func (h *Hub) Broadcast(message *Message) {
	h.broadcast <- message
}

// SendTo 发送给特定连接
func (h *Hub) SendTo(connID string, message *Message) {
	message.Target = connID
	h.broadcast <- message
}

// ConnectionCount 获取连接数
func (h *Hub) ConnectionCount() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return len(h.connections)
}

// NewConnection 创建连接
func NewConnection(id string, conn *websocket.Conn, hub *Hub) *Connection {
	return &Connection{
		ID:       id,
		conn:     conn,
		send:     make(chan []byte, 256),
		hub:      hub,
		metadata: make(map[string]interface{}),
	}
}

// ReadPump 读取消息
func (c *Connection) ReadPump(onMessage func(*Message)) {
	defer func() {
		c.hub.Unregister(c)
		c.conn.Close()
	}()

	c.conn.SetReadLimit(512 * 1024)
	c.conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	c.conn.SetPongHandler(func(string) error {
		c.conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		return nil
	})

	for {
		_, data, err := c.conn.ReadMessage()
		if err != nil {
			break
		}

		var msg Message
		if err := json.Unmarshal(data, &msg); err != nil {
			continue
		}

		if onMessage != nil {
			onMessage(&msg)
		}

		c.conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	}
}

// WritePump 写入消息
func (c *Connection) WritePump() {
	ticker := time.NewTicker(30 * time.Second)
	defer func() {
		ticker.Stop()
		c.conn.Close()
	}()

	for {
		select {
		case data, ok := <-c.send:
			c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if !ok {
				c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}

			w, err := c.conn.NextWriter(websocket.TextMessage)
			if err != nil {
				return
			}
			w.Write(data)

			// 批量发送
			n := len(c.send)
			for i := 0; i < n; i++ {
				w.Write([]byte{'\n'})
				w.Write(<-c.send)
			}

			if err := w.Close(); err != nil {
				return
			}

		case <-ticker.C:
			c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// SetMetadata 设置元数据
func (c *Connection) SetMetadata(key string, value interface{}) {
	c.metadata[key] = value
}

// GetMetadata 获取元数据
func (c *Connection) GetMetadata(key string) (interface{}, bool) {
	v, ok := c.metadata[key]
	return v, ok
}
