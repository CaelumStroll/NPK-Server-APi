package database

import (
	"database/sql"
	"fmt"
	"path/filepath"
	"strings"
	"time"
)

// SoundPackRecord 音效包记录
type SoundPackRecord struct {
	ID          int64     `json:"id"`
	Name        string    `json:"name"`
	Path        string    `json:"path"`
	DirPath     string    `json:"dir_path"`
	Size        int64     `json:"size"`
	IsEncrypted bool      `json:"is_encrypted"`
	FormatType  int       `json:"format_type"`
	OggCount    int       `json:"ogg_count"`
	SHA256Hash  string    `json:"sha256_hash"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// SoundPackEntry 音效包内的 OGG 条目
type SoundPackEntry struct {
	ID           int64   `json:"id"`
	SoundpackID  int64   `json:"soundpack_id"`
	EntryPath    string  `json:"entry_path"`
	EntryName    string  `json:"entry_name"`
	EntrySize    int64   `json:"entry_size"`
	EntryOffset  int64   `json:"entry_offset"`
	OggDuration  float64 `json:"ogg_duration"`
	OggSampleRate int    `json:"ogg_sample_rate"`
	OggChannels  int     `json:"ogg_channels"`
	Data         []byte  `json:"-"` // OGG 原始数据（仅导入条目）
}

// SoundPackStats 音效统计
type SoundPackStats struct {
	TotalCount    int   `json:"total_count"`
	TotalSize     int64 `json:"total_size"`
	TotalOggCount int   `json:"total_ogg_count"`
}

func initSoundPackTable(db *sql.DB) error {
	tables := []string{
		`CREATE TABLE IF NOT EXISTS soundpacks (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			path TEXT NOT NULL UNIQUE,
			dir_path TEXT NOT NULL,
			size INTEGER NOT NULL DEFAULT 0,
			is_encrypted INTEGER NOT NULL DEFAULT 0,
			format_type INTEGER DEFAULT 0,
			ogg_count INTEGER DEFAULT 0,
			sha256_hash TEXT DEFAULT '',
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,
		`CREATE TABLE IF NOT EXISTS soundpack_entries (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			soundpack_id INTEGER NOT NULL,
			entry_path TEXT NOT NULL,
			entry_name TEXT NOT NULL,
			entry_size INTEGER DEFAULT 0,
			entry_offset INTEGER DEFAULT 0,
			ogg_duration REAL DEFAULT 0,
			ogg_sample_rate INTEGER DEFAULT 0,
			ogg_channels INTEGER DEFAULT 0,
			data BLOB,
			UNIQUE(soundpack_id, entry_path),
			FOREIGN KEY (soundpack_id) REFERENCES soundpacks(id) ON DELETE CASCADE
		)`,
		`CREATE INDEX IF NOT EXISTS idx_soundpacks_path ON soundpacks(path)`,
		`CREATE INDEX IF NOT EXISTS idx_soundpacks_dir_path ON soundpacks(dir_path)`,
		`CREATE INDEX IF NOT EXISTS idx_soundpack_entries_spid ON soundpack_entries(soundpack_id)`,
	}

	for _, table := range tables {
		if _, err := db.Exec(table); err != nil {
			return fmt.Errorf("创建音效表失败: %w", err)
		}
	}

	// 迁移：添加 data 列（如果不存在）
	var hasDataColumn bool
	err := db.QueryRow(`SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='soundpack_entries'`).Scan(&hasDataColumn)
	if err == nil && hasDataColumn {
		var hasCol bool
		if err := db.QueryRow(`SELECT COUNT(*) FROM pragma_table_info('soundpack_entries') WHERE name = 'data'`).Scan(&hasCol); err == nil && !hasCol {
			db.Exec(`ALTER TABLE soundpack_entries ADD COLUMN data BLOB`)
		}
	}

	return nil
}

func scanSoundPackRow(row *sql.Row) (*SoundPackRecord, error) {
	record := &SoundPackRecord{}
	var encryptedInt int
	err := row.Scan(
		&record.ID, &record.Name, &record.Path, &record.DirPath,
		&record.Size, &encryptedInt, &record.FormatType,
		&record.OggCount, &record.SHA256Hash, &record.CreatedAt, &record.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	record.IsEncrypted = encryptedInt == 1
	return record, nil
}

func scanSoundPackRows(rows *sql.Rows) ([]*SoundPackRecord, error) {
	var records []*SoundPackRecord
	for rows.Next() {
		record := &SoundPackRecord{}
		var encryptedInt int
		err := rows.Scan(
			&record.ID, &record.Name, &record.Path, &record.DirPath,
			&record.Size, &encryptedInt, &record.FormatType,
			&record.OggCount, &record.SHA256Hash, &record.CreatedAt, &record.UpdatedAt,
		)
		if err != nil {
			continue
		}
		record.IsEncrypted = encryptedInt == 1
		records = append(records, record)
	}
	return records, nil
}

func scanSoundPackEntryRows(rows *sql.Rows) ([]*SoundPackEntry, error) {
	var entries []*SoundPackEntry
	for rows.Next() {
		e := &SoundPackEntry{}
		err := rows.Scan(
			&e.ID, &e.SoundpackID, &e.EntryPath, &e.EntryName,
			&e.EntrySize, &e.EntryOffset, &e.OggDuration,
			&e.OggSampleRate, &e.OggChannels, &e.Data,
		)
		if err != nil {
			continue
		}
		entries = append(entries, e)
	}
	return entries, nil
}

func (d *Database) InsertSoundPack(sp *SoundPackRecord) (int64, error) {
	encryptedInt := 0
	if sp.IsEncrypted {
		encryptedInt = 1
	}
	result, err := d.db.Exec(`
		INSERT INTO soundpacks (name, path, dir_path, size, is_encrypted, format_type, ogg_count, sha256_hash)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?)
	`, sp.Name, sp.Path, sp.DirPath, sp.Size, encryptedInt, sp.FormatType, sp.OggCount, sp.SHA256Hash)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

func (d *Database) UpdateSoundPack(sp *SoundPackRecord) error {
	encryptedInt := 0
	if sp.IsEncrypted {
		encryptedInt = 1
	}
	_, err := d.db.Exec(`
		UPDATE soundpacks
		SET name = ?, dir_path = ?, size = ?, is_encrypted = ?,
		    format_type = ?, ogg_count = ?, sha256_hash = ?, updated_at = ?
		WHERE id = ?
	`, sp.Name, sp.DirPath, sp.Size, encryptedInt,
		sp.FormatType, sp.OggCount, sp.SHA256Hash, time.Now(), sp.ID)
	return err
}

func (d *Database) DeleteSoundPack(id int64) error {
	_, err := d.db.Exec(`DELETE FROM soundpacks WHERE id = ?`, id)
	return err
}

func (d *Database) GetSoundPackByID(id int64) (*SoundPackRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, dir_path, size, is_encrypted, format_type, ogg_count,
		       sha256_hash, created_at, updated_at
		FROM soundpacks WHERE id = ?
	`, id)
	return scanSoundPackRow(row)
}

func (d *Database) GetSoundPackByPath(path string) (*SoundPackRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, dir_path, size, is_encrypted, format_type, ogg_count,
		       sha256_hash, created_at, updated_at
		FROM soundpacks WHERE path = ?
	`, path)
	record, err := scanSoundPackRow(row)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	return record, nil
}

func (d *Database) ListSoundPacks(query string, page, pageSize int) ([]*SoundPackRecord, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100000 {
		pageSize = 50
	}
	offset := (page - 1) * pageSize

	where := ""
	args := []interface{}{}
	if query != "" {
		where = `WHERE sp.name LIKE ? OR sp.path LIKE ? OR sp.id IN (
			SELECT DISTINCT se.soundpack_id FROM soundpack_entries se
			WHERE se.entry_name LIKE ? OR se.entry_path LIKE ?
		)`
		q := "%" + query + "%"
		args = append(args, q, q, q, q)
	}

	countSQL := "SELECT COUNT(*) FROM soundpacks sp " + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	querySQL := `
		SELECT sp.id, sp.name, sp.path, sp.dir_path, sp.size, sp.is_encrypted, sp.format_type, sp.ogg_count,
		       sp.sha256_hash, sp.created_at, sp.updated_at
		FROM soundpacks sp ` + where + `
		ORDER BY sp.name
		LIMIT ? OFFSET ?
	`
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	records, err := scanSoundPackRows(rows)
	if err != nil {
		return nil, 0, err
	}
	return records, total, nil
}

func (d *Database) GetSoundPackStats() (*SoundPackStats, error) {
	stats := &SoundPackStats{}
	err := d.db.QueryRow(`
		SELECT COUNT(*), COALESCE(SUM(size), 0), COALESCE(SUM(ogg_count), 0)
		FROM soundpacks
	`).Scan(&stats.TotalCount, &stats.TotalSize, &stats.TotalOggCount)
	if err != nil {
		return nil, err
	}
	return stats, nil
}

func (d *Database) DeleteSoundPackByDir(dirPath string) (int64, error) {
	result, err := d.db.Exec(`DELETE FROM soundpacks WHERE dir_path = ?`, dirPath)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

func (d *Database) GetSoundPacksByIDs(ids []int64) ([]*SoundPackRecord, error) {
	if len(ids) == 0 {
		return []*SoundPackRecord{}, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`
		SELECT id, name, path, dir_path, size, is_encrypted, format_type, ogg_count,
		       sha256_hash, created_at, updated_at
		FROM soundpacks WHERE id IN (%s)
	`, phs)
	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanSoundPackRows(rows)
}

func (d *Database) DeleteSoundPacksByIDs(ids []int64) (int64, error) {
	if len(ids) == 0 {
		return 0, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`DELETE FROM soundpacks WHERE id IN (%s)`, phs)
	result, err := d.db.Exec(query, args...)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

// SoundPack Entry operations
func (d *Database) InsertSoundPackEntry(entry *SoundPackEntry) (int64, error) {
	result, err := d.db.Exec(`
		INSERT OR REPLACE INTO soundpack_entries
			(soundpack_id, entry_path, entry_name, entry_size, entry_offset, ogg_duration, ogg_sample_rate, ogg_channels, data)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, entry.SoundpackID, entry.EntryPath, entry.EntryName,
		entry.EntrySize, entry.EntryOffset, entry.OggDuration,
		entry.OggSampleRate, entry.OggChannels, entry.Data)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

func (d *Database) GetSoundPackEntries(soundpackID int64) ([]*SoundPackEntry, error) {
	rows, err := d.db.Query(`
		SELECT id, soundpack_id, entry_path, entry_name, entry_size, entry_offset,
		       ogg_duration, ogg_sample_rate, ogg_channels, COALESCE(data, '')
		FROM soundpack_entries
		WHERE soundpack_id = ?
		ORDER BY entry_path
	`, soundpackID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanSoundPackEntryRows(rows)
}

func (d *Database) GetSoundPackEntry(id int64) (*SoundPackEntry, error) {
	query := `
		SELECT id, soundpack_id, entry_path, entry_name, entry_size, entry_offset,
		       ogg_duration, ogg_sample_rate, ogg_channels, COALESCE(data, '')
		FROM soundpack_entries WHERE id = ?
	`
	row := d.db.QueryRow(query, id)
	var e SoundPackEntry
	err := row.Scan(&e.ID, &e.SoundpackID, &e.EntryPath, &e.EntryName,
		&e.EntrySize, &e.EntryOffset, &e.OggDuration, &e.OggSampleRate, &e.OggChannels, &e.Data)
	if err != nil {
		return nil, err
	}
	return &e, nil
}

// FindSoundPackEntryByPath 按路径查找任意音效包中的条目
func (d *Database) FindSoundPackEntryByPath(entryPath string) (*SoundPackEntry, error) {
	fixed := entryPath
	fixed = strings.ReplaceAll(fixed, "\\", "/")
	query := `
		SELECT id, soundpack_id, entry_path, entry_name, entry_size, entry_offset,
		       ogg_duration, ogg_sample_rate, ogg_channels, COALESCE(data, '')
		FROM soundpack_entries WHERE REPLACE(entry_path, '\', '/') = ? OR entry_path LIKE ?
		LIMIT 1
	`
	likePattern := "%/" + filepath.Base(entryPath)
	row := d.db.QueryRow(query, fixed, likePattern)
	var e SoundPackEntry
	err := row.Scan(&e.ID, &e.SoundpackID, &e.EntryPath, &e.EntryName,
		&e.EntrySize, &e.EntryOffset, &e.OggDuration, &e.OggSampleRate, &e.OggChannels, &e.Data)
	if err != nil {
		return nil, err
	}
	return &e, nil
}

func (d *Database) DeleteSoundPackEntry(id int64) error {
	_, err := d.db.Exec(`DELETE FROM soundpack_entries WHERE id = ?`, id)
	return err
}

func (d *Database) UpdateSoundPackEntryPath(entryID int64, newPath string) error {
	_, err := d.db.Exec(`
		UPDATE soundpack_entries SET entry_path = ?, entry_name = ? WHERE id = ?
	`, newPath, filepath.Base(newPath), entryID)
	return err
}

func (d *Database) UpdateOGGCount(soundpackID int64, count int) error {
	_, err := d.db.Exec(`UPDATE soundpacks SET ogg_count = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, count, soundpackID)
	return err
}

func (d *Database) DeleteSoundPackEntriesBySoundPackID(soundpackID int64) error {
	_, err := d.db.Exec(`DELETE FROM soundpack_entries WHERE soundpack_id = ?`, soundpackID)
	return err
}

func (d *Database) GetSoundPackEntriesByIDs(ids []int64) ([]*SoundPackEntry, error) {
	if len(ids) == 0 {
		return []*SoundPackEntry{}, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`
		SELECT id, soundpack_id, entry_path, entry_name, entry_size, entry_offset,
		       ogg_duration, ogg_sample_rate, ogg_channels, COALESCE(data, '')
		FROM soundpack_entries WHERE id IN (%s)
	`, phs)
	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanSoundPackEntryRows(rows)
}
