package database

import (
	"database/sql"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

// extractName 从路径中提取文件名（不含扩展名）
func extractName(path string) string {
	base := filepath.Base(path)
	if idx := strings.LastIndex(base, "."); idx != -1 {
		return base[:idx]
	}
	return base
}

// readNpkIndexes 读取 NPK 文件索引（不依赖 npk 包，避免循环依赖）
func readNpkIndexes(npkPath string) (map[string]bool, error) {
	file, err := os.Open(npkPath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// 读取文件头
	header := make([]byte, 16)
	if _, err := file.Read(header); err != nil {
		return nil, err
	}

	// 验证 NPK 魔数 "NeoplePack_Bill"
	if string(header[:14]) != "NeoplePack_Bill" {
		return nil, fmt.Errorf("invalid NPK header")
	}

	// 读取索引数量（小端序）
	var indexCount uint32
	if err := binary.Read(file, binary.LittleEndian, &indexCount); err != nil {
		return nil, err
	}

	// 读取索引
	paths := make(map[string]bool)
	for i := uint32(0); i < indexCount; i++ {
		// 每个索引：offset(4) + size(4) + path(256)
		idxData := make([]byte, 264)
		if _, err := file.Read(idxData); err != nil {
			break
		}

		// 提取路径（从第8字节开始，256字节，以\x00结尾）
		pathBytes := idxData[8:264]
		pathLen := 0
		for j, b := range pathBytes {
			if b == 0 {
				pathLen = j
				break
			}
		}
		if pathLen > 0 {
			paths[string(pathBytes[:pathLen])] = true
		}
	}

	return paths, nil
}

// Database 数据库
type Database struct {
	db *sql.DB
}

// NewDatabase 创建数据库
func NewDatabase(path string) (*Database, error) {
	// 确保目录存在
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, err
	}

	// 使用 WAL 模式和 busy timeout 避免 "database is locked" 错误
	dbPath := path + "?_journal_mode=WAL&_busy_timeout=30000"
	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, err
	}

	// SQLite 写操作是串行的，1 个连接避免并发写冲突
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)
	db.SetConnMaxLifetime(5 * time.Minute)

	d := &Database{db: db}

	// 启用 WAL 模式（提升并发读写性能）
	if err := d.enableWALMode(); err != nil {
		db.Close()
		return nil, fmt.Errorf("启用 WAL 模式失败: %w", err)
	}

	if err := d.initTables(); err != nil {
		db.Close()
		return nil, err
	}

	return d, nil
}

// enableWALMode 启用 WAL 模式并配置优化参数
func (d *Database) enableWALMode() error {
	// 启用 WAL 模式
	if _, err := d.db.Exec(`PRAGMA journal_mode = WAL`); err != nil {
		return err
	}

	// 降低同步级别以提升写入性能（WAL 模式下 NORMAL 是安全的）
	if _, err := d.db.Exec(`PRAGMA synchronous = NORMAL`); err != nil {
		return err
	}

	// 增加页缓存大小（64MB）
	if _, err := d.db.Exec(`PRAGMA cache_size = -64000`); err != nil {
		return err
	}

	// 启用内存映射 I/O（提升读取性能）
	if _, err := d.db.Exec(`PRAGMA mmap_size = 268435456`); err != nil {
		return err
	}

	// 临时表使用内存存储
	if _, err := d.db.Exec(`PRAGMA temp_store = MEMORY`); err != nil {
		return err
	}

	// 自动检查点间隔（每 1000 页）
	if _, err := d.db.Exec(`PRAGMA wal_autocheckpoint = 1000`); err != nil {
		return err
	}

	log.Println("WAL 模式已启用，数据库并发性能已优化")
	return nil
}

// initTables 初始化表
func (d *Database) initTables() error {
	// 启用外键约束
	if _, err := d.db.Exec(`PRAGMA foreign_keys = ON`); err != nil {
		return fmt.Errorf("启用外键失败: %w", err)
	}

	tables := []string{
		// Schema 版本管理表
		`CREATE TABLE IF NOT EXISTS schema_migrations (
			version INTEGER PRIMARY KEY,
			applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,

		// NPK 文件表 - v4: 新增 img_count, sha256_hash, format_type, encryption_verified
		`CREATE TABLE IF NOT EXISTS npk_files (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL UNIQUE,
			path TEXT NOT NULL,
			size INTEGER,
			img_count INTEGER DEFAULT 0,
			sha256_hash TEXT,
			format_type INTEGER DEFAULT 0,
			encryption_verified INTEGER DEFAULT 0,
			modified_at DATETIME,
			scanned_at DATETIME,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,

		// Albums 表 - v5: 新增 file_type, offset, size, palette_json, dds_info_json
		`CREATE TABLE IF NOT EXISTS albums (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			npk_id INTEGER NOT NULL,
			path TEXT NOT NULL,
			name TEXT NOT NULL,
			file_type INTEGER DEFAULT 0,
			version INTEGER,
			sprite_count INTEGER,
			offset INTEGER,
			size INTEGER,
			palette_json TEXT,
			dds_info_json TEXT,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			FOREIGN KEY (npk_id) REFERENCES npk_files(id) ON DELETE CASCADE,
			UNIQUE(npk_id, path)
		)`,

		// Sprites 表 - v6: 新增 data_size
		`CREATE TABLE IF NOT EXISTS sprites (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			album_id INTEGER NOT NULL,
			"index" INTEGER NOT NULL,
			type INTEGER,
			compress_mode INTEGER,
			width INTEGER,
			height INTEGER,
			x INTEGER,
			y INTEGER,
			frame_width INTEGER,
			frame_height INTEGER,
			is_link INTEGER DEFAULT 0 CHECK(is_link IN (0, 1)),
			target_index INTEGER,
			data_size INTEGER,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE,
			UNIQUE(album_id, "index")
		)`,

		// Tags 表
		`CREATE TABLE IF NOT EXISTS tags (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL UNIQUE,
			color TEXT,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,

		// Sprite 标签关联表 - 级联删除
		`CREATE TABLE IF NOT EXISTS sprite_tags (
			sprite_id INTEGER NOT NULL,
			tag_id INTEGER NOT NULL,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (sprite_id, tag_id),
			FOREIGN KEY (sprite_id) REFERENCES sprites(id) ON DELETE CASCADE,
			FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
		)`,

		// Album 标签关联表
		`CREATE TABLE IF NOT EXISTS album_tags (
			album_id INTEGER NOT NULL,
			tag_id INTEGER NOT NULL,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (album_id, tag_id),
			FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE,
			FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
		)`,

		// NPK 标签关联表（新增）
		`CREATE TABLE IF NOT EXISTS npk_tags (
			npk_id INTEGER NOT NULL,
			tag_id INTEGER NOT NULL,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (npk_id, tag_id),
			FOREIGN KEY (npk_id) REFERENCES npk_files(id) ON DELETE CASCADE,
			FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
		)`,

		// Settings 表
		`CREATE TABLE IF NOT EXISTS settings (
			key TEXT PRIMARY KEY,
			value TEXT,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,

		// Batch tasks 表 - 增强版
		`CREATE TABLE IF NOT EXISTS batch_tasks (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			type TEXT NOT NULL,
			status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
			total INTEGER DEFAULT 0,
			completed INTEGER DEFAULT 0,
			failed INTEGER DEFAULT 0,
			params TEXT,
			result TEXT,
			error TEXT,
			retry_count INTEGER DEFAULT 0,
			max_retries INTEGER DEFAULT 3,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			started_at DATETIME,
			finished_at DATETIME,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,

		// 索引 - 优化查询性能
		`CREATE INDEX IF NOT EXISTS idx_albums_npk_id ON albums(npk_id)`,
		`CREATE INDEX IF NOT EXISTS idx_albums_path ON albums(path)`,
		`CREATE INDEX IF NOT EXISTS idx_albums_name ON albums(name)`,
		`CREATE INDEX IF NOT EXISTS idx_sprites_album_id ON sprites(album_id)`,
		`CREATE INDEX IF NOT EXISTS idx_sprites_type ON sprites(type)`,
		`CREATE INDEX IF NOT EXISTS idx_sprites_index ON sprites("index")`,
		`CREATE INDEX IF NOT EXISTS idx_npk_files_name ON npk_files(name)`,
		`CREATE INDEX IF NOT EXISTS idx_batch_tasks_status ON batch_tasks(status)`,
		`CREATE INDEX IF NOT EXISTS idx_batch_tasks_type ON batch_tasks(type)`,
		// 新增复合索引
		`CREATE INDEX IF NOT EXISTS idx_albums_npk_id_path ON albums(npk_id, path)`,
		`CREATE INDEX IF NOT EXISTS idx_sprites_album_id_index ON sprites(album_id, "index")`,
		`CREATE INDEX IF NOT EXISTS idx_sprite_tags_sprite_id ON sprite_tags(sprite_id)`,
		`CREATE INDEX IF NOT EXISTS idx_sprite_tags_tag_id ON sprite_tags(tag_id)`,
		`CREATE INDEX IF NOT EXISTS idx_album_tags_album_id ON album_tags(album_id)`,
		`CREATE INDEX IF NOT EXISTS idx_album_tags_tag_id ON album_tags(tag_id)`,
		`CREATE INDEX IF NOT EXISTS idx_npk_tags_npk_id ON npk_tags(npk_id)`,
		`CREATE INDEX IF NOT EXISTS idx_npk_tags_tag_id ON npk_tags(tag_id)`,
	}

	for _, table := range tables {
		if _, err := d.db.Exec(table); err != nil {
			return fmt.Errorf("创建表失败: %w", err)
		}
	}

	// 初始化视频表
	if err := d.initVideoTable(); err != nil {
		return fmt.Errorf("初始化视频表失败: %w", err)
	}

	// 初始化音乐表
	if err := initMusicTable(d.db); err != nil {
		return fmt.Errorf("初始化音乐表失败: %w", err)
	}

	// 初始化音效表
	if err := initSoundPackTable(d.db); err != nil {
		return fmt.Errorf("初始化音效表失败: %w", err)
	}

	// 初始化音频 XML 表
	if err := initAudioXmlTable(d.db); err != nil {
		return fmt.Errorf("初始化音频XML表失败: %w", err)
	}

	// 记录 schema 版本
	if err := d.migrateSchema(); err != nil {
		return fmt.Errorf("执行迁移失败: %w", err)
	}

	return nil
}

// tableExists 检查表是否存在
func (d *Database) tableExists(tableName string) bool {
	var count int
	err := d.db.QueryRow(`SELECT count(*) FROM sqlite_master WHERE type='table' AND name=?`, tableName).Scan(&count)
	return err == nil && count > 0
}

// columnExists 检查列是否存在
func (d *Database) columnExists(tableName, columnName string) bool {
	var count int
	err := d.db.QueryRow(`SELECT count(*) FROM pragma_table_info(?) WHERE name=?`, tableName, columnName).Scan(&count)
	return err == nil && count > 0
}

// migrateSchema 执行数据库迁移
func (d *Database) migrateSchema() error {
	// 获取当前版本
	var currentVersion int
	err := d.db.QueryRow(`SELECT COALESCE(MAX(version), 0) FROM schema_migrations`).Scan(&currentVersion)
	if err != nil {
		return err
	}

	// 定义迁移脚本（每个迁移独立执行，支持容错）
	migrations := []struct {
		version int
		name    string
		fn      func() error
	}{
		{
			version: 1,
			name:    "添加 updated_at 字段",
			fn: func() error {
				columns := []struct {
					table  string
					column string
				}{
					{"npk_files", "updated_at"},
					{"albums", "updated_at"},
					{"sprites", "updated_at"},
					{"tags", "updated_at"},
				}
				for _, col := range columns {
					if !d.columnExists(col.table, col.column) {
						if _, err := d.db.Exec(fmt.Sprintf(`ALTER TABLE %s ADD COLUMN %s DATETIME DEFAULT CURRENT_TIMESTAMP`, col.table, col.column)); err != nil {
							return err
						}
					}
				}
				return nil
			},
		},
		{
			version: 2,
			name:    "创建 album_tags 表",
			fn: func() error {
				if !d.tableExists("album_tags") {
					_, err := d.db.Exec(`CREATE TABLE album_tags (
						album_id INTEGER NOT NULL,
						tag_id INTEGER NOT NULL,
						created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
						PRIMARY KEY (album_id, tag_id),
						FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE,
						FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
					)`)
					return err
				}
				return nil
			},
		},
		{
			version: 3,
			name:    "增强 batch_tasks 表",
			fn: func() error {
				newColumns := []struct {
					column string
					def    string
				}{
					{"failed", "INTEGER DEFAULT 0"},
					{"params", "TEXT"},
					{"result", "TEXT"},
					{"retry_count", "INTEGER DEFAULT 0"},
					{"max_retries", "INTEGER DEFAULT 3"},
					{"started_at", "DATETIME"},
					{"updated_at", "DATETIME DEFAULT CURRENT_TIMESTAMP"},
				}
				for _, col := range newColumns {
					if !d.columnExists("batch_tasks", col.column) {
						if _, err := d.db.Exec(fmt.Sprintf(`ALTER TABLE batch_tasks ADD COLUMN %s %s`, col.column, col.def)); err != nil {
							return err
						}
					}
				}
				return nil
			},
		},
		{
			version: 4,
			name:    "增强 npk_files 表 - 添加文件级元数据",
			fn: func() error {
				newColumns := []struct {
					column string
					def    string
				}{
					{"img_count", "INTEGER DEFAULT 0"},
					{"sha256_hash", "TEXT"},
					{"format_type", "INTEGER DEFAULT 0"},
					{"encryption_verified", "INTEGER DEFAULT 0"},
				}
				for _, col := range newColumns {
					if !d.columnExists("npk_files", col.column) {
						if _, err := d.db.Exec(fmt.Sprintf(`ALTER TABLE npk_files ADD COLUMN %s %s`, col.column, col.def)); err != nil {
							return err
						}
					}
				}
				return nil
			},
		},
		{
			version: 5,
			name:    "增强 albums 表 - 添加 IMG 级元数据",
			fn: func() error {
				newColumns := []struct {
					column string
					def    string
				}{
					{"file_type", "INTEGER DEFAULT 0"},
					{"offset", "INTEGER"},
					{"size", "INTEGER"},
					{"palette_json", "TEXT"},
					{"dds_info_json", "TEXT"},
				}
				for _, col := range newColumns {
					if !d.columnExists("albums", col.column) {
						if _, err := d.db.Exec(fmt.Sprintf(`ALTER TABLE albums ADD COLUMN %s %s`, col.column, col.def)); err != nil {
							return err
						}
					}
				}
				return nil
			},
		},
		{
			version: 6,
			name:    "增强 sprites 表 - 添加 data_size",
			fn: func() error {
				if !d.columnExists("sprites", "data_size") {
					if _, err := d.db.Exec(`ALTER TABLE sprites ADD COLUMN data_size INTEGER`); err != nil {
						return err
					}
				}
				return nil
			},
		},
		{
			version: 7,
			name:    "创建 npk_tags 表",
			fn: func() error {
				if !d.tableExists("npk_tags") {
					_, err := d.db.Exec(`CREATE TABLE npk_tags (
						npk_id INTEGER NOT NULL,
						tag_id INTEGER NOT NULL,
						created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
						PRIMARY KEY (npk_id, tag_id),
						FOREIGN KEY (npk_id) REFERENCES npk_files(id) ON DELETE CASCADE,
						FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
					)`)
					if err != nil {
						return err
					}
					// 创建索引
					_, err = d.db.Exec(`CREATE INDEX idx_npk_tags_npk_id ON npk_tags(npk_id)`)
					if err != nil {
						return err
					}
					_, err = d.db.Exec(`CREATE INDEX idx_npk_tags_tag_id ON npk_tags(tag_id)`)
					return err
				}
				return nil
			},
		},
	}

	// 执行未应用的迁移
	for _, m := range migrations {
		if m.version > currentVersion {
			if err := m.fn(); err != nil {
				return fmt.Errorf("迁移 %d (%s) 失败: %w", m.version, m.name, err)
			}
			if _, err := d.db.Exec(`INSERT INTO schema_migrations (version) VALUES (?)`, m.version); err != nil {
				return fmt.Errorf("记录迁移版本 %d 失败: %w", m.version, err)
			}
			log.Printf("已应用数据库迁移: 版本 %d (%s)", m.version, m.name)
		}
	}

	return nil
}

// Close 关闭数据库
func (d *Database) Close() error {
	return d.db.Close()
}

// Begin 开始事务（供外部使用）
func (d *Database) Begin() (*sql.Tx, error) {
	return d.db.Begin()
}

// 数据模型

type NpkFileRecord struct {
	ID                 int64
	Name               string
	Path               string
	Size               int64
	ImgCount           int
	SHA256Hash         string
	FormatType         int
	EncryptionVerified bool
	ModifiedAt         time.Time
	ScannedAt          time.Time
	CreatedAt          time.Time
}

type AlbumRecord struct {
	ID          int64
	NpkID       int64
	Path        string
	Name        string
	FileType    int
	Version     int
	SpriteCount int
	Offset      int64
	Size        int64
	PaletteJSON string
	DDSInfoJSON string
	CreatedAt   time.Time
}

type SpriteRecord struct {
	ID           int64
	AlbumID      int64
	Index        int
	Type         int
	CompressMode int
	Width        int
	Height       int
	X            int
	Y            int
	FrameWidth   int
	FrameHeight  int
	IsLink       bool
	TargetIndex  int
	DataSize     int
	CreatedAt    time.Time
}

type TagRecord struct {
	ID        int64
	Name      string
	Color     string
	CreatedAt time.Time
}

type BatchTaskRecord struct {
	ID         int64
	Type       string
	Status     string
	Total      int
	Completed  int
	Error      string
	CreatedAt  time.Time
	FinishedAt time.Time
}

// SearchAlbumResult 搜索结果
type SearchAlbumResult struct {
	AlbumID     int64  `json:"album_id"`
	NpkID       int64  `json:"npk_id"`
	NpkName     string `json:"npk_name"`
	AlbumPath   string `json:"album_path"`
	AlbumName   string `json:"album_name"`
	Version     int    `json:"version"`
	SpriteCount int    `json:"sprite_count"`
}

// BuildInClause 构建 IN (?,?,?) 占位符和参数列表
func BuildInClause[T int64 | int](ids []T) (string, []interface{}) {
	if len(ids) == 0 {
		return "", nil
	}
	placeholders := strings.Repeat("?,", len(ids)-1) + "?"
	args := make([]interface{}, len(ids))
	for i, id := range ids {
		args[i] = id
	}
	return placeholders, args
}


