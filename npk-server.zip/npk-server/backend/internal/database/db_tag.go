package database

import (
	"fmt"
	"strings"
	"time"
)

// CreateTag 创建标签
func (d *Database) CreateTag(name, color string) (int64, error) {
	result, err := d.db.Exec(`
		INSERT INTO tags (name, color) VALUES (?, ?)
	`, name, color)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

// GetTagByID 根据 ID 获取标签
func (d *Database) GetTagByID(id int64) (*TagRecord, error) {
	row := d.db.QueryRow(`SELECT id, name, color, created_at FROM tags WHERE id = ?`, id)
	record := &TagRecord{}
	err := row.Scan(&record.ID, &record.Name, &record.Color, &record.CreatedAt)
	if err != nil {
		return nil, err
	}
	return record, nil
}

// GetTagByName 根据名称获取标签
func (d *Database) GetTagByName(name string) (*TagRecord, error) {
	row := d.db.QueryRow(`SELECT id, name, color, created_at FROM tags WHERE name = ?`, name)
	record := &TagRecord{}
	err := row.Scan(&record.ID, &record.Name, &record.Color, &record.CreatedAt)
	if err != nil {
		return nil, err
	}
	return record, nil
}

// GetTags 获取所有标签
func (d *Database) GetTags() ([]*TagRecord, error) {
	rows, err := d.db.Query(`SELECT id, name, color, created_at FROM tags ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []*TagRecord
	for rows.Next() {
		record := &TagRecord{}
		err := rows.Scan(&record.ID, &record.Name, &record.Color, &record.CreatedAt)
		if err != nil {
			return nil, err
		}
		records = append(records, record)
	}
	return records, nil
}

// UpdateTag 更新标签
func (d *Database) UpdateTag(id int64, name, color string) error {
	_, err := d.db.Exec(`UPDATE tags SET name = ?, color = ?, updated_at = ? WHERE id = ?`, name, color, time.Now(), id)
	return err
}

// DeleteTag 删除标签
func (d *Database) DeleteTag(id int64) error {
	_, err := d.db.Exec(`DELETE FROM tags WHERE id = ?`, id)
	return err
}

// AddTagToNPK 为 NPK 添加标签
func (d *Database) AddTagToNPK(npkID, tagID int64) error {
	_, err := d.db.Exec(`
		INSERT OR IGNORE INTO npk_tags (npk_id, tag_id) VALUES (?, ?)
	`, npkID, tagID)
	return err
}

// RemoveTagFromNPK 从 NPK 移除标签
func (d *Database) RemoveTagFromNPK(npkID, tagID int64) error {
	_, err := d.db.Exec(`DELETE FROM npk_tags WHERE npk_id = ? AND tag_id = ?`, npkID, tagID)
	return err
}

// RemoveAllTagsFromNPK 移除 NPK 的所有标签（批量删除）
func (d *Database) RemoveAllTagsFromNPK(npkID int64) error {
	_, err := d.db.Exec(`DELETE FROM npk_tags WHERE npk_id = ?`, npkID)
	return err
}

// AddTagsToNPKBatch 批量添加标签到 NPK（事务+批量INSERT）
func (d *Database) AddTagsToNPKBatch(npkID int64, tagIDs []int64) error {
	if len(tagIDs) == 0 {
		return nil
	}

	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	stmt, err := tx.Prepare(`INSERT OR IGNORE INTO npk_tags (npk_id, tag_id) VALUES (?, ?)`)
	if err != nil {
		return err
	}
	defer stmt.Close()

	for _, tagID := range tagIDs {
		if _, err := stmt.Exec(npkID, tagID); err != nil {
			return err
		}
	}

	return tx.Commit()
}

// AddTagsToAlbumBatch 批量添加标签到 Album
func (d *Database) AddTagsToAlbumBatch(albumID int64, tagIDs []int64) error {
	if len(tagIDs) == 0 {
		return nil
	}

	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	stmt, err := tx.Prepare(`INSERT OR IGNORE INTO album_tags (album_id, tag_id) VALUES (?, ?)`)
	if err != nil {
		return err
	}
	defer stmt.Close()

	for _, tagID := range tagIDs {
		if _, err := stmt.Exec(albumID, tagID); err != nil {
			return err
		}
	}

	return tx.Commit()
}

// RemoveAllTagsFromAlbum 移除 Album 的所有标签
func (d *Database) RemoveAllTagsFromAlbum(albumID int64) error {
	_, err := d.db.Exec(`DELETE FROM album_tags WHERE album_id = ?`, albumID)
	return err
}

// GetTagsByNPKID 获取 NPK 的所有标签
func (d *Database) GetTagsByNPKID(npkID int64) ([]*TagRecord, error) {
	rows, err := d.db.Query(`
		SELECT t.id, t.name, t.color, t.created_at
		FROM tags t
		JOIN npk_tags nt ON t.id = nt.tag_id
		WHERE nt.npk_id = ?
		ORDER BY t.name
	`, npkID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []*TagRecord
	for rows.Next() {
		record := &TagRecord{}
		err := rows.Scan(&record.ID, &record.Name, &record.Color, &record.CreatedAt)
		if err != nil {
			return nil, err
		}
		records = append(records, record)
	}
	return records, nil
}

// AddTagToAlbum 为 Album 添加标签
func (d *Database) AddTagToAlbum(albumID, tagID int64) error {
	_, err := d.db.Exec(`
		INSERT OR IGNORE INTO album_tags (album_id, tag_id) VALUES (?, ?)
	`, albumID, tagID)
	return err
}

// RemoveTagFromAlbum 从 Album 移除标签
func (d *Database) RemoveTagFromAlbum(albumID, tagID int64) error {
	_, err := d.db.Exec(`DELETE FROM album_tags WHERE album_id = ? AND tag_id = ?`, albumID, tagID)
	return err
}

// GetTagsByAlbumID 获取 Album 的所有标签
func (d *Database) GetTagsByAlbumID(albumID int64) ([]*TagRecord, error) {
	rows, err := d.db.Query(`
		SELECT t.id, t.name, t.color, t.created_at
		FROM tags t
		JOIN album_tags at ON t.id = at.tag_id
		WHERE at.album_id = ?
		ORDER BY t.name
	`, albumID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []*TagRecord
	for rows.Next() {
		record := &TagRecord{}
		err := rows.Scan(&record.ID, &record.Name, &record.Color, &record.CreatedAt)
		if err != nil {
			return nil, err
		}
		records = append(records, record)
	}
	return records, nil
}

// AddTagToSprite 为 Sprite 添加标签
func (d *Database) AddTagToSprite(spriteID, tagID int64) error {
	_, err := d.db.Exec(`
		INSERT OR IGNORE INTO sprite_tags (sprite_id, tag_id) VALUES (?, ?)
	`, spriteID, tagID)
	return err
}

// RemoveTagFromSprite 从 Sprite 移除标签
func (d *Database) RemoveTagFromSprite(spriteID, tagID int64) error {
	_, err := d.db.Exec(`DELETE FROM sprite_tags WHERE sprite_id = ? AND tag_id = ?`, spriteID, tagID)
	return err
}

// GetTagsBySpriteID 获取 Sprite 的所有标签
func (d *Database) GetTagsBySpriteID(spriteID int64) ([]*TagRecord, error) {
	rows, err := d.db.Query(`
		SELECT t.id, t.name, t.color, t.created_at
		FROM tags t
		JOIN sprite_tags st ON t.id = st.tag_id
		WHERE st.sprite_id = ?
		ORDER BY t.name
	`, spriteID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []*TagRecord
	for rows.Next() {
		record := &TagRecord{}
		err := rows.Scan(&record.ID, &record.Name, &record.Color, &record.CreatedAt)
		if err != nil {
			return nil, err
		}
		records = append(records, record)
	}
	return records, nil
}

// SearchAssetsByTags 根据标签搜索资源（NPK/Album/Sprite）
func (d *Database) SearchAssetsByTags(tagIDs []int64, assetType string) (map[string][]int64, error) {
	result := make(map[string][]int64)
	result["npk"] = []int64{}
	result["album"] = []int64{}
	result["sprite"] = []int64{}

	if len(tagIDs) == 0 {
		return result, nil
	}

	placeholders := make([]string, len(tagIDs))
	args := make([]interface{}, len(tagIDs))
	for i, id := range tagIDs {
		placeholders[i] = "?"
		args[i] = id
	}
	inClause := strings.Join(placeholders, ",")

	// 搜索 NPK
	if assetType == "" || assetType == "npk" {
		query := fmt.Sprintf(`
			SELECT DISTINCT npk_id FROM npk_tags
			WHERE tag_id IN (%s)
		`, inClause)
		rows, err := d.db.Query(query, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var id int64
				if err := rows.Scan(&id); err == nil {
					result["npk"] = append(result["npk"], id)
				}
			}
		}
	}

	// 搜索 Album
	if assetType == "" || assetType == "album" {
		query := fmt.Sprintf(`
			SELECT DISTINCT album_id FROM album_tags
			WHERE tag_id IN (%s)
		`, inClause)
		rows, err := d.db.Query(query, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var id int64
				if err := rows.Scan(&id); err == nil {
					result["album"] = append(result["album"], id)
				}
			}
		}
	}

	// 搜索 Sprite
	if assetType == "" || assetType == "sprite" {
		query := fmt.Sprintf(`
			SELECT DISTINCT sprite_id FROM sprite_tags
			WHERE tag_id IN (%s)
		`, inClause)
		rows, err := d.db.Query(query, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var id int64
				if err := rows.Scan(&id); err == nil {
					result["sprite"] = append(result["sprite"], id)
				}
			}
		}
	}

	return result, nil
}
