package database

import (
	"database/sql"
	"fmt"
	"strings"
	"time"
)

// AlbumBatchItem 批量插入的 Album 数据项
type AlbumBatchItem struct {
	Path        string
	Name        string
	FileType    int
	Version     int
	SpriteCount int
	Offset      int64
	Size        int64
	PaletteJSON string
	DDSInfoJSON string
}

// InsertAlbum 插入 Album（增强版）
func (d *Database) InsertAlbum(npkID int64, path, name string, fileType, version, spriteCount int, offset, size int64, paletteJSON, ddsInfoJSON string) (int64, error) {
	result, err := d.db.Exec(`
		INSERT INTO albums (npk_id, path, name, file_type, version, sprite_count, offset, size, palette_json, dds_info_json)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, npkID, path, name, fileType, version, spriteCount, offset, size, paletteJSON, ddsInfoJSON)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

// InsertAlbumsBatch 批量插入 Albums
func (d *Database) InsertAlbumsBatch(npkID int64, albums []*AlbumBatchItem) error {
	if len(albums) == 0 {
		return nil
	}

	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	const batchSize = 100

	for i := 0; i < len(albums); i += batchSize {
		end := i + batchSize
		if end > len(albums) {
			end = len(albums)
		}

		batch := albums[i:end]
		if err := d.insertAlbumsBatchInternal(tx, npkID, batch); err != nil {
			return err
		}
	}

	return tx.Commit()
}

// insertAlbumsBatchInternal 内部批量插入实现
func (d *Database) insertAlbumsBatchInternal(tx *sql.Tx, npkID int64, albums []*AlbumBatchItem) error {
	if len(albums) == 0 {
		return nil
	}

	values := make([]string, 0, len(albums))
	args := make([]interface{}, 0, len(albums)*10)

	for _, album := range albums {
		values = append(values, "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
		args = append(args, npkID, album.Path, album.Name, album.FileType,
			album.Version, album.SpriteCount, album.Offset, album.Size,
			album.PaletteJSON, album.DDSInfoJSON)
	}

	sql := `INSERT INTO albums (npk_id, path, name, file_type, version, sprite_count, offset, size, palette_json, dds_info_json) VALUES ` +
		strings.Join(values, ", ")

	_, err := tx.Exec(sql, args...)
	return err
}

// UpdateAlbum 更新 Album 元数据
func (d *Database) UpdateAlbum(id int64, fileType, version, spriteCount int, offset, size int64, paletteJSON, ddsInfoJSON string) error {
	_, err := d.db.Exec(`
		UPDATE albums 
		SET file_type = ?, version = ?, sprite_count = ?, offset = ?, size = ?, palette_json = ?, dds_info_json = ?, updated_at = ?
		WHERE id = ?
	`, fileType, version, spriteCount, offset, size, paletteJSON, ddsInfoJSON, time.Now(), id)
	return err
}

// UpdateAlbumSpriteInfo 更新 Album 的 sprite_count 和 version
func (d *Database) UpdateAlbumSpriteInfo(npkID int64, path string, version, spriteCount int) error {
	_, err := d.db.Exec(`
		UPDATE albums 
		SET version = ?, sprite_count = ?, updated_at = ?
		WHERE npk_id = ? AND path = ?
	`, version, spriteCount, time.Now(), npkID, path)
	return err
}

// GetAlbumsByNpkID 获取 NPK 的所有 Album
func (d *Database) GetAlbumsByNpkID(npkID int64) ([]*AlbumRecord, error) {
	rows, err := d.db.Query(`
		SELECT id, npk_id, path, name, file_type, version, sprite_count, offset, size, palette_json, dds_info_json, created_at
		FROM albums WHERE npk_id = ? ORDER BY path
	`, npkID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []*AlbumRecord
	for rows.Next() {
		record := &AlbumRecord{}
		err := rows.Scan(&record.ID, &record.NpkID, &record.Path, &record.Name, &record.FileType,
			&record.Version, &record.SpriteCount, &record.Offset, &record.Size, &record.PaletteJSON, &record.DDSInfoJSON, &record.CreatedAt)
		if err != nil {
			return nil, err
		}
		records = append(records, record)
	}
	return records, nil
}

// GetAlbumsByNpkIDs 批量获取 Albums（避免 N+1 查询）
func (d *Database) GetAlbumsByNpkIDs(npkIDs []int64) (map[int64][]*AlbumRecord, error) {
	if len(npkIDs) == 0 {
		return make(map[int64][]*AlbumRecord), nil
	}

	// 构建 IN 查询
	placeholders := make([]string, len(npkIDs))
	args := make([]interface{}, len(npkIDs))
	for i, id := range npkIDs {
		placeholders[i] = "?"
		args[i] = id
	}

	query := fmt.Sprintf(`
		SELECT id, npk_id, path, name, file_type, version, sprite_count, offset, size, palette_json, dds_info_json, created_at
		FROM albums WHERE npk_id IN (%s) ORDER BY npk_id, path
	`, strings.Join(placeholders, ","))

	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := make(map[int64][]*AlbumRecord)
	for _, id := range npkIDs {
		result[id] = []*AlbumRecord{}
	}

	for rows.Next() {
		record := &AlbumRecord{}
		var createdAt string
		err := rows.Scan(
			&record.ID, &record.NpkID, &record.Path, &record.Name, &record.FileType,
			&record.Version, &record.SpriteCount, &record.Offset, &record.Size,
			&record.PaletteJSON, &record.DDSInfoJSON, &createdAt,
		)
		if err != nil {
			return nil, err
		}
		result[record.NpkID] = append(result[record.NpkID], record)
	}

	return result, nil
}

// GetAlbumByPath 根据路径获取 Album
func (d *Database) GetAlbumByPath(npkID int64, path string) (*AlbumRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, npk_id, path, name, file_type, version, sprite_count, offset, size, palette_json, dds_info_json, created_at
		FROM albums WHERE npk_id = ? AND path = ?
	`, npkID, path)

	record := &AlbumRecord{}
	var createdAt string
	err := row.Scan(
		&record.ID, &record.NpkID, &record.Path, &record.Name,
		&record.FileType, &record.Version, &record.SpriteCount,
		&record.Offset, &record.Size, &record.PaletteJSON, &record.DDSInfoJSON,
		&createdAt,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	record.CreatedAt, _ = time.Parse(time.RFC3339, createdAt)
	return record, nil
}

// FindAlbumByPath 通过 album 路径查找（不依赖 npkID，一次 SQL 查询）
func (d *Database) FindAlbumByPath(albumPath string) (*NpkFileRecord, *AlbumRecord, error) {
	// 尝试多种匹配策略

	// 策略 1：精确匹配
	npk, album, err := d.findAlbumByPathExact(albumPath)
	if err == nil && npk != nil {
		return npk, album, nil
	}

	// 策略 2：添加 sprite/ 前缀
	if !strings.HasPrefix(albumPath, "sprite/") {
		npk, album, err = d.findAlbumByPathExact("sprite/" + albumPath)
		if err == nil && npk != nil {
			return npk, album, nil
		}
	}

	// 策略 3：移除 sprite/ 前缀
	trimmed := strings.TrimPrefix(albumPath, "sprite/")
	if trimmed != albumPath {
		npk, album, err = d.findAlbumByPathExact(trimmed)
		if err == nil && npk != nil {
			return npk, album, nil
		}
	}

	// 策略 4：大小写不敏感匹配
	albumPathLower := strings.ToLower(albumPath)
	npk, album, err = d.findAlbumByPathCaseInsensitive(albumPathLower)
	if err == nil && npk != nil {
		return npk, album, nil
	}

	// 策略 5：移除 sprite/ + 大小写不敏感
	trimmedLower := strings.ToLower(trimmed)
	if trimmedLower != albumPathLower {
		npk, album, err = d.findAlbumByPathCaseInsensitive(trimmedLower)
		if err == nil && npk != nil {
			return npk, album, nil
		}
	}

	// 策略 6：处理大写 Map/ 前缀转为 sprite/ + 小写
	// 例如: "Map/Town/SilverCrown/Far.img" → "sprite/map/town/silvercrown/far.img"
	if strings.HasPrefix(albumPathLower, "map/") {
		convertedPath := "sprite/" + strings.Replace(albumPathLower, "\\", "/", -1)
		npk, album, err = d.findAlbumByPathCaseInsensitive(convertedPath)
		if err == nil && npk != nil {
			return npk, album, nil
		}

		// 策略 7：只转前缀，不转大小写
		convertedPath2 := "sprite/" + strings.Replace(albumPath, "\\", "/", 1)
		npk, album, err = d.findAlbumByPathCaseInsensitive(convertedPath2)
		if err == nil && npk != nil {
			return npk, album, nil
		}
	}

	return nil, nil, nil
}

func (d *Database) findAlbumByPathExact(albumPath string) (*NpkFileRecord, *AlbumRecord, error) {
	row := d.db.QueryRow(`
		SELECT n.id, n.name, n.path, n.size, n.img_count, n.sha256_hash, n.format_type, n.encryption_verified, n.modified_at,
		       a.id, a.npk_id, a.path, a.name, a.file_type, a.version, a.sprite_count, a.offset, a.size, a.palette_json, a.dds_info_json
		FROM albums a
		JOIN npk_files n ON a.npk_id = n.id
		WHERE a.path = ?
	`, albumPath)

	npk := &NpkFileRecord{}
	album := &AlbumRecord{}
	var npkModifiedAt string

	err := row.Scan(
		&npk.ID, &npk.Name, &npk.Path, &npk.Size, &npk.ImgCount, &npk.SHA256Hash, &npk.FormatType, &npk.EncryptionVerified, &npkModifiedAt,
		&album.ID, &album.NpkID, &album.Path, &album.Name, &album.FileType, &album.Version, &album.SpriteCount, &album.Offset, &album.Size, &album.PaletteJSON, &album.DDSInfoJSON,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil, nil
		}
		return nil, nil, err
	}
	npk.ModifiedAt, _ = time.Parse(time.RFC3339, npkModifiedAt)
	return npk, album, nil
}

func (d *Database) findAlbumByPathCaseInsensitive(albumPathLower string) (*NpkFileRecord, *AlbumRecord, error) {
	row := d.db.QueryRow(`
		SELECT n.id, n.name, n.path, n.size, n.img_count, n.sha256_hash, n.format_type, n.encryption_verified, n.modified_at,
		       a.id, a.npk_id, a.path, a.name, a.file_type, a.version, a.sprite_count, a.offset, a.size, a.palette_json, a.dds_info_json
		FROM albums a
		JOIN npk_files n ON a.npk_id = n.id
		WHERE LOWER(a.path) = ?
	`, albumPathLower)

	npk := &NpkFileRecord{}
	album := &AlbumRecord{}
	var npkModifiedAt string

	err := row.Scan(
		&npk.ID, &npk.Name, &npk.Path, &npk.Size, &npk.ImgCount, &npk.SHA256Hash, &npk.FormatType, &npk.EncryptionVerified, &npkModifiedAt,
		&album.ID, &album.NpkID, &album.Path, &album.Name, &album.FileType, &album.Version, &album.SpriteCount, &album.Offset, &album.Size, &album.PaletteJSON, &album.DDSInfoJSON,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil, nil
		}
		return nil, nil, err
	}
	npk.ModifiedAt, _ = time.Parse(time.RFC3339, npkModifiedAt)
	return npk, album, nil
}

// UpdateAlbumPath 更新 Album 路径和名称
func (d *Database) UpdateAlbumPath(npkID int64, oldPath, newPath, newName string) error {
	result, err := d.db.Exec(`
		UPDATE albums SET path = ?, name = ? WHERE npk_id = ? AND path = ?
	`, newPath, newName, npkID, oldPath)
	if err != nil {
		return err
	}
	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		return fmt.Errorf("Album 不存在: %s", oldPath)
	}
	return nil
}

// GetAlbumsWithSpritesByNpkID 获取 NPK 的所有 Album 及其 Sprites（避免 N+1）
func (d *Database) GetAlbumsWithSpritesByNpkID(npkID int64) (map[int64][]*SpriteRecord, error) {
	// 先获取所有 album IDs
	rows, err := d.db.Query(`SELECT id FROM albums WHERE npk_id = ?`, npkID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var albumIDs []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err == nil {
			albumIDs = append(albumIDs, id)
		}
	}

	if len(albumIDs) == 0 {
		return make(map[int64][]*SpriteRecord), nil
	}

	// 构建 IN 子句
	placeholders := make([]string, len(albumIDs))
	args := make([]interface{}, len(albumIDs))
	for i, id := range albumIDs {
		placeholders[i] = "?"
		args[i] = id
	}

	// 一次性查询所有 sprites
	query := fmt.Sprintf(`
		SELECT id, album_id, "index", type, compress_mode, width, height, x, y, frame_width, frame_height, is_link, target_index, data_size, created_at
		FROM sprites WHERE album_id IN (%s) ORDER BY album_id, "index"
	`, strings.Join(placeholders, ","))

	rows, err = d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := make(map[int64][]*SpriteRecord)
	for rows.Next() {
		record := &SpriteRecord{}
		var isLinkInt int
		err := rows.Scan(&record.ID, &record.AlbumID, &record.Index, &record.Type, &record.CompressMode,
			&record.Width, &record.Height, &record.X, &record.Y, &record.FrameWidth, &record.FrameHeight,
			&isLinkInt, &record.TargetIndex, &record.DataSize, &record.CreatedAt)
		if err != nil {
			continue
		}
		record.IsLink = isLinkInt == 1
		result[record.AlbumID] = append(result[record.AlbumID], record)
	}

	return result, nil
}

// DeleteAlbumWithRelations 删除 Album 及其所有关联数据
func (d *Database) DeleteAlbumWithRelations(albumID int64) error {
	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	// 删除 sprite_tags
	_, err = tx.Exec(`DELETE FROM sprite_tags WHERE sprite_id IN (SELECT id FROM sprites WHERE album_id = ?)`, albumID)
	if err != nil {
		return err
	}

	// 删除 sprites
	_, err = tx.Exec(`DELETE FROM sprites WHERE album_id = ?`, albumID)
	if err != nil {
		return err
	}

	// 删除 album_tags
	_, err = tx.Exec(`DELETE FROM album_tags WHERE album_id = ?`, albumID)
	if err != nil {
		return err
	}

	// 删除 album
	_, err = tx.Exec(`DELETE FROM albums WHERE id = ?`, albumID)
	if err != nil {
		return err
	}

	return tx.Commit()
}

// SearchAlbums SQL 级别搜索 albums（支持分页）
func (d *Database) SearchAlbums(query string, assetType string, page, pageSize int) ([]*SearchAlbumResult, int, error) {
	where := "WHERE 1=1"
	args := []interface{}{}

	if query != "" {
		where += " AND (a.path LIKE ? OR a.name LIKE ? OR n.name LIKE ?)"
		likeArg := "%" + query + "%"
		args = append(args, likeArg, likeArg, likeArg)
	}

	// 查询总数（只基于 albums 表）
	countSQL := `SELECT COUNT(*) FROM albums a JOIN npk_files n ON a.npk_id = n.id ` + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	// 查询分页数据（优先从 sprites 表统计真实数据，无数据时回退到 albums 表）
	querySQL := `
		SELECT 
			a.id, 
			a.npk_id, 
			a.path, 
			a.name, 
			CASE 
				WHEN COALESCE(sp.sprite_count, 0) > 0 THEN COALESCE(sp.type_count, 0)
				ELSE a.version
			END as version,
			CASE 
				WHEN COALESCE(sp.sprite_count, 0) > 0 THEN COALESCE(sp.sprite_count, 0)
				ELSE a.sprite_count
			END as sprite_count,
			n.name
		FROM albums a 
		JOIN npk_files n ON a.npk_id = n.id
		LEFT JOIN (
			SELECT 
				album_id,
				COUNT(*) as sprite_count,
				MAX(type) as type_count
			FROM sprites 
			GROUP BY album_id
		) sp ON a.id = sp.album_id
		` + where + `
		ORDER BY a.path
		LIMIT ? OFFSET ?
	`
	offset := (page - 1) * pageSize
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var results []*SearchAlbumResult
	for rows.Next() {
		r := &SearchAlbumResult{}
		err := rows.Scan(&r.AlbumID, &r.NpkID, &r.AlbumPath, &r.AlbumName, &r.Version, &r.SpriteCount, &r.NpkName)
		if err != nil {
			continue
		}
		results = append(results, r)
	}

	return results, total, nil
}

// GetAllAlbumsWithNpkName 获取所有 Album（含 NPK 名称）
func (d *Database) GetAllAlbumsWithNpkName() ([]*SearchAlbumResult, error) {
	rows, err := d.db.Query(`
		SELECT a.id, a.npk_id, n.name, a.path, a.name, a.version, a.sprite_count
		FROM albums a JOIN npk_files n ON a.npk_id = n.id
		ORDER BY n.name, a.path
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var results []*SearchAlbumResult
	for rows.Next() {
		r := &SearchAlbumResult{}
		err := rows.Scan(&r.AlbumID, &r.NpkID, &r.NpkName, &r.AlbumPath, &r.AlbumName, &r.Version, &r.SpriteCount)
		if err != nil {
			continue
		}
		results = append(results, r)
	}

	return results, nil
}

// GetDuplicateAlbums 获取重复的 Album（按 path 分组，返回出现次数 > 1 的）
func (d *Database) GetDuplicateAlbums() ([]*SearchAlbumResult, error) {
	rows, err := d.db.Query(`
		SELECT a.id, a.npk_id, n.name, a.path, a.name, a.version, a.sprite_count
		FROM albums a
		JOIN npk_files n ON a.npk_id = n.id
		WHERE a.path IN (
			SELECT path FROM albums GROUP BY path HAVING COUNT(*) > 1
		)
		ORDER BY a.path, n.name
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var results []*SearchAlbumResult
	for rows.Next() {
		r := &SearchAlbumResult{}
		err := rows.Scan(&r.AlbumID, &r.NpkID, &r.NpkName, &r.AlbumPath, &r.AlbumName, &r.Version, &r.SpriteCount)
		if err != nil {
			continue
		}
		results = append(results, r)
	}

	return results, nil
}
