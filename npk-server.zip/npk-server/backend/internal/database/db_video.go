package database

import (
	"database/sql"
	"fmt"
	"time"
)

// VideoRecord 视频记录
type VideoRecord struct {
	ID          int64     `json:"id"`
	Name        string    `json:"name"`
	Path        string    `json:"path"`
	DirPath     string    `json:"dir_path"`
	Size        int64     `json:"size"`
	Format      string    `json:"format"`
	IsEncrypted bool      `json:"is_encrypted"`
	Width       int       `json:"width"`
	Height      int       `json:"height"`
	FrameCount  int       `json:"frame_count"`
	AudioCount  int       `json:"audio_count"`
	FPS         float64   `json:"fps"`
	Duration    float64   `json:"duration"`
	SHA256Hash  string    `json:"sha256_hash"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// VideoStats 视频统计信息
type VideoStats struct {
	TotalCount    int   `json:"total_count"`
	TotalSize     int64 `json:"total_size"`
	EncryptedCount int  `json:"encrypted_count"`
	TotalDuration float64 `json:"total_duration"`
}

// initVideoTable 初始化视频表
func (d *Database) initVideoTable() error {
	tables := []string{
		`CREATE TABLE IF NOT EXISTS videos (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			path TEXT NOT NULL UNIQUE,
			dir_path TEXT NOT NULL,
			size INTEGER NOT NULL DEFAULT 0,
			format TEXT NOT NULL DEFAULT '',
			is_encrypted INTEGER NOT NULL DEFAULT 0,
			width INTEGER DEFAULT 0,
			height INTEGER DEFAULT 0,
			frame_count INTEGER DEFAULT 0,
			audio_count INTEGER DEFAULT 0,
			fps REAL DEFAULT 0,
			duration REAL DEFAULT 0,
			sha256_hash TEXT DEFAULT '',
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,
		// 索引
		`CREATE INDEX IF NOT EXISTS idx_videos_path ON videos(path)`,
		`CREATE INDEX IF NOT EXISTS idx_videos_dir_path ON videos(dir_path)`,
		`CREATE INDEX IF NOT EXISTS idx_videos_name ON videos(name)`,
		`CREATE INDEX IF NOT EXISTS idx_videos_format ON videos(format)`,
		`CREATE INDEX IF NOT EXISTS idx_videos_is_encrypted ON videos(is_encrypted)`,
	}

	for _, table := range tables {
		if _, err := d.db.Exec(table); err != nil {
			return fmt.Errorf("创建视频表失败: %w", err)
		}
	}

	return nil
}

// scanVideoRow 从行数据扫描到 VideoRecord
func scanVideoRow(row *sql.Row) (*VideoRecord, error) {
	record := &VideoRecord{}
	var encryptedInt int
	err := row.Scan(
		&record.ID, &record.Name, &record.Path, &record.DirPath,
		&record.Size, &record.Format, &encryptedInt,
		&record.Width, &record.Height, &record.FrameCount, &record.AudioCount,
		&record.FPS, &record.Duration, &record.SHA256Hash,
		&record.CreatedAt, &record.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	record.IsEncrypted = encryptedInt == 1
	return record, nil
}

// scanVideoRows 从多行数据扫描到 VideoRecord 列表
func scanVideoRows(rows *sql.Rows) ([]*VideoRecord, error) {
	var records []*VideoRecord
	for rows.Next() {
		record := &VideoRecord{}
		var encryptedInt int
		err := rows.Scan(
			&record.ID, &record.Name, &record.Path, &record.DirPath,
			&record.Size, &record.Format, &encryptedInt,
			&record.Width, &record.Height, &record.FrameCount, &record.AudioCount,
			&record.FPS, &record.Duration, &record.SHA256Hash,
			&record.CreatedAt, &record.UpdatedAt,
		)
		if err != nil {
			continue
		}
		record.IsEncrypted = encryptedInt == 1
		records = append(records, record)
	}
	return records, nil
}

// InsertVideo 插入视频记录
func (d *Database) InsertVideo(v *VideoRecord) (int64, error) {
	encryptedInt := 0
	if v.IsEncrypted {
		encryptedInt = 1
	}

	result, err := d.db.Exec(`
		INSERT INTO videos (name, path, dir_path, size, format, is_encrypted, width, height, frame_count, audio_count, fps, duration, sha256_hash)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, v.Name, v.Path, v.DirPath, v.Size, v.Format, encryptedInt,
		v.Width, v.Height, v.FrameCount, v.AudioCount, v.FPS, v.Duration, v.SHA256Hash)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

// UpdateVideo 更新视频记录
func (d *Database) UpdateVideo(v *VideoRecord) error {
	encryptedInt := 0
	if v.IsEncrypted {
		encryptedInt = 1
	}

	_, err := d.db.Exec(`
		UPDATE videos
		SET name = ?, dir_path = ?, size = ?, format = ?, is_encrypted = ?,
		    width = ?, height = ?, frame_count = ?, audio_count = ?,
		    fps = ?, duration = ?, sha256_hash = ?, updated_at = ?
		WHERE id = ?
	`, v.Name, v.DirPath, v.Size, v.Format, encryptedInt,
		v.Width, v.Height, v.FrameCount, v.AudioCount,
		v.FPS, v.Duration, v.SHA256Hash, time.Now(), v.ID)
	return err
}

// DeleteVideo 删除视频记录
func (d *Database) DeleteVideo(id int64) error {
	_, err := d.db.Exec(`DELETE FROM videos WHERE id = ?`, id)
	return err
}

// GetVideoByID 根据 ID 获取视频记录
func (d *Database) GetVideoByID(id int64) (*VideoRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, dir_path, size, format, is_encrypted,
		       width, height, frame_count, audio_count, fps, duration, sha256_hash,
		       created_at, updated_at
		FROM videos WHERE id = ?
	`, id)
	return scanVideoRow(row)
}

// GetVideoByPath 根据路径获取视频记录
func (d *Database) GetVideoByPath(path string) (*VideoRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, dir_path, size, format, is_encrypted,
		       width, height, frame_count, audio_count, fps, duration, sha256_hash,
		       created_at, updated_at
		FROM videos WHERE path = ?
	`, path)
	record, err := scanVideoRow(row)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	return record, nil
}

// ListVideos 分页列出视频记录
func (d *Database) ListVideos(query string, page, pageSize int) ([]*VideoRecord, int, error) {
	if page < 1 {
		page = 1
	}
	// pageSize 上限设为 100000，超过则使用 100000（全量获取）
	if pageSize < 1 {
		pageSize = 50
	}
	if pageSize > 100000 {
		pageSize = 100000
	}
	offset := (page - 1) * pageSize

	// 构建 WHERE 条件
	where := ""
	args := []interface{}{}
	if query != "" {
		where = "WHERE name LIKE ?"
		args = append(args, "%"+query+"%")
	}

	// 查询总数
	countSQL := "SELECT COUNT(*) FROM videos " + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	// 查询分页数据
	querySQL := `
		SELECT id, name, path, dir_path, size, format, is_encrypted,
		       width, height, frame_count, audio_count, fps, duration, sha256_hash,
		       created_at, updated_at
		FROM videos ` + where + `
		ORDER BY name
		LIMIT ? OFFSET ?
	`
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	records, err := scanVideoRows(rows)
	if err != nil {
		return nil, 0, err
	}
	return records, total, nil
}

// ListVideosByDir 根据目录路径列出视频记录
func (d *Database) ListVideosByDir(dirPath string) ([]*VideoRecord, error) {
	rows, err := d.db.Query(`
		SELECT id, name, path, dir_path, size, format, is_encrypted,
		       width, height, frame_count, audio_count, fps, duration, sha256_hash,
		       created_at, updated_at
		FROM videos WHERE dir_path = ?
		ORDER BY name
	`, dirPath)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	return scanVideoRows(rows)
}

// GetVideoStats 获取视频统计信息
func (d *Database) GetVideoStats() (*VideoStats, error) {
	stats := &VideoStats{}

	err := d.db.QueryRow(`
		SELECT COUNT(*), COALESCE(SUM(size), 0), SUM(CASE WHEN is_encrypted = 1 THEN 1 ELSE 0 END), COALESCE(SUM(duration), 0)
		FROM videos
	`).Scan(&stats.TotalCount, &stats.TotalSize, &stats.EncryptedCount, &stats.TotalDuration)
	if err != nil {
		return nil, err
	}

	return stats, nil
}

// DeleteVideosByDir 删除某目录下所有视频记录，返回删除的行数
func (d *Database) DeleteVideosByDir(dirPath string) (int64, error) {
	result, err := d.db.Exec(`DELETE FROM videos WHERE dir_path = ?`, dirPath)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

// GetVideosByIDs 根据 ID 列表获取视频记录
func (d *Database) GetVideosByIDs(ids []int64) ([]*VideoRecord, error) {
	if len(ids) == 0 {
		return []*VideoRecord{}, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`
		SELECT id, name, path, dir_path, size, format, is_encrypted,
		       width, height, frame_count, audio_count, fps, duration, sha256_hash,
		       created_at, updated_at
		FROM videos WHERE id IN (%s)
	`, phs)
	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanVideoRows(rows)
}

// DeleteVideosByIDs 根据 ID 列表删除视频记录，返回删除的行数
func (d *Database) DeleteVideosByIDs(ids []int64) (int64, error) {
	if len(ids) == 0 {
		return 0, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`DELETE FROM videos WHERE id IN (%s)`, phs)
	result, err := d.db.Exec(query, args...)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

// SearchVideos 搜索视频（支持按名称、格式、是否加密筛选，支持分页）
func (d *Database) SearchVideos(query string, format string, encryptedOnly bool, page, pageSize int) ([]*VideoRecord, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 200 {
		pageSize = 50
	}
	offset := (page - 1) * pageSize

	// 构建 WHERE 条件
	where := "WHERE 1=1"
	args := []interface{}{}

	if query != "" {
		where += " AND (name LIKE ? OR path LIKE ?)"
		likeArg := "%" + query + "%"
		args = append(args, likeArg, likeArg)
	}

	if format != "" {
		where += " AND format = ?"
		args = append(args, format)
	}

	if encryptedOnly {
		where += " AND is_encrypted = 1"
	}

	// 查询总数
	countSQL := "SELECT COUNT(*) FROM videos " + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	// 查询分页数据
	querySQL := `
		SELECT id, name, path, dir_path, size, format, is_encrypted,
		       width, height, frame_count, audio_count, fps, duration, sha256_hash,
		       created_at, updated_at
		FROM videos ` + where + `
		ORDER BY name
		LIMIT ? OFFSET ?
	`
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	records, err := scanVideoRows(rows)
	if err != nil {
		return nil, 0, err
	}
	return records, total, nil
}
