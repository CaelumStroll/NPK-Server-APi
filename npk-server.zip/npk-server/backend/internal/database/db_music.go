package database

import (
	"database/sql"
	"fmt"
	"time"
)

// MusicRecord 音乐记录
type MusicRecord struct {
	ID         int64     `json:"id"`
	Name       string    `json:"name"`
	Path       string    `json:"path"`
	DirPath    string    `json:"dir_path"`
	Size       int64     `json:"size"`
	Format     string    `json:"format"`
	Duration   float64   `json:"duration"`
	SampleRate int       `json:"sample_rate"`
	Channels   int       `json:"channels"`
	Bitrate    int       `json:"bitrate"`
	SHA256Hash string    `json:"sha256_hash"`
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
}

// MusicStats 音乐统计信息
type MusicStats struct {
	TotalCount    int     `json:"total_count"`
	TotalSize     int64   `json:"total_size"`
	TotalDuration float64 `json:"total_duration"`
}

func initMusicTable(db *sql.DB) error {
	tables := []string{
		`CREATE TABLE IF NOT EXISTS music (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			path TEXT NOT NULL UNIQUE,
			dir_path TEXT NOT NULL,
			size INTEGER NOT NULL DEFAULT 0,
			format TEXT NOT NULL DEFAULT '',
			duration REAL DEFAULT 0,
			sample_rate INTEGER DEFAULT 0,
			channels INTEGER DEFAULT 0,
			bitrate INTEGER DEFAULT 0,
			sha256_hash TEXT DEFAULT '',
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)`,
		`CREATE INDEX IF NOT EXISTS idx_music_path ON music(path)`,
		`CREATE INDEX IF NOT EXISTS idx_music_dir_path ON music(dir_path)`,
		`CREATE INDEX IF NOT EXISTS idx_music_name ON music(name)`,
		`CREATE INDEX IF NOT EXISTS idx_music_format ON music(format)`,
	}

	for _, table := range tables {
		if _, err := db.Exec(table); err != nil {
			return fmt.Errorf("创建音乐表失败: %w", err)
		}
	}

	return nil
}

func scanMusicRow(row *sql.Row) (*MusicRecord, error) {
	record := &MusicRecord{}
	err := row.Scan(
		&record.ID, &record.Name, &record.Path, &record.DirPath,
		&record.Size, &record.Format, &record.Duration,
		&record.SampleRate, &record.Channels, &record.Bitrate,
		&record.SHA256Hash, &record.CreatedAt, &record.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}
	return record, nil
}

func scanMusicRows(rows *sql.Rows) ([]*MusicRecord, error) {
	var records []*MusicRecord
	for rows.Next() {
		record := &MusicRecord{}
		err := rows.Scan(
			&record.ID, &record.Name, &record.Path, &record.DirPath,
			&record.Size, &record.Format, &record.Duration,
			&record.SampleRate, &record.Channels, &record.Bitrate,
			&record.SHA256Hash, &record.CreatedAt, &record.UpdatedAt,
		)
		if err != nil {
			continue
		}
		records = append(records, record)
	}
	return records, nil
}

func (d *Database) InsertMusic(m *MusicRecord) (int64, error) {
	result, err := d.db.Exec(`
		INSERT INTO music (name, path, dir_path, size, format, duration, sample_rate, channels, bitrate, sha256_hash)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, m.Name, m.Path, m.DirPath, m.Size, m.Format, m.Duration,
		m.SampleRate, m.Channels, m.Bitrate, m.SHA256Hash)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

func (d *Database) UpdateMusic(m *MusicRecord) error {
	_, err := d.db.Exec(`
		UPDATE music
		SET name = ?, dir_path = ?, size = ?, format = ?,
		    duration = ?, sample_rate = ?, channels = ?, bitrate = ?,
		    sha256_hash = ?, updated_at = ?
		WHERE id = ?
	`, m.Name, m.DirPath, m.Size, m.Format,
		m.Duration, m.SampleRate, m.Channels, m.Bitrate,
		m.SHA256Hash, time.Now(), m.ID)
	return err
}

func (d *Database) DeleteMusic(id int64) error {
	_, err := d.db.Exec(`DELETE FROM music WHERE id = ?`, id)
	return err
}

func (d *Database) GetMusicByID(id int64) (*MusicRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, dir_path, size, format, duration,
		       sample_rate, channels, bitrate, sha256_hash,
		       created_at, updated_at
		FROM music WHERE id = ?
	`, id)
	return scanMusicRow(row)
}

func (d *Database) GetMusicByPath(path string) (*MusicRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, dir_path, size, format, duration,
		       sample_rate, channels, bitrate, sha256_hash,
		       created_at, updated_at
		FROM music WHERE path = ?
	`, path)
	record, err := scanMusicRow(row)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	return record, nil
}

func (d *Database) ListMusic(query string, page, pageSize int) ([]*MusicRecord, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 50
	}
	if pageSize > 100000 {
		pageSize = 100000
	}
	offset := (page - 1) * pageSize

	where := ""
	args := []interface{}{}
	if query != "" {
		where = "WHERE name LIKE ? COLLATE NOCASE"
		args = append(args, "%"+query+"%")
	}

	countSQL := "SELECT COUNT(*) FROM music " + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	querySQL := `
		SELECT id, name, path, dir_path, size, format, duration,
		       sample_rate, channels, bitrate, sha256_hash,
		       created_at, updated_at
		FROM music ` + where + `
		ORDER BY name
		LIMIT ? OFFSET ?
	`
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	records, err := scanMusicRows(rows)
	if err != nil {
		return nil, 0, err
	}
	return records, total, nil
}

func (d *Database) GetMusicStats() (*MusicStats, error) {
	stats := &MusicStats{}

	err := d.db.QueryRow(`
		SELECT COUNT(*), COALESCE(SUM(size), 0), COALESCE(SUM(duration), 0)
		FROM music
	`).Scan(&stats.TotalCount, &stats.TotalSize, &stats.TotalDuration)
	if err != nil {
		return nil, err
	}

	return stats, nil
}

func (d *Database) DeleteMusicByDir(dirPath string) (int64, error) {
	result, err := d.db.Exec(`DELETE FROM music WHERE dir_path = ?`, dirPath)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

func (d *Database) GetMusicByIDs(ids []int64) ([]*MusicRecord, error) {
	if len(ids) == 0 {
		return []*MusicRecord{}, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`
		SELECT id, name, path, dir_path, size, format, duration,
		       sample_rate, channels, bitrate, sha256_hash,
		       created_at, updated_at
		FROM music WHERE id IN (%s)
	`, phs)
	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanMusicRows(rows)
}

func (d *Database) DeleteMusicByIDs(ids []int64) (int64, error) {
	if len(ids) == 0 {
		return 0, nil
	}
	phs, args := BuildInClause(ids)
	query := fmt.Sprintf(`DELETE FROM music WHERE id IN (%s)`, phs)
	result, err := d.db.Exec(query, args...)
	if err != nil {
		return 0, err
	}
	return result.RowsAffected()
}

func (d *Database) SearchMusic(query string, format string, page, pageSize int) ([]*MusicRecord, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100000 {
		pageSize = 50
	}
	offset := (page - 1) * pageSize

	where := "WHERE 1=1"
	args := []interface{}{}

	if query != "" {
		where += " AND (name LIKE ? OR path LIKE ?)"
		likeArg := "%" + query + "%"
		args = append(args, likeArg, likeArg)
	}

	if format != "" {
		where += " AND format = ?"
		args = append(args, format)
	}

	countSQL := "SELECT COUNT(*) FROM music " + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	querySQL := `
		SELECT id, name, path, dir_path, size, format, duration,
		       sample_rate, channels, bitrate, sha256_hash,
		       created_at, updated_at
		FROM music ` + where + `
		ORDER BY name
		LIMIT ? OFFSET ?
	`
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	records, err := scanMusicRows(rows)
	if err != nil {
		return nil, 0, err
	}
	return records, total, nil
}
