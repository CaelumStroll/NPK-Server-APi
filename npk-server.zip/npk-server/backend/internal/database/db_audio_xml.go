package database

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"log"
	"os"
	"regexp"
	"strings"

	"database/sql"
)

// AudioXmlEntry 音频 XML 条目（数据库行）
type AudioXmlEntry struct {
	ID         int64  `json:"id"`
	EntryType  string `json:"type"`
	EntryID    string `json:"entry_id"`
	File       string `json:"file,omitempty"`
	Attributes string `json:"attributes,omitempty"` // JSON
	SortOrder  int    `json:"sort_order"`
}

// AudioXmlItem 音频 XML 子条目
type AudioXmlItem struct {
	ID            int64  `json:"id"`
	EntryID       int64  `json:"entry_id"` // FK → audio_entries.id
	Tag           string `json:"tag"`
	Prob          string `json:"prob,omitempty"`
	Delay         string `json:"delay,omitempty"`
	DelayRange    string `json:"delay_range,omitempty"`
	LoopDelay     string `json:"loop_delay,omitempty"`
	LoopDelayRange string `json:"loop_delay_range,omitempty"`
	SortOrder     int    `json:"sort_order"`
}

// AudioXmlStats XML 统计
type AudioXmlStats struct {
	EffectCount  int `json:"effect_count"`
	RandomCount  int `json:"random_count"`
	GroupCount   int `json:"group_count"`
	MusicCount   int `json:"music_count"`
	AmbientCount int `json:"ambient_count"`
}

// AudioXmlRecord 前端返回的条目结构
type AudioXmlRecord struct {
	Type        string            `json:"type"`
	ID          string            `json:"id"`
	File        string            `json:"file,omitempty"`
	FileMissing bool              `json:"file_missing,omitempty"`
	Attributes  map[string]string `json:"attributes,omitempty"`
	Items       []AudioXmlItemRecord `json:"items,omitempty"`
}

// AudioXmlItemRecord 前端返回的子条目
type AudioXmlItemRecord struct {
	Tag            string `json:"tag"`
	Prob           string `json:"prob,omitempty"`
	Delay          string `json:"delay,omitempty"`
	DelayRange     string `json:"delay_range,omitempty"`
	LoopDelay      string `json:"loop_delay,omitempty"`
	LoopDelayRange string `json:"loop_delay_range,omitempty"`
	File           string `json:"file,omitempty"` // 解析后的文件路径（仅 GROUP 查询时填充）
}

func initAudioXmlTable(db *sql.DB) error {
	tables := []string{
		`CREATE TABLE IF NOT EXISTS audio_entries (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			entry_type TEXT NOT NULL,
			entry_id TEXT NOT NULL,
			file TEXT DEFAULT '',
			attributes TEXT DEFAULT '{}',
			sort_order INTEGER DEFAULT 0
		)`,
		`CREATE TABLE IF NOT EXISTS audio_items (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			entry_id INTEGER NOT NULL,
			tag TEXT NOT NULL,
			prob TEXT DEFAULT '',
			delay TEXT DEFAULT '',
			delay_range TEXT DEFAULT '',
			loop_delay TEXT DEFAULT '',
			loop_delay_range TEXT DEFAULT '',
			sort_order INTEGER DEFAULT 0,
			FOREIGN KEY (entry_id) REFERENCES audio_entries(id) ON DELETE CASCADE
		)`,
		`CREATE INDEX IF NOT EXISTS idx_audio_entries_type ON audio_entries(entry_type)`,
		`CREATE INDEX IF NOT EXISTS idx_audio_entries_eid ON audio_entries(entry_id)`,
		`CREATE INDEX IF NOT EXISTS idx_audio_entries_type_eid ON audio_entries(entry_type, entry_id)`,
		`CREATE INDEX IF NOT EXISTS idx_audio_items_entry ON audio_items(entry_id)`,
	}
	for _, t := range tables {
		if _, err := db.Exec(t); err != nil {
			return fmt.Errorf("初始化 audio_xml 表失败: %w", err)
		}
	}

	// 迁移：移除旧 UNIQUE 约束（SQLite 不支持 DROP CONSTRAINT，需要重建表）
	var hasUnique int
	db.QueryRow(`SELECT COUNT(*) FROM pragma_index_list('audio_entries') WHERE name LIKE '%autoindex%' AND "unique"=1`).Scan(&hasUnique)
	if hasUnique > 0 {
		tx, _ := db.Begin()
		if tx != nil {
			tx.Exec(`CREATE TABLE IF NOT EXISTS audio_entries_new (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				entry_type TEXT NOT NULL,
				entry_id TEXT NOT NULL,
				file TEXT DEFAULT '',
				attributes TEXT DEFAULT '{}',
				sort_order INTEGER DEFAULT 0
			)`)
			tx.Exec(`INSERT INTO audio_entries_new SELECT * FROM audio_entries`)
			tx.Exec(`DROP TABLE audio_entries`)
			tx.Exec(`ALTER TABLE audio_entries_new RENAME TO audio_entries`)
			tx.Exec(`CREATE INDEX IF NOT EXISTS idx_audio_entries_type ON audio_entries(entry_type)`)
			tx.Exec(`CREATE INDEX IF NOT EXISTS idx_audio_entries_eid ON audio_entries(entry_id)`)
			tx.Exec(`CREATE INDEX IF NOT EXISTS idx_audio_entries_type_eid ON audio_entries(entry_type, entry_id)`)
			tx.Exec(`CREATE INDEX IF NOT EXISTS idx_audio_items_entry ON audio_items(entry_id)`)
			tx.Commit()
		}
	}
	return nil
}

// ==================== Import from XML ====================

// ImportFromXML 从 audio.xml 文件导入数据
func (d *Database) ImportAudioXml(xmlPath string) (*AudioXmlStats, error) {
	data, err := os.ReadFile(xmlPath)
	if err != nil {
		return nil, fmt.Errorf("读取失败: %w", err)
	}

	// 按原始顺序解析，逐 token 读取
	decoder := xml.NewDecoder(strings.NewReader(string(data)))
	tx, err := d.db.Begin()
	if err != nil {
		return nil, fmt.Errorf("开始事务失败: %w", err)
	}
	defer tx.Rollback()

	tx.Exec("PRAGMA foreign_keys = ON")
	if _, err := tx.Exec("DELETE FROM audio_items"); err != nil {
		return nil, fmt.Errorf("清空旧数据失败: %w", err)
	}
	if _, err := tx.Exec("DELETE FROM audio_entries"); err != nil {
		return nil, fmt.Errorf("清空旧数据失败: %w", err)
	}

	stats := &AudioXmlStats{}
	sort := 0
	var currentEntry *struct {
		typ   string
		id    string
		file  string
		attrs map[string]string
		items []AudioXmlItemRecord
	}

	for {
		token, tokErr := decoder.Token()
		if tokErr != nil {
			break
		}

		switch t := token.(type) {
		case xml.StartElement:
			name := t.Name.Local
			switch name {
			case "EFFECT", "MUSIC", "AMBIENT", "RANDOM", "GROUP":
				currentEntry = &struct {
					typ   string
					id    string
					file  string
					attrs map[string]string
					items []AudioXmlItemRecord
				}{typ: name, attrs: map[string]string{}}
				for _, attr := range t.Attr {
					n := attr.Name.Local
					v := attr.Value
					if n == "ID" {
						currentEntry.id = v
					} else if n == "FILE" {
						currentEntry.file = v
					} else {
						currentEntry.attrs[strings.ToLower(n)] = v
					}
				}
			case "ITEM":
				if currentEntry != nil {
					it := AudioXmlItemRecord{}
					for _, attr := range t.Attr {
						switch attr.Name.Local {
						case "TAG":
							it.Tag = attr.Value
						case "PROB":
							it.Prob = attr.Value
						case "DELAY":
							it.Delay = attr.Value
						case "DELAY_RANGE":
							it.DelayRange = attr.Value
						case "LOOP_DELAY":
							it.LoopDelay = attr.Value
						case "LOOP_DELAY_RANGE":
							it.LoopDelayRange = attr.Value
						}
					}
					currentEntry.items = append(currentEntry.items, it)
				}
			}
		case xml.EndElement:
			name := t.Name.Local
			if currentEntry != nil && (name == "EFFECT" || name == "MUSIC" || name == "AMBIENT" || name == "RANDOM" || name == "GROUP") {
				attrsJSON, _ := json.Marshal(currentEntry.attrs)
				res, err := tx.Exec(
					`INSERT INTO audio_entries(entry_type,entry_id,file,attributes,sort_order) VALUES(?,?,?,?,?)`,
					currentEntry.typ, currentEntry.id, currentEntry.file, string(attrsJSON), sort,
				)
				if err == nil {
					entryID, _ := res.LastInsertId()
					for i, it := range currentEntry.items {
						tx.Exec(
							`INSERT INTO audio_items(entry_id,tag,prob,delay,delay_range,loop_delay,loop_delay_range,sort_order) VALUES(?,?,?,?,?,?,?,?)`,
							entryID, it.Tag, it.Prob, it.Delay, it.DelayRange, it.LoopDelay, it.LoopDelayRange, i,
						)
					}
				}
				switch currentEntry.typ {
				case "EFFECT":
					stats.EffectCount++
				case "RANDOM":
					stats.RandomCount++
				case "GROUP":
					stats.GroupCount++
				case "MUSIC":
					stats.MusicCount++
				case "AMBIENT":
					stats.AmbientCount++
				}
				sort++
				currentEntry = nil
			}
		}
	}

	return stats, tx.Commit()
}

// ==================== Export to XML ====================

func (d *Database) ExportAudioXml(xmlPath string) error {
	records, _, _, err := d.ListAudioXml("", "all", 1, -1)
	if err != nil {
		return fmt.Errorf("查询失败: %w", err)
	}
	if len(records) == 0 {
		return fmt.Errorf("没有数据")
	}

	// 读取原始文件获取根元素名和头部
	rootName, headerLines := "AudioTagDatabase", ""
	if data, err := os.ReadFile(xmlPath); err == nil {
		rootName = extractRootName(data)
		headerLines = extractHeader(data)
	}

	// 按原始 sort_order 顺序逐条序列化
	var buf strings.Builder
	if headerLines != "" {
		buf.WriteString(strings.ReplaceAll(headerLines, "\n", "\r\n"))
		buf.WriteString("\r\n")
	} else {
		buf.WriteString("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\"?>\r\n")
	}
	buf.WriteString("<" + rootName + ">\r\n")

	for _, r := range records {
		switch r.Type {
		case "EFFECT":
			writeEffectXML(&buf, r)
		case "RANDOM":
			writeRandomXML(&buf, r)
		case "GROUP":
			writeGroupXML(&buf, r)
		case "MUSIC":
			writeMusicXML(&buf, r)
		case "AMBIENT":
			writeAmbientXML(&buf, r)
		}
	}
	buf.WriteString("</" + rootName + ">\r\n")
	return os.WriteFile(xmlPath, []byte(buf.String()), 0644)
}

func attr(k, v string) string {
	if v == "" { return "" }
	return " " + k + "=\"" + v + "\""
}

func writeEffectXML(buf *strings.Builder, r *AudioXmlRecord) {
	e := EffectEntry{ID: r.ID, File: r.File}
	fillEffectAttrs(&e, r.Attributes)
	buf.WriteString("  <EFFECT")
	buf.WriteString(attr("DUPLICATE_LIMIT", e.DuplicateLimit))
	buf.WriteString(" FILE=\"" + e.File + "\"")
	buf.WriteString(" ID=\"" + e.ID + "\"")
	buf.WriteString(attr("VOLUME_ADJUST", e.VolumeAdjust))
	buf.WriteString(attr("PRIORITY", e.Priority))
	buf.WriteString(attr("LOOP_DELAY", e.LoopDelay))
	buf.WriteString(attr("LOOP_DELAY_RANGE", e.LoopDelayRange))
	buf.WriteString(attr("DELAY", e.Delay))
	buf.WriteString(attr("DELAY_RANGE", e.DelayRange))
	buf.WriteString(attr("SUBGROUP", e.SubGroup))
	buf.WriteString(" />\r\n")
}

func writeRandomXML(buf *strings.Builder, r *AudioXmlRecord) {
	e := RandomEntry{ID: r.ID}
	fillRandomAttrs(&e, r.Attributes)
	buf.WriteString("  <RANDOM")
	buf.WriteString(attr("ID", e.ID))
	buf.WriteString(attr("DUPLICATE_LIMIT", e.DuplicateLimit))
	buf.WriteString(attr("LOOP_DELAY", e.LoopDelay))
	buf.WriteString(attr("LOOP_DELAY_RANGE", e.LoopDelayRange))
	buf.WriteString(attr("DELAY", e.Delay))
	buf.WriteString(attr("DELAY_RANGE", e.DelayRange))
	buf.WriteString(">\r\n")
	for _, it := range r.Items {
		buf.WriteString("    <ITEM PROB=\"" + it.Prob + "\"")
		buf.WriteString(" TAG=\"" + it.Tag + "\"")
		buf.WriteString(" />\r\n")
	}
	buf.WriteString("  </RANDOM>\r\n")
}

func writeGroupXML(buf *strings.Builder, r *AudioXmlRecord) {
	buf.WriteString("  <GROUP")
	buf.WriteString(attr("ID", r.ID))
	buf.WriteString(">\r\n")
	for _, it := range r.Items {
		buf.WriteString("    <ITEM TAG=\"" + it.Tag + "\"")
		if it.Prob != "" { buf.WriteString(attr("PROB", it.Prob)) }
		buf.WriteString(attr("DELAY", it.Delay))
		buf.WriteString(attr("DELAY_RANGE", it.DelayRange))
		buf.WriteString(attr("LOOP_DELAY", it.LoopDelay))
		buf.WriteString(attr("LOOP_DELAY_RANGE", it.LoopDelayRange))
		buf.WriteString(" />\r\n")
	}
	buf.WriteString("  </GROUP>\r\n")
}

func writeMusicXML(buf *strings.Builder, r *AudioXmlRecord) {
	e := MusicEntry{ID: r.ID, File: r.File}
	fillMusicAttrs(&e, r.Attributes)
	buf.WriteString("  <MUSIC")
	buf.WriteString(" FILE=\"" + e.File + "\"")
	buf.WriteString(" ID=\"" + e.ID + "\"")
	buf.WriteString(attr("DUPLICATE_LIMIT", e.DuplicateLimit))
	buf.WriteString(attr("LOOP_DELAY", e.LoopDelay))
	buf.WriteString(attr("VOLUME_ADJUST", e.VolumeAdjust))
	buf.WriteString(" />\r\n")
}

func writeAmbientXML(buf *strings.Builder, r *AudioXmlRecord) {
	e := AmbientEntry{ID: r.ID, File: r.File}
	fillAmbientAttrs(&e, r.Attributes)
	buf.WriteString("  <AMBIENT")
	buf.WriteString(" FILE=\"" + e.File + "\"")
	buf.WriteString(" ID=\"" + e.ID + "\"")
	buf.WriteString(attr("DUPLICATE_LIMIT", e.DuplicateLimit))
	buf.WriteString(attr("LOOP_DELAY", e.LoopDelay))
	buf.WriteString(attr("VOLUME_ADJUST", e.VolumeAdjust))
	buf.WriteString(" />\r\n")
}

// ==================== CRUD ====================

// ListAudioXml 列出条目（带筛选）
func (d *Database) ListAudioXml(query, typeFilter string, page, pageSize int) ([]*AudioXmlRecord, int, *AudioXmlStats, error) {
	var stats AudioXmlStats
	d.db.QueryRow(`SELECT
		COALESCE(SUM(CASE WHEN entry_type='EFFECT' THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN entry_type='RANDOM' THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN entry_type='GROUP'  THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN entry_type='MUSIC'  THEN 1 ELSE 0 END),0),
		COALESCE(SUM(CASE WHEN entry_type='AMBIENT'THEN 1 ELSE 0 END),0)
	FROM audio_entries`).Scan(&stats.EffectCount, &stats.RandomCount, &stats.GroupCount, &stats.MusicCount, &stats.AmbientCount)

	args := []interface{}{}
	where := ""
	if typeFilter != "" && typeFilter != "all" {
		where = " WHERE entry_type = ?"
		args = append(args, typeFilter)
	}
	if query != "" {
		if where == "" {
			where = " WHERE (entry_id LIKE ? OR file LIKE ?)"
		} else {
			where += " AND (entry_id LIKE ? OR file LIKE ?)"
		}
		q := "%" + query + "%"
		args = append(args, q, q)
	}

	// count
	var total int
	d.db.QueryRow("SELECT COUNT(*) FROM audio_entries"+where, args...).Scan(&total)

	// query
	sql := "SELECT id, entry_type, entry_id, file, attributes, sort_order FROM audio_entries" + where + " ORDER BY sort_order"
	if pageSize > 0 {
		if page < 1 {
			page = 1
		}
		sql += " LIMIT ? OFFSET ?"
		args = append(args, pageSize, (page-1)*pageSize)
	}

	rows, err := d.db.Query(sql, args...)
	if err != nil {
		return nil, 0, nil, err
	}
	defer rows.Close()

	var records []*AudioXmlRecord
	var entryIDs []int64
	entryMap := make(map[int64]*AudioXmlRecord)
	for rows.Next() {
		var e AudioXmlEntry
		rows.Scan(&e.ID, &e.EntryType, &e.EntryID, &e.File, &e.Attributes, &e.SortOrder)

		r := &AudioXmlRecord{Type: e.EntryType, ID: e.EntryID, File: e.File}
		if e.Attributes != "" && e.Attributes != "{}" {
			json.Unmarshal([]byte(e.Attributes), &r.Attributes)
		}
		records = append(records, r)
		entryIDs = append(entryIDs, e.ID)
		entryMap[e.ID] = r
	}

	// 批量加载所有子条目（分批，避免 SQLite 变量上限 999）
	if len(entryIDs) > 0 {
		itemCount := 0
		for i := 0; i < len(entryIDs); i += 500 {
			end := i + 500
			if end > len(entryIDs) {
				end = len(entryIDs)
			}
			chunk := entryIDs[i:end]
			phs, args2 := BuildInClause(chunk)
			itemRows, _ := d.db.Query(`SELECT entry_id,tag,prob,delay,delay_range,loop_delay,loop_delay_range FROM audio_items WHERE entry_id IN (`+phs+`) ORDER BY sort_order`, args2...)
			if itemRows != nil {
				for itemRows.Next() {
					var eid int64
					var it AudioXmlItemRecord
					itemRows.Scan(&eid, &it.Tag, &it.Prob, &it.Delay, &it.DelayRange, &it.LoopDelay, &it.LoopDelayRange)
					if r, ok := entryMap[eid]; ok {
						r.Items = append(r.Items, it)
						itemCount++
					}
				}
				itemRows.Close()
			}
		}
		log.Printf("[ListAudioXml] 加载完成: %d items", itemCount)
	}
	return records, total, &stats, nil
}

// GetAudioXmlEntry 获取单个条目
func (d *Database) GetAudioXmlEntry(entryType, entryID string) (*AudioXmlRecord, error) {
	var e AudioXmlEntry
	var err error
	if entryType == "" {
		err = d.db.QueryRow("SELECT id,entry_type,entry_id,file,attributes,sort_order FROM audio_entries WHERE entry_id=? LIMIT 1",
			entryID).Scan(&e.ID, &e.EntryType, &e.EntryID, &e.File, &e.Attributes, &e.SortOrder)
	} else {
		err = d.db.QueryRow("SELECT id,entry_type,entry_id,file,attributes,sort_order FROM audio_entries WHERE entry_type=? AND entry_id=?",
			entryType, entryID).Scan(&e.ID, &e.EntryType, &e.EntryID, &e.File, &e.Attributes, &e.SortOrder)
	}
	if err != nil {
		return nil, err
	}
	r := &AudioXmlRecord{Type: e.EntryType, ID: e.EntryID, File: e.File}
	if e.Attributes != "" && e.Attributes != "{}" {
		json.Unmarshal([]byte(e.Attributes), &r.Attributes)
	}
	rows, _ := d.db.Query("SELECT tag,prob,delay,delay_range,loop_delay,loop_delay_range FROM audio_items WHERE entry_id=? ORDER BY sort_order", e.ID)
	if rows != nil {
		defer rows.Close()
		for rows.Next() {
			var it AudioXmlItemRecord
			rows.Scan(&it.Tag, &it.Prob, &it.Delay, &it.DelayRange, &it.LoopDelay, &it.LoopDelayRange)
			r.Items = append(r.Items, it)
		}
	}
	return r, nil
}

// UpsertAudioXmlEntry 插入或更新条目
func (d *Database) UpsertAudioXmlEntry(entry *AudioXmlRecord) error {
	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	attrs := "{}"
	if entry.Attributes != nil && len(entry.Attributes) > 0 {
		b, _ := json.Marshal(entry.Attributes)
		attrs = string(b)
	}

	// 获取最大 sort_order
	var maxSort int
	tx.QueryRow("SELECT COALESCE(MAX(sort_order),-1) FROM audio_entries").Scan(&maxSort)

	// 删除旧条目及其子条目
	var oldID int64
	tx.QueryRow("SELECT id FROM audio_entries WHERE entry_type=? AND entry_id=?", entry.Type, entry.ID).Scan(&oldID)
	if oldID > 0 {
		tx.Exec("DELETE FROM audio_items WHERE entry_id=?", oldID)
		tx.Exec("DELETE FROM audio_entries WHERE id=?", oldID)
	} else {
		maxSort++
	}

	// 插入条目
	res, err := tx.Exec(`INSERT INTO audio_entries(entry_type,entry_id,file,attributes,sort_order) VALUES(?,?,?,?,?)`,
		entry.Type, entry.ID, entry.File, attrs, maxSort)
	if err != nil {
		return err
	}
	entryID, _ := res.LastInsertId()

	// 插入子条目
	for i, it := range entry.Items {
		_, err := tx.Exec(`INSERT INTO audio_items(entry_id,tag,prob,delay,delay_range,loop_delay,loop_delay_range,sort_order) VALUES(?,?,?,?,?,?,?,?)`,
			entryID, it.Tag, it.Prob, it.Delay, it.DelayRange, it.LoopDelay, it.LoopDelayRange, i)
		if err != nil {
			return err
		}
	}

	return tx.Commit()
}

// DeleteAudioXmlEntry 删除条目
func (d *Database) DeleteAudioXmlEntry(entryType, entryID string) error {
	var id int64
	err := d.db.QueryRow("SELECT id FROM audio_entries WHERE entry_type=? AND entry_id=?", entryType, entryID).Scan(&id)
	if err != nil {
		return err
	}
	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	tx.Exec("DELETE FROM audio_items WHERE entry_id=?", id)
	tx.Exec("DELETE FROM audio_entries WHERE id=?", id)
	return tx.Commit()
}

// ==================== Helper: XML structs and converters ====================

// XML 解析使用的结构体（与 handler 中的兼容）
type AudioTagDB struct {
	XMLName  xml.Name       `xml:"-"`        // 不序列化根标签，手动处理
	RootName string         `xml:"-"`        // 原始根元素名
	Effects  []EffectEntry  `xml:"EFFECT"`
	Randoms  []RandomEntry  `xml:"RANDOM"`
	Groups   []GroupEntry   `xml:"GROUP"`
	Musics   []MusicEntry   `xml:"MUSIC"`
	Ambients []AmbientEntry `xml:"AMBIENT"`
}

type EffectEntry struct {
	ID             string `xml:"ID,attr"`
	File           string `xml:"FILE,attr"`
	DuplicateLimit string `xml:"DUPLICATE_LIMIT,attr,omitempty"`
	VolumeAdjust   string `xml:"VOLUME_ADJUST,attr,omitempty"`
	Priority       string `xml:"PRIORITY,attr,omitempty"`
	LoopDelay      string `xml:"LOOP_DELAY,attr,omitempty"`
	LoopDelayRange string `xml:"LOOP_DELAY_RANGE,attr,omitempty"`
	Delay          string `xml:"DELAY,attr,omitempty"`
	DelayRange     string `xml:"DELAY_RANGE,attr,omitempty"`
	SubGroup       string `xml:"SUBGROUP,attr,omitempty"`
}

type RandomEntry struct {
	ID             string       `xml:"ID,attr"`
	DuplicateLimit string       `xml:"DUPLICATE_LIMIT,attr,omitempty"`
	LoopDelay      string       `xml:"LOOP_DELAY,attr,omitempty"`
	LoopDelayRange string       `xml:"LOOP_DELAY_RANGE,attr,omitempty"`
	Delay          string       `xml:"DELAY,attr,omitempty"`
	DelayRange     string       `xml:"DELAY_RANGE,attr,omitempty"`
	Items          []RandomItem `xml:"ITEM"`
}

type RandomItem struct {
	Prob string `xml:"PROB,attr"`
	Tag  string `xml:"TAG,attr"`
}

type GroupEntry struct {
	ID    string      `xml:"ID,attr"`
	Items []GroupItem `xml:"ITEM"`
}

type GroupItem struct {
	Prob           string `xml:"PROB,attr,omitempty"`
	Tag            string `xml:"TAG,attr"`
	Delay          string `xml:"DELAY,attr,omitempty"`
	DelayRange     string `xml:"DELAY_RANGE,attr,omitempty"`
	LoopDelay      string `xml:"LOOP_DELAY,attr,omitempty"`
	LoopDelayRange string `xml:"LOOP_DELAY_RANGE,attr,omitempty"`
}

type MusicEntry struct {
	ID             string `xml:"ID,attr"`
	File           string `xml:"FILE,attr"`
	DuplicateLimit string `xml:"DUPLICATE_LIMIT,attr,omitempty"`
	LoopDelay      string `xml:"LOOP_DELAY,attr,omitempty"`
	VolumeAdjust   string `xml:"VOLUME_ADJUST,attr,omitempty"`
}

type AmbientEntry struct {
	ID             string `xml:"ID,attr"`
	File           string `xml:"FILE,attr"`
	DuplicateLimit string `xml:"DUPLICATE_LIMIT,attr,omitempty"`
	LoopDelay      string `xml:"LOOP_DELAY,attr,omitempty"`
	VolumeAdjust   string `xml:"VOLUME_ADJUST,attr,omitempty"`
}

// 属性提取
func effectAttrs(e EffectEntry) map[string]string {
	m := map[string]string{}
	if e.VolumeAdjust != "" { m["volume_adjust"] = e.VolumeAdjust }
	if e.Priority != "" { m["priority"] = e.Priority }
	if e.LoopDelay != "" { m["loop_delay"] = e.LoopDelay }
	if e.LoopDelayRange != "" { m["loop_delay_range"] = e.LoopDelayRange }
	if e.Delay != "" { m["delay"] = e.Delay }
	if e.DelayRange != "" { m["delay_range"] = e.DelayRange }
	if e.SubGroup != "" { m["subgroup"] = e.SubGroup }
	if e.DuplicateLimit != "" { m["duplicate_limit"] = e.DuplicateLimit }
	return m
}

func fillEffectAttrs(e *EffectEntry, m map[string]string) {
	if m == nil { return }
	if v, ok := m["volume_adjust"]; ok { e.VolumeAdjust = v }
	if v, ok := m["priority"]; ok { e.Priority = v }
	if v, ok := m["loop_delay"]; ok { e.LoopDelay = v }
	if v, ok := m["loop_delay_range"]; ok { e.LoopDelayRange = v }
	if v, ok := m["delay"]; ok { e.Delay = v }
	if v, ok := m["delay_range"]; ok { e.DelayRange = v }
	if v, ok := m["subgroup"]; ok { e.SubGroup = v }
	if v, ok := m["duplicate_limit"]; ok { e.DuplicateLimit = v }
}

func randomAttrs(r RandomEntry) map[string]string {
	m := map[string]string{}
	if r.LoopDelay != "" { m["loop_delay"] = r.LoopDelay }
	if r.LoopDelayRange != "" { m["loop_delay_range"] = r.LoopDelayRange }
	if r.Delay != "" { m["delay"] = r.Delay }
	if r.DelayRange != "" { m["delay_range"] = r.DelayRange }
	if r.DuplicateLimit != "" { m["duplicate_limit"] = r.DuplicateLimit }
	return m
}

func fillRandomAttrs(r *RandomEntry, m map[string]string) {
	if m == nil { return }
	if v, ok := m["loop_delay"]; ok { r.LoopDelay = v }
	if v, ok := m["loop_delay_range"]; ok { r.LoopDelayRange = v }
	if v, ok := m["delay"]; ok { r.Delay = v }
	if v, ok := m["delay_range"]; ok { r.DelayRange = v }
	if v, ok := m["duplicate_limit"]; ok { r.DuplicateLimit = v }
}

func musicAttrs(mu MusicEntry) map[string]string {
	m := map[string]string{}
	if mu.LoopDelay != "" { m["loop_delay"] = mu.LoopDelay }
	if mu.VolumeAdjust != "" { m["volume_adjust"] = mu.VolumeAdjust }
	if mu.DuplicateLimit != "" { m["duplicate_limit"] = mu.DuplicateLimit }
	return m
}

func fillMusicAttrs(mu *MusicEntry, m map[string]string) {
	if m == nil { return }
	if v, ok := m["loop_delay"]; ok { mu.LoopDelay = v }
	if v, ok := m["volume_adjust"]; ok { mu.VolumeAdjust = v }
	if v, ok := m["duplicate_limit"]; ok { mu.DuplicateLimit = v }
}

func ambientAttrs(a AmbientEntry) map[string]string {
	m := map[string]string{}
	if a.LoopDelay != "" { m["loop_delay"] = a.LoopDelay }
	if a.VolumeAdjust != "" { m["volume_adjust"] = a.VolumeAdjust }
	if a.DuplicateLimit != "" { m["duplicate_limit"] = a.DuplicateLimit }
	return m
}

func fillAmbientAttrs(a *AmbientEntry, m map[string]string) {
	if m == nil { return }
	if v, ok := m["loop_delay"]; ok { a.LoopDelay = v }
	if v, ok := m["volume_adjust"]; ok { a.VolumeAdjust = v }
	if v, ok := m["duplicate_limit"]; ok { a.DuplicateLimit = v }
}

// FindAudioXmlFilesInMusic 批量检查音乐库
func (d *Database) FindAudioXmlFilesInMusic(files []string) map[string]bool {
	result := make(map[string]bool)
	if len(files) == 0 { return result }
	for i := 0; i < len(files); i += 500 {
		end := i + 500
		if end > len(files) { end = len(files) }
		chunk := files[i:end]
		phs := make([]string, len(chunk))
		args := make([]interface{}, len(chunk))
		for j, f := range chunk {
			phs[j] = "?"
			args[j] = f
		}
		rows, _ := d.db.Query("SELECT REPLACE(path,'\\','/') FROM music WHERE REPLACE(path,'\\','/') IN ("+strings.Join(phs, ",")+")", args...)
		if rows != nil {
			for rows.Next() {
				var p string; rows.Scan(&p)
				result[p] = true
			}
			rows.Close()
		}
	}
	return result
}

// FindAudioXmlFilesInSoundPack 批量检查音效包
func (d *Database) FindAudioXmlFilesInSoundPack(files []string) map[string]bool {
	result := make(map[string]bool)
	if len(files) == 0 { return result }
	for i := 0; i < len(files); i += 500 {
		end := i + 500
		if end > len(files) { end = len(files) }
		chunk := files[i:end]
		phs := make([]string, len(chunk))
		args := make([]interface{}, len(chunk))
		for j, f := range chunk {
			phs[j] = "?"
			args[j] = f
		}
		rows, _ := d.db.Query("SELECT REPLACE(entry_path,'\\','/') FROM soundpack_entries WHERE REPLACE(entry_path,'\\','/') IN ("+strings.Join(phs, ",")+")", args...)
		if rows != nil {
			for rows.Next() {
				var p string; rows.Scan(&p)
				result[p] = true
			}
			rows.Close()
		}
	}
	return result
}

// FindAudioXmlFileInMusic 单文件检查（流式播放用）
func (d *Database) FindAudioXmlFileInMusic(filePath string) bool {
	return len(d.FindAudioXmlFilesInMusic([]string{filePath})) > 0
}

// FindAudioXmlFileInSoundPack 单文件检查（流式播放用）
func (d *Database) FindAudioXmlFileInSoundPack(filePath string) bool {
	return len(d.FindAudioXmlFilesInSoundPack([]string{filePath})) > 0
}

// extractRootName 从 XML 数据中提取根元素名
func extractRootName(data []byte) string {
	re := regexp.MustCompile(`<(\w+)[>\s]`)
	if m := re.FindSubmatch(data); len(m) > 1 {
		name := string(m[1])
		if name != "?" && name != "!--" {
			return name
		}
	}
	return "AudioTagDB"
}

// extractHeader 提取 XML 声明和注释头部
func extractHeader(data []byte) string {
	text := string(data)
	// 找到第一个非注释非声明的标签
	contentStart := regexp.MustCompile(`(?s)^(.*?)<[A-Za-z]`).FindStringSubmatch(text)
	if len(contentStart) > 1 {
		header := strings.TrimSpace(contentStart[1])
		if header != "" {
			return header
		}
	}
	return ""
}
