package database

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"
	"time"
)

// Stats 统计信息
type Stats struct {
	NpkCount         int
	AlbumCount       int
	SpriteCount      int
	TotalSize        int64
	SpritesTotalSize int64
}

// TableStats 表统计信息
type TableStats struct {
	Table       string `json:"table"`
	Rows        int    `json:"rows"`
	Description string `json:"description"`
}

// 表名映射和说明
var tableDescriptions = map[string]string{
	"npk_files":   "NPK 文件索引",
	"albums":      "IMG 文件索引",
	"sprites":     "帧数据",
	"tags":        "标签定义",
	"sprite_tags": "帧标签关联",
	"album_tags":  "Album 标签关联",
	"npk_tags":    "NPK 标签关联",
	"settings":    "系统设置",
	"batch_tasks": "批量任务记录",
}

// GetStats 获取统计信息（优化版 - 单次查询）
func (d *Database) GetStats() (*Stats, error) {
	stats := &Stats{}
	row := d.db.QueryRow(`
		SELECT 
			(SELECT COUNT(*) FROM npk_files),
			(SELECT COUNT(*) FROM albums),
			(SELECT COALESCE(SUM(sprite_count), 0) FROM albums),
			(SELECT COALESCE(SUM(size), 0) FROM npk_files),
			0
	`)
	err := row.Scan(&stats.NpkCount, &stats.AlbumCount, &stats.SpriteCount, &stats.TotalSize, &stats.SpritesTotalSize)
	if err != nil {
		return nil, err
	}
	return stats, nil
}

// GetTableStats 返回每张表的行数（优化版 - UNION ALL）
func (d *Database) GetTableStats() ([]*TableStats, error) {
	query := `
		SELECT 'npk_files' as table_name, COUNT(*) as cnt FROM npk_files
		UNION ALL SELECT 'albums', COUNT(*) FROM albums
		UNION ALL SELECT 'sprites', COUNT(*) FROM sprites
		UNION ALL SELECT 'tags', COUNT(*) FROM tags
		UNION ALL SELECT 'sprite_tags', COUNT(*) FROM sprite_tags
		UNION ALL SELECT 'album_tags', COUNT(*) FROM album_tags
		UNION ALL SELECT 'npk_tags', COUNT(*) FROM npk_tags
		UNION ALL SELECT 'settings', COUNT(*) FROM settings
		UNION ALL SELECT 'batch_tasks', COUNT(*) FROM batch_tasks
	`
	rows, err := d.db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := make([]*TableStats, 0, 9)
	for rows.Next() {
		var name string
		var count int
		if err := rows.Scan(&name, &count); err != nil {
			continue
		}
		result = append(result, &TableStats{
			Table:       name,
			Rows:        count,
			Description: tableDescriptions[name],
		})
	}
	return result, nil
}

// GetDBSize 获取数据库文件大小
func (d *Database) GetDBSize() (int64, error) {
	var path string
	// PRAGMA database_list 返回: seq, name, file
	// 过滤主数据库（name='main'）
	err := d.db.QueryRow(`SELECT file FROM pragma_database_list WHERE name = 'main'`).Scan(&path)
	if err != nil {
		return 0, err
	}

	if path == "" {
		return 0, fmt.Errorf("数据库路径为空")
	}

	stat, err := os.Stat(path)
	if err != nil {
		return 0, err
	}

	// 包含 WAL 和 SHM 文件
	walPath := path + "-wal"
	shmPath := path + "-shm"
	size := stat.Size()

	if walStat, err := os.Stat(walPath); err == nil {
		size += walStat.Size()
	}
	if shmStat, err := os.Stat(shmPath); err == nil {
		size += shmStat.Size()
	}

	return size, nil
}

// Cleanup 清理无效记录（优化版）
func (d *Database) Cleanup() (int, int, int, error) {
	// 获取所有 NPK 文件路径
	rows, err := d.db.Query(`SELECT id, path FROM npk_files`)
	if err != nil {
		return 0, 0, 0, err
	}
	defer rows.Close()

	type fileInfo struct {
		id   int64
		path string
	}
	var files []fileInfo
	for rows.Next() {
		var f fileInfo
		if err := rows.Scan(&f.id, &f.path); err == nil {
			files = append(files, f)
		}
	}

	var deletedNpks, deletedAlbums, deletedSprites int

	// 批量删除无效文件
	tx, err := d.db.Begin()
	if err != nil {
		return 0, 0, 0, err
	}
	defer tx.Rollback()

	for _, f := range files {
		if _, err := os.Stat(f.path); os.IsNotExist(err) {
			// 获取 album IDs
			albumRows, err := tx.Query(`SELECT id FROM albums WHERE npk_id = ?`, f.id)
			if err != nil {
				continue
			}
			var albumIDs []int64
			for albumRows.Next() {
				var id int64
				if err := albumRows.Scan(&id); err == nil {
					albumIDs = append(albumIDs, id)
				}
			}
			albumRows.Close()

			// 批量删除 sprites 和 sprite_tags
			if len(albumIDs) > 0 {
				placeholders := make([]string, len(albumIDs))
				args := make([]interface{}, len(albumIDs))
				for i, id := range albumIDs {
					placeholders[i] = "?"
					args[i] = id
				}
				inClause := strings.Join(placeholders, ",")

				// 删除 sprite_tags
				result, _ := tx.Exec(fmt.Sprintf(
					`DELETE FROM sprite_tags WHERE sprite_id IN (SELECT id FROM sprites WHERE album_id IN (%s))`,
					inClause), args...)
				if result != nil {
					cnt, _ := result.RowsAffected()
					deletedSprites += int(cnt)
				}

				// 删除 sprites
				result, _ = tx.Exec(fmt.Sprintf(`DELETE FROM sprites WHERE album_id IN (%s)`, inClause), args...)
				if result != nil {
					cnt, _ := result.RowsAffected()
					deletedSprites += int(cnt)
				}

				// 删除 album_tags
				result, _ = tx.Exec(fmt.Sprintf(`DELETE FROM album_tags WHERE album_id IN (%s)`, inClause), args...)
				if result != nil {
					cnt, _ := result.RowsAffected()
					deletedAlbums += int(cnt)
				}

				// 删除 albums
				result, _ = tx.Exec(fmt.Sprintf(`DELETE FROM albums WHERE id IN (%s)`, inClause), args...)
				if result != nil {
					cnt, _ := result.RowsAffected()
					deletedAlbums += int(cnt)
				}
			}

			// 删除 npk_tags
			tx.Exec(`DELETE FROM npk_tags WHERE npk_id = ?`, f.id)

			// 删除 npk_files
			result, _ := tx.Exec(`DELETE FROM npk_files WHERE id = ?`, f.id)
			if result != nil {
				cnt, _ := result.RowsAffected()
				deletedNpks += int(cnt)
			}
		}
	}

	if err := tx.Commit(); err != nil {
		return 0, 0, 0, err
	}

	return deletedNpks, deletedAlbums, deletedSprites, nil
}

// Compact 压缩数据库
func (d *Database) Compact() error {
	_, err := d.db.Exec(`VACUUM`)
	return err
}

// ClearAll 清空所有数据
func (d *Database) ClearAll() error {
	tables := []string{"sprite_tags", "sprites", "album_tags", "npk_tags", "albums", "npk_files", "tags", "settings", "batch_tasks"}
	for _, table := range tables {
		if _, err := d.db.Exec(fmt.Sprintf(`DELETE FROM %s`, table)); err != nil {
			return err
		}
		// 重置自增 ID
		d.db.Exec(fmt.Sprintf(`DELETE FROM sqlite_sequence WHERE name='%s'`, table))
	}
	return nil
}

// ExportAll 导出所有数据（流式版，避免内存溢出）
func (d *Database) ExportAll() (map[string]interface{}, error) {
	result := make(map[string]interface{})

	// 导出 npk_files（流式）
	npkFiles := []map[string]interface{}{}
	rows, err := d.db.Query(`SELECT id, name, path, size, img_count, sha256_hash, format_type, encryption_verified, modified_at, scanned_at, created_at FROM npk_files ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id, size, imgCount, formatType, encryptionVerified int64
		var name, path, sha256Hash string
		var modifiedAt, scannedAt, createdAt time.Time
		if err := rows.Scan(&id, &name, &path, &size, &imgCount, &sha256Hash, &formatType, &encryptionVerified, &modifiedAt, &scannedAt, &createdAt); err == nil {
			npkFiles = append(npkFiles, map[string]interface{}{
				"id": id, "name": name, "path": path, "size": size,
				"img_count": imgCount, "sha256_hash": sha256Hash,
				"format_type": formatType, "encryption_verified": encryptionVerified,
				"modified_at": modifiedAt, "scanned_at": scannedAt, "created_at": createdAt,
			})
		}
	}
	result["npk_files"] = npkFiles

	// 导出 albums（流式）
	albums := []map[string]interface{}{}
	rows, err = d.db.Query(`
		SELECT a.id, a.npk_id, n.name as npk_name, a.path, a.name, a.file_type, a.version, a.sprite_count, 
		       a.offset, a.size, a.palette_json, a.dds_info_json, a.created_at
		FROM albums a JOIN npk_files n ON a.npk_id = n.id
		ORDER BY a.npk_id, a.id
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id, npkID, fileType, version, spriteCount int64
		var offset, size int64
		var path, name, npkName string
		var paletteJSON, ddsInfoJSON sql.NullString
		var createdAt time.Time
		if err := rows.Scan(&id, &npkID, &npkName, &path, &name, &fileType, &version, &spriteCount,
			&offset, &size, &paletteJSON, &ddsInfoJSON, &createdAt); err == nil {
			albums = append(albums, map[string]interface{}{
				"id": id, "npk_id": npkID, "npk_name": npkName, "path": path, "name": name,
				"file_type": fileType, "version": version, "sprite_count": spriteCount,
				"offset": offset, "size": size,
				"palette_json": paletteJSON.String, "dds_info_json": ddsInfoJSON.String,
				"created_at": createdAt,
			})
		}
	}
	result["albums"] = albums

	// 导出 sprites（流式）
	sprites := []map[string]interface{}{}
	rows, err = d.db.Query(`SELECT id, album_id, "index", type, compress_mode, width, height, x, y, frame_width, frame_height, is_link, target_index, data_size, created_at FROM sprites ORDER BY album_id, "index"`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id, albumID, index, type_, compressMode, width, height, x, y, frameWidth, frameHeight, isLink, targetIndex, dataSize int64
		var createdAt time.Time
		if err := rows.Scan(&id, &albumID, &index, &type_, &compressMode, &width, &height, &x, &y, &frameWidth, &frameHeight, &isLink, &targetIndex, &dataSize, &createdAt); err == nil {
			sprites = append(sprites, map[string]interface{}{
				"id": id, "album_id": albumID, "index": index, "type": type_,
				"compress_mode": compressMode, "width": width, "height": height,
				"x": x, "y": y, "frame_width": frameWidth, "frame_height": frameHeight,
				"is_link": isLink, "target_index": targetIndex, "data_size": dataSize,
				"created_at": createdAt,
			})
		}
	}
	result["sprites"] = sprites

	// 导出 tags
	tags := []map[string]interface{}{}
	rows, err = d.db.Query(`SELECT id, name, color, created_at FROM tags ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		var name, color string
		var createdAt time.Time
		if err := rows.Scan(&id, &name, &color, &createdAt); err == nil {
			tags = append(tags, map[string]interface{}{
				"id": id, "name": name, "color": color, "created_at": createdAt,
			})
		}
	}
	result["tags"] = tags

	// 导出 settings
	settings := []map[string]interface{}{}
	rows, err = d.db.Query(`SELECT key, value, updated_at FROM settings ORDER BY key`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var key, value string
		var updatedAt time.Time
		if err := rows.Scan(&key, &value, &updatedAt); err == nil {
			settings = append(settings, map[string]interface{}{
				"key": key, "value": value, "updated_at": updatedAt,
			})
		}
	}
	result["settings"] = settings

	// 导出 batch_tasks
	tasks := []map[string]interface{}{}
	rows, err = d.db.Query(`SELECT id, type, status, total, completed, error, created_at, finished_at FROM batch_tasks ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id int64
		var type_, status, errorStr string
		var total, completed int64
		var createdAt time.Time
		var finishedAt sql.NullTime
		if err := rows.Scan(&id, &type_, &status, &total, &completed, &errorStr, &createdAt, &finishedAt); err == nil {
			task := map[string]interface{}{
				"id": id, "type": type_, "status": status, "total": total,
				"completed": completed, "error": errorStr, "created_at": createdAt,
			}
			if finishedAt.Valid {
				task["finished_at"] = finishedAt.Time
			}
			tasks = append(tasks, task)
		}
	}
	result["batch_tasks"] = tasks

	return result, nil
}

// ExportAllJSON 导出所有数据为 JSON 字节
func (d *Database) ExportAllJSON() ([]byte, error) {
	data, err := d.ExportAll()
	if err != nil {
		return nil, err
	}
	return json.MarshalIndent(data, "", "  ")
}

// Vacuum 执行数据库 VACUUM 操作，优化数据库文件大小和性能
func (d *Database) Vacuum() error {
	log.Println("Starting database vacuum...")
	_, err := d.db.Exec("VACUUM")
	if err != nil {
		log.Printf("Database vacuum failed: %v", err)
		return err
	}
	log.Println("Database vacuum completed successfully")
	return nil
}

// CleanupOldBatchTasks 清理过期的批量任务记录（默认保留 7 天）
func (d *Database) CleanupOldBatchTasks(retentionDays int) (int64, error) {
	if retentionDays <= 0 {
		retentionDays = 7
	}
	result, err := d.db.Exec(`
		DELETE FROM batch_tasks 
		WHERE created_at < datetime('now', '-' || ? || ' days')
	`, retentionDays)
	if err != nil {
		return 0, err
	}
	cnt, _ := result.RowsAffected()
	log.Printf("Cleaned up %d old batch tasks", cnt)
	return cnt, nil
}
