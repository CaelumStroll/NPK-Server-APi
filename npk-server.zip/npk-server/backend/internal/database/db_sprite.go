package database

import (
	"database/sql"
	"strings"
)

// SpriteBatchItem 批量插入的 Sprite 数据项（增强版）
type SpriteBatchItem struct {
	Index        int
	Type         int
	CompressMode int
	Width        int
	Height       int
	X            int
	Y            int
	FrameWidth   int
	FrameHeight  int
	IsLink       bool
	TargetIndex  int
	DataSize     int
}

// InsertSpritesBatch 批量插入 Sprites
func (d *Database) InsertSpritesBatch(albumID int64, sprites []*SpriteBatchItem) error {
	if len(sprites) == 0 {
		return nil
	}

	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	const batchSize = 100

	for i := 0; i < len(sprites); i += batchSize {
		end := i + batchSize
		if end > len(sprites) {
			end = len(sprites)
		}

		batch := sprites[i:end]
		if err := d.insertSpritesBatchInternal(tx, albumID, batch); err != nil {
			return err
		}
	}

	return tx.Commit()
}

// insertSpritesBatchInternal 内部批量插入实现（增强版）
func (d *Database) insertSpritesBatchInternal(tx *sql.Tx, albumID int64, sprites []*SpriteBatchItem) error {
	if len(sprites) == 0 {
		return nil
	}

	values := make([]string, 0, len(sprites))
	args := make([]interface{}, 0, len(sprites)*13)

	for _, sp := range sprites {
		isLinkInt := 0
		if sp.IsLink {
			isLinkInt = 1
		}
		values = append(values, "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
		args = append(args, albumID, sp.Index, sp.Type, sp.CompressMode,
			sp.Width, sp.Height, sp.X, sp.Y, sp.FrameWidth, sp.FrameHeight, isLinkInt, sp.TargetIndex, sp.DataSize)
	}

	sql := `INSERT INTO sprites (album_id, "index", type, compress_mode, width, height, x, y, frame_width, frame_height, is_link, target_index, data_size) VALUES ` +
		strings.Join(values, ", ")

	_, err := tx.Exec(sql, args...)
	return err
}
