package database

import (
	"fmt"
	"strings"
	"time"
)

// InsertNpkFile 插入 NPK 文件（事务版）
func (d *Database) InsertNpkFile(name, path string, size int64, imgCount int, sha256Hash string, formatType int, encryptionVerified bool, modifiedAt time.Time) (int64, error) {
	tx, err := d.db.Begin()
	if err != nil {
		return 0, err
	}
	defer tx.Rollback()

	// 先清理旧的关联数据（如果存在）
	var oldID int64
	err = tx.QueryRow(`SELECT id FROM npk_files WHERE name = ?`, name).Scan(&oldID)
	if err == nil && oldID > 0 {
		// 级联删除 albums 和 sprites
		_, err = tx.Exec(`DELETE FROM sprites WHERE album_id IN (SELECT id FROM albums WHERE npk_id = ?)`, oldID)
		if err != nil {
			return 0, err
		}
		_, err = tx.Exec(`DELETE FROM albums WHERE npk_id = ?`, oldID)
		if err != nil {
			return 0, err
		}
		// 删除 npk_tags 关联
		_, err = tx.Exec(`DELETE FROM npk_tags WHERE npk_id = ?`, oldID)
		if err != nil {
			return 0, err
		}
	}

	verifiedInt := 0
	if encryptionVerified {
		verifiedInt = 1
	}

	result, err := tx.Exec(`
		INSERT OR REPLACE INTO npk_files (name, path, size, img_count, sha256_hash, format_type, encryption_verified, modified_at, scanned_at)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, name, path, size, imgCount, sha256Hash, formatType, verifiedInt, modifiedAt, time.Now())
	if err != nil {
		return 0, err
	}

	if err := tx.Commit(); err != nil {
		return 0, err
	}

	return result.LastInsertId()
}

// UpdateNpkFile 更新 NPK 文件元数据
func (d *Database) UpdateNpkFile(id int64, imgCount int, sha256Hash string, formatType int, encryptionVerified bool) error {
	verifiedInt := 0
	if encryptionVerified {
		verifiedInt = 1
	}
	_, err := d.db.Exec(`
		UPDATE npk_files 
		SET img_count = ?, sha256_hash = ?, format_type = ?, encryption_verified = ?, updated_at = ?
		WHERE id = ?
	`, imgCount, sha256Hash, formatType, verifiedInt, time.Now(), id)
	return err
}

// GetNpkFile 获取 NPK 文件
func (d *Database) GetNpkFile(id int64) (*NpkFileRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, size, img_count, sha256_hash, format_type, encryption_verified, modified_at, scanned_at, created_at
		FROM npk_files WHERE id = ?
	`, id)

	record := &NpkFileRecord{}
	var verifiedInt int
	err := row.Scan(&record.ID, &record.Name, &record.Path, &record.Size, &record.ImgCount,
		&record.SHA256Hash, &record.FormatType, &verifiedInt, &record.ModifiedAt, &record.ScannedAt, &record.CreatedAt)
	if err != nil {
		return nil, err
	}
	record.EncryptionVerified = verifiedInt == 1
	return record, nil
}

// GetNpkFileByName 根据名称获取 NPK 文件
func (d *Database) GetNpkFileByName(name string) (*NpkFileRecord, error) {
	row := d.db.QueryRow(`
		SELECT id, name, path, size, img_count, sha256_hash, format_type, encryption_verified, modified_at, scanned_at, created_at
		FROM npk_files WHERE name = ?
	`, name)

	record := &NpkFileRecord{}
	var verifiedInt int
	err := row.Scan(&record.ID, &record.Name, &record.Path, &record.Size, &record.ImgCount,
		&record.SHA256Hash, &record.FormatType, &verifiedInt, &record.ModifiedAt, &record.ScannedAt, &record.CreatedAt)
	if err != nil {
		return nil, err
	}
	record.EncryptionVerified = verifiedInt == 1
	return record, nil
}

// ListNpkFiles 列出所有 NPK 文件
func (d *Database) ListNpkFiles() ([]*NpkFileRecord, error) {
	rows, err := d.db.Query(`
		SELECT id, name, path, size, img_count, sha256_hash, format_type, encryption_verified, modified_at, scanned_at, created_at
		FROM npk_files ORDER BY name
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []*NpkFileRecord
	for rows.Next() {
		record := &NpkFileRecord{}
		var verifiedInt int
		err := rows.Scan(&record.ID, &record.Name, &record.Path, &record.Size, &record.ImgCount,
			&record.SHA256Hash, &record.FormatType, &verifiedInt, &record.ModifiedAt, &record.ScannedAt, &record.CreatedAt)
		if err != nil {
			return nil, err
		}
		record.EncryptionVerified = verifiedInt == 1
		records = append(records, record)
	}
	return records, nil
}

// ListNpkFilesPaginated 分页列出 NPK 文件
func (d *Database) ListNpkFilesPaginated(query string, page, pageSize int) ([]*NpkFileRecord, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 200 {
		pageSize = 50
	}
	offset := (page - 1) * pageSize

	// 构建 WHERE 条件
	where := ""
	args := []interface{}{}
	if query != "" {
		where = "WHERE name LIKE ?"
		args = append(args, "%"+query+"%")
	}

	// 查询总数
	countSQL := "SELECT COUNT(*) FROM npk_files " + where
	var total int
	err := d.db.QueryRow(countSQL, args...).Scan(&total)
	if err != nil {
		return nil, 0, err
	}

	// 查询分页数据
	querySQL := `
		SELECT id, name, path, size, img_count, sha256_hash, format_type, encryption_verified, modified_at, scanned_at, created_at
		FROM npk_files ` + where + `
		ORDER BY name
		LIMIT ? OFFSET ?
	`
	args = append(args, pageSize, offset)

	rows, err := d.db.Query(querySQL, args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var records []*NpkFileRecord
	for rows.Next() {
		record := &NpkFileRecord{}
		var verifiedInt int
		err := rows.Scan(&record.ID, &record.Name, &record.Path, &record.Size, &record.ImgCount,
			&record.SHA256Hash, &record.FormatType, &verifiedInt, &record.ModifiedAt, &record.ScannedAt, &record.CreatedAt)
		if err != nil {
			continue
		}
		record.EncryptionVerified = verifiedInt == 1
		records = append(records, record)
	}
	return records, total, nil
}

// DeleteNpkFile 删除 NPK 文件（使用级联删除）
func (d *Database) DeleteNpkFile(id int64) error {
	// 使用外键级联删除，不需要手动处理关联数据
	_, err := d.db.Exec(`DELETE FROM npk_files WHERE id = ?`, id)
	return err
}

// DeleteNpkFileWithRelations 删除 NPK 及其所有关联数据（事务版）
func (d *Database) DeleteNpkFileWithRelations(id int64) error {
	tx, err := d.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	// 获取所有 album IDs
	rows, err := tx.Query(`SELECT id FROM albums WHERE npk_id = ?`, id)
	if err != nil {
		return err
	}
	var albumIDs []int64
	for rows.Next() {
		var albumID int64
		if err := rows.Scan(&albumID); err == nil {
			albumIDs = append(albumIDs, albumID)
		}
	}
	rows.Close()

	// 批量删除关联数据
	if len(albumIDs) > 0 {
		placeholders := make([]string, len(albumIDs))
		args := make([]interface{}, len(albumIDs))
		for i, aid := range albumIDs {
			placeholders[i] = "?"
			args[i] = aid
		}
		inClause := strings.Join(placeholders, ",")

		// 删除 sprite_tags
		tx.Exec(fmt.Sprintf(`DELETE FROM sprite_tags WHERE sprite_id IN (SELECT id FROM sprites WHERE album_id IN (%s))`, inClause), args...)
		// 删除 sprites
		tx.Exec(fmt.Sprintf(`DELETE FROM sprites WHERE album_id IN (%s)`, inClause), args...)
		// 删除 album_tags
		tx.Exec(fmt.Sprintf(`DELETE FROM album_tags WHERE album_id IN (%s)`, inClause), args...)
		// 删除 albums
		tx.Exec(fmt.Sprintf(`DELETE FROM albums WHERE id IN (%s)`, inClause), args...)
	}

	// 删除 npk_tags
	_, err = tx.Exec(`DELETE FROM npk_tags WHERE npk_id = ?`, id)
	if err != nil {
		return err
	}

	// 删除 npk_files
	_, err = tx.Exec(`DELETE FROM npk_files WHERE id = ?`, id)
	if err != nil {
		return err
	}

	return tx.Commit()
}
