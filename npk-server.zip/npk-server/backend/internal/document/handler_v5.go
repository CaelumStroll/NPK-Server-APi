package document

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
)

// FifthHandler Ver5 处理器（支持纹理集）
type FifthHandler struct{}

func (h *FifthHandler) Parse(album *Album, r io.Reader) error {
	// 读取 IMG_FLAG
	var flag uint32
	if err := binary.Read(r, binary.LittleEndian, &flag); err != nil {
		return fmt.Errorf("read flag failed: %w", err)
	}

	if flag != 0x534E4646 {
		return fmt.Errorf("invalid IMG flag: 0x%08X", flag)
	}

	// 读取版本
	var version uint32
	if err := binary.Read(r, binary.LittleEndian, &version); err != nil {
		return fmt.Errorf("read version failed: %w", err)
	}
	album.Version = ImgVersion(version)

	// 读取索引数量
	var indexCount uint32
	if err := binary.Read(r, binary.LittleEndian, &indexCount); err != nil {
		return fmt.Errorf("read index count failed: %w", err)
	}

	// 解析索引（包含纹理信息）
	album.Sprites = make([]*Sprite, 0, indexCount)
	for i := uint32(0); i < indexCount; i++ {
		sprite := &Sprite{}
		if err := h.parseSpriteIndex(sprite, r); err != nil {
			return fmt.Errorf("parse sprite %d failed: %w", i, err)
		}
		album.Sprites = append(album.Sprites, sprite)
	}

	// 解析纹理集信息（如果有）
	var textureCount uint32
	if err := binary.Read(r, binary.LittleEndian, &textureCount); err == nil && textureCount > 0 {
		album.Textures = make([]*Texture, 0, textureCount)
		for i := uint32(0); i < textureCount; i++ {
			texture := &Texture{}
			if err := h.parseTextureIndex(texture, r); err != nil {
				return fmt.Errorf("parse texture %d failed: %w", i, err)
			}
			album.Textures = append(album.Textures, texture)
		}
	}

	// 解析纹理数据
	for _, texture := range album.Textures {
		if err := h.parseTextureData(texture, r); err != nil {
			return fmt.Errorf("parse texture data %d failed: %w", texture.Index, err)
		}
	}

	// 解析 Sprite 数据
	for _, sprite := range album.Sprites {
		if err := h.parseSpriteData(sprite, r); err != nil {
			return fmt.Errorf("parse sprite data %d failed: %w", sprite.Index, err)
		}
	}

	return nil
}

func (h *FifthHandler) Serialize(album *Album) ([]byte, error) {
	var buf bytes.Buffer

	// 写入 IMG_FLAG
	if err := binary.Write(&buf, binary.LittleEndian, uint32(0x534E4646)); err != nil {
		return nil, err
	}

	// 写入版本
	if err := binary.Write(&buf, binary.LittleEndian, uint32(album.Version)); err != nil {
		return nil, err
	}

	// 写入索引数量
	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(album.Sprites))); err != nil {
		return nil, err
	}

	// 写入 Sprite 索引
	for _, sprite := range album.Sprites {
		if err := h.writeSpriteIndex(&buf, sprite); err != nil {
			return nil, err
		}
	}

	// 写入纹理集信息
	if len(album.Textures) > 0 {
		if err := binary.Write(&buf, binary.LittleEndian, uint32(len(album.Textures))); err != nil {
			return nil, err
		}
		for _, texture := range album.Textures {
			if err := h.writeTextureIndex(&buf, texture); err != nil {
				return nil, err
			}
		}
		// 写入纹理数据
		for _, texture := range album.Textures {
			if err := h.writeTextureData(&buf, texture); err != nil {
				return nil, err
			}
		}
	}

	// 写入 Sprite 数据
	for _, sprite := range album.Sprites {
		if err := h.writeSpriteData(&buf, sprite); err != nil {
			return nil, err
		}
	}

	return buf.Bytes(), nil
}

func (h *FifthHandler) parseSpriteIndex(sprite *Sprite, r io.Reader) error {
	// Ver5 索引包含纹理信息
	var idx struct {
		Index        uint32
		Type         uint32
		X            uint32
		Y            uint32
		Width        uint32
		Height       uint32
		FrameWidth   uint32
		FrameHeight  uint32
		CompressMode uint32
		Length       uint32
		TextureIndex uint32 // V5 特有
		TexLeftUpX   uint32
		TexLeftUpY   uint32
		TexRightDownX uint32
		TexRightDownY uint32
		TexTop       uint32
	}

	if err := binary.Read(r, binary.LittleEndian, &idx); err != nil {
		return err
	}

	sprite.Index = int(idx.Index)
	sprite.Type = ColorBits(idx.Type)
	sprite.X = int(idx.X)
	sprite.Y = int(idx.Y)
	sprite.Width = int(idx.Width)
	sprite.Height = int(idx.Height)
	sprite.FrameWidth = int(idx.FrameWidth)
	sprite.FrameHeight = int(idx.FrameHeight)
	sprite.CompressMode = CompressMode(idx.CompressMode)
	sprite.Length = int(idx.Length)
	sprite.TextureIndex = int(idx.TextureIndex)
	sprite.TextureRect = TextureRect{
		LeftUp:    Point{X: int(idx.TexLeftUpX), Y: int(idx.TexLeftUpY)},
		RightDown: Point{X: int(idx.TexRightDownX), Y: int(idx.TexRightDownY)},
		Top:       int(idx.TexTop),
	}

	return nil
}

func (h *FifthHandler) parseSpriteData(sprite *Sprite, r io.Reader) error {
	data := make([]byte, sprite.Length)
	if _, err := io.ReadFull(r, data); err != nil {
		return err
	}
	sprite.Data = data
	return nil
}

func (h *FifthHandler) parseTextureIndex(texture *Texture, r io.Reader) error {
	var idx struct {
		Index      uint32
		Type       uint32
		Width      uint32
		Height     uint32
		Length     uint32
		FullLength uint32
	}

	if err := binary.Read(r, binary.LittleEndian, &idx); err != nil {
		return err
	}

	texture.Index = int(idx.Index)
	texture.Type = ColorBits(idx.Type)
	texture.Width = int(idx.Width)
	texture.Height = int(idx.Height)
	texture.Length = int(idx.Length)
	texture.FullLength = int(idx.FullLength)

	return nil
}

func (h *FifthHandler) parseTextureData(texture *Texture, r io.Reader) error {
	data := make([]byte, texture.Length)
	if _, err := io.ReadFull(r, data); err != nil {
		return err
	}
	texture.Data = data
	return nil
}

func (h *FifthHandler) writeSpriteIndex(w io.Writer, sprite *Sprite) error {
	idx := struct {
		Index         uint32
		Type          uint32
		X             uint32
		Y             uint32
		Width         uint32
		Height        uint32
		FrameWidth    uint32
		FrameHeight   uint32
		CompressMode  uint32
		Length        uint32
		TextureIndex  uint32
		TexLeftUpX    uint32
		TexLeftUpY    uint32
		TexRightDownX uint32
		TexRightDownY uint32
		TexTop        uint32
	}{
		Index:         uint32(sprite.Index),
		Type:          uint32(sprite.Type),
		X:             uint32(sprite.X),
		Y:             uint32(sprite.Y),
		Width:         uint32(sprite.Width),
		Height:        uint32(sprite.Height),
		FrameWidth:    uint32(sprite.FrameWidth),
		FrameHeight:   uint32(sprite.FrameHeight),
		CompressMode:  uint32(sprite.CompressMode),
		Length:        uint32(len(sprite.Data)),
		TextureIndex:  uint32(sprite.TextureIndex),
		TexLeftUpX:    uint32(sprite.TextureRect.LeftUp.X),
		TexLeftUpY:    uint32(sprite.TextureRect.LeftUp.Y),
		TexRightDownX: uint32(sprite.TextureRect.RightDown.X),
		TexRightDownY: uint32(sprite.TextureRect.RightDown.Y),
		TexTop:        uint32(sprite.TextureRect.Top),
	}

	return binary.Write(w, binary.LittleEndian, idx)
}

func (h *FifthHandler) writeSpriteData(w io.Writer, sprite *Sprite) error {
	_, err := w.Write(sprite.Data)
	return err
}

func (h *FifthHandler) writeTextureIndex(w io.Writer, texture *Texture) error {
	idx := struct {
		Index      uint32
		Type       uint32
		Width      uint32
		Height     uint32
		Length     uint32
		FullLength uint32
	}{
		Index:      uint32(texture.Index),
		Type:       uint32(texture.Type),
		Width:      uint32(texture.Width),
		Height:     uint32(texture.Height),
		Length:     uint32(len(texture.Data)),
		FullLength: uint32(texture.FullLength),
	}

	return binary.Write(w, binary.LittleEndian, idx)
}

func (h *FifthHandler) writeTextureData(w io.Writer, texture *Texture) error {
	_, err := w.Write(texture.Data)
	return err
}
