// Package document 实现 IMG 编辑的内存模型
// 基于 ExtractorSharp 设计，支持 Ver1/2/4/5/6 版本
package document

import (
	"image"
	"image/color"
	"time"
)

// ImgVersion IMG 版本
type ImgVersion int

const (
	Ver1 ImgVersion = 1
	Ver2 ImgVersion = 2
	Ver4 ImgVersion = 4
	Ver5 ImgVersion = 5
	Ver6 ImgVersion = 6
)

// ColorBits 颜色格式
type ColorBits int

const (
	ARGB_1555 ColorBits = 0x0e // 16位
	ARGB_4444 ColorBits = 0x0f // 16位
	ARGB_8888 ColorBits = 0x10 // 32位
	LINK      ColorBits = 0x11 // 链接
	DXT_1     ColorBits = 0x12 // DXT1压缩
	DXT_3     ColorBits = 0x13 // DXT3压缩
	DXT_5     ColorBits = 0x14 // DXT5压缩
)

// String 返回颜色格式名称
func (c ColorBits) String() string {
	switch c {
	case ARGB_1555:
		return "ARGB1555"
	case ARGB_4444:
		return "ARGB4444"
	case ARGB_8888:
		return "ARGB8888"
	case LINK:
		return "LINK"
	case DXT_1:
		return "DXT1"
	case DXT_3:
		return "DXT3"
	case DXT_5:
		return "DXT5"
	default:
		return "UNKNOWN"
	}
}

// CompressMode 压缩方式
type CompressMode int

const (
	NONE     CompressMode = 0x05 // 无压缩
	ZLIB     CompressMode = 0x06 // ZLIB压缩
	DDS_ZLIB CompressMode = 0x07 // DDS+ZLIB (V5)
)

// Document NPK 文档（内存模型根）
type Document struct {
	// 基础信息
	Name     string    // NPK 文件名
	Path     string    // 文件路径
	Modified time.Time // 修改时间

	// Album 集合
	Albums map[string]*Album // key: album path
	Order  []string          // Album 顺序（支持重排序）

	// 修改追踪
	ModifiedAlbums map[string]bool // 标记修改的 Album
	DeletedAlbums  map[string]bool // 标记删除的 Album
	NewAlbums      map[string]bool // 标记新增的 Album
}

// NewDocument 创建新 Document
func NewDocument(name, path string) *Document {
	return &Document{
		Name:           name,
		Path:           path,
		Modified:       time.Now(),
		Albums:         make(map[string]*Album),
		Order:          []string{},
		ModifiedAlbums: make(map[string]bool),
		DeletedAlbums:  make(map[string]bool),
		NewAlbums:      make(map[string]bool),
	}
}

// IsModified 检查 Document 是否有修改
func (d *Document) IsModified() bool {
	if len(d.ModifiedAlbums) > 0 || len(d.DeletedAlbums) > 0 || len(d.NewAlbums) > 0 {
		return true
	}
	for _, album := range d.Albums {
		if album.IsModified {
			return true
		}
	}
	return false
}

// MarkAlbumModified 标记 Album 已修改
func (d *Document) MarkAlbumModified(path string) {
	d.ModifiedAlbums[path] = true
	if album, ok := d.Albums[path]; ok {
		album.IsModified = true
	}
}

// Album IMG 文件
type Album struct {
	// 基础信息
	Path    string     // 完整路径 (如 "sprite/item/test.img")
	Name    string     // 文件名
	Version ImgVersion // IMG 版本

	// 文件位置（在 NPK 中）
	Offset int64 // 起始偏移
	Length int64 // 数据长度

	// Sprite 集合
	Sprites []*Sprite // 贴图列表（按索引有序）

	// V5+ 特有
	Tables   [][]color.Color // 色表集合
	Textures []*Texture      // DDS 纹理集

	// 修改追踪
	IsModified      bool         // 是否修改
	IsDeleted       bool         // 是否删除
	IsNew           bool         // 是否新建
	ModifiedSprites map[int]bool // 修改的 Sprite 索引
	DeletedSprites  map[int]bool // 删除的 Sprite 索引
	NewSprites      map[int]bool // 新增的 Sprite 索引
}

// NewAlbum 创建新 Album
func NewAlbum(path string, version ImgVersion) *Album {
	return &Album{
		Path:            path,
		Name:            extractFileName(path),
		Version:         version,
		Sprites:         []*Sprite{},
		Tables:          [][]color.Color{},
		Textures:        []*Texture{},
		ModifiedSprites: make(map[int]bool),
		DeletedSprites:  make(map[int]bool),
		NewSprites:      make(map[int]bool),
	}
}

// GetSpriteByIndex 根据索引获取 Sprite
func (a *Album) GetSpriteByIndex(index int) *Sprite {
	for _, s := range a.Sprites {
		if s.Index == index {
			return s
		}
	}
	return nil
}

// MarkSpriteModified 标记 Sprite 已修改
func (a *Album) MarkSpriteModified(index int) {
	a.ModifiedSprites[index] = true
	a.IsModified = true
}

// Sprite 贴图/帧
type Sprite struct {
	// 基础信息
	Index int       // 帧索引
	Type  ColorBits // 颜色格式

	// 几何信息
	X, Y          int // 基准坐标
	Width, Height int // 图像尺寸
	FrameWidth    int // 帧域宽度
	FrameHeight   int // 帧域高度

	// 压缩与数据
	CompressMode CompressMode // 压缩方式
	Length       int          // 压缩后数据长度
	Data         []byte       // 压缩后的图像数据

	// 图像数据（内存中，懒加载）
	Image    *image.RGBA // 解码后的位图
	IsLoaded bool        // 是否已加载

	// 链接类型特有
	TargetIndex int    // 链接目标索引（Type == LINK 时有效）
	Target      *Sprite // 链接目标引用（运行时解析）

	// V5+ 纹理映射
	TextureIndex int         // 所属纹理集索引（-1 表示无）
	TextureRect  TextureRect // 在纹理集中的位置

	// 修改追踪
	IsModified bool // 是否修改
	IsDeleted  bool // 是否删除
	IsNew      bool // 是否新建
}

// NewSprite 创建新 Sprite
func NewSprite(album *Album, index int) *Sprite {
	return &Sprite{
		Index:        index,
		Type:         ARGB_1555,
		Width:        1,
		Height:       1,
		FrameWidth:   1,
		FrameHeight:  1,
		CompressMode: ZLIB,
		TextureIndex: -1,
	}
}

// TextureRect 纹理映射矩形
type TextureRect struct {
	LeftUp     Point // 左上角
	RightDown  Point // 右下角
	Top        int   // 旋转标记
}

// Point 坐标点
type Point struct {
	X, Y int
}

// Texture V5+ DDS 纹理集
type Texture struct {
	Index      int       // 纹理索引
	Type       ColorBits // DXT1/DXT3/DXT5
	Width      int       // 纹理宽度
	Height     int       // 纹理高度
	Length     int       // 压缩后长度
	FullLength int       // 解压后长度
	Data       []byte    // 压缩数据

	// 运行时
	Image    *image.RGBA // 解码后的纹理
	IsLoaded bool
}

// 辅助函数

func extractFileName(path string) string {
	for i := len(path) - 1; i >= 0; i-- {
		if path[i] == '/' || path[i] == '\\' {
			return path[i+1:]
		}
	}
	return path
}
