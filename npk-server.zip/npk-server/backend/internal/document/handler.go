package document

import (
	"io"
)

// Handler IMG 处理器接口
type Handler interface {
	Parse(album *Album, r io.Reader) error
	Serialize(album *Album) ([]byte, error)
}

// GetHandler 根据版本获取处理器
func GetHandler(version ImgVersion) Handler {
	switch version {
	case Ver1:
		return &FirstHandler{}
	case Ver2:
		return &SecondHandler{}
	case Ver4:
		return &FourthHandler{}
	case Ver5:
		return &FifthHandler{}
	case Ver6:
		return &SixthHandler{}
	default:
		return &SecondHandler{} // 默认使用 Ver2
	}
}
