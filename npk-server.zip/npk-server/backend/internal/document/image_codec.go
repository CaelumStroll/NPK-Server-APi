package document

import (
	"fmt"
	"image"
	"image/color"
)

// decodeColorFormat 根据颜色格式解码
func decodeColorFormat(data []byte, width, height int, format ColorBits) (*image.RGBA, error) {
	switch format {
	case ARGB_1555:
		return decodeARGB1555(data, width, height)
	case ARGB_4444:
		return decodeARGB4444(data, width, height)
	case ARGB_8888:
		return decodeARGB8888(data, width, height)
	default:
		return nil, fmt.Errorf("unsupported color format: %v", format)
	}
}

// encodeColorFormat 根据颜色格式编码
func encodeColorFormat(img *image.RGBA, format ColorBits) ([]byte, error) {
	switch format {
	case ARGB_1555:
		return encodeARGB1555(img)
	case ARGB_4444:
		return encodeARGB4444(img)
	case ARGB_8888:
		return encodeARGB8888(img)
	default:
		return nil, fmt.Errorf("unsupported color format: %v", format)
	}
}

// ARGB1555 解码 (16位: 1位Alpha + 5位RGB)
func decodeARGB1555(data []byte, width, height int) (*image.RGBA, error) {
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	idx := 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			if idx+1 >= len(data) {
				break
			}
			pixel := uint16(data[idx]) | uint16(data[idx+1])<<8
			idx += 2

			// ARGB1555: A(1) R(5) G(5) B(5)
			a := uint8((pixel >> 15) * 255)
			r := uint8(((pixel >> 10) & 0x1F) * 255 / 31)
			g := uint8(((pixel >> 5) & 0x1F) * 255 / 31)
			b := uint8((pixel & 0x1F) * 255 / 31)

			img.SetRGBA(x, y, color.RGBA{R: r, G: g, B: b, A: a})
		}
	}

	return img, nil
}

// ARGB4444 解码 (16位: 4位ARGB)
func decodeARGB4444(data []byte, width, height int) (*image.RGBA, error) {
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	idx := 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			if idx+1 >= len(data) {
				break
			}
			pixel := uint16(data[idx]) | uint16(data[idx+1])<<8
			idx += 2

			// ARGB4444: A(4) R(4) G(4) B(4)
			a := uint8((pixel >> 12) & 0x0F * 255 / 15)
			r := uint8((pixel >> 8) & 0x0F * 255 / 15)
			g := uint8((pixel >> 4) & 0x0F * 255 / 15)
			b := uint8(pixel & 0x0F * 255 / 15)

			img.SetRGBA(x, y, color.RGBA{R: r, G: g, B: b, A: a})
		}
	}

	return img, nil
}

// ARGB8888 解码 (32位)
func decodeARGB8888(data []byte, width, height int) (*image.RGBA, error) {
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	idx := 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			if idx+3 >= len(data) {
				break
			}
			img.SetRGBA(x, y, color.RGBA{
				B: data[idx],
				G: data[idx+1],
				R: data[idx+2],
				A: data[idx+3],
			})
			idx += 4
		}
	}

	return img, nil
}

// encodeARGB1555 ARGB1555 编码
func encodeARGB1555(img *image.RGBA) ([]byte, error) {
	bounds := img.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	data := make([]byte, width*height*2)
	idx := 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			c := img.RGBAAt(x, y)
			a := uint16(c.A / 255)
			r := uint16(c.R * 31 / 255)
			g := uint16(c.G * 31 / 255)
			b := uint16(c.B * 31 / 255)

			pixel := (a << 15) | (r << 10) | (g << 5) | b
			data[idx] = byte(pixel)
			data[idx+1] = byte(pixel >> 8)
			idx += 2
		}
	}

	return data, nil
}

// encodeARGB4444 ARGB4444 编码
func encodeARGB4444(img *image.RGBA) ([]byte, error) {
	bounds := img.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	data := make([]byte, width*height*2)
	idx := 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			c := img.RGBAAt(x, y)
			a := uint16(c.A * 15 / 255)
			r := uint16(c.R * 15 / 255)
			g := uint16(c.G * 15 / 255)
			b := uint16(c.B * 15 / 255)

			pixel := (a << 12) | (r << 8) | (g << 4) | b
			data[idx] = byte(pixel)
			data[idx+1] = byte(pixel >> 8)
			idx += 2
		}
	}

	return data, nil
}

// encodeARGB8888 ARGB8888 编码
func encodeARGB8888(img *image.RGBA) ([]byte, error) {
	bounds := img.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	data := make([]byte, width*height*4)
	idx := 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			c := img.RGBAAt(x, y)
			data[idx] = c.B
			data[idx+1] = c.G
			data[idx+2] = c.R
			data[idx+3] = c.A
			idx += 4
		}
	}

	return data, nil
}

// decodeDXT 解码 DXT 压缩纹理
func decodeDXT(data []byte, width, height int, format ColorBits) (*image.RGBA, error) {
	switch format {
	case DXT_1:
		return decodeDXT1(data, width, height)
	case DXT_3:
		return decodeDXT3(data, width, height)
	case DXT_5:
		return decodeDXT5(data, width, height)
	default:
		return nil, fmt.Errorf("unsupported DXT format: %v", format)
	}
}

// decodeDXT1 DXT1 解码
func decodeDXT1(data []byte, width, height int) (*image.RGBA, error) {
	// TODO: 实现 DXT1 解码
	// 简化实现：返回占位图像
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	return img, nil
}

// decodeDXT3 DXT3 解码
func decodeDXT3(data []byte, width, height int) (*image.RGBA, error) {
	// TODO: 实现 DXT3 解码
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	return img, nil
}

// decodeDXT5 DXT5 解码
func decodeDXT5(data []byte, width, height int) (*image.RGBA, error) {
	// TODO: 实现 DXT5 解码
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	return img, nil
}
