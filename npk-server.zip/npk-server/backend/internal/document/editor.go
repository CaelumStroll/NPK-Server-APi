package document

import (
	"fmt"
	"image"
)

// Editor 提供 Document 编辑操作
type Editor struct {
	doc *Document
}

// NewEditor 创建编辑器
func NewEditor(doc *Document) *Editor {
	return &Editor{doc: doc}
}

// ========== Album 操作 ==========

// NewAlbum 新建 IMG
func (e *Editor) NewAlbum(path string, version ImgVersion) (*Album, error) {
	if _, exists := e.doc.Albums[path]; exists {
		return nil, fmt.Errorf("album %s already exists", path)
	}

	album := NewAlbum(path, version)
	album.IsNew = true

	e.doc.Albums[path] = album
	e.doc.Order = append(e.doc.Order, path)
	e.doc.NewAlbums[path] = true
	e.doc.MarkAlbumModified(path)

	return album, nil
}

// DeleteAlbum 删除 IMG
func (e *Editor) DeleteAlbum(path string) error {
	album, exists := e.doc.Albums[path]
	if !exists {
		return fmt.Errorf("album %s not found", path)
	}

	if album.IsNew {
		// 新建的 Album，直接删除
		delete(e.doc.Albums, path)
		delete(e.doc.NewAlbums, path)
		e.removeFromOrder(path)
	} else {
		// 已存在的 Album，标记删除
		album.IsDeleted = true
		e.doc.DeletedAlbums[path] = true
		e.doc.MarkAlbumModified(path)
	}

	return nil
}

// RenameAlbum 重命名 IMG
func (e *Editor) RenameAlbum(oldPath, newPath string) error {
	album, exists := e.doc.Albums[oldPath]
	if !exists {
		return fmt.Errorf("album %s not found", oldPath)
	}

	if _, exists := e.doc.Albums[newPath]; exists {
		return fmt.Errorf("album %s already exists", newPath)
	}

	// 更新路径
	album.Path = newPath
	album.Name = extractFileName(newPath)

	// 更新 Document
	delete(e.doc.Albums, oldPath)
	e.doc.Albums[newPath] = album

	// 更新 Order
	for i, p := range e.doc.Order {
		if p == oldPath {
			e.doc.Order[i] = newPath
			break
		}
	}

	// 更新修改追踪
	if album.IsNew {
		delete(e.doc.NewAlbums, oldPath)
		e.doc.NewAlbums[newPath] = true
	} else {
		e.doc.ModifiedAlbums[newPath] = true
		delete(e.doc.ModifiedAlbums, oldPath)
	}

	return nil
}

// MoveAlbum 移动 Album 顺序
func (e *Editor) MoveAlbum(fromIndex, toIndex int) error {
	if fromIndex < 0 || fromIndex >= len(e.doc.Order) {
		return fmt.Errorf("fromIndex out of range")
	}
	if toIndex < 0 || toIndex >= len(e.doc.Order) {
		return fmt.Errorf("toIndex out of range")
	}

	path := e.doc.Order[fromIndex]

	// 移除
	e.doc.Order = append(e.doc.Order[:fromIndex], e.doc.Order[fromIndex+1:]...)

	// 插入到新位置
	if toIndex > fromIndex {
		toIndex--
	}
	e.doc.Order = append(e.doc.Order[:toIndex], append([]string{path}, e.doc.Order[toIndex:]...)...)

	return nil
}

// ConvertAlbumVersion 转换 Album 版本
func (e *Editor) ConvertAlbumVersion(path string, targetVersion ImgVersion) error {
	album, exists := e.doc.Albums[path]
	if !exists {
		return fmt.Errorf("album %s not found", path)
	}

	if album.Version == targetVersion {
		return nil
	}

	// 版本转换逻辑
	switch targetVersion {
	case Ver4, Ver6:
		// 强制转换为 ARGB_1555
		for _, sprite := range album.Sprites {
			sprite.Type = ARGB_1555
		}
	case Ver5:
		// 需要构建纹理集（复杂操作）
		if err := e.buildTextureAtlas(album); err != nil {
			return fmt.Errorf("build texture atlas failed: %w", err)
		}
	}

	album.Version = targetVersion
	album.IsModified = true
	e.doc.MarkAlbumModified(path)

	return nil
}

// ========== 保存 ==========

// Save 保存 Document
func (e *Editor) Save() error {
	// 1. 处理删除的 Album
	for path := range e.doc.DeletedAlbums {
		delete(e.doc.Albums, path)
	}

	// 2. 序列化每个 Album
	for path, album := range e.doc.Albums {
		if album.IsModified || album.IsNew {
			handler := GetHandler(album.Version)
			data, err := handler.Serialize(album)
			if err != nil {
				return fmt.Errorf("serialize album %s failed: %w", path, err)
			}
			// TODO: 写入 NPK 文件
			_ = data
		}
	}

	// 3. 清理修改标记
	e.doc.ModifiedAlbums = make(map[string]bool)
	e.doc.DeletedAlbums = make(map[string]bool)
	e.doc.NewAlbums = make(map[string]bool)

	return nil
}

// ========== 辅助函数 ==========

func (e *Editor) removeFromOrder(path string) {
	for i, p := range e.doc.Order {
		if p == path {
			e.doc.Order = append(e.doc.Order[:i], e.doc.Order[i+1:]...)
			break
		}
	}
}

func (e *Editor) buildTextureAtlas(album *Album) error {
	// TODO: 实现纹理集构建算法
	// 1. 收集所有非 LINK Sprite
	// 2. 按尺寸排序
	// 3. 使用矩形打包算法分配到纹理
	// 4. 生成 DXT 压缩的纹理数据
	return fmt.Errorf("texture atlas building not implemented")
}

func calculateTrimBounds(img *image.RGBA) image.Rectangle {
	bounds := img.Bounds()
	minX, minY := bounds.Max.X, bounds.Max.Y
	maxX, maxY := bounds.Min.X, bounds.Min.Y

	found := false
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			_, _, _, a := img.At(x, y).RGBA()
			if a > 0 {
				found = true
				if x < minX { minX = x }
				if y < minY { minY = y }
				if x > maxX { maxX = x }
				if y > maxY { maxY = y }
			}
		}
	}

	if !found {
		return image.Rectangle{}
	}

	return image.Rect(minX, minY, maxX+1, maxY+1)
}

// SpriteOptions Sprite 创建选项
type SpriteOptions struct {
	X, Y         int
	FrameWidth   int
	FrameHeight  int
	Type         ColorBits
}
