package document

import (
	"bytes"
	"fmt"
	"image"
	"image/draw"
	"image/png"
)

// GetImage 获取解码后的图像（懒加载）
func (s *Sprite) GetImage(album *Album) (*image.RGBA, error) {
	if s.IsLoaded && s.Image != nil {
		return s.Image, nil
	}

	// 链接类型
	if s.Type == LINK && s.Target != nil {
		return s.Target.GetImage(album)
	}

	// V5+ 且使用纹理
	if album.Version == Ver5 && s.TextureIndex >= 0 && s.TextureIndex < len(album.Textures) {
		return s.getImageFromTexture(album)
	}

	// 从 Data 解码
	img, err := s.decodeFromData()
	if err != nil {
		return nil, fmt.Errorf("decode sprite %d failed: %w", s.Index, err)
	}

	s.Image = img
	s.IsLoaded = true
	return img, nil
}

// Unload 释放图像内存（保留 Data）
func (s *Sprite) Unload() {
	s.Image = nil
	s.IsLoaded = false
}

// decodeFromData 从压缩数据解码图像
func (s *Sprite) decodeFromData() (*image.RGBA, error) {
	if len(s.Data) == 0 {
		return image.NewRGBA(image.Rect(0, 0, s.Width, s.Height)), nil
	}

	// 解压数据
	var rawData []byte
	var err error

	switch s.CompressMode {
	case ZLIB:
		rawData, err = decompressZlib(s.Data, s.getUncompressedSize())
	case NONE:
		rawData = s.Data
	default:
		return nil, fmt.Errorf("unsupported compress mode: %d", s.CompressMode)
	}

	if err != nil {
		return nil, err
	}

	// 根据颜色格式解码
	return decodeColorFormat(rawData, s.Width, s.Height, s.Type)
}

// getImageFromTexture 从 V5 纹理集获取图像
func (s *Sprite) getImageFromTexture(album *Album) (*image.RGBA, error) {
	texture := album.Textures[s.TextureIndex]

	// 确保纹理已加载
	if !texture.IsLoaded || texture.Image == nil {
		if err := texture.Load(); err != nil {
			return nil, fmt.Errorf("load texture %d failed: %w", s.TextureIndex, err)
		}
	}

	// 裁剪纹理区域
	rect := s.TextureRect
	srcRect := image.Rect(
		rect.LeftUp.X, rect.LeftUp.Y,
		rect.RightDown.X, rect.RightDown.Y,
	)

	// 创建目标图像
	dst := image.NewRGBA(image.Rect(0, 0, s.Width, s.Height))
	draw.Draw(dst, dst.Bounds(), texture.Image, srcRect.Min, draw.Src)

	// 处理旋转 (Top != 0 表示需要旋转)
	if rect.Top != 0 {
		dst = rotateImage(dst)
	}

	return dst, nil
}

// EncodeImage 将图像编码为压缩数据
func (s *Sprite) EncodeImage(img *image.RGBA, targetType ColorBits) error {
	// 根据目标格式编码
	rawData, err := encodeColorFormat(img, targetType)
	if err != nil {
		return err
	}

	// 压缩数据
	compressed, err := compressZlib(rawData)
	if err != nil {
		return err
	}

	s.Data = compressed
	s.Length = len(compressed)
	s.Type = targetType
	s.Width = img.Bounds().Dx()
	s.Height = img.Bounds().Dy()
	s.CompressMode = ZLIB

	// 更新内存中的图像
	s.Image = img
	s.IsLoaded = true

	return nil
}

// getUncompressedSize 计算解压后大小
func (s *Sprite) getUncompressedSize() int {
	bpp := 2 // 默认16位
	if s.Type == ARGB_8888 {
		bpp = 4
	}
	return s.Width * s.Height * bpp
}

// Load 加载纹理图像
func (t *Texture) Load() error {
	if t.IsLoaded && t.Image != nil {
		return nil
	}

	if len(t.Data) == 0 {
		return fmt.Errorf("texture %d has no data", t.Index)
	}

	// 解压数据
	rawData, err := decompressZlib(t.Data, t.FullLength)
	if err != nil {
		return fmt.Errorf("decompress texture failed: %w", err)
	}

	// 解码 DXT 格式
	img, err := decodeDXT(rawData, t.Width, t.Height, t.Type)
	if err != nil {
		return fmt.Errorf("decode DXT failed: %w", err)
	}

	t.Image = img
	t.IsLoaded = true
	return nil
}

// Unload 释放纹理内存
func (t *Texture) Unload() {
	t.Image = nil
	t.IsLoaded = false
}

// rotateImage 旋转图像 90 度
func rotateImage(img *image.RGBA) *image.RGBA {
	bounds := img.Bounds()
	w, h := bounds.Dx(), bounds.Dy()

	// 创建新图像（宽高互换）
	rotated := image.NewRGBA(image.Rect(0, 0, h, w))

	// 顺时针旋转 90 度
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			rotated.SetRGBA(h-1-y, x, img.RGBAAt(x, y))
		}
	}

	return rotated
}

// PNG 辅助函数

// SpriteToPNG 将 Sprite 转换为 PNG 字节
func SpriteToPNG(sprite *Sprite, album *Album) ([]byte, error) {
	img, err := sprite.GetImage(album)
	if err != nil {
		return nil, err
	}

	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

// PNGToSprite 将 PNG 字节转换为 Sprite 数据
func PNGToSprite(data []byte) (*image.RGBA, error) {
	img, err := png.Decode(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}

	// 转换为 RGBA
	bounds := img.Bounds()
	rgba := image.NewRGBA(bounds)
	draw.Draw(rgba, bounds, img, bounds.Min, draw.Src)

	return rgba, nil
}

// 压缩/解压辅助函数

func compressZlib(data []byte) ([]byte, error) {
	// TODO: 使用 zlib 压缩
	// 简化实现：直接返回
	return data, nil
}

func decompressZlib(data []byte, uncompressedSize int) ([]byte, error) {
	// TODO: 使用 zlib 解压
	// 简化实现：直接返回
	return data, nil
}
