package document

import (
	"fmt"
	"io"
)

// FirstHandler Ver1 处理器
type FirstHandler struct{}

func (h *FirstHandler) Parse(album *Album, r io.Reader) error {
	// Ver1 无 IMG_FLAG 头，直接解析索引
	return h.parseIndex(album, r)
}

func (h *FirstHandler) Serialize(album *Album) ([]byte, error) {
	return h.buildIndex(album)
}

func (h *FirstHandler) parseIndex(album *Album, r io.Reader) error {
	// TODO: 实现 Ver1 索引解析
	return fmt.Errorf("Ver1 not implemented")
}

func (h *FirstHandler) buildIndex(album *Album) ([]byte, error) {
	return nil, fmt.Errorf("Ver1 not implemented")
}
