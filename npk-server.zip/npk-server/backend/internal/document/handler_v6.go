package document

import (
	"io"
)

// SixthHandler Ver6 处理器（强制 ARGB_1555）
type SixthHandler struct {
	SecondHandler
}

func (h *SixthHandler) Parse(album *Album, r io.Reader) error {
	if err := h.SecondHandler.Parse(album, r); err != nil {
		return err
	}
	// Ver6 强制使用 ARGB_1555
	for _, sprite := range album.Sprites {
		sprite.Type = ARGB_1555
	}
	return nil
}

func (h *SixthHandler) Serialize(album *Album) ([]byte, error) {
	// 强制转换所有 Sprite 为 ARGB_1555
	for _, sprite := range album.Sprites {
		sprite.Type = ARGB_1555
	}
	return h.SecondHandler.Serialize(album)
}
