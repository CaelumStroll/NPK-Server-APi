package document

import (
	"fmt"
	"image"
	"sort"
)

// BatchReplace 批量替换
func (e *Editor) BatchReplace(albumPath string, replacements map[int]*image.RGBA) error {
	for index, img := range replacements {
		if err := e.ReplaceSpriteImage(albumPath, index, img, 0); err != nil {
			return fmt.Errorf("replace sprite %d failed: %w", index, err)
		}
	}
	return nil
}

// BatchAdjust 批量调整
func (e *Editor) BatchAdjust(albumPath string, adjustFn func(*Sprite) error) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	for _, sprite := range album.Sprites {
		if err := adjustFn(sprite); err != nil {
			return fmt.Errorf("adjust sprite %d failed: %w", sprite.Index, err)
		}
	}

	return nil
}

// SortSpritesBySize 按尺寸排序
func (e *Editor) SortSpritesBySize(albumPath string) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	sort.Slice(album.Sprites, func(i, j int) bool {
		areaI := album.Sprites[i].Width * album.Sprites[i].Height
		areaJ := album.Sprites[j].Width * album.Sprites[j].Height
		return areaI > areaJ // 从大到小
	})

	// 更新索引
	for i, sprite := range album.Sprites {
		sprite.Index = i
	}

	album.IsModified = true
	e.doc.MarkAlbumModified(albumPath)

	return nil
}
