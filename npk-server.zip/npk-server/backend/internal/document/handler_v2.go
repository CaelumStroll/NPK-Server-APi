package document

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
)

// SecondHandler Ver2 处理器
type SecondHandler struct{}

func (h *SecondHandler) Parse(album *Album, r io.Reader) error {
	// 读取 IMG_FLAG
	var flag uint32
	if err := binary.Read(r, binary.LittleEndian, &flag); err != nil {
		return fmt.Errorf("read flag failed: %w", err)
	}

	if flag != 0x534E4646 { // "FFNS" little-endian
		return fmt.Errorf("invalid IMG flag: 0x%08X", flag)
	}

	// 读取版本
	var version uint32
	if err := binary.Read(r, binary.LittleEndian, &version); err != nil {
		return fmt.Errorf("read version failed: %w", err)
	}
	album.Version = ImgVersion(version)

	// 读取索引数量
	var indexCount uint32
	if err := binary.Read(r, binary.LittleEndian, &indexCount); err != nil {
		return fmt.Errorf("read index count failed: %w", err)
	}

	// 解析索引
	album.Sprites = make([]*Sprite, 0, indexCount)
	for i := uint32(0); i < indexCount; i++ {
		sprite := &Sprite{}
		if err := h.parseSpriteIndex(sprite, r); err != nil {
			return fmt.Errorf("parse sprite %d failed: %w", i, err)
		}
		album.Sprites = append(album.Sprites, sprite)
	}

	// 解析数据
	for _, sprite := range album.Sprites {
		if err := h.parseSpriteData(sprite, r); err != nil {
			return fmt.Errorf("parse sprite data %d failed: %w", sprite.Index, err)
		}
	}

	return nil
}

func (h *SecondHandler) Serialize(album *Album) ([]byte, error) {
	var buf bytes.Buffer

	// 写入 IMG_FLAG
	if err := binary.Write(&buf, binary.LittleEndian, uint32(0x534E4646)); err != nil {
		return nil, err
	}

	// 写入版本
	if err := binary.Write(&buf, binary.LittleEndian, uint32(album.Version)); err != nil {
		return nil, err
	}

	// 写入索引数量
	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(album.Sprites))); err != nil {
		return nil, err
	}

	// 写入索引
	for _, sprite := range album.Sprites {
		if err := h.writeSpriteIndex(&buf, sprite); err != nil {
			return nil, err
		}
	}

	// 写入数据
	for _, sprite := range album.Sprites {
		if err := h.writeSpriteData(&buf, sprite); err != nil {
			return nil, err
		}
	}

	return buf.Bytes(), nil
}

func (h *SecondHandler) parseSpriteIndex(sprite *Sprite, r io.Reader) error {
	var idx struct {
		Index        uint32
		Type         uint32
		X            uint32
		Y            uint32
		Width        uint32
		Height       uint32
		FrameWidth   uint32
		FrameHeight  uint32
		CompressMode uint32
		Length       uint32
	}

	if err := binary.Read(r, binary.LittleEndian, &idx); err != nil {
		return err
	}

	sprite.Index = int(idx.Index)
	sprite.Type = ColorBits(idx.Type)
	sprite.X = int(idx.X)
	sprite.Y = int(idx.Y)
	sprite.Width = int(idx.Width)
	sprite.Height = int(idx.Height)
	sprite.FrameWidth = int(idx.FrameWidth)
	sprite.FrameHeight = int(idx.FrameHeight)
	sprite.CompressMode = CompressMode(idx.CompressMode)
	sprite.Length = int(idx.Length)

	return nil
}

func (h *SecondHandler) parseSpriteData(sprite *Sprite, r io.Reader) error {
	data := make([]byte, sprite.Length)
	if _, err := io.ReadFull(r, data); err != nil {
		return err
	}
	sprite.Data = data
	return nil
}

func (h *SecondHandler) writeSpriteIndex(w io.Writer, sprite *Sprite) error {
	idx := struct {
		Index        uint32
		Type         uint32
		X            uint32
		Y            uint32
		Width        uint32
		Height       uint32
		FrameWidth   uint32
		FrameHeight  uint32
		CompressMode uint32
		Length       uint32
	}{
		Index:        uint32(sprite.Index),
		Type:         uint32(sprite.Type),
		X:            uint32(sprite.X),
		Y:            uint32(sprite.Y),
		Width:        uint32(sprite.Width),
		Height:       uint32(sprite.Height),
		FrameWidth:   uint32(sprite.FrameWidth),
		FrameHeight:  uint32(sprite.FrameHeight),
		CompressMode: uint32(sprite.CompressMode),
		Length:       uint32(len(sprite.Data)),
	}

	return binary.Write(w, binary.LittleEndian, idx)
}

func (h *SecondHandler) writeSpriteData(w io.Writer, sprite *Sprite) error {
	_, err := w.Write(sprite.Data)
	return err
}
