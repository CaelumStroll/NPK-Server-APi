package document

import (
	"fmt"
	"image"
)

// AddSprite 添加 Sprite
func (e *Editor) AddSprite(albumPath string, index int, img *image.RGBA, opts SpriteOptions) (*Sprite, error) {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return nil, fmt.Errorf("album %s not found", albumPath)
	}

	// 如果 index < 0，添加到末尾
	if index < 0 {
		index = len(album.Sprites)
	}

	// 检查索引范围
	if index > len(album.Sprites) {
		return nil, fmt.Errorf("index %d out of range", index)
	}

	// 创建 Sprite
	sprite := NewSprite(album, index)
	sprite.X = opts.X
	sprite.Y = opts.Y
	sprite.FrameWidth = opts.FrameWidth
	sprite.FrameHeight = opts.FrameHeight

	// 编码图像
	if err := sprite.EncodeImage(img, opts.Type); err != nil {
		return nil, fmt.Errorf("encode image failed: %w", err)
	}

	sprite.IsNew = true

	// 插入到列表
	album.Sprites = append(album.Sprites[:index], append([]*Sprite{sprite}, album.Sprites[index:]...)...)

	// 更新后续 Sprite 的索引
	for i := index + 1; i < len(album.Sprites); i++ {
		album.Sprites[i].Index = i
	}

	// 标记修改
	album.NewSprites[index] = true
	album.MarkSpriteModified(index)

	return sprite, nil
}

// DeleteSprite 删除 Sprite
func (e *Editor) DeleteSprite(albumPath string, index int) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	sprite := album.GetSpriteByIndex(index)
	if sprite == nil {
		return fmt.Errorf("sprite %d not found", index)
	}

	if sprite.IsNew {
		// 新建的 Sprite，直接删除
		album.Sprites = append(album.Sprites[:index], album.Sprites[index+1:]...)
		delete(album.NewSprites, index)
	} else {
		// 已存在的 Sprite，标记删除
		sprite.IsDeleted = true
		album.DeletedSprites[index] = true
		album.MarkSpriteModified(index)
	}

	// 更新后续 Sprite 的索引
	for i := index; i < len(album.Sprites); i++ {
		album.Sprites[i].Index = i
	}

	return nil
}

// ReplaceSpriteImage 替换 Sprite 图像
func (e *Editor) ReplaceSpriteImage(albumPath string, index int, img *image.RGBA, targetType ColorBits) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	sprite := album.GetSpriteByIndex(index)
	if sprite == nil {
		return fmt.Errorf("sprite %d not found", index)
	}

	// 编码新图像
	if err := sprite.EncodeImage(img, targetType); err != nil {
		return fmt.Errorf("encode image failed: %w", err)
	}

	sprite.IsModified = true
	album.MarkSpriteModified(index)

	return nil
}

// SetSpriteGeometry 修改 Sprite 几何属性
func (e *Editor) SetSpriteGeometry(albumPath string, index int, x, y, width, height, frameW, frameH int) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	sprite := album.GetSpriteByIndex(index)
	if sprite == nil {
		return fmt.Errorf("sprite %d not found", index)
	}

	sprite.X = x
	sprite.Y = y
	sprite.Width = width
	sprite.Height = height
	sprite.FrameWidth = frameW
	sprite.FrameHeight = frameH

	sprite.IsModified = true
	album.MarkSpriteModified(index)

	return nil
}

// TrimSprite 裁剪透明边缘
func (e *Editor) TrimSprite(albumPath string, index int) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	sprite := album.GetSpriteByIndex(index)
	if sprite == nil {
		return fmt.Errorf("sprite %d not found", index)
	}

	img, err := sprite.GetImage(album)
	if err != nil {
		return fmt.Errorf("get image failed: %w", err)
	}

	// 计算裁剪区域
	bounds := calculateTrimBounds(img)
	if bounds.Empty() {
		return fmt.Errorf("image is fully transparent")
	}

	// 裁剪
	trimmed := image.NewRGBA(bounds)
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			trimmed.SetRGBA(x-bounds.Min.X, y-bounds.Min.Y, img.RGBAAt(x, y))
		}
	}

	// 更新坐标
	sprite.X += bounds.Min.X
	sprite.Y += bounds.Min.Y

	// 重新编码
	if err := sprite.EncodeImage(trimmed, sprite.Type); err != nil {
		return fmt.Errorf("encode trimmed image failed: %w", err)
	}

	sprite.IsModified = true
	album.MarkSpriteModified(index)

	return nil
}

// CreateLink 创建链接 Sprite
func (e *Editor) CreateLink(albumPath string, sourceIndex, targetIndex int) error {
	album, exists := e.doc.Albums[albumPath]
	if !exists {
		return fmt.Errorf("album %s not found", albumPath)
	}

	target := album.GetSpriteByIndex(targetIndex)
	if target == nil {
		return fmt.Errorf("target sprite %d not found", targetIndex)
	}

	source := album.GetSpriteByIndex(sourceIndex)
	if source == nil {
		return fmt.Errorf("source sprite %d not found", sourceIndex)
	}

	// 转换为 LINK 类型
	source.Type = LINK
	source.TargetIndex = targetIndex
	source.Target = target
	source.Data = nil
	source.Length = 0
	source.Image = nil
	source.IsLoaded = false

	source.IsModified = true
	album.MarkSpriteModified(sourceIndex)

	return nil
}
