package npk

import (
	"io"
)

// 读取 V6 数据 (多调色板模式)
func readImgV6Data(reader io.Reader, album *Album) error {
	// V6 类似 V4，但支持多个调色板
	return readImgV4Data(reader, album)
}
