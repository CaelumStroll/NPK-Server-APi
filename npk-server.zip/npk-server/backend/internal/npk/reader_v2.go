package npk

import (
	"encoding/binary"
	"fmt"
	"io"
	"log"
)

// 读取 V2+ 格式 IMG
func readImgV2(reader io.Reader, album *Album) error {
	// 读取索引长度 (8 bytes: 4 bytes 0 + 4 bytes actual length)
	var indexLength int64
	if err := binary.Read(reader, binary.LittleEndian, &indexLength); err != nil {
		return err
	}
	album.IndexLength = indexLength

	// 读取版本
	var version int32
	if err := binary.Read(reader, binary.LittleEndian, &version); err != nil {
		return err
	}
	album.Version = ImgVersion(version)

	// 读取数量
	var count int32
	if err := binary.Read(reader, binary.LittleEndian, &count); err != nil {
		return err
	}
	album.Count = int(count)

	// 根据版本读取
	switch album.Version {
	case Ver1:
		return readImgV2Data(reader, album) // V1 也用 V2 数据格式
	case Ver2, Ver3:
		return readImgV2Data(reader, album) // V3 用 V2 处理
	case Ver4:
		return readImgV4Data(reader, album)
	case Ver5:
		return readImgV5Data(reader, album)
	case Ver6:
		return readImgV6Data(reader, album)
	default:
		return readImgV2Data(reader, album)
	}
}

// 读取 V2 数据
func readImgV2Data(reader io.Reader, album *Album) error {
	linkMap := make(map[int]int) // sprite index -> target index

	// 先读取所有索引
	for i := 0; i < album.Count; i++ {
		sprite := &Sprite{
			Index:  i,
			Parent: album,
		}

		var typeCode int32
		if err := binary.Read(reader, binary.LittleEndian, &typeCode); err != nil {
			return err
		}
		sprite.Type = ColorBits(typeCode)

		if sprite.Type == LINK {
			var targetIndex int32
			if err := binary.Read(reader, binary.LittleEndian, &targetIndex); err != nil {
				return err
			}
			linkMap[i] = int(targetIndex)
			album.Sprites = append(album.Sprites, sprite)
			continue
		}

		var compressCode int32
		if err := binary.Read(reader, binary.LittleEndian, &compressCode); err != nil {
			return err
		}
		sprite.CompressMode = CompressMode(compressCode)

		var width, height, length int32
		if err := binary.Read(reader, binary.LittleEndian, &width); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &height); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &length); err != nil {
			return err
		}

		sprite.Width = int(width)
		sprite.Height = int(height)
		sprite.Length = int(length)

		// 验证尺寸是否合理
		if sprite.Width < 0 || sprite.Width > 8192 || sprite.Height < 0 || sprite.Height > 8192 {
			return fmt.Errorf("invalid sprite dimensions %dx%d for sprite %d", sprite.Width, sprite.Height, i)
		}

		var x, y, frameW, frameH int32
		if err := binary.Read(reader, binary.LittleEndian, &x); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &y); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &frameW); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &frameH); err != nil {
			return err
		}

		sprite.X = int(x)
		sprite.Y = int(y)
		sprite.FrameWidth = int(frameW)
		sprite.FrameHeight = int(frameH)

		album.Sprites = append(album.Sprites, sprite)
	}

	// 读取数据
	for i := range album.Sprites {
		sprite := album.Sprites[i]
		if sprite == nil {
			continue
		}
		if sprite.Type == LINK {
			continue
		}
		
		// 根据 CompressMode 确定要读取的数据长度
		var dataLen int
		if sprite.CompressMode == NONE {
			// 无压缩：根据类型计算像素数据长度
			bpp := 2
			if sprite.Type == ARGB_8888 {
				bpp = 4
			}
			dataLen = sprite.Width * sprite.Height * bpp
		} else {
			// ZLIB/DDS_ZLIB 压缩：Length 是压缩后的数据长度
			dataLen = sprite.Length
		}
		
		// 验证 Length
		if dataLen <= 0 || dataLen > 100*1024*1024 {
			log.Printf("跳过异常 sprite %d: length=%d", sprite.Index, dataLen)
			sprite.Data = []byte{}
			continue
		}
		
		sprite.Data = make([]byte, dataLen)
		if _, err := io.ReadFull(reader, sprite.Data); err != nil {
			log.Printf("读取 sprite %d 数据失败: %v", sprite.Index, err)
			sprite.Data = []byte{}
			continue
		}
		sprite.Length = dataLen
	}

	// 解析链接
	for i, targetIdx := range linkMap {
		album.Sprites[i].TargetIndex = targetIdx
		if targetIdx >= 0 && targetIdx < len(album.Sprites) {
			album.Sprites[i].Target = album.Sprites[targetIdx]
		}
	}

	return nil
}
