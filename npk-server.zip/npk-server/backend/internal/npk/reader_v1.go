package npk

import (
	"encoding/binary"
	"io"
)

// 读取 V1 格式 IMG
func readImgV1(reader io.Reader, album *Album) error {
	// V1 格式: 读取索引长度 (4 bytes)
	var indexLength int32
	if err := binary.Read(reader, binary.LittleEndian, &indexLength); err != nil {
		return err
	}
	album.IndexLength = int64(indexLength)

	// 跳过 2 bytes (未知)
	var skip int16
	if err := binary.Read(reader, binary.LittleEndian, &skip); err != nil {
		return err
	}

	// 读取版本 (4 bytes)
	var version int32
	if err := binary.Read(reader, binary.LittleEndian, &version); err != nil {
		return err
	}
	album.Version = ImgVersion(version)

	// 读取数量
	var count int32
	if err := binary.Read(reader, binary.LittleEndian, &count); err != nil {
		return err
	}
	album.Count = int(count)

	linkMap := make(map[int]int)

	for i := 0; i < album.Count; i++ {
		sprite := &Sprite{
			Index:  i,
			Parent: album,
		}

		var typeCode int32
		if err := binary.Read(reader, binary.LittleEndian, &typeCode); err != nil {
			return err
		}
		sprite.Type = ColorBits(typeCode)

		if sprite.Type == LINK {
			var targetIndex int32
			if err := binary.Read(reader, binary.LittleEndian, &targetIndex); err != nil {
				return err
			}
			linkMap[i] = int(targetIndex)
			album.Sprites = append(album.Sprites, sprite)
			continue
		}

		var compressCode int32
		if err := binary.Read(reader, binary.LittleEndian, &compressCode); err != nil {
			return err
		}
		sprite.CompressMode = CompressMode(compressCode)

		var width, height, length int32
		if err := binary.Read(reader, binary.LittleEndian, &width); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &height); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &length); err != nil {
			return err
		}

		sprite.Width = int(width)
		sprite.Height = int(height)
		sprite.Length = int(length)

		// V1 中读取 frame 信息 (X, Y, FrameWidth, FrameHeight)
		var x, y, frameW, frameH int32
		if err := binary.Read(reader, binary.LittleEndian, &x); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &y); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &frameW); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &frameH); err != nil {
			return err
		}
		sprite.X = int(x)
		sprite.Y = int(y)
		sprite.FrameWidth = int(frameW)
		sprite.FrameHeight = int(frameH)

		// V1 中 NONE 压缩需要计算实际长度
		if sprite.CompressMode == NONE {
			sprite.Length = sprite.Width * sprite.Height * 4
			if sprite.Type != ARGB_8888 {
				sprite.Length = sprite.Width * sprite.Height * 2
			}
		}

		// 读取数据
		if sprite.Length > 0 && sprite.Length < 100*1024*1024 {
			sprite.Data = make([]byte, sprite.Length)
			if _, err := io.ReadFull(reader, sprite.Data); err != nil {
				return err
			}
		}

		album.Sprites = append(album.Sprites, sprite)
	}

	// 解析 LINK
	for i, targetIdx := range linkMap {
		album.Sprites[i].TargetIndex = targetIdx
		if targetIdx >= 0 && targetIdx < len(album.Sprites) {
			album.Sprites[i].Target = album.Sprites[targetIdx]
		}
	}

	return nil
}
