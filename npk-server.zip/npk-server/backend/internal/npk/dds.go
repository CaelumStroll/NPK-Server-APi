package npk

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
)

// RawDDSData 存储解析后的 DDS 原始数据
type RawDDSData struct {
	DDSWidth   int
	DDSHeight  int
	Format     string
	BlockBytes int
	RawData    []byte
}

// ParseDDSHeader 解析 DDS 头，返回原始数据信息
// 与 ExtractorSharp DdsDecoder.Decode 完全一致
func ParseDDSHeader(data []byte) (*RawDDSData, error) {
	r := bytes.NewReader(data)

	var magic uint32
	if err := binary.Read(r, binary.LittleEndian, &magic); err != nil {
		return nil, err
	}
	if magic != 0x20534444 {
		return nil, fmt.Errorf("invalid DDS magic: 0x%x", magic)
	}

	var length, flags, ddsHeight, ddsWidth int32
	binary.Read(r, binary.LittleEndian, &length)
	binary.Read(r, binary.LittleEndian, &flags)
	binary.Read(r, binary.LittleEndian, &ddsHeight)
	binary.Read(r, binary.LittleEndian, &ddsWidth)

	// 跳过 pitch, depth, count, reserved[11] (共 14 个 int32 = 56 字节)
	r.Seek(14*4, io.SeekCurrent)

	// 读取像素格式
	var pfSize, pfFlags, fourCC, rgbBitCount int32
	binary.Read(r, binary.LittleEndian, &pfSize)
	binary.Read(r, binary.LittleEndian, &pfFlags)
	binary.Read(r, binary.LittleEndian, &fourCC)
	binary.Read(r, binary.LittleEndian, &rgbBitCount)

	var blockBytes int
	var format string
	switch fourCC {
	case 0x31545844: // "DXT1"
		format = "DXT1"
		blockBytes = 8
	case 0x33545844: // "DXT3"
		format = "DXT3"
		blockBytes = 16
	case 0x35545844: // "DXT5"
		format = "DXT5"
		blockBytes = 16
	default:
		return nil, fmt.Errorf("unsupported DDS format: 0x%x", fourCC)
	}

	// 跳到数据区: header size + 4 (magic)
	dataOffset := int64(length + 4)
	r.Seek(dataOffset, io.SeekStart)

	mipW := int(ddsWidth)
	mipH := int(ddsHeight)
	mipLen := mipW * mipH / 16 * blockBytes
	if mipLen <= 0 {
		return &RawDDSData{
			DDSWidth: mipW, DDSHeight: mipH,
			Format: format, BlockBytes: blockBytes,
			RawData: []byte{},
		}, nil
	}

	mipData := make([]byte, mipLen)
	if _, err := r.Read(mipData); err != nil {
		return nil, fmt.Errorf("读取 mipmap 数据失败: %w", err)
	}

	return &RawDDSData{
		DDSWidth:   mipW,
		DDSHeight:  mipH,
		Format:     format,
		BlockBytes: blockBytes,
		RawData:    mipData,
	}, nil
}

// DDSTexture 表示解析后的 DDS 纹理
type DDSTexture struct {
	Width    int
	Height   int
	Format   string
	Mipmaps  []DDSImage
}

type DDSImage struct {
	Width  int
	Height int
	Data   []byte
}

// DecodeDDS 解码 DDS 数据
func DecodeDDS(data []byte) (*DDSTexture, error) {
	raw, err := ParseDDSHeader(data)
	if err != nil {
		return nil, err
	}

	texture := &DDSTexture{
		Width:  raw.DDSWidth,
		Height: raw.DDSHeight,
		Format: raw.Format,
	}

	var pixels []byte
	switch raw.Format {
	case "DXT1":
		pixels = DecodeDXT1(raw.RawData, raw.DDSWidth, raw.DDSHeight)
	case "DXT3":
		pixels = DecodeDXT3(raw.RawData, raw.DDSWidth, raw.DDSHeight)
	case "DXT5":
		pixels = DecodeDXT5(raw.RawData, raw.DDSWidth, raw.DDSHeight)
	}

	texture.Mipmaps = []DDSImage{
		{Width: raw.DDSWidth, Height: raw.DDSHeight, Data: pixels},
	}

	return texture, nil
}

// DecodeDXT1 解码 DXT1 格式
// 行优先布局，与裁剪代码一致
func DecodeDXT1(data []byte, width, height int) []byte {
	ms := bytes.NewReader(data)
	buf := make([]byte, width*height*4)

	// 行优先: 外层遍历行(y)，内层遍历列(x)
	for y := 0; y < height; y += 4 {
		for x := 0; x < width; x += 4 {
			var co0, co1 uint16
			binary.Read(ms, binary.LittleEndian, &co0)
			binary.Read(ms, binary.LittleEndian, &co1)

			colors := make([][]byte, 4)
			colors[0] = DecodeRgb565(co0)
			colors[1] = DecodeRgb565(co1)
			colors[2] = make([]byte, 4)
			colors[3] = make([]byte, 4)

			if co0 > co1 {
			colors[2][0] = uint8((uint16(colors[0][0])*2 + uint16(colors[1][0])) / 3)
			colors[2][1] = uint8((uint16(colors[0][1])*2 + uint16(colors[1][1])) / 3)
			colors[2][2] = uint8((uint16(colors[0][2])*2 + uint16(colors[1][2])) / 3)
			colors[2][3] = 0xff
			colors[3][0] = uint8((uint16(colors[0][0]) + uint16(colors[1][0])*2) / 3)
			colors[3][1] = uint8((uint16(colors[0][1]) + uint16(colors[1][1])*2) / 3)
			colors[3][2] = uint8((uint16(colors[0][2]) + uint16(colors[1][2])*2) / 3)
			colors[3][3] = 0xff
		} else {
			colors[2][0] = uint8((uint16(colors[0][0]) + uint16(colors[1][0])) / 2)
			colors[2][1] = uint8((uint16(colors[0][1]) + uint16(colors[1][1])) / 2)
			colors[2][2] = uint8((uint16(colors[0][2]) + uint16(colors[1][2])) / 2)
			colors[2][3] = uint8((uint16(colors[0][3]) + uint16(colors[1][3])) / 2)
			// colors[3] 保持为 0（透明色）
		}

			var index uint32
			binary.Read(ms, binary.LittleEndian, &index)

			// 行优先: pos = 4 * (width*row + col)
			for i := 0; i < 16; i++ {
				j := index & 0x3
				row := y + i/4
				col := x + i%4
				pos := 4 * (width*row + col)
				buf[pos+0] = colors[j][0]
				buf[pos+1] = colors[j][1]
				buf[pos+2] = colors[j][2]
				buf[pos+3] = colors[j][3]
				index >>= 2
			}
		}
	}

	return buf
}

// DecodeDXT3 解码 DXT3 格式
// 行优先布局，与裁剪代码一致
func DecodeDXT3(data []byte, width, height int) []byte {
	ms := bytes.NewReader(data)
	buf := make([]byte, width*height*4)

	// 行优先: 外层遍历行(y)，内层遍历列(x)
	for y := 0; y < height; y += 4 {
		for x := 0; x < width; x += 4 {
			// 与 ES 一致: 先读颜色，再读 alpha
			var co0, co1 uint16
			binary.Read(ms, binary.LittleEndian, &co0)
			binary.Read(ms, binary.LittleEndian, &co1)

			var index uint32
			binary.Read(ms, binary.LittleEndian, &index)

			alphas := make([]uint16, 4)
			for i := 0; i < 4; i++ {
				binary.Read(ms, binary.LittleEndian, &alphas[i])
			}

			colors := make([][]byte, 4)
			colors[0] = DecodeRgb565(co0)
			colors[1] = DecodeRgb565(co1)
			colors[2] = make([]byte, 4)
			colors[3] = make([]byte, 4)

			colors[2][0] = uint8((uint16(colors[0][0])*2 + uint16(colors[1][0])) / 3)
			colors[2][1] = uint8((uint16(colors[0][1])*2 + uint16(colors[1][1])) / 3)
			colors[2][2] = uint8((uint16(colors[0][2])*2 + uint16(colors[1][2])) / 3)
			colors[3][0] = uint8((uint16(colors[0][0]) + uint16(colors[1][0])*2) / 3)
			colors[3][1] = uint8((uint16(colors[0][1]) + uint16(colors[1][1])*2) / 3)
			colors[3][2] = uint8((uint16(colors[0][2]) + uint16(colors[1][2])*2) / 3)

			// 行优先: pos = 4 * (width*row + col)
			for i := 0; i < 16; i++ {
				j := index & 0x3
				row := y + i/4
				col := x + i%4
				pos := 4 * (width*row + col)
				// 与 ES 一致: alphas[i/4] & 0xf
				a := uint8(alphas[i/4] & 0xf)
				buf[pos+0] = colors[j][0]
				buf[pos+1] = colors[j][1]
				buf[pos+2] = colors[j][2]
				buf[pos+3] = a | (a << 4)
				index >>= 2
			}
		}
	}

	return buf
}

// DecodeDXT5 解码 DXT5 格式
// 行优先布局，与裁剪代码一致
func DecodeDXT5(data []byte, width, height int) []byte {
	ms := bytes.NewReader(data)
	buf := make([]byte, width*height*4)

	// 行优先: 外层遍历行(y)，内层遍历列(x)
	for y := 0; y < height; y += 4 {
		for x := 0; x < width; x += 4 {
			var a0, a1 uint8
			var err1, err2 error
			a0, err1 = ms.ReadByte()
			a1, err2 = ms.ReadByte()
			if err1 != nil || err2 != nil {
				break
			}

			alphas := make([]byte, 8)
			if a0 > a1 {
				alphas[0] = a0
				alphas[1] = a1
				alphas[2] = (6*a0 + a1) / 7
				alphas[3] = (5*a0 + 2*a1) / 7
				alphas[4] = (4*a0 + 3*a1) / 7
				alphas[5] = (3*a0 + 4*a1) / 7
				alphas[6] = (2*a0 + 5*a1) / 7
				alphas[7] = (a0 + 6*a1) / 7
			} else {
				alphas[0] = a0
				alphas[1] = a1
				alphas[2] = (4*a0 + a1) / 5
				alphas[3] = (3*a0 + 2*a1) / 5
				alphas[4] = (2*a0 + 3*a1) / 5
				alphas[5] = (a0 + 4*a1) / 5
				alphas[6] = 0
				alphas[7] = 255
			}

			alphaBits := Read6Byte(ms)

			var co0, co1 uint16
			binary.Read(ms, binary.LittleEndian, &co0)
			binary.Read(ms, binary.LittleEndian, &co1)

			colors := make([][]byte, 4)
			colors[0] = DecodeRgb565(co0)
			colors[1] = DecodeRgb565(co1)
			colors[2] = make([]byte, 4)
			colors[3] = make([]byte, 4)

			colors[2][0] = uint8((uint16(colors[0][0])*2 + uint16(colors[1][0])) / 3)
			colors[2][1] = uint8((uint16(colors[0][1])*2 + uint16(colors[1][1])) / 3)
			colors[2][2] = uint8((uint16(colors[0][2])*2 + uint16(colors[1][2])) / 3)
			colors[2][3] = 0xff
			colors[3][0] = uint8((uint16(colors[0][0]) + uint16(colors[1][0])*2) / 3)
			colors[3][1] = uint8((uint16(colors[0][1]) + uint16(colors[1][1])*2) / 3)
			colors[3][2] = uint8((uint16(colors[0][2]) + uint16(colors[1][2])*2) / 3)
			colors[3][3] = 0xff

			var index uint32
			binary.Read(ms, binary.LittleEndian, &index)

			// 行优先: pos = 4 * (width*row + col)
			for i := 0; i < 16; i++ {
				j := index & 0x3
				ai := alphaBits & 0x7
				row := y + i/4
				col := x + i%4
				pos := 4 * (width*row + col)
				buf[pos+0] = colors[j][0]
				buf[pos+1] = colors[j][1]
				buf[pos+2] = colors[j][2]
				buf[pos+3] = alphas[ai]
				index >>= 2
				alphaBits >>= 3
			}
		}
	}

	return buf
}

// Read6Byte 读取 6 字节并转换为 uint64
// 与 ExtractorSharp DdsDecoder.Read6Byte 一致
func Read6Byte(ms *bytes.Reader) uint64 {
	buf := make([]byte, 8)
	ms.Read(buf[:6])
	return binary.LittleEndian.Uint64(buf)
}

// decodeRgb565BGRA 解码 RGB565 颜色为 BGRA 格式（用于编码时的颜色比较）
func decodeRgb565BGRA(color uint16) []byte {
	r := uint8(color & 0x1f)
	g := uint8((color >> 5) & 0x3f)
	b := uint8((color >> 11) & 0x1f)

	r = (r << 3) | (r >> 2)
	g = (g << 2) | (g >> 4)
	b = (b << 3) | (b >> 2)

	// 返回 BGRA，与解码输出一致
	return []byte{b, g, r, 0xff}
}

// decodeRgb565RGBA 解码 RGB565 颜色为 RGBA 格式（用于编码）
func decodeRgb565RGBA(color uint16) []byte {
	r := uint8(color & 0x1f)
	g := uint8((color >> 5) & 0x3f)
	b := uint8((color >> 11) & 0x1f)

	r = (r << 3) | (r >> 2)
	g = (g << 2) | (g >> 4)
	b = (b << 3) | (b >> 2)

	return []byte{r, g, b, 0xff}
}

// DecodeRgb565 解码 RGB565 颜色
// 注意：Windows Format32bppArgb 实际是 BGRA 存储
// 所以这里返回 BGRA 格式，与 ES 的实际效果一致
func DecodeRgb565(color uint16) []byte {
	r := uint8(color & 0x1f)
	g := uint8((color >> 5) & 0x3f)
	b := uint8((color >> 11) & 0x1f)
	a := uint8(0xff)

	r = (r << 3) | (r >> 2)
	g = (g << 2) | (g >> 4)
	b = (b << 3) | (b >> 2)

	// 返回 BGRA，因为 Windows Format32bppArgb 实际就是 BGRA
	// 这样 ToImage() 做 BGRA→RGBA 转换后颜色就正确了
	return []byte{b, g, r, a}
}

// encodeRGB565 编码 RGB565 颜色（用于保存）
func encodeRGB565(r, g, b uint8) uint16 {
	r = (r >> 3) & 0x1f
	g = (g >> 2) & 0x3f
	b = (b >> 3) & 0x1f
	return uint16(r) | uint16(g)<<5 | uint16(b)<<11
}

// EncodeDXT1 编码 DXT1 格式（用于保存）
func EncodeDXT1(pixels []byte, width, height int) []byte {
	var buf bytes.Buffer

	for y := 0; y < height; y += 4 {
		for x := 0; x < width; x += 4 {
			// 提取 4x4 块的像素
			block := make([][]byte, 16)
			for row := 0; row < 4; row++ {
				for col := 0; col < 4; col++ {
					px := x + col
					py := y + row
					if px < width && py < height {
						pos := (py*width + px) * 4
						block[row*4+col] = []byte{pixels[pos], pixels[pos+1], pixels[pos+2], pixels[pos+3]}
					} else {
						block[row*4+col] = []byte{0, 0, 0, 0}
					}
				}
			}

			// 计算两个关键颜色（使用块内最小和最大颜色）
			// block 是 BGRA 格式，但 encodeRGB565 期望 (r, g, b)
			var minColor, maxColor uint16
			var minDist, maxDist int = -1, -1

			for i := 0; i < 16; i++ {
				// BGRA -> RGB
				c := encodeRGB565(block[i][2], block[i][1], block[i][0])
				dist := int(block[i][0]) + int(block[i][1]) + int(block[i][2])
				if minDist == -1 || dist < minDist {
					minDist = dist
					minColor = c
				}
				if maxDist == -1 || dist > maxDist {
					maxDist = dist
					maxColor = c
				}
			}

			if minColor == maxColor {
				maxColor = minColor + 1
			}

			binary.Write(&buf, binary.LittleEndian, maxColor)
			binary.Write(&buf, binary.LittleEndian, minColor)

			// 计算颜色索引
			colors := make([][]byte, 4)
			colors[0] = decodeRgb565BGRA(maxColor)
			colors[1] = decodeRgb565BGRA(minColor)
			colors[2] = make([]byte, 4)
			colors[3] = make([]byte, 4)

			colors[2][0] = uint8((uint16(colors[0][0])*2 + uint16(colors[1][0])) / 3)
			colors[2][1] = uint8((uint16(colors[0][1])*2 + uint16(colors[1][1])) / 3)
			colors[2][2] = uint8((uint16(colors[0][2])*2 + uint16(colors[1][2])) / 3)
			colors[2][3] = 255
			colors[3][0] = uint8((uint16(colors[0][0]) + uint16(colors[1][0])*2) / 3)
			colors[3][1] = uint8((uint16(colors[0][1]) + uint16(colors[1][1])*2) / 3)
			colors[3][2] = uint8((uint16(colors[0][2]) + uint16(colors[1][2])*2) / 3)
			colors[3][3] = 255

			var index uint32
			for i := 15; i >= 0; i-- {
				bestIdx := 0
				bestDist := -1
				for j := 0; j < 4; j++ {
					dist := 0
					for k := 0; k < 3; k++ {
						d := int(block[i][k]) - int(colors[j][k])
						if d < 0 {
							d = -d
						}
						dist += d
					}
					if bestDist == -1 || dist < bestDist {
						bestDist = dist
						bestIdx = j
					}
				}
				index = (index << 2) | uint32(bestIdx)
			}

			binary.Write(&buf, binary.LittleEndian, index)
		}
	}

	return buf.Bytes()
}

// BuildDDSFile 构建 DDS 文件（头 + DXT5 编码数据）
// 输入: BGRA 像素数据
func BuildDDSFile(bgraPixels []byte, width, height int) []byte {
	// 直接使用 BGRA 格式编码，与解码输出一致
	dxt5Data := EncodeDXT5(bgraPixels, width, height)

	// 构建 DDS 头
	header := make([]byte, 128)
	binary.LittleEndian.PutUint32(header[0:4], 0x20534444)   // magic "DDS "
	binary.LittleEndian.PutUint32(header[4:8], 124)           // size
	binary.LittleEndian.PutUint32(header[8:12], 0x00081007)   // flags
	binary.LittleEndian.PutUint32(header[12:16], uint32(height))
	binary.LittleEndian.PutUint32(header[16:20], uint32(width))
	binary.LittleEndian.PutUint32(header[20:24], uint32(len(dxt5Data))) // pitchOrLinearSize
	// caps: 0x00001000 = DDSCAPS_TEXTURE
	binary.LittleEndian.PutUint32(header[100:104], 0x00001000)

	// pixel format (offset 76)
	binary.LittleEndian.PutUint32(header[76:80], 32)          // pf size
	binary.LittleEndian.PutUint32(header[80:84], 0x00000004)  // pf flags = DDPF_FOURCC
	binary.LittleEndian.PutUint32(header[84:88], 0x35545844)  // fourCC "DXT5"

	result := append(header, dxt5Data...)
	return result
}

// EncodeDXT5 编码 DXT5 格式（用于保存）
func EncodeDXT5(pixels []byte, width, height int) []byte {
	var buf bytes.Buffer

	for y := 0; y < height; y += 4 {
		for x := 0; x < width; x += 4 {
			// 提取 4x4 块的像素
			block := make([][]byte, 16)
			for row := 0; row < 4; row++ {
				for col := 0; col < 4; col++ {
					px := x + col
					py := y + row
					if px < width && py < height {
						pos := (py*width + px) * 4
						block[row*4+col] = []byte{pixels[pos], pixels[pos+1], pixels[pos+2], pixels[pos+3]}
					} else {
						block[row*4+col] = []byte{0, 0, 0, 0}
					}
				}
			}

			// Alpha: 找 min/max
			var a0, a1 uint8 = 0xff, 0
			for i := 0; i < 16; i++ {
				if block[i][3] < a0 {
					a0 = block[i][3]
				}
				if block[i][3] > a1 {
					a1 = block[i][3]
				}
			}

			buf.WriteByte(a0)
			buf.WriteByte(a1)

			// Alpha 索引
			var alphaBits uint64
			alphas := make([]uint8, 8)
			if a0 <= a1 {
				alphas[0] = a0
				alphas[1] = a1
				alphas[2] = uint8((4*uint16(a0) + uint16(a1)) / 5)
				alphas[3] = uint8((3*uint16(a0) + 2*uint16(a1)) / 5)
				alphas[4] = uint8((2*uint16(a0) + 3*uint16(a1)) / 5)
				alphas[5] = uint8((uint16(a0) + 4*uint16(a1)) / 5)
				alphas[6] = 0
				alphas[7] = 255
			} else {
				alphas[0] = a0
				alphas[1] = a1
				alphas[2] = uint8((6*uint16(a0) + uint16(a1)) / 7)
				alphas[3] = uint8((5*uint16(a0) + 2*uint16(a1)) / 7)
				alphas[4] = uint8((4*uint16(a0) + 3*uint16(a1)) / 7)
				alphas[5] = uint8((3*uint16(a0) + 4*uint16(a1)) / 7)
				alphas[6] = uint8((2*uint16(a0) + 5*uint16(a1)) / 7)
				alphas[7] = uint8((uint16(a0) + 6*uint16(a1)) / 7)
			}

			for i := 15; i >= 0; i-- {
				bestIdx := 0
				bestDist := -1
				for j := 0; j < 8; j++ {
					d := int(block[i][3]) - int(alphas[j])
					if d < 0 {
						d = -d
					}
					if bestDist == -1 || d < bestDist {
						bestDist = d
						bestIdx = j
					}
				}
				alphaBits = (alphaBits << 3) | uint64(bestIdx)
			}

			alphaBuf := make([]byte, 6)
			for k := 0; k < 6; k++ {
				alphaBuf[k] = uint8(alphaBits >> uint(k*8))
			}
			buf.Write(alphaBuf)

			// 颜色: 找 min/max
			// block 是 BGRA 格式，但 encodeRGB565 期望 (r, g, b)
			var minColor, maxColor uint16
			var minDist, maxDist int = -1, -1

			for i := 0; i < 16; i++ {
				// BGRA -> RGB
				c := encodeRGB565(block[i][2], block[i][1], block[i][0])
				dist := int(block[i][0]) + int(block[i][1]) + int(block[i][2])
				if minDist == -1 || dist < minDist {
					minDist = dist
					minColor = c
				}
				if maxDist == -1 || dist > maxDist {
					maxDist = dist
					maxColor = c
				}
			}

			if minColor == maxColor {
				maxColor = minColor + 1
			}

			binary.Write(&buf, binary.LittleEndian, maxColor)
			binary.Write(&buf, binary.LittleEndian, minColor)

			// 颜色索引
			colors := make([][]byte, 4)
			colors[0] = decodeRgb565BGRA(maxColor)
			colors[1] = decodeRgb565BGRA(minColor)
			colors[2] = make([]byte, 4)
			colors[3] = make([]byte, 4)

			colors[2][0] = uint8((uint16(colors[0][0])*2 + uint16(colors[1][0])) / 3)
			colors[2][1] = uint8((uint16(colors[0][1])*2 + uint16(colors[1][1])) / 3)
			colors[2][2] = uint8((uint16(colors[0][2])*2 + uint16(colors[1][2])) / 3)
			colors[2][3] = 255
			colors[3][0] = uint8((uint16(colors[0][0]) + uint16(colors[1][0])*2) / 3)
			colors[3][1] = uint8((uint16(colors[0][1]) + uint16(colors[1][1])*2) / 3)
			colors[3][2] = uint8((uint16(colors[0][2]) + uint16(colors[1][2])*2) / 3)
			colors[3][3] = 255

			var index uint32
			for i := 15; i >= 0; i-- {
				bestIdx := 0
				bestDist := -1
				for j := 0; j < 4; j++ {
					dist := 0
					for k := 0; k < 3; k++ {
						d := int(block[i][k]) - int(colors[j][k])
						if d < 0 {
							d = -d
						}
						dist += d
					}
					if bestDist == -1 || dist < bestDist {
						bestDist = dist
						bestIdx = j
					}
				}
				index = (index << 2) | uint32(bestIdx)
			}

			binary.Write(&buf, binary.LittleEndian, index)
		}
	}

	return buf.Bytes()
}
