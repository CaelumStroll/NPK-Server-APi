package npk

import (
	"encoding/binary"
	"io"
	"log"
)

// 读取 V5 数据 (DDS 纹理模式)
func readImgV5Data(reader io.Reader, album *Album) error {
	// 读取 DDS 索引数量
	var indexCount int32
	if err := binary.Read(reader, binary.LittleEndian, &indexCount); err != nil {
		return err
	}

	// 读取长度
	var length int32
	if err := binary.Read(reader, binary.LittleEndian, &length); err != nil {
		return err
	}

	// 读取调色板数量
	var paletteCount int32
	if err := binary.Read(reader, binary.LittleEndian, &paletteCount); err != nil {
		return err
	}

	palette := make([]RGBA, paletteCount)
	for i := 0; i < int(paletteCount); i++ {
		var r, g, b, a uint8
		if err := binary.Read(reader, binary.LittleEndian, &r); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &g); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &b); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &a); err != nil {
			return err
		}
		palette[i] = RGBA{R: r, G: g, B: b, A: a}
	}
	album.Tables = [][]RGBA{palette}

	// 读取 DDS 纹理列表
	textures := make([]*Texture, indexCount)
	for i := 0; i < int(indexCount); i++ {
		var version, typeCode, idx, dataLen, fullLen, w, h int32
		if err := binary.Read(reader, binary.LittleEndian, &version); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &typeCode); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &idx); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &dataLen); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &fullLen); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &w); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &h); err != nil {
			return err
		}

		textures[i] = &Texture{
			Index:      int(idx),
			Version:    TextureVersion(version),
			Type:       ColorBits(typeCode),
			Length:     int(dataLen),
			FullLength: int(fullLen),
			Width:      int(w),
			Height:     int(h),
		}
	}
	album.Textures = textures

	// 读取 Sprite 索引
	textureInfos := make(map[int]*TextureInfo)
	album.TextureInfos = textureInfos
	linkMap := make(map[int]int)
	var ver2Sprites []*Sprite

	for i := 0; i < album.Count; i++ {
		sprite := &Sprite{
			Index:  i,
			Parent: album,
		}

		var typeCode int32
		if err := binary.Read(reader, binary.LittleEndian, &typeCode); err != nil {
			return err
		}
		sprite.Type = ColorBits(typeCode)

		if sprite.Type == LINK {
			var targetIndex int32
			if err := binary.Read(reader, binary.LittleEndian, &targetIndex); err != nil {
				return err
			}
			linkMap[i] = int(targetIndex)
			album.Sprites = append(album.Sprites, sprite)
			continue
		}

		var compressCode int32
		if err := binary.Read(reader, binary.LittleEndian, &compressCode); err != nil {
			return err
		}
		sprite.CompressMode = CompressMode(compressCode)

		var w, h, dataLen, x, y, frameW, frameH int32
		if err := binary.Read(reader, binary.LittleEndian, &w); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &h); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &dataLen); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &x); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &y); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &frameW); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &frameH); err != nil {
			return err
		}

		sprite.Width = int(w)
		sprite.Height = int(h)
		sprite.Length = int(dataLen)
		sprite.X = int(x)
		sprite.Y = int(y)
		sprite.FrameWidth = int(frameW)
		sprite.FrameHeight = int(frameH)

		// V5 特有: 读取纹理引用信息
		// 根据 ExtractorSharp: Type < LINK 且 Length != 0 是 V2 格式，否则是纹理引用
		if sprite.Type < LINK && sprite.Length != 0 {
			// V2 格式，数据在后面读取
			ver2Sprites = append(ver2Sprites, sprite)
		} else {
			// 纹理引用或 LINK
			var unknown, texIdx, luX, luY, rdX, rdY, top int32
			if err := binary.Read(reader, binary.LittleEndian, &unknown); err != nil {
				return err
			}
			if err := binary.Read(reader, binary.LittleEndian, &texIdx); err != nil {
				return err
			}
			if err := binary.Read(reader, binary.LittleEndian, &luX); err != nil {
				return err
			}
			if err := binary.Read(reader, binary.LittleEndian, &luY); err != nil {
				return err
			}
			if err := binary.Read(reader, binary.LittleEndian, &rdX); err != nil {
				return err
			}
			if err := binary.Read(reader, binary.LittleEndian, &rdY); err != nil {
				return err
			}
			if err := binary.Read(reader, binary.LittleEndian, &top); err != nil {
				return err
			}

			// 确保纹理索引有效
			if texIdx >= 0 && int(texIdx) < len(textures) {
				textureInfos[i] = &TextureInfo{
					Texture:   textures[texIdx],
					LeftUp:    Point{X: int(luX), Y: int(luY)},
				RightDown: Point{X: int(rdX), Y: int(rdY)},
				Top:       int(top),
				Unknown:   int(unknown),
			}
		} else {
			// 纹理索引无效，跳过
		}
		}

		album.Sprites = append(album.Sprites, sprite)
	}

	// 读取 DDS 数据
	for i, tex := range textures {
		if tex.Length <= 0 || tex.Length > 100*1024*1024 {
			log.Printf("跳过异常 DDS texture %d: length=%d", i, tex.Length)
			tex.Data = []byte{}
			continue
		}
		tex.Data = make([]byte, tex.Length)
		if _, err := io.ReadFull(reader, tex.Data); err != nil {
			log.Printf("读取 DDS texture %d 数据失败: %v", i, err)
			tex.Data = []byte{}
			continue
		}
	}

	// 读取 V2 格式 Sprite 数据
	for _, sprite := range ver2Sprites {
		if sprite.Length <= 0 || sprite.Length > 100*1024*1024 {
			sprite.Data = []byte{}
			continue
		}
		sprite.Data = make([]byte, sprite.Length)
		if _, err := io.ReadFull(reader, sprite.Data); err != nil {
			sprite.Data = []byte{}
			continue
		}
	}

	// 解析链接
	for i, targetIdx := range linkMap {
		album.Sprites[i].TargetIndex = targetIdx
		if targetIdx >= 0 && targetIdx < len(album.Sprites) {
			album.Sprites[i].Target = album.Sprites[targetIdx]
		}
	}

	return nil
}
