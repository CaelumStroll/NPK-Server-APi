package npk

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"sort"
)

// ============================================================================
// 像素编码（IMG 数据类 - 像素格式转换）
// ============================================================================

// EncodePixels 将 BGRA 像素编码为指定格式
// 输入 bgra 为 BGRA 排列的字节（每像素 4 字节），输出为编码后的像素字节
// colorBits 支持 ARGB_1555 (0x0e)、ARGB_4444 (0x0f)、ARGB_8888 (0x10)、DXT1/3/5 (0x12/13/14)
func EncodePixels(bgra []byte, colorBits int32) ([]byte, error) {
	pixelCount := len(bgra) / 4
	if pixelCount == 0 {
		return []byte{}, nil
	}

	switch ColorBits(colorBits) {
	case ARGB_8888:
		result := make([]byte, len(bgra))
		copy(result, bgra)
		return result, nil

	case ARGB_1555:
		result := make([]byte, pixelCount*2)
		for i := 0; i < pixelCount; i++ {
			b := bgra[i*4+0]
			g := bgra[i*4+1]
			r := bgra[i*4+2]
			a := bgra[i*4+3]
			a1 := a >> 7
			r5 := r >> 3
			gLeft := g & 7
			gRight := g >> 3
			b5 := b >> 3
			left := byte((gLeft << 5) | b5)
			right := byte((a1 << 7) | (r5 << 2) | gRight)
			result[i*2+0] = left
			result[i*2+1] = right
		}
		return result, nil

	case ARGB_4444:
		result := make([]byte, pixelCount*2)
		for i := 0; i < pixelCount; i++ {
			b := bgra[i*4+0]
			g := bgra[i*4+1]
			r := bgra[i*4+2]
			a := bgra[i*4+3]
			left := byte(g | (b >> 4))
			right := byte(a | (r >> 4))
			result[i*2+0] = left
			result[i*2+1] = right
		}
		return result, nil

	case DXT_1:
		// DXT1 需要知道宽高，这里返回 nil，由调用方使用 BuildDDSFile
		return nil, fmt.Errorf("DXT1 需要使用 BuildDDSFile 编码")

	case DXT_3:
		return nil, fmt.Errorf("DXT3 需要使用 BuildDDSFile 编码")

	case DXT_5:
		// DXT5 需要使用 BuildDDSFile 编码
		return nil, fmt.Errorf("DXT5 需要使用 BuildDDSFile 编码")

	default:
		return nil, fmt.Errorf("不支持的像素格式: 0x%x", colorBits)
	}
}

// ============================================================================
// IMG 数据类 — Sprite 数据准备（编码 + 压缩）
// 参考 ExtractorSharp Sprite.Adjust()
// ============================================================================

// spriteEncoded 表示一个 sprite 编码压缩后的结果
type spriteEncoded struct {
	data         []byte       // 编码压缩后的数据（LINK 类型为 nil）
	compressMode CompressMode // 压缩模式
	length       int32        // 数据长度
}

// prepareSpriteData 准备单个 sprite 的写入数据
// 参考 ExtractorSharp Sprite.Adjust():
//
//	if (Type == LINK) { Length = 0; return; }
//	if (!IsOpen) return;
//	Data = Parent.ConvertToByte(this);
//	if (Data.Length > 0 && CompressMode >= ZLIB) Data = Zlib.Compress(Data);
//	Length = Data.Length;
//
// 参数:
//   - sprite: sprite 对象
//   - bgraData: BGRA 像素数据（编辑过的帧传入，未编辑的传 nil）
//   - rawCompressedData: 原始压缩数据（未编辑的帧传入，编辑过的传 nil）
//
// 返回 spriteEncoded
func prepareSpriteData(sprite *Sprite, bgraData []byte, rawCompressedData []byte) (spriteEncoded, error) {
	// LINK 类型没有数据
	if sprite.Type == LINK {
		return spriteEncoded{}, nil
	}

	// ---- 有 BGRA 数据（编辑过的帧）：BGRA → 编码 → 压缩 ----
	if len(bgraData) > 0 {
		// DXT 格式特殊处理：使用 DDS 编码
		if sprite.Type == DXT_1 || sprite.Type == DXT_3 || sprite.Type == DXT_5 {
			// 目前只支持 DXT5，DXT1/DXT3 也使用 DXT5 编码（兼容性处理）
			ddsFile := BuildDDSFile(bgraData, sprite.Width, sprite.Height)
			if sprite.Width*sprite.Height > 1 {
				compressed, err := ZlibCompress(ddsFile)
				if err != nil {
					return spriteEncoded{}, fmt.Errorf("压缩 sprite %d DDS 数据失败: %w", sprite.Index, err)
				}
				return spriteEncoded{
					data:         compressed,
					compressMode: DDS_ZLIB,
					length:       int32(len(compressed)),
				}, nil
			}
			// 1x1 不压缩
			return spriteEncoded{
				data:         ddsFile,
				compressMode: NONE,
				length:       int32(len(ddsFile)),
			}, nil
		}

		// 普通格式：ARGB_1555/4444/8888
		encoded, err := EncodePixels(bgraData, int32(sprite.Type))
		if err != nil {
			return spriteEncoded{}, fmt.Errorf("编码 sprite %d 像素失败: %w", sprite.Index, err)
		}

		// 参考 ExtractorSharp: if (Data.Length > 0 && CompressMode >= ZLIB) Data = Zlib.Compress(Data);
		// 以及 ReplaceImage 中: if (Width * Height > 1) CompressMode = ZLIB;
		if sprite.Width*sprite.Height > 1 && len(encoded) > 0 {
			compressed, err := ZlibCompress(encoded)
			if err != nil {
				return spriteEncoded{}, fmt.Errorf("压缩 sprite %d 数据失败: %w", sprite.Index, err)
			}
			return spriteEncoded{
				data:         compressed,
				compressMode: ZLIB,
				length:       int32(len(compressed)),
			}, nil
		}
		// 1x1 或空数据：不压缩
		return spriteEncoded{
			data:         encoded,
			compressMode: NONE,
			length:       int32(len(encoded)),
		}, nil
	}

	// ---- 有原始压缩数据（未编辑的帧）：直接使用 ----
	if len(rawCompressedData) > 0 {
		return spriteEncoded{
			data:         rawCompressedData,
			compressMode: sprite.CompressMode,
			length:       int32(len(rawCompressedData)),
		}, nil
	}

	// ---- 无数据：创建空占位 ----
	return spriteEncoded{
		data:         []byte{},
		compressMode: NONE,
		length:       0,
	}, nil
}

// ============================================================================
// IMG 属性类 — 索引区读写（属性序列化）
// ============================================================================

// writeInt32 向 buf 写入一个 int32 小端序
func writeInt32(buf *[]byte, val int32) {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, uint32(val))
	*buf = append(*buf, b...)
}

// writeInt64 向 buf 写入一个 int64 小端序
func writeInt64(buf *[]byte, val int64) {
	b := make([]byte, 8)
	binary.LittleEndian.PutUint64(b, uint64(val))
	*buf = append(*buf, b...)
}

// writeSpriteIndexV2 写入 V2 格式的单个 sprite 索引
// LINK: type(4) + targetIndex(4) = 8 字节
// 非LINK: type(4) + compressMode(4) + width(4) + height(4) + length(4) + x(4) + y(4) + frameWidth(4) + frameHeight(4) = 36 字节
func writeSpriteIndexV2(buf *[]byte, sprite *Sprite, encoded spriteEncoded) {
	writeInt32(buf, int32(sprite.Type))

	if sprite.Type == LINK {
		targetIdx := int32(0)
		if sprite.TargetIndex >= 0 {
			targetIdx = int32(sprite.TargetIndex)
		} else if sprite.Target != nil {
			targetIdx = int32(sprite.Target.Index)
		}
		writeInt32(buf, targetIdx)
	} else {
		writeInt32(buf, int32(encoded.compressMode))
		writeInt32(buf, int32(sprite.Width))
		writeInt32(buf, int32(sprite.Height))
		writeInt32(buf, int32(encoded.length))
		writeInt32(buf, int32(sprite.X))
		writeInt32(buf, int32(sprite.Y))
		writeInt32(buf, int32(sprite.FrameWidth))
		writeInt32(buf, int32(sprite.FrameHeight))
	}
}

// WriteAlbumToData 将 Album 序列化为字节数据（用于独立 IMG 文件）
func WriteAlbumToData(album *Album) ([]byte, error) {
	if album == nil {
		return nil, fmt.Errorf("album 为 nil")
	}

	if len(album.Sprites) == 0 {
		return nil, fmt.Errorf("album 中没有 sprite")
	}

	// 根据版本选择写入方式
	switch album.Version {
	case Ver5:
		return WriteAlbumV5(album, nil)
	case Ver1, Ver2, Ver3, Ver4, Ver6:
		return WriteAlbumV2(album, nil)
	default:
		return WriteAlbumV2(album, nil)
	}
}

// ============================================================================
// NPK 文件写入
// 参考 ExtractorSharp NpkCoder.WriteNpk()
//
// 文件结构:
//   [Header] "NeoplePack_Bill"(16) + count(4)
//   [索引区] 每个 Album 264 字节 (offset(4) + length(4) + encryptedPath(256))
//   [Hash]   SHA-256(32)
//   [Album Data Blocks]
// ============================================================================

// WriteNpk 将多个 Album 写入 NPK 文件
func WriteNpk(filePath string, albums []*Album, allWriteDatas [][]SpriteWriteData, rawAlbumData [][]byte, formatType int, npkName string) error {
	if len(albums) == 0 {
		return fmt.Errorf("没有 album 可写入")
	}

	count := int32(len(albums))

	// 第一步：序列化所有 Album 数据（跳过引用 album，它们共享目标的数据）
	albumDataList := make([][]byte, count)
	for i, album := range albums {
		// 引用 album：跳过数据序列化，它将共享目标的数据块
		if album.TargetPath != "" {
			log.Printf("[WriteNpk] 跳过引用 album 的数据序列化: %s -> %s", album.Path, album.TargetPath)
			continue
		}

		if album.Version == Other {
			if rawAlbumData != nil && i < len(rawAlbumData) && len(rawAlbumData[i]) > 0 {
				albumDataList[i] = rawAlbumData[i]
				continue
			}
			return fmt.Errorf("非 IMG 文件 %s 没有原始数据", album.Path)
		}
		if len(album.Sprites) == 0 {
			return fmt.Errorf("IMG 文件 %s 没有 sprite", album.Path)
		}

		var writeDatas []SpriteWriteData
		if i < len(allWriteDatas) {
			writeDatas = allWriteDatas[i]
		}

		var data []byte
		var err error
		if album.Version == Ver5 {
			data, err = WriteAlbumV5(album, writeDatas)
		} else {
			data, err = WriteAlbumV2(album, writeDatas)
		}
		if err != nil {
			return fmt.Errorf("序列化 album %d (%s) 失败: %w", i, album.Path, err)
		}
		albumDataList[i] = data
	}

	// 第二步：计算偏移和长度
	// 参考 ExtractorSharp: position = 52 + List.Count * 264
	headerSize := int64(16 + 4)
	indexAreaSize := int64(count) * 264
	hashOutputSize := int64(32)
	firstAlbumOffset := headerSize + indexAreaSize + hashOutputSize

	albumOffsets := make([]int64, count)
	albumLengths := make([]int64, count)
	currentOffset := firstAlbumOffset
	
	// 先为非引用 album 分配 offset 和 length
	for i, album := range albums {
		if album.TargetPath != "" {
			continue // 引用 album 稍后处理
		}
		albumOffsets[i] = currentOffset
		albumLengths[i] = int64(len(albumDataList[i]))
		currentOffset += albumLengths[i]
	}
	
	// 为引用 album 设置与目标相同的 offset 和 length
	for i, album := range albums {
		if album.TargetPath == "" {
			continue
		}
		// 找到目标 album
		for j, targetAlbum := range albums {
			if targetAlbum.Path == album.TargetPath {
				albumOffsets[i] = albumOffsets[j]
				albumLengths[i] = albumLengths[j]
				log.Printf("[WriteNpk] 设置引用 album 共享目标数据: %s -> %s (offset=%d, length=%d)", 
					album.Path, targetAlbum.Path, albumOffsets[i], albumLengths[i])
				break
			}
		}
	}

	// 第三步：构建索引区
	indexData := make([]byte, 0, indexAreaSize)
	for i, album := range albums {
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], uint32(albumOffsets[i]))
		indexData = append(indexData, b[:]...)
		binary.LittleEndian.PutUint32(b[:], uint32(albumLengths[i]))
		indexData = append(indexData, b[:]...)
		// 根据 formatType 选择加密方式
		var encryptedPath []byte
		switch formatType {
		case 0: // 标准加密
			encryptedPath = EncryptPath(album.Path)
		case 1: // 明文
			encryptedPath = make([]byte, 256)
			copy(encryptedPath, album.Path)
		case 2: // 名称加密
			encryptedPath = EncryptPathWithNameKey(album.Path, npkName)
		case 99: // 名损坏 - 保存时使用标准加密，确保文件可正常读取
			encryptedPath = EncryptPath(album.Path)
		default: // 默认标准加密
			encryptedPath = EncryptPath(album.Path)
		}
		indexData = append(indexData, encryptedPath...)
	}

	// 第四步：计算 SHA-256 哈希
	hashInputSize := int(indexAreaSize) / 17 * 17
	if hashInputSize > len(indexData) {
		hashInputSize = len(indexData)
	}
	hash := sha256.Sum256(indexData[:hashInputSize])

	// 第五步：写入文件
	file, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("创建文件失败: %w", err)
	}
	defer file.Close()

	// NPK 文件头
	flagBytes := make([]byte, 16)
	copy(flagBytes, NpkFlag)
	if _, err := file.Write(flagBytes); err != nil {
		return fmt.Errorf("写入文件标志失败: %w", err)
	}

	var countBytes [4]byte
	binary.LittleEndian.PutUint32(countBytes[:], uint32(count))
	if _, err := file.Write(countBytes[:]); err != nil {
		return fmt.Errorf("写入 album 数量失败: %w", err)
	}

	if _, err := file.Write(indexData); err != nil {
		return fmt.Errorf("写入索引区失败: %w", err)
	}

	if _, err := file.Write(hash[:]); err != nil {
		return fmt.Errorf("写入哈希失败: %w", err)
	}

	// 按 offset 顺序写入 Album 数据（跳过引用 album，它们共享目标的数据）
	type albumBlock struct {
		offset int64
		data   []byte
	}
	var blocks []albumBlock
	for i := range albumDataList {
		// 跳过空数据块（引用 album 或未序列化的 album）
		if len(albumDataList[i]) == 0 {
			continue
		}
		blocks = append(blocks, albumBlock{offset: albumOffsets[i], data: albumDataList[i]})
	}
	sort.Slice(blocks, func(i, j int) bool {
		return blocks[i].offset < blocks[j].offset
	})

	for _, block := range blocks {
		if _, err := file.Write(block.data); err != nil {
			return fmt.Errorf("写入 album 数据失败: %w", err)
		}
	}

	return nil
}

// WriteNpkToData 将多个 Album 写入字节数据（NPK 格式）
func WriteNpkToData(albums []*Album, formatType int, npkName string) ([]byte, error) {
	if len(albums) == 0 {
		return nil, fmt.Errorf("没有 album 可写入")
	}

	count := int32(len(albums))

	// 第一步：序列化所有 Album 数据
	albumDataList := make([][]byte, count)
	for i, album := range albums {
		if album.Version == Other {
			return nil, fmt.Errorf("非 IMG 文件 %s 无法转换", album.Path)
		}
		if len(album.Sprites) == 0 {
			return nil, fmt.Errorf("IMG 文件 %s 没有 sprite", album.Path)
		}

		var data []byte
		var err error
		if album.Version == Ver5 {
			data, err = WriteAlbumV5(album, nil)
		} else {
			data, err = WriteAlbumV2(album, nil)
		}
		if err != nil {
			return nil, fmt.Errorf("序列化 album %d (%s) 失败: %w", i, album.Path, err)
		}
		albumDataList[i] = data
	}

	// 第二步：计算偏移和长度
	headerSize := int64(16 + 4)
	indexAreaSize := int64(count) * 264
	hashOutputSize := int64(32)
	firstAlbumOffset := headerSize + indexAreaSize + hashOutputSize

	albumOffsets := make([]int64, count)
	albumLengths := make([]int64, count)
	currentOffset := firstAlbumOffset
	for i := range albumDataList {
		albumOffsets[i] = currentOffset
		albumLengths[i] = int64(len(albumDataList[i]))
		currentOffset += albumLengths[i]
	}

	// 第三步：构建索引区
	indexData := make([]byte, 0, indexAreaSize)
	for i, album := range albums {
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], uint32(albumOffsets[i]))
		indexData = append(indexData, b[:]...)
		binary.LittleEndian.PutUint32(b[:], uint32(albumLengths[i]))
		indexData = append(indexData, b[:]...)
		// 根据 formatType 选择加密方式
		var encryptedPath []byte
		switch formatType {
		case 0: // 标准加密
			encryptedPath = EncryptPath(album.Path)
		case 1: // 明文
			encryptedPath = make([]byte, 256)
			copy(encryptedPath, album.Path)
		case 2: // 名称加密
			encryptedPath = EncryptPathWithNameKey(album.Path, npkName)
		case 99: // 名损坏 - 保存时使用标准加密，确保文件可正常读取
			encryptedPath = EncryptPath(album.Path)
		default: // 默认标准加密
			encryptedPath = EncryptPath(album.Path)
		}
		indexData = append(indexData, encryptedPath...)
	}

	// 第四步：计算 SHA-256 哈希
	hashInputSize := int(indexAreaSize) / 17 * 17
	if hashInputSize > len(indexData) {
		hashInputSize = len(indexData)
	}
	hash := sha256.Sum256(indexData[:hashInputSize])

	// 第五步：构建输出数据
	var buf []byte

	// NPK 文件头
	flagBytes := make([]byte, 16)
	copy(flagBytes, NpkFlag)
	buf = append(buf, flagBytes...)

	var countBytes [4]byte
	binary.LittleEndian.PutUint32(countBytes[:], uint32(count))
	buf = append(buf, countBytes[:]...)

	// 索引区
	buf = append(buf, indexData...)

	// 哈希
	buf = append(buf, hash[:]...)

	// Album 数据（按 offset 顺序）
	type albumBlock struct {
		offset int64
		data   []byte
	}
	blocks := make([]albumBlock, count)
	for i := range albumDataList {
		blocks[i] = albumBlock{offset: albumOffsets[i], data: albumDataList[i]}
	}
	sort.Slice(blocks, func(i, j int) bool {
		return blocks[i].offset < blocks[j].offset
	})

	for _, block := range blocks {
		buf = append(buf, block.data...)
	}

	return buf, nil
}

// WriteNpkToDataWithNameKey 将 Album 列表序列化为 NPK 字节数据（使用名称加密）
// npkName 作为加密密钥，用于将标准加密转换为名称加密
func WriteNpkToDataWithNameKey(albums []*Album, npkName string) ([]byte, error) {
	if len(albums) == 0 {
		return nil, fmt.Errorf("没有 album 可写入")
	}

	count := int32(len(albums))

	// 第一步：序列化所有 Album 数据
	albumDataList := make([][]byte, count)
	for i, album := range albums {
		if album.Version == Other {
			return nil, fmt.Errorf("非 IMG 文件 %s 无法转换", album.Path)
		}
		if len(album.Sprites) == 0 {
			return nil, fmt.Errorf("IMG 文件 %s 没有 sprite", album.Path)
		}

		var data []byte
		var err error
		if album.Version == Ver5 {
			data, err = WriteAlbumV5(album, nil)
		} else {
			data, err = WriteAlbumV2(album, nil)
		}
		if err != nil {
			return nil, fmt.Errorf("序列化 album %d (%s) 失败: %w", i, album.Path, err)
		}
		albumDataList[i] = data
	}

	// 第二步：计算偏移和长度
	headerSize := int64(16 + 4)
	indexAreaSize := int64(count) * 264
	hashOutputSize := int64(32)
	firstAlbumOffset := headerSize + indexAreaSize + hashOutputSize

	albumOffsets := make([]int64, count)
	albumLengths := make([]int64, count)
	currentOffset := firstAlbumOffset
	for i := range albumDataList {
		albumOffsets[i] = currentOffset
		albumLengths[i] = int64(len(albumDataList[i]))
		currentOffset += albumLengths[i]
	}

	// 第三步：构建索引区（使用名称加密）
	indexData := make([]byte, 0, indexAreaSize)
	for i, album := range albums {
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], uint32(albumOffsets[i]))
		indexData = append(indexData, b[:]...)
		binary.LittleEndian.PutUint32(b[:], uint32(albumLengths[i]))
		indexData = append(indexData, b[:]...)
		// 使用文件名作为密钥进行加密（名称加密）
		indexData = append(indexData, EncryptPathWithNameKey(album.Path, npkName)...)
	}

	// 第四步：计算 SHA-256 哈希
	hashInputSize := int(indexAreaSize) / 17 * 17
	if hashInputSize > len(indexData) {
		hashInputSize = len(indexData)
	}
	hash := sha256.Sum256(indexData[:hashInputSize])

	// 第五步：构建输出数据
	var buf []byte

	// NPK 文件头
	flagBytes := make([]byte, 16)
	copy(flagBytes, NpkFlag)
	buf = append(buf, flagBytes...)

	var countBytes [4]byte
	binary.LittleEndian.PutUint32(countBytes[:], uint32(count))
	buf = append(buf, countBytes[:]...)

	// 索引区
	buf = append(buf, indexData...)

	// 哈希
	buf = append(buf, hash[:]...)

	// Album 数据（按 offset 顺序）
	type albumBlock struct {
		offset int64
		data   []byte
	}
	blocks := make([]albumBlock, count)
	for i := range albumDataList {
		blocks[i] = albumBlock{offset: albumOffsets[i], data: albumDataList[i]}
	}
	sort.Slice(blocks, func(i, j int) bool {
		return blocks[i].offset < blocks[j].offset
	})

	for _, block := range blocks {
		buf = append(buf, block.data...)
	}

	return buf, nil
}
