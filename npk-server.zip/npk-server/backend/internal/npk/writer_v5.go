package npk

import (
	"encoding/binary"
	"fmt"
)

// ============================================================================
// IMG 文件序列化 — V5 格式
// ============================================================================

// WriteAlbumV5 将 Album 序列化为 V5 格式的字节
// 参考 ExtractorSharp FifthHandler.AdjustData + Handler.Adjust()
func WriteAlbumV5(album *Album, writeDatas []SpriteWriteData) ([]byte, error) {
	if album == nil {
		return nil, fmt.Errorf("album 为 nil")
	}

	count := len(album.Sprites)
	if count == 0 {
		return nil, fmt.Errorf("album 中没有 sprite")
	}

	// 构建 sprite 索引到 writeData 的映射
	writeDataMap := make(map[int]*SpriteWriteData)
	for i := range writeDatas {
		writeDataMap[writeDatas[i].Sprite.Index] = &writeDatas[i]
	}

	textureInfos := album.TextureInfos
	if textureInfos == nil {
		textureInfos = make(map[int]*TextureInfo)
	}

	// ---- 第一步：分类处理所有 Sprite ----
	type newTextureEntry struct {
		spriteIndex int
		texture     *Texture
		textureInfo *TextureInfo
	}
	var newTextures []newTextureEntry

	type v2Entry struct {
		spriteIndex int
		data        []byte
	}
	var v2Entries []v2Entry

	type retainedTexture struct {
		texture *Texture
	}
	var retainedTextures []retainedTexture

	for i, sprite := range album.Sprites {
		if sprite.Type == LINK {
			continue
		}

		wd := writeDataMap[sprite.Index]

		// 1x1 隐藏帧: 走 V2 编码路径，不压缩
		if sprite.Width*sprite.Height == 1 {
			var rawPixels []byte
			if wd != nil && len(wd.BGRAData) > 0 {
				encoded, err := EncodePixels(wd.BGRAData, int32(sprite.Type))
				if err != nil {
					return nil, fmt.Errorf("编码 sprite %d 像素失败: %w", i, err)
				}
				rawPixels = encoded
			} else if len(sprite.Data) > 0 {
				rawPixels = sprite.Data
			} else {
				rawPixels = []byte{0, 0, 0, 0}
			}
			v2Entries = append(v2Entries, v2Entry{spriteIndex: i, data: rawPixels})
			continue
		}

		// 有编辑数据的帧: BGRA → DDS DXT5 → zlib 压缩
		if wd != nil && len(wd.BGRAData) > 0 {
			ddsFile := BuildDDSFile(wd.BGRAData, sprite.Width, sprite.Height)
			compressed, err := ZlibCompress(ddsFile)
			if err != nil {
				return nil, fmt.Errorf("压缩 sprite %d DDS 数据失败: %w", i, err)
			}

			tex := &Texture{
				Width:      sprite.Width,
				Height:     sprite.Height,
				Length:     len(compressed),
				FullLength: len(ddsFile),
				Data:       compressed,
				Version:    Dxt5,
				Type:       DXT_5,
			}
			texInfo := &TextureInfo{
				Texture:   tex,
				LeftUp:    Point{X: 0, Y: 0},
				RightDown: Point{X: sprite.Width, Y: sprite.Height},
				Top:       0,
				Unknown:   0,
			}
			newTextures = append(newTextures, newTextureEntry{
				spriteIndex: i, texture: tex, textureInfo: texInfo,
			})
			continue
		}

		// 无编辑数据的帧: 保留原始格式
		if sprite.Type > LINK {
			if info, ok := textureInfos[sprite.Index]; ok && info.Texture != nil {
				retainedTextures = append(retainedTextures, retainedTexture{texture: info.Texture})
			}
		} else if sprite.Type < LINK && sprite.Length > 0 {
			if len(sprite.Data) > 0 {
				v2Entries = append(v2Entries, v2Entry{spriteIndex: i, data: sprite.Data})
			}
		} else if sprite.Type < LINK && sprite.Length == 0 {
			if info, ok := textureInfos[sprite.Index]; ok && info.Texture != nil {
				retainedTextures = append(retainedTextures, retainedTexture{texture: info.Texture})
			}
		}
	}

	// ---- 第二步：去重并构建纹理列表 ----
	textureList := make([]*Texture, 0)
	textureIndexMap := make(map[*Texture]int)

	for _, rt := range retainedTextures {
		if _, exists := textureIndexMap[rt.texture]; !exists {
			textureIndexMap[rt.texture] = len(textureList)
			textureList = append(textureList, rt.texture)
		}
	}
	for _, nt := range newTextures {
		if _, exists := textureIndexMap[nt.texture]; !exists {
			textureIndexMap[nt.texture] = len(textureList)
			textureList = append(textureList, nt.texture)
		}
	}
	for j := range newTextures {
		newTextures[j].texture.Index = textureIndexMap[newTextures[j].texture]
	}
	for _, rt := range retainedTextures {
		rt.texture.Index = textureIndexMap[rt.texture]
	}

	// 构建 sprite → TextureInfo 映射
	spriteTextureInfoMap := make(map[int]*TextureInfo)
	for _, nt := range newTextures {
		spriteTextureInfoMap[nt.spriteIndex] = nt.textureInfo
	}
	for i := range album.Sprites {
		if _, ok := spriteTextureInfoMap[i]; !ok {
			if info, ok := textureInfos[i]; ok {
				spriteTextureInfoMap[i] = info
			}
		}
	}

	newTextureSpriteSet := make(map[int]bool)
	for _, nt := range newTextures {
		newTextureSpriteSet[nt.spriteIndex] = true
	}

	// ---- 第三步：构建 V5 数据 ----
	var v5Data []byte

	// 调色板
	if len(album.Tables) > 0 && len(album.Tables[0]) > 0 {
		palette := album.Tables[0]
		writeInt32(&v5Data, int32(len(palette)))
		for _, c := range palette {
			v5Data = append(v5Data, c.R, c.G, c.B, c.A)
		}
	} else {
		writeInt32(&v5Data, 0)
	}

	// DDS 纹理索引列表（每个 28 字节）
	for _, tex := range textureList {
		writeInt32(&v5Data, int32(tex.Version))
		writeInt32(&v5Data, int32(tex.Type))
		writeInt32(&v5Data, int32(tex.Index))
		writeInt32(&v5Data, int32(tex.Length))
		writeInt32(&v5Data, int32(tex.FullLength))
		writeInt32(&v5Data, int32(tex.Width))
		writeInt32(&v5Data, int32(tex.Height))
	}

	// Sprite 索引列表
	var v2SpriteDataList [][]byte
	for i, sprite := range album.Sprites {
		writeType := sprite.Type
		if newTextureSpriteSet[i] {
			writeType = DXT_5
		}
		writeInt32(&v5Data, int32(writeType))

		if sprite.Type == LINK {
			targetIdx := int32(0)
			if sprite.TargetIndex >= 0 {
				targetIdx = int32(sprite.TargetIndex)
			} else if sprite.Target != nil {
				targetIdx = int32(sprite.Target.Index)
			}
			writeInt32(&v5Data, targetIdx)
			continue
		}

		isV2 := false
		isTexRef := false

		if sprite.Width*sprite.Height == 1 && !newTextureSpriteSet[i] {
			isV2 = true
		} else if newTextureSpriteSet[i] {
			isTexRef = true
		} else if _, ok := spriteTextureInfoMap[i]; ok {
			if sprite.Type < LINK && sprite.Length > 0 && len(sprite.Data) > 0 {
				isV2 = true
			} else {
				isTexRef = true
			}
		} else if sprite.Type < LINK && sprite.Length > 0 {
			isV2 = true
		}

		if isV2 {
			if sprite.Width*sprite.Height == 1 {
				writeInt32(&v5Data, int32(NONE))
			} else {
				writeInt32(&v5Data, int32(ZLIB))
			}
			writeInt32(&v5Data, int32(sprite.Width))
			writeInt32(&v5Data, int32(sprite.Height))

			var dataLen int32
			for _, ve := range v2Entries {
				if ve.spriteIndex == i {
					dataLen = int32(len(ve.data))
					v2SpriteDataList = append(v2SpriteDataList, ve.data)
					break
				}
			}
			writeInt32(&v5Data, dataLen)
			writeInt32(&v5Data, int32(sprite.X))
			writeInt32(&v5Data, int32(sprite.Y))
			writeInt32(&v5Data, int32(sprite.FrameWidth))
			writeInt32(&v5Data, int32(sprite.FrameHeight))
		} else if isTexRef {
			info := spriteTextureInfoMap[i]
			writeInt32(&v5Data, int32(DDS_ZLIB))
			writeInt32(&v5Data, int32(sprite.Width))
			writeInt32(&v5Data, int32(sprite.Height))
			writeInt32(&v5Data, 0)
			writeInt32(&v5Data, int32(sprite.X))
			writeInt32(&v5Data, int32(sprite.Y))
			writeInt32(&v5Data, int32(sprite.FrameWidth))
			writeInt32(&v5Data, int32(sprite.FrameHeight))
			writeInt32(&v5Data, int32(info.Unknown))
			writeInt32(&v5Data, int32(info.Texture.Index))
			writeInt32(&v5Data, int32(info.LeftUp.X))
			writeInt32(&v5Data, int32(info.LeftUp.Y))
			writeInt32(&v5Data, int32(info.RightDown.X))
			writeInt32(&v5Data, int32(info.RightDown.Y))
			writeInt32(&v5Data, int32(info.Top))
		} else {
			writeInt32(&v5Data, int32(sprite.CompressMode))
			writeInt32(&v5Data, int32(sprite.Width))
			writeInt32(&v5Data, int32(sprite.Height))
			writeInt32(&v5Data, int32(sprite.Length))
			writeInt32(&v5Data, int32(sprite.X))
			writeInt32(&v5Data, int32(sprite.Y))
			writeInt32(&v5Data, int32(sprite.FrameWidth))
			writeInt32(&v5Data, int32(sprite.FrameHeight))
		}
	}

	// DDS 纹理数据
	for _, tex := range textureList {
		v5Data = append(v5Data, tex.Data...)
	}
	// V2 Sprite 数据
	for _, data := range v2SpriteDataList {
		v5Data = append(v5Data, data...)
	}

	// ---- 第四步：构建完整文件 ----
	totalLength := len(v5Data) + 40

	var prefixedData []byte
	{
		b := make([]byte, 4)
		binary.LittleEndian.PutUint32(b, uint32(len(textureList)))
		prefixedData = append(prefixedData, b...)
		binary.LittleEndian.PutUint32(b, uint32(totalLength))
		prefixedData = append(prefixedData, b...)
	}
	prefixedData = append(prefixedData, v5Data...)

	imgIndexLength := int64(4 + 4 + len(prefixedData))

	var buf []byte
	imgFlag := make([]byte, 16)
	copy(imgFlag, ImgFlag)
	imgFlag[15] = 0
	buf = append(buf, imgFlag...)
	writeInt64(&buf, imgIndexLength)
	writeInt32(&buf, int32(Ver5))
	writeInt32(&buf, int32(count))
	buf = append(buf, prefixedData...)

	return buf, nil
}
