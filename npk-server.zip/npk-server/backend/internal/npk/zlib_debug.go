package npk

// WriteZlibDebugLog 写入 zlib 调试日志（已禁用）
func WriteZlibDebugLog(msg string) {}

// WriteZlibDebugHeader 写入调试报告头部（已禁用）
func WriteZlibDebugHeader(npkName, albumPath string, spriteIndex int) {}

// CloseDebugLog 关闭调试日志文件（已禁用）
func CloseDebugLog() {}

// GetDebugFilePath 返回调试文件路径
func GetDebugFilePath() string { return "" }
