package npk

import (
	"fmt"
)

// ============================================================================
// IMG 文件序列化 — V2 格式
// 参考 ExtractorSharp SecondHandler.AdjustData() + Handler.Adjust()
//
// ExtractorSharp 写入流程:
//   1. SecondHandler.AdjustData():
//      - 遍历所有 sprite，写入索引（type + compressMode + width + height + length + x + y + frameWidth + frameHeight）
//      - IndexLength = 索引区字节数
//      - 紧接着写入所有 sprite 的 Data
//   2. Handler.Adjust():
//      - 在前面拼接: IMG_FLAG(16) + IndexLength(int64) + Version(int32) + Count(int32)
//      - Album.Data = 拼接后的完整数据
//
// NPK 文件中的 V2 IMG 结构:
//   [IMG头] "Neople Img File\0"(16) + indexLength(int64) + version(int32) + count(int32)
//   [索引区] sprite 索引（不含末尾 count）
//   [数据区] sprite 数据连续排列
// ============================================================================

// SpriteWriteData 用于写入 Sprite 时携带的额外数据
type SpriteWriteData struct {
	Sprite   *Sprite
	BGRAData []byte // 编码前的 BGRA 像素数据（仅编辑过的帧需要）
}

// WriteAlbumV2 将 Album 序列化为 V2 格式的字节
func WriteAlbumV2(album *Album, writeDatas []SpriteWriteData) ([]byte, error) {
	if album == nil {
		return nil, fmt.Errorf("album 为 nil")
	}

	count := len(album.Sprites)
	if count == 0 {
		return nil, fmt.Errorf("album 中没有 sprite")
	}

	// 构建 writeData 查找映射（key = sprite 在 album.Sprites 中的遍历索引）
	writeDataMap := make(map[int]*SpriteWriteData)
	for i := range writeDatas {
		for j, sprite := range album.Sprites {
			if sprite == writeDatas[i].Sprite {
				writeDataMap[j] = &writeDatas[i]
				break
			}
		}
	}

	// ---- 第一步：准备所有 sprite 的编码数据（IMG 数据类）----
	encodedList := make([]spriteEncoded, count)
	var dataBlocks [][]byte

	for i, sprite := range album.Sprites {
		var bgraData []byte
		var rawData []byte

		wd := writeDataMap[i]
		if wd != nil {
			bgraData = wd.BGRAData
			if len(bgraData) == 0 && len(wd.Sprite.Data) > 0 {
				rawData = wd.Sprite.Data
			}
		}
		if len(rawData) == 0 && len(sprite.Data) > 0 {
			rawData = sprite.Data
		}

		encoded, err := prepareSpriteData(sprite, bgraData, rawData)
		if err != nil {
			return nil, err
		}
		encodedList[i] = encoded

		if encoded.data != nil {
			dataBlocks = append(dataBlocks, encoded.data)
		}
	}

	// ---- 第二步：构建索引区（IMG 属性类）----
	// 参考 ExtractorSharp SecondHandler.AdjustData():
	//   只写 sprite 索引，不写末尾 count
	//   IndexLength = 索引区字节数

	var indexBuf []byte
	for i, sprite := range album.Sprites {
		writeSpriteIndexV2(&indexBuf, sprite, encodedList[i])
	}
	indexLength := int64(len(indexBuf))

	// ---- 第三步：拼接完整文件 ----
	// 参考 ExtractorSharp Handler.Adjust():
	//   IMG_FLAG(16) + IndexLength(int64) + Version(int32) + Count(int32) + 索引区 + 数据区

	var buf []byte

	// IMG 文件头
	imgFlag := make([]byte, 16)
	copy(imgFlag, ImgFlag)
	imgFlag[15] = 0
	buf = append(buf, imgFlag...)

	// indexLength (int64)
	writeInt64(&buf, indexLength)

	// version (int32)
	writeInt32(&buf, int32(album.Version))

	// count (int32)
	writeInt32(&buf, int32(count))

	// V4/V6 调色板（在索引区之前）
	if album.Version == Ver4 || album.Version == Ver6 {
		if len(album.Tables) > 0 && len(album.Tables[0]) > 0 {
			palette := album.Tables[0]
			writeInt32(&buf, int32(len(palette)))
			for _, c := range palette {
				buf = append(buf, c.R, c.G, c.B, c.A)
			}
		} else {
			writeInt32(&buf, 0)
		}
	}

	// 索引区
	buf = append(buf, indexBuf...)

	// 数据区
	for _, data := range dataBlocks {
		buf = append(buf, data...)
	}

	return buf, nil
}
