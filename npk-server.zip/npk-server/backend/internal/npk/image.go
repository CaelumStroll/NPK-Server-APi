package npk

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/color/palette"
	"image/gif"
	"image/png"
)

// ImageData 图像数据
type ImageData struct {
	Width  int
	Height int
	Pixels []byte // 像素数据，格式取决于 IsV5
	IsRGBA bool   // 历史遗留字段
	IsV5   bool   // V5 解码器输出 RGBA，标记后 ToImage() 不做通道转换
}
// ToImage 转换为 image.Image
// 参考 NPK_ENCRYPTION_RESEARCH.md 15.1 节：使用 NRGBA 格式 + 交换 R/B 通道
func (img *ImageData) ToImage() image.Image {
	if img.Width <= 0 || img.Height <= 0 {
		return image.NewNRGBA(image.Rect(0, 0, 1, 1))
	}

	if img.IsV5 {
		// V5 DXT 解码器输出 RGBA，直接使用 RGBA 格式
		rgba := image.NewRGBA(image.Rect(0, 0, img.Width, img.Height))
		copy(rgba.Pix, img.Pixels)
		return rgba
	}

	// V2/V1 格式：使用 NRGBA（非预乘 Alpha）+ 交换 R/B 通道
	// 原始数据是 BGRA (B, G, R, A)，输出为 RGBA (R, G, B, A)
	nrgba := image.NewNRGBA(image.Rect(0, 0, img.Width, img.Height))
	for i := 0; i < len(img.Pixels) && i+3 < len(img.Pixels); i += 4 {
		nrgba.Pix[i] = img.Pixels[i+2]   // R ← B
		nrgba.Pix[i+1] = img.Pixels[i+1] // G 不变
		nrgba.Pix[i+2] = img.Pixels[i]   // B ← R
		nrgba.Pix[i+3] = img.Pixels[i+3] // A 不变
	}

	return nrgba
}

// ToPNG 转换为 PNG 字节（使用默认压缩）
func (img *ImageData) ToPNG() ([]byte, error) {
	buf := new(bytes.Buffer)
	// 使用默认压缩级别（与 .NET 的 Bitmap.Save 类似）
	if err := png.Encode(buf, img.ToImage()); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// ToPNGNoCompression 转换为 PNG 字节（不压缩，全质量）
func (img *ImageData) ToPNGNoCompression() ([]byte, error) {
	buf := new(bytes.Buffer)
	encoder := &png.Encoder{CompressionLevel: png.NoCompression}
	if err := encoder.Encode(buf, img.ToImage()); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// Encode 编码为指定格式
func (img *ImageData) Encode(format string, quality int) ([]byte, error) {
	switch format {
	case "png":
		return img.ToPNG()
	case "gif":
		return img.ToGIF()
	default:
		return img.ToPNG()
	}
}

// ToGIF 转换为 GIF 字节（单帧）
func (img *ImageData) ToGIF() ([]byte, error) {
	buf := new(bytes.Buffer)
	g := &gif.GIF{
		Image: []*image.Paletted{img.toPaletted()},
		Delay: []int{0},
	}
	if err := gif.EncodeAll(buf, g); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// toPaletted 转换为 Paletted 图像（用于 GIF）
func (img *ImageData) toPaletted() *image.Paletted {
	// 使用 Plan9 调色板（256色）
	paletted := image.NewPaletted(image.Rect(0, 0, img.Width, img.Height), palette.Plan9)
	for y := 0; y < img.Height; y++ {
		for x := 0; x < img.Width; x++ {
			idx := (y*img.Width + x) * 4
			r, g, b, a := img.Pixels[idx+2], img.Pixels[idx+1], img.Pixels[idx+0], img.Pixels[idx+3]
			paletted.Set(x, y, color.RGBA{r, g, b, a})
		}
	}
	return paletted
}

// DecodeSpriteToImage 统一解码入口
func DecodeSpriteToImage(sprite *Sprite, album *Album, visited ...map[int]bool) (*ImageData, error) {
	if sprite == nil {
		return nil, fmt.Errorf("sprite is nil")
	}

	// 处理 LINK
	if sprite.Type == LINK {
		// 空指针检查
		if sprite.Target == nil {
			return nil, fmt.Errorf("LINK sprite %d: 空指针", sprite.Index)
		}

		// 初始化 visited 集合
		var visitedMap map[int]bool
		if len(visited) == 0 {
			visitedMap = make(map[int]bool)
		} else {
			visitedMap = visited[0]
		}

		// 循环引用检查
		if visitedMap[sprite.Index] {
			return nil, fmt.Errorf("LINK sprite %d: 循环引用", sprite.Index)
		}
		visitedMap[sprite.Index] = true

		// 递归解析目标 sprite
		return DecodeSpriteToImage(sprite.Target, album, visitedMap)
	}

	// V5 纹理引用
	if album.Version == Ver5 && sprite.Type > LINK {
		texInfo := album.TextureInfos[sprite.Index]
		if texInfo == nil || texInfo.Texture == nil {
			return nil, fmt.Errorf("V5 sprite %d: missing texture info", sprite.Index)
		}
		result, err := decodeV5TextureSprite(sprite, texInfo, album)
		if err != nil {
			return nil, err
		}
		return result, nil
	}

	// V4/V6 调色板
	if (album.Version == Ver4 || album.Version == Ver6) && len(album.Tables) > 0 && len(album.Tables[0]) > 0 {
		pixels, err := DecodeSpriteWithPalette(sprite, album.Tables[0])
		if err != nil {
			return nil, err
		}
		return &ImageData{
			Width:  sprite.Width,
			Height: sprite.Height,
			Pixels: pixels,
			IsRGBA: true,
		}, nil
	}

	// 标准解码
	pixels, err := DecodeSprite(sprite)
	if err != nil {
		return nil, err
	}
	return &ImageData{
		Width:  sprite.Width,
		Height: sprite.Height,
		Pixels: pixels,
		IsRGBA: true,
	}, nil
}

// decodeV5TextureSprite V5 DDS 纹理帧解码（与 KoishiEx 对齐）
func decodeV5TextureSprite(sprite *Sprite, texInfo *TextureInfo, album *Album) (*ImageData, error) {
	if texInfo.Texture == nil {
		return nil, fmt.Errorf("texture is nil for sprite %d", sprite.Index)
	}

	// 1. 解压 DDS 数据
	var ddsData []byte
	var err error
	
	if texInfo.Texture.FullLength > 0 && texInfo.Texture.FullLength != texInfo.Texture.Length {
		ddsData, err = ZlibDecompress(texInfo.Texture.Data, texInfo.Texture.FullLength)
		if err != nil {
			return nil, fmt.Errorf("解压 DDS 数据失败: %w", err)
		}
	} else {
		ddsData = texInfo.Texture.Data
	}

	// 2. 解析 DDS 头
	rawDDS, err := ParseDDSHeader(ddsData)
	if err != nil {
		return nil, fmt.Errorf("DDS 解析失败: %w", err)
	}

	ddsWidth := rawDDS.DDSWidth
	ddsHeight := rawDDS.DDSHeight

	// 3. DDS 解码为像素（行优先，与 KoishiEx 一致）
	var pixels []byte
	switch rawDDS.Format {
	case "DXT1":
		pixels = DecodeDXT1(rawDDS.RawData, ddsWidth, ddsHeight)
	case "DXT3":
		pixels = DecodeDXT3(rawDDS.RawData, ddsWidth, ddsHeight)
	case "DXT5":
		pixels = DecodeDXT5(rawDDS.RawData, ddsWidth, ddsHeight)
	default:
		return nil, fmt.Errorf("unsupported DDS format: %s", rawDDS.Format)
	}

	// 4. 裁剪子区域（与 KoishiEx getSubMatrix 对齐）
	lu := texInfo.LeftUp
	rd := texInfo.RightDown

	// 边界检查
	if lu.Y < 0 { lu.Y = 0 }
	if lu.X < 0 { lu.X = 0 }
	if rd.Y > ddsHeight { rd.Y = ddsHeight }
	if rd.X > ddsWidth { rd.X = ddsWidth }

	outW := rd.X - lu.X
	outH := rd.Y - lu.Y
	if outW <= 0 || outH <= 0 {
		return &ImageData{
			Width: sprite.Width, Height: sprite.Height,
			Pixels: make([]byte, sprite.Width*sprite.Height*4),
			IsRGBA: true,
		}, nil
	}

	// 裁剪
	cropped := make([]byte, outW*outH*4)
	for y := 0; y < outH; y++ {
		for x := 0; x < outW; x++ {
			srcIdx := ((lu.Y + y) * ddsWidth + (lu.X + x)) * 4
			dstIdx := (y*outW + x) * 4
			if srcIdx+3 < len(pixels) {
				cropped[dstIdx+0] = pixels[srcIdx+0]
				cropped[dstIdx+1] = pixels[srcIdx+1]
				cropped[dstIdx+2] = pixels[srcIdx+2]
				cropped[dstIdx+3] = pixels[srcIdx+3]
			}
		}
	}

	// 5. 如果 Top != 0，旋转 90 度并翻转
	if texInfo.Top != 0 {
		cropped = rotate90FlipXYBytes(cropped, outW, outH)
		outW, outH = outH, outW
	}

	// 6. 将裁剪结果放到 sprite 尺寸的画布上
	out := &ImageData{
		Width:  sprite.Width,
		Height: sprite.Height,
		Pixels: make([]byte, sprite.Width*sprite.Height*4),
		IsV5:   true,
	}

	copyW := outW
	copyH := outH
	if copyW > sprite.Width { copyW = sprite.Width }
	if copyH > sprite.Height { copyH = sprite.Height }

	for y := 0; y < copyH; y++ {
		for x := 0; x < copyW; x++ {
			srcIdx := (y*outW + x) * 4
			dstIdx := (y*sprite.Width + x) * 4
			out.Pixels[dstIdx+0] = cropped[srcIdx+0]
			out.Pixels[dstIdx+1] = cropped[srcIdx+1]
			out.Pixels[dstIdx+2] = cropped[srcIdx+2]
			out.Pixels[dstIdx+3] = cropped[srcIdx+3]
		}
	}

	return out, nil
}

// rotate90FlipXYBytes 旋转90度并翻转XY
func rotate90FlipXYBytes(data []byte, w, h int) []byte {
	out := make([]byte, w*h*4)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			srcIdx := (y*w + x) * 4
			dstIdx := (x*h + (h - 1 - y)) * 4
			out[dstIdx+0] = data[srcIdx+0]
			out[dstIdx+1] = data[srcIdx+1]
			out[dstIdx+2] = data[srcIdx+2]
			out[dstIdx+3] = data[srcIdx+3]
		}
	}
	return out
}

// DecodeSpriteFrame 解码帧图像（用于动画预览）
// 帧域定义输出画布尺寸，不裁剪图像内容
func DecodeSpriteFrame(sprite *Sprite, album *Album, frameWidth, frameHeight, offsetX, offsetY int) (*ImageData, error) {
	img, err := DecodeSpriteToImage(sprite, album)
	if err != nil {
		return nil, err
	}

	// 如果 frame 尺寸为 0，使用 sprite 实际尺寸
	if frameWidth <= 0 || frameHeight <= 0 {
		frameWidth = img.Width
		frameHeight = img.Height
		offsetX = 0
		offsetY = 0
	}

	// 如果图像尺寸超出帧域，扩展帧域以容纳完整图像
	srcW := img.Width
	srcH := img.Height
	if offsetX + srcW > frameWidth {
		frameWidth = offsetX + srcW
	}
	if offsetY + srcH > frameHeight {
		frameHeight = offsetY + srcH
	}

	frame := &ImageData{
		Width:  frameWidth,
		Height: frameHeight,
		Pixels: make([]byte, frameWidth*frameHeight*4),
		IsV5:   img.IsV5,
	}

	// 确保不超出边界
	if offsetX < 0 { offsetX = 0 }
	if offsetY < 0 { offsetY = 0 }
	if offsetX+srcW > frameWidth { srcW = frameWidth - offsetX }
	if offsetY+srcH > frameHeight { srcH = frameHeight - offsetY }
	if srcW <= 0 || srcH <= 0 {
		return frame, nil
	}

	for y := 0; y < srcH; y++ {
		for x := 0; x < srcW; x++ {
			srcIdx := (y*img.Width + x) * 4
			dstIdx := ((offsetY+y)*frameWidth + (offsetX+x)) * 4
			frame.Pixels[dstIdx+0] = img.Pixels[srcIdx+0]
			frame.Pixels[dstIdx+1] = img.Pixels[srcIdx+1]
			frame.Pixels[dstIdx+2] = img.Pixels[srcIdx+2]
			frame.Pixels[dstIdx+3] = img.Pixels[srcIdx+3]
		}
	}

	return frame, nil
}

// ImageToBGRA 将 image.Image 转换为 BGRA 字节
func ImageToBGRA(img image.Image) []byte {
	bounds := img.Bounds()
	w := bounds.Dx()
	h := bounds.Dy()
	data := make([]byte, w*h*4)

	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			r, g, b, a := img.At(x+bounds.Min.X, y+bounds.Min.Y).RGBA()
			idx := (y*w + x) * 4
			data[idx+0] = uint8(b >> 8)
			data[idx+1] = uint8(g >> 8)
			data[idx+2] = uint8(r >> 8)
			data[idx+3] = uint8(a >> 8)
		}
	}

	return data
}

// rotate90FlipXY 旋转90度并翻转XY（ImageData 版本）
func rotate90FlipXY(img *ImageData) *ImageData {
	w := img.Width
	h := img.Height
	out := &ImageData{
		Width:  h,
		Height: w,
		Pixels: make([]byte, w*h*4),
		IsRGBA: img.IsRGBA,
	}

	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			srcIdx := (y*w + x) * 4
			dstIdx := (x*h + (h - 1 - y)) * 4
			out.Pixels[dstIdx+0] = img.Pixels[srcIdx+0]
			out.Pixels[dstIdx+1] = img.Pixels[srcIdx+1]
			out.Pixels[dstIdx+2] = img.Pixels[srcIdx+2]
			out.Pixels[dstIdx+3] = img.Pixels[srcIdx+3]
		}
	}

	return out
}

// ApplyScreenFilter 对 ImageData 应用 Screen 滤色模式去黑底
// 根据 RGB 最大值设置透明度，纯黑完全透明
func ApplyScreenFilter(img *ImageData) {
	for i := 0; i < len(img.Pixels); i += 4 {
		r := img.Pixels[i]
		g := img.Pixels[i+1]
		b := img.Pixels[i+2]

		brightness := r
		if g > brightness {
			brightness = g
		}
		if b > brightness {
			brightness = b
		}

		if brightness == 0 {
			img.Pixels[i+3] = 0
		} else {
			img.Pixels[i+3] = brightness
		}
	}
}

// NewImageData 从 image.Image 创建 ImageData
func NewImageData(img image.Image) *ImageData {
	bounds := img.Bounds()
	w := bounds.Dx()
	h := bounds.Dy()
	pixels := make([]byte, w*h*4)

	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			r, g, b, a := img.At(x+bounds.Min.X, y+bounds.Min.Y).RGBA()
			idx := (y*w + x) * 4
			pixels[idx+0] = uint8(b >> 8)
			pixels[idx+1] = uint8(g >> 8)
			pixels[idx+2] = uint8(r >> 8)
			pixels[idx+3] = uint8(a >> 8)
		}
	}

	return &ImageData{
		Width:  w,
		Height: h,
		Pixels: pixels,
		IsRGBA: true,
	}
}

// Draw 将另一个 ImageData 绘制到当前图像上（Alpha 混合）
func (dst *ImageData) Draw(src *ImageData, offsetX, offsetY int) {
	for y := 0; y < src.Height; y++ {
		dstY := y + offsetY
		if dstY < 0 || dstY >= dst.Height {
			continue
		}
		for x := 0; x < src.Width; x++ {
			dstX := x + offsetX
			if dstX < 0 || dstX >= dst.Width {
				continue
			}
			srcIdx := (y*src.Width + x) * 4
			dstIdx := (dstY*dst.Width + dstX) * 4

			sa := src.Pixels[srcIdx+3]
			if sa == 255 {
				dst.Pixels[dstIdx+0] = src.Pixels[srcIdx+0]
				dst.Pixels[dstIdx+1] = src.Pixels[srcIdx+1]
				dst.Pixels[dstIdx+2] = src.Pixels[srcIdx+2]
				dst.Pixels[dstIdx+3] = 255
			} else if sa > 0 {
				// Alpha 混合
				da := dst.Pixels[dstIdx+3]
				if da == 0 {
					dst.Pixels[dstIdx+0] = src.Pixels[srcIdx+0]
					dst.Pixels[dstIdx+1] = src.Pixels[srcIdx+1]
					dst.Pixels[dstIdx+2] = src.Pixels[srcIdx+2]
					dst.Pixels[dstIdx+3] = sa
				} else {
					invSa := 255 - sa
					dst.Pixels[dstIdx+0] = (src.Pixels[srcIdx+0]*sa + dst.Pixels[dstIdx+0]*invSa) / 255
					dst.Pixels[dstIdx+1] = (src.Pixels[srcIdx+1]*sa + dst.Pixels[dstIdx+1]*invSa) / 255
					dst.Pixels[dstIdx+2] = (src.Pixels[srcIdx+2]*sa + dst.Pixels[dstIdx+2]*invSa) / 255
					dst.Pixels[dstIdx+3] = 255 - (invSa*(255-da))/255
				}
			}
		}
	}
}
