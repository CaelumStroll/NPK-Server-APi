package npk

import (
	"encoding/binary"
	"io"
)

// 读取 V4 数据 (调色板索引模式)
func readImgV4Data(reader io.Reader, album *Album) error {
	// 读取调色板
	var paletteCount int32
	if err := binary.Read(reader, binary.LittleEndian, &paletteCount); err != nil {
		return err
	}

	palette := make([]RGBA, paletteCount)
	for i := 0; i < int(paletteCount); i++ {
		var r, g, b, a uint8
		if err := binary.Read(reader, binary.LittleEndian, &r); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &g); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &b); err != nil {
			return err
		}
		if err := binary.Read(reader, binary.LittleEndian, &a); err != nil {
			return err
		}
		palette[i] = RGBA{R: r, G: g, B: b, A: a}
	}
	album.Tables = [][]RGBA{palette}
	album.TableIndex = 0

	return readImgV2Data(reader, album)
}
