package npk

import (
	"bytes"
	"compress/flate"
	"compress/zlib"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
	"time"
)

var (
	debugCount int
	debugMu    sync.Mutex
	debugDir   = "/sessions/6a043872c614418b134b1217/workspace/npk-server/debug_zlib"
)

// ZlibDecompress zlib 解压缩（增强版）
// 模拟 zlib1.dll uncompress 的行为，尝试多种解压策略
func ZlibDecompress(data []byte, expectedSize int) ([]byte, error) {
	if len(data) < 2 {
		return nil, fmt.Errorf("数据太短: %d 字节", len(data))
	}

	// 记录到文件
	WriteZlibDebugLog(fmt.Sprintf("[%s] ZlibDecompress: input=%d, expected=%d, header=%02X%02X",
		time.Now().Format("15:04:05.000"), len(data), expectedSize, data[0], data[1]))

	// 策略 1: 尝试作为标准 zlib 解压（带 header）
	if len(data) >= 2 && data[0] == 0x78 {
		result, err := tryZlibWithHeader(data, expectedSize)
		if err == nil {
			WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 1 (zlib header) SUCCESS: %d bytes", time.Now().Format("15:04:05.000"), len(result)))
			logDecompressResult(result, data, "zlib_header", expectedSize)
			return result, nil
		}
		WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 1 (zlib header) FAILED: %v", time.Now().Format("15:04:05.000"), err))
	}

	// 策略 2: 尝试作为 raw deflate 解压
	result, err := tryRawDeflate(data, expectedSize)
	if err == nil {
		WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 2 (raw deflate) SUCCESS: %d bytes", time.Now().Format("15:04:05.000"), len(result)))
		logDecompressResult(result, data, "raw_deflate", expectedSize)
		return result, nil
	}
	WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 2 (raw deflate) FAILED: %v", time.Now().Format("15:04:05.000"), err))

	// 策略 3: 尝试跳过前 2 字节作为 raw deflate（某些变体格式）
	if len(data) > 2 {
		result, err := tryRawDeflate(data[2:], expectedSize)
		if err == nil {
			WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 3 (skip 2 bytes) SUCCESS: %d bytes", time.Now().Format("15:04:05.000"), len(result)))
			logDecompressResult(result, data, "skip_2bytes", expectedSize)
			return result, nil
		}
		WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 3 (skip 2 bytes) FAILED: %v", time.Now().Format("15:04:05.000"), err))
	}

	// 策略 4: 尝试跳过前 4 字节（header + 部分数据）
	if len(data) > 4 {
		result, err := tryRawDeflate(data[4:], expectedSize)
		if err == nil {
			WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 4 (skip 4 bytes) SUCCESS: %d bytes", time.Now().Format("15:04:05.000"), len(result)))
			logDecompressResult(result, data, "skip_4bytes", expectedSize)
			return result, nil
		}
		WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 4 (skip 4 bytes) FAILED: %v", time.Now().Format("15:04:05.000"), err))
	}

	// 策略 5: 使用 flate.NewReader 的不同窗口大小尝试
	result, err = tryDeflateWithWindow(data, expectedSize, 15) // 最大窗口大小
	if err == nil {
		WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 5 (window=15) SUCCESS: %d bytes", time.Now().Format("15:04:05.000"), len(result)))
		logDecompressResult(result, data, "deflate_w15", expectedSize)
		return result, nil
	}
	WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 5 (window=15) FAILED: %v", time.Now().Format("15:04:05.000"), err))

	// 策略 6: 尝试作为未压缩的数据（直接返回原始数据）
	if len(data) >= expectedSize {
		result = make([]byte, expectedSize)
		copy(result, data[:expectedSize])
		WriteZlibDebugLog(fmt.Sprintf("[%s] Strategy 6 (raw data) SUCCESS: %d bytes", time.Now().Format("15:04:05.000"), len(result)))
		logDecompressResult(result, data, "raw_data", expectedSize)
		return result, nil
	}

	// 所有策略都失败了
	saveFailedData(data, expectedSize, "all_strategies_failed")
	return nil, fmt.Errorf("所有解压策略均失败，已保存调试数据")
}

// tryZlibWithHeader 尝试使用标准 zlib 解码（带 header）
// 注意：与 zlib1.dll uncompress 行为一致，始终返回 expectedSize 字节
func tryZlibWithHeader(data []byte, expectedSize int) ([]byte, error) {
	r, err := zlib.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("创建 zlib reader 失败: %w", err)
	}
	defer r.Close()

	result := make([]byte, expectedSize)
	totalRead := 0
	for totalRead < expectedSize {
		n, err := r.Read(result[totalRead:])
		totalRead += n
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("zlib 解压失败: %w", err)
		}
	}

	// 与 zlib1.dll 行为一致：始终返回 expectedSize 字节
	// 如果实际解压数据少于 expectedSize，剩余部分保持为零
	return result, nil
}

// tryRawDeflate 尝试使用 raw deflate 解码
// 注意：与 zlib1.dll uncompress 行为一致，始终返回 expectedSize 字节
func tryRawDeflate(data []byte, expectedSize int) ([]byte, error) {
	r := flate.NewReader(bytes.NewReader(data))
	if r == nil {
		return nil, fmt.Errorf("创建 deflate reader 失败")
	}

	result := make([]byte, expectedSize)
	totalRead := 0
	for totalRead < expectedSize {
		n, err := r.Read(result[totalRead:])
		totalRead += n
		if err == io.EOF {
			break
		}
		if err != nil {
			r.Close()
			return nil, fmt.Errorf("deflate 解压失败: %w", err)
		}
	}
	r.Close()

	// 与 zlib1.dll 行为一致：始终返回 expectedSize 字节
	return result, nil
}

// tryDeflateWithWindow 尝试使用指定窗口大小的 deflate 解码
// 注意：与 zlib1.dll uncompress 行为一致，始终返回 expectedSize 字节
func tryDeflateWithWindow(data []byte, expectedSize int, windowBits int) ([]byte, error) {
	r := flate.NewReaderDict(bytes.NewReader(data), nil)
	if r == nil {
		return nil, fmt.Errorf("创建 deflate reader 失败")
	}

	result := make([]byte, expectedSize)
	totalRead := 0
	for totalRead < expectedSize {
		n, err := r.Read(result[totalRead:])
		totalRead += n
		if err == io.EOF {
			break
		}
		if err != nil {
			r.Close()
			return nil, fmt.Errorf("deflate 解压失败: %w", err)
		}
	}
	r.Close()

	// 与 zlib1.dll 行为一致：始终返回 expectedSize 字节
	return result, nil
}

// logDecompressResult 记录解压结果
func logDecompressResult(result []byte, input []byte, strategy string, expectedSize int) {
	// 记录实际返回大小与期望大小的对比
	WriteZlibDebugLog(fmt.Sprintf("[%s] Result (%s): actual=%d, expected=%d", time.Now().Format("15:04:05.000"), strategy, len(result), expectedSize))

	// 记录前 32 字节的十六进制
	if len(result) > 0 {
		hexStr := ""
		for i := 0; i < 32 && i < len(result); i++ {
			hexStr += fmt.Sprintf("%02X ", result[i])
		}
		WriteZlibDebugLog(fmt.Sprintf("[%s] Result (%s): first32=%s", time.Now().Format("15:04:05.000"), strategy, hexStr))
	}

	// 检查是否以 DDS 头开始
	if len(result) >= 4 {
		if result[0] == 0x44 && result[1] == 0x44 && result[2] == 0x53 && result[3] == 0x20 {
			WriteZlibDebugLog(fmt.Sprintf("[%s] Result is DDS data!", time.Now().Format("15:04:05.000")))
		}
	}
}

// saveFailedData 保存解压失败的数据用于调试
func saveFailedData(data []byte, expectedSize int, reason string) {
	debugMu.Lock()
	defer debugMu.Unlock()

	// 确保调试目录存在
	if err := os.MkdirAll(debugDir, 0755); err != nil {
		WriteZlibDebugLog(fmt.Sprintf("[%s] Failed to create debug dir: %v", time.Now().Format("15:04:05.000"), err))
		return
	}

	debugCount++
	filename := filepath.Join(debugDir, fmt.Sprintf("failed_%03d_size%d_expected%d_%s.bin", debugCount, len(data), expectedSize, reason))
	if err := os.WriteFile(filename, data, 0644); err != nil {
		WriteZlibDebugLog(fmt.Sprintf("[%s] Failed to save debug file: %v", time.Now().Format("15:04:05.000"), err))
		return
	}

	WriteZlibDebugLog(fmt.Sprintf("[%s] Saved failed data to: %s", time.Now().Format("15:04:05.000"), filename))

	// 记录前 64 字节的十六进制
	hexStr := ""
	for i := 0; i < 64 && i < len(data); i++ {
		hexStr += fmt.Sprintf("%02X ", data[i])
	}
	WriteZlibDebugLog(fmt.Sprintf("[%s] Failed data first64: %s", time.Now().Format("15:04:05.000"), hexStr))
}

// ZlibCompress zlib 压缩
func ZlibCompress(data []byte) ([]byte, error) {
	var buf bytes.Buffer
	w := zlib.NewWriter(&buf)
	if _, err := w.Write(data); err != nil {
		w.Close()
		return nil, err
	}
	w.Close()
	return buf.Bytes(), nil
}
