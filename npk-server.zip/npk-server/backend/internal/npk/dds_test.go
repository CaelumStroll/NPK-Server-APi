package npk

import (
	"bytes"
	"testing"
)

func TestParseDDSHeaderInvalid(t *testing.T) {
	_, err := ParseDDSHeader(nil)
	if err == nil {
		t.Error("expected error for nil")
	}

	_, err = ParseDDSHeader([]byte("not a dds file"))
	if err == nil {
		t.Error("expected error for invalid magic")
	}

	shortHeader := make([]byte, 32)
	copy(shortHeader, "DDS ")
	_, err = ParseDDSHeader(shortHeader)
	if err == nil {
		t.Error("expected error for short header")
	}
}

func TestDecodeRgb565(t *testing.T) {
	result := DecodeRgb565(0x0000)
	if len(result) != 4 {
		t.Fatalf("expected 4 bytes BGRA, got %d", len(result))
	}

	resultWhite := DecodeRgb565(0xFFFF)
	if resultWhite[0] != 255 || resultWhite[1] != 255 || resultWhite[2] != 255 || resultWhite[3] != 255 {
		t.Errorf("0xFFFF should be white (BGRA 255,255,255,255), got %v", resultWhite)
	}
}

func TestEncodeRGB565(t *testing.T) {
	result := encodeRGB565(255, 255, 255)
	if result != 0xFFFF {
		t.Errorf("encodeRGB565(255,255,255) = 0x%04X, want 0xFFFF", result)
	}

	result = encodeRGB565(0, 0, 0)
	if result != 0x0000 {
		t.Errorf("encodeRGB565(0,0,0) = 0x%04X, want 0x0000", result)
	}
}

func TestRoundtrip565(t *testing.T) {
	// encode → decode should preserve color
	for _, c := range []struct{ r, g, b uint8 }{
		{255, 0, 0},
		{0, 255, 0},
		{0, 0, 255},
		{128, 128, 128},
		{255, 255, 255},
	} {
		encoded := encodeRGB565(c.r, c.g, c.b)
		_ = DecodeRgb565(encoded)
		// Note: 565 encoding is lossy, so we just verify no panic
	}
}

func TestRead6Byte(t *testing.T) {
	buf := make([]byte, 6)
	buf[5] = 0x01
	buf[4] = 0x00
	buf[3] = 0x00
	buf[2] = 0x00
	buf[1] = 0x00
	buf[0] = 0x00

	val := Read6Byte(bytes.NewReader(buf))
	if val != 0x01_00_00_00_00_00 {
		t.Errorf("Read6Byte = 0x%X, want 0x010000000000", val)
	}
}
