package npk

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/gif"
)

// ==================== 动画相关 ====================

// AnimationFrame 动画帧
type AnimationFrame struct {
	Sprite  *Sprite
	Image   *ImageData
	Delay   int // 延迟（百分之一秒）
	OffsetX int
	OffsetY int
}

// Animation 动画
type Animation struct {
	Name   string
	Frames []*AnimationFrame
	Width  int
	Height int
}

// DecodeAnimation 从 Album 解码动画
func DecodeAnimation(album *Album, name string) (*Animation, error) {
	if album == nil || len(album.Sprites) == 0 {
		return nil, fmt.Errorf("empty album")
	}

	anim := &Animation{
		Name:   name,
		Frames: make([]*AnimationFrame, 0, len(album.Sprites)),
	}

	for i, sprite := range album.Sprites {
		img, err := DecodeSpriteToImage(sprite, album)
		if err != nil {
			continue // 跳过解码失败的帧
		}

		frame := &AnimationFrame{
			Sprite:  sprite,
			Image:   img,
			Delay:   5, // 默认 50ms
			OffsetX: sprite.X,
			OffsetY: sprite.Y,
		}
		anim.Frames = append(anim.Frames, frame)

		// 更新动画尺寸
		if i == 0 {
			anim.Width = sprite.FrameWidth
			anim.Height = sprite.FrameHeight
		}
	}

	return anim, nil
}

// ExportGIF 导出为 GIF
func (anim *Animation) ExportGIF() ([]byte, error) {
	if len(anim.Frames) == 0 {
		return nil, fmt.Errorf("no frames")
	}

	g := &gif.GIF{}

	// 构建全局调色板：收集所有帧中使用的颜色
	paletteMap := make(map[color.RGBA]uint16) // 颜色 -> 调色板索引
	palette := color.Palette{}

	// 添加透明色
	palette = append(palette, color.RGBA{0, 0, 0, 0})

	for _, frame := range anim.Frames {
		if frame.Image != nil {
			for y := 0; y < frame.Image.Height; y++ {
				for x := 0; x < frame.Image.Width; x++ {
					srcIdx := (y*frame.Image.Width + x) * 4
					a := frame.Image.Pixels[srcIdx+3]
					if a > 0 {
						c := color.RGBA{
							R: frame.Image.Pixels[srcIdx+2],
							G: frame.Image.Pixels[srcIdx+1],
							B: frame.Image.Pixels[srcIdx+0],
							A: a,
						}
						if _, exists := paletteMap[c]; !exists && len(palette) < 256 {
							paletteMap[c] = uint16(len(palette))
							palette = append(palette, c)
						}
					}
				}
			}
		}
	}

	// 确保至少有黑色（用于没有颜色的像素）
	hasBlack := false
	for _, p := range palette {
		r, g, b, a := p.RGBA()
		if r == 0 && g == 0 && b == 0 && a > 0 {
			hasBlack = true
			break
		}
	}
	if !hasBlack && len(palette) < 256 {
		palette = append(palette, color.RGBA{0, 0, 0, 255})
	}

	for _, frame := range anim.Frames {
		// 创建帧画布
		canvas := image.NewPaletted(
			image.Rect(0, 0, anim.Width, anim.Height),
			palette,
		)

		// 将帧绘制到画布
		if frame.Image != nil {
			for y := 0; y < frame.Image.Height && y+frame.OffsetY < anim.Height; y++ {
				for x := 0; x < frame.Image.Width && x+frame.OffsetX < anim.Width; x++ {
					srcIdx := (y*frame.Image.Width + x) * 4
					dstX := x + frame.OffsetX
					dstY := y + frame.OffsetY
					if dstX >= 0 && dstY >= 0 {
						a := frame.Image.Pixels[srcIdx+3]
						if a == 0 {
							// 透明色
							canvas.Set(dstX, dstY, palette[0])
						} else {
							c := color.RGBA{
								R: frame.Image.Pixels[srcIdx+2],
								G: frame.Image.Pixels[srcIdx+1],
								B: frame.Image.Pixels[srcIdx+0],
								A: a,
							}
							canvas.Set(dstX, dstY, c)
						}
					}
				}
			}
		}

		g.Image = append(g.Image, canvas)
		g.Delay = append(g.Delay, frame.Delay)
	}

	buf := new(bytes.Buffer)
	if err := gif.EncodeAll(buf, g); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
