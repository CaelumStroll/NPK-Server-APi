package npk

import (
	"encoding/binary"
	"fmt"
	"io"
	"strings"
)

// NPK 文件格式常量
const (
	NpkFlag    = "NeoplePack_Bill"
	ImgFlag    = "Neople Img File"
	ImageFlag  = "Neople Image File"
	KeyHeader  = "puchikon@neople dungeon and fighter "
)

// 颜色格式类型
type ColorBits int

const (
	ARGB_1555 ColorBits = 0x0e
	ARGB_4444 ColorBits = 0x0f
	ARGB_8888 ColorBits = 0x10
	LINK      ColorBits = 0x11
	DXT_1     ColorBits = 0x12
	DXT_3     ColorBits = 0x13
	DXT_5     ColorBits = 0x14
	UNKNOWN   ColorBits = 0x00
)

func (c ColorBits) String() string {
	switch c {
	case ARGB_1555:
		return "ARGB_1555"
	case ARGB_4444:
		return "ARGB_4444"
	case ARGB_8888:
		return "ARGB_8888"
	case LINK:
		return "LINK"
	case DXT_1:
		return "DXT_1"
	case DXT_3:
		return "DXT_3"
	case DXT_5:
		return "DXT_5"
	default:
		return "UNKNOWN"
	}
}

// 压缩类型
type CompressMode int

const (
	ZLIB     CompressMode = 0x06
	NONE     CompressMode = 0x05
	DDS_ZLIB CompressMode = 0x07
)

func (c CompressMode) String() string {
	switch c {
	case ZLIB:
		return "ZLIB"
	case NONE:
		return "NONE"
	case DDS_ZLIB:
		return "DDS_ZLIB"
	default:
		return "UNKNOWN"
	}
}

// IMG 版本
type ImgVersion int

const (
	Other ImgVersion = 0x00
	Ver1  ImgVersion = 0x01
	Ver2  ImgVersion = 0x02
	Ver3  ImgVersion = 0x03
	Ver4  ImgVersion = 0x04
	Ver5  ImgVersion = 0x05
	Ver6  ImgVersion = 0x06
)

// NPK 加密类型
type EncryptionType int

const (
	Encrypted     EncryptionType = 0 // 标准加密（使用官方密钥）
	Plaintext     EncryptionType = 1 // 未加密明文
	EncryptedVarA EncryptionType = 2 // 加密变体 A（自定义密钥）
	EncryptedVarB EncryptionType = 3 // 加密变体 B（自定义密钥）
	EncryptedUnknown EncryptionType = 99 // 未知/异常
)

func (v ImgVersion) String() string {
	switch v {
	case Ver1:
		return "V1"
	case Ver2:
		return "V2"
	case Ver3:
		return "V3"
	case Ver4:
		return "V4"
	case Ver5:
		return "V5"
	case Ver6:
		return "V6"
	default:
		return "Other"
	}
}

func (e EncryptionType) String() string {
	switch e {
	case Encrypted:
		return "Encrypted"
	case Plaintext:
		return "Plaintext"
	case EncryptedVarA:
		return "EncryptedVarA"
	case EncryptedVarB:
		return "EncryptedVarB"
	default:
		return "Unknown"
	}
}

// 解密密钥
var decryptionKey []byte

func init() {
	decryptionKey = make([]byte, 256)
	copy(decryptionKey, []byte(KeyHeader))
	dnf := []byte("DNF")
	for i := len(KeyHeader); i < 255; i++ {
		decryptionKey[i] = dnf[i%3]
	}
	decryptionKey[255] = 0
}

// 解密文件名
func DecryptPath(encrypted []byte) string {
	decrypted := make([]byte, len(encrypted))
	for i := 0; i < len(encrypted) && i < 256; i++ {
		decrypted[i] = encrypted[i] ^ decryptionKey[i]
		if decrypted[i] == 0 {
			return string(decrypted[:i])
		}
	}
	return strings.TrimRight(string(decrypted), "\x00")
}

// 加密文件名（使用标准密钥）
func EncryptPath(path string) []byte {
	data := make([]byte, 256)
	copy(data, []byte(path))
	for i := 0; i < len(data); i++ {
		data[i] = data[i] ^ decryptionKey[i]
	}
	return data
}

// 自定义密钥加密文件名
func EncryptPathWithKey(path string, key []byte) []byte {
	data := make([]byte, 256)
	copy(data, []byte(path))
	for i := 0; i < len(data) && i < len(key); i++ {
		data[i] = data[i] ^ key[i]
	}
	return data
}

// 使用文件名作为密钥进行加密（名称加密）
// 文件名取前256字节，不足部分用 0x00 填充
func EncryptPathWithNameKey(path string, npkName string) []byte {
	key := make([]byte, 256)
	copy(key, []byte(npkName))
	return EncryptPathWithKey(path, key)
}

// 读取明文路径
func ReadPlaintext(pathData []byte) string {
	for i, b := range pathData {
		if b == 0 {
			return string(pathData[:i])
		}
	}
	return string(pathData)
}

// CleanCorruptedPath 清理损坏的路径，截断到有效部分
// 用于处理 02.NPK 类型的异常文件，去除 "dungeon and fighter" 和 "DNF" 填充字符
func CleanCorruptedPath(path string) string {
	// 查找 "dungeon" 或 "DNF" 填充字符的位置
	dungeonIdx := strings.Index(strings.ToLower(path), "dungeon")
	dnfIdx := strings.Index(path, "DNF")

	// 取最早出现的污染位置
	cutIdx := len(path)
	if dungeonIdx > 0 && dungeonIdx < cutIdx {
		cutIdx = dungeonIdx
	}
	if dnfIdx > 0 && dnfIdx < cutIdx {
		cutIdx = dnfIdx
	}

	if cutIdx < len(path) {
		path = path[:cutIdx]
	}

	// 去除尾部空白和特殊字符
	path = strings.TrimRight(path, " \t\n\r\x00")

	return path
}

// 验证路径有效性
func IsValidPath(path string) bool {
	if len(path) == 0 {
		return false
	}
	if !strings.Contains(path, "/") {
		return false
	}
	lower := strings.ToLower(path)
	if !strings.HasSuffix(lower, ".img") && !strings.HasSuffix(lower, ".ogg") {
		return false
	}
	// 排除被密钥填充字符污染的路径
	if strings.Contains(path, "dungeon and fighter") {
		return false
	}
	if strings.Contains(path, "DNFDNF") {
		return false
	}
	return true
}

// 检测单个路径的加密类型
func DetectEncryptionType(pathData []byte) EncryptionType {
	decrypted := DecryptPath(pathData)
	decValid := IsValidPath(decrypted)

	plaintext := ReadPlaintext(pathData)
	plainValid := IsValidPath(plaintext)

	if decValid && !plainValid {
		return Encrypted
	}
	if !decValid && plainValid {
		return Plaintext
	}
	if !decValid && !plainValid {
		return EncryptedUnknown
	}
	// 两者都有效时优先使用加密
	return Encrypted
}

// DetectNpkEncryptionType 检测整个 NPK 文件的加密类型
// 返回: 0=标准加密, 1=明文, 99=异常/损坏
func DetectNpkEncryptionType(reader io.ReadSeeker) (int, error) {
	// 保存当前位置
	currentPos, err := reader.Seek(0, io.SeekCurrent)
	if err != nil {
		return 0, err
	}
	defer reader.Seek(currentPos, io.SeekStart)

	// 读取标志
	flag := make([]byte, 16)
	if _, err := reader.Read(flag); err != nil {
		return 0, fmt.Errorf("读取标志失败: %w", err)
	}

	flagStr := strings.TrimRight(string(flag), "\x00")
	if flagStr != NpkFlag {
		return 0, fmt.Errorf("无效的 NPK 文件标志: %s", flagStr)
	}

	// 读取数量
	var count int32
	if err := binary.Read(reader, binary.LittleEndian, &count); err != nil {
		return 0, fmt.Errorf("读取数量失败: %w", err)
	}

	if count == 0 {
		return 0, nil // 空文件，默认加密
	}

	// 采样检测（最多检测前 20 个路径）
	sampleSize := int(count)
	if sampleSize > 20 {
		sampleSize = 20
	}

	var encValidCount, plainValidCount int

	for i := 0; i < sampleSize; i++ {
		// 跳过 offset 和 length
		var offset, length int32
		if err := binary.Read(reader, binary.LittleEndian, &offset); err != nil {
			break
		}
		if err := binary.Read(reader, binary.LittleEndian, &length); err != nil {
			break
		}

		pathData := make([]byte, 256)
		if _, err := reader.Read(pathData); err != nil {
			break
		}

		encType := DetectEncryptionType(pathData)
		switch encType {
		case Encrypted:
			encValidCount++
		case Plaintext:
			plainValidCount++
		}
	}

	total := sampleSize
	encRate := float64(encValidCount) / float64(total)
	plainRate := float64(plainValidCount) / float64(total)

	// 判断逻辑
	if encRate > 0.8 {
		return 0, nil // 标准加密
	}
	if plainRate > 0.8 {
		return 1, nil // 明文
	}
	// 如果大部分路径是加密的，即使少数路径检测失败，也认为是标准加密
	// 这可以处理自定义 NPK 文件中包含非标准 IMG 的情况
	if encRate > 0.5 {
		return 0, nil // 标准加密（容忍部分非标准路径）
	}
	return 99, nil // 异常/损坏
}

// NPK 文件头
type NpkHeader struct {
	Flag  string // 16 bytes
	Count int32
}

// NPK 索引项
type NpkIndex struct {
	Offset int32
	Length int32
	Path   string // 256 bytes encrypted
}

// NPK 文件
type NpkFile struct {
	Path    string
	Albums  []*Album
	Indexes []*NpkIndex
}

// Album (IMG 文件)
type Album struct {
	Path         string
	Name         string
	Offset       int64
	Length       int64
	IndexLength  int64
	Version      ImgVersion
	Count        int
	Sprites      []*Sprite
	Textures     []*Texture
	Tables       [][]RGBA            // 调色板表 (V4/V6)
	TableIndex   int
	TextureInfos map[int]*TextureInfo // V5 纹理引用
	Data         []byte
	Target       *Album               // 重定向目标（引用另一个 Album）
	TargetPath   string               // 重定向目标路径（用于序列化）
}

// Sprite (贴图/帧)
type Sprite struct {
	Index       int
	Type        ColorBits
	CompressMode CompressMode
	Width       int
	Height      int
	Length      int
	X           int // 坐标偏移
	Y           int
	FrameWidth  int  // 帧域宽度
	FrameHeight int
	Data        []byte
	Target      *Sprite // Link 指向的目标（解析后填充）
	TargetIndex int     // LINK 类型时指向的目标索引（用于 API 返回）
	Parent      *Album
}

// Texture (DDS 纹理, V5 专用)
type Texture struct {
	Index      int
	Width      int
	Height     int
	Length     int
	FullLength int
	Data       []byte
	Version    TextureVersion
	Type       ColorBits
}

type TextureVersion int

const (
	Dxt1 TextureVersion = 0x01
	Dxt3 TextureVersion = 0x03
	Dxt5 TextureVersion = 0x05
)

// TextureInfo (V5 纹理引用信息)
type TextureInfo struct {
	Texture  *Texture
	LeftUp   Point
	RightDown Point
	Top      int
	Unknown  int
}

type Point struct {
	X, Y int
}

// RGBA 颜色
type RGBA struct {
	R, G, B, A uint8
}

// 读取 NPK 文件（默认使用解密）
func ReadNpk(reader io.ReadSeeker) (*NpkFile, error) {
	return ReadNpkWithFormat(reader, 0) // 默认标准加密
}

// ReadNpkWithFormat 根据 format_type 读取 NPK 文件
// formatType: 0=标准加密(解密), 1=明文(不解密), 99=异常(尝试解密，失败则使用明文)
func ReadNpkWithFormat(reader io.ReadSeeker, formatType int) (*NpkFile, error) {
	// 读取标志
	flag := make([]byte, 16)
	if _, err := reader.Read(flag); err != nil {
		return nil, fmt.Errorf("读取标志失败: %w", err)
	}

	flagStr := strings.TrimRight(string(flag), "\x00")
	if flagStr != NpkFlag {
		return nil, fmt.Errorf("无效的 NPK 文件标志: %s", flagStr)
	}

	// 读取数量
	var count int32
	if err := binary.Read(reader, binary.LittleEndian, &count); err != nil {
		return nil, fmt.Errorf("读取数量失败: %w", err)
	}

	npk := &NpkFile{
		Albums:  make([]*Album, 0, count),
		Indexes: make([]*NpkIndex, 0, count),
	}

	// 读取索引表
	for i := 0; i < int(count); i++ {
		var offset, length int32
		if err := binary.Read(reader, binary.LittleEndian, &offset); err != nil {
			return nil, err
		}
		if err := binary.Read(reader, binary.LittleEndian, &length); err != nil {
			return nil, err
		}

		pathData := make([]byte, 256)
		if _, err := reader.Read(pathData); err != nil {
			return nil, err
		}

		// 根据 format_type 选择读取方式
		var path string
		switch formatType {
		case 1: // 明文 NPK (如 01.NPK)
			path = ReadPlaintext(pathData)
		case 99: // 异常 NPK (如 02.NPK)，尝试解密，如果无效则使用原始数据并清理
			decrypted := DecryptPath(pathData)
			if IsValidPath(decrypted) {
				path = decrypted
			} else {
				// 使用原始数据并清理填充字符
				path = ReadPlaintext(pathData)
				path = CleanCorruptedPath(path)
			}
		default: // 标准加密 (formatType = 0 或未指定)
			path = DecryptPath(pathData)
		}

		npk.Indexes = append(npk.Indexes, &NpkIndex{
			Offset: offset,
			Length: length,
			Path:   path,
		})
	}

	return npk, nil
}

// AlbumHeader 包含 IMG 的基础头部信息
type AlbumHeader struct {
	Path        string
	Name        string
	Version     ImgVersion
	SpriteCount int
}

// ReadAlbumHeader 快速读取 Album 的头部信息（Version 和 SpriteCount），不解析 Sprites 详情
func ReadAlbumHeader(reader io.ReadSeeker, index *NpkIndex) (*AlbumHeader, error) {
	header := &AlbumHeader{
		Path: index.Path,
		Name: extractName(index.Path),
	}

	if _, err := reader.Seek(int64(index.Offset), io.SeekStart); err != nil {
		return nil, err
	}

	// 读取 IMG 标志 (以 \0 结尾的字符串)
	var flagBuf []byte
	for {
		b := make([]byte, 1)
		if _, err := reader.Read(b); err != nil {
			return nil, err
		}
		if b[0] == 0 {
			break
		}
		flagBuf = append(flagBuf, b[0])
	}
	flagStr := string(flagBuf)

	if flagStr == ImgFlag {
		// V2+ 格式
		// 跳过索引长度 (8 bytes)
		skipBuf := make([]byte, 8)
		if _, err := io.ReadFull(reader, skipBuf); err != nil {
			return nil, err
		}
		// 读取版本
		var version int32
		if err := binary.Read(reader, binary.LittleEndian, &version); err != nil {
			return nil, err
		}
		header.Version = ImgVersion(version)
		// 读取数量
		var count int32
		if err := binary.Read(reader, binary.LittleEndian, &count); err != nil {
			return nil, err
		}
		header.SpriteCount = int(count)
	} else if flagStr == ImageFlag {
		// V1 格式
		header.Version = Ver1
		// 跳过索引长度 (4 bytes) + 未知 2 bytes
		skipBuf := make([]byte, 6)
		if _, err := io.ReadFull(reader, skipBuf); err != nil {
			return nil, err
		}
		// 读取版本 (4 bytes)
		var version int32
		if err := binary.Read(reader, binary.LittleEndian, &version); err != nil {
			return nil, err
		}
		header.Version = ImgVersion(version)
		// 读取数量 (4 bytes)
		var count int32
		if err := binary.Read(reader, binary.LittleEndian, &count); err != nil {
			return nil, err
		}
		header.SpriteCount = int(count)
	} else {
		// 其他格式
		header.Version = Other
		header.SpriteCount = 0
	}

	return header, nil
}

// 读取指定 Album
func ReadAlbum(reader io.ReadSeeker, index *NpkIndex) (*Album, error) {
	album := &Album{
		Path:   index.Path,
		Name:   extractName(index.Path),
		Offset: int64(index.Offset),
		Length: int64(index.Length),
	}

	if _, err := reader.Seek(int64(index.Offset), io.SeekStart); err != nil {
		return nil, err
	}

	// 读取 IMG 标志 (以 \0 结尾的字符串)
	var flagBuf []byte
	for {
		b := make([]byte, 1)
		if _, err := reader.Read(b); err != nil {
			return nil, err
		}
		if b[0] == 0 {
			break
		}
		flagBuf = append(flagBuf, b[0])
	}
	flagStr := string(flagBuf)

	if flagStr == ImgFlag {
		// V2+ 格式
		if err := readImgV2(reader, album); err != nil {
			return nil, err
		}
	} else if flagStr == ImageFlag {
		// V1 格式
		album.Version = Ver1
		if err := readImgV1(reader, album); err != nil {
			return nil, err
		}
	} else {
		// 其他格式或音频文件
		album.Version = Other
	}

	return album, nil
}

// ReadAlbumFromData 从字节数据读取 Album（用于独立 IMG 文件）
func ReadAlbumFromData(data []byte) (*Album, error) {
	reader := &bytesReader{data: data, pos: 0}

	// 模拟 NpkIndex（独立 IMG 文件不需要实际的 NPK 索引信息）
	index := &NpkIndex{
		Path:   "",
		Offset: 0,
		Length: int32(len(data)),
	}

	return ReadAlbum(reader, index)
}

// bytesReader 简单的字节切片读取器
type bytesReader struct {
	data []byte
	pos  int64
}

func (r *bytesReader) Read(p []byte) (n int, err error) {
	if r.pos >= int64(len(r.data)) {
		return 0, io.EOF
	}
	n = copy(p, r.data[r.pos:])
	r.pos += int64(n)
	return n, nil
}

func (r *bytesReader) Seek(offset int64, whence int) (int64, error) {
	switch whence {
	case io.SeekStart:
		r.pos = offset
	case io.SeekCurrent:
		r.pos += offset
	case io.SeekEnd:
		r.pos = int64(len(r.data)) + offset
	}
	if r.pos < 0 {
		r.pos = 0
	}
	if r.pos > int64(len(r.data)) {
		r.pos = int64(len(r.data))
	}
	return r.pos, nil
}

// 从路径提取名称
func extractName(path string) string {
	parts := strings.Split(path, "/")
	if len(parts) > 0 {
		return parts[len(parts)-1]
	}
	return path
}

// DecodeSprite 解码 Sprite 为 RGBA 图像数据
func DecodeSprite(sprite *Sprite) ([]byte, error) {
	if sprite == nil {
		return nil, fmt.Errorf("sprite is nil")
	}
	if sprite.Type == LINK && sprite.Target != nil {
		return DecodeSprite(sprite.Target)
	}

	// 验证尺寸
	if sprite.Width <= 0 || sprite.Height <= 0 || sprite.Width > 8192 || sprite.Height > 8192 {
		return nil, fmt.Errorf("invalid sprite dimensions: %dx%d", sprite.Width, sprite.Height)
	}

	data := sprite.Data
	var err error

	// 处理空数据
	if len(data) == 0 {
		// 验证尺寸后再分配
		pixelCount := int64(sprite.Width) * int64(sprite.Height) * 4
		if pixelCount <= 0 || pixelCount > 100*1024*1024 {
			return nil, fmt.Errorf("invalid dimensions for empty data: %dx%d", sprite.Width, sprite.Height)
		}
		// 返回透明图像
		pixels := make([]byte, pixelCount)
		return pixels, nil
	}

	// 解压缩
	// 根据颜色类型计算正确的解压大小（参考 ExtractorSharp SecondHandler.ConvertToBitmap）
	// ARGB_8888: 每像素 4 字节, ARGB_1555/ARGB_4444: 每像素 2 字节
	if sprite.CompressMode == ZLIB || sprite.CompressMode == DDS_ZLIB {
		bytesPerPixel := int64(4)
		if sprite.Type == ARGB_1555 || sprite.Type == ARGB_4444 {
			bytesPerPixel = 2
		}
		decompressSize := int64(sprite.Width) * int64(sprite.Height) * bytesPerPixel
		if decompressSize <= 0 || decompressSize > 100*1024*1024 {
			return nil, fmt.Errorf("invalid decompress size: %d", decompressSize)
		}
		
		// 记录调试信息
		WriteZlibDebugLog(fmt.Sprintf("[DecodeSprite] Index=%d, Type=%v, Size=%dx%d, CompressMode=%v, DataLen=%d, ExpectedDecompress=%d",
			sprite.Index, sprite.Type, sprite.Width, sprite.Height, sprite.CompressMode, len(data), decompressSize))
		
		data, err = ZlibDecompress(data, int(decompressSize))
		if err != nil {
			return nil, fmt.Errorf("解压缩失败: %w", err)
		}
	}

	// 根据类型解码
	// 注意：解码后的数据格式为 BGRA (B, G, R, A)，ToImage() 会转换为 RGBA
	switch sprite.Type {
	case ARGB_1555:
		return DecodeARGB1555(data, sprite.Width, sprite.Height)
	case ARGB_4444:
		return DecodeARGB4444(data, sprite.Width, sprite.Height)
	case ARGB_8888:
		// ARGB_8888 直接返回原始数据（BGRA 格式）
		return data, nil
	default:
		return data, nil
	}
}

// DecodeARGB1555 解码 ARGB1555 格式
func DecodeARGB1555(data []byte, width, height int) ([]byte, error) {
	// 验证尺寸
	if width <= 0 || height <= 0 || width > 8192 || height > 8192 {
		return nil, fmt.Errorf("invalid dimensions: %dx%d", width, height)
	}
	pixels := make([]byte, width*height*4)
	for i := 0; i < width*height; i++ {
		if i*2+1 >= len(data) {
			break
		}
		lo := data[i*2]
		hi := data[i*2+1]

		// ARGB_1555 的 alpha 位（bit 15）：1=不透明，0=透明（标准解释）
		a := uint8(255)
		if hi&0x80 == 0 {
			a = 0
		}
		r := (hi >> 2) & 0x1F
		g := ((lo >> 5) & 0x07) | ((hi & 0x03) << 3)
		b := lo & 0x1F

		// 扩展到 8 位
		r = (r << 3) | (r >> 2)
		g = (g << 3) | (g >> 2)
		b = (b << 3) | (b >> 2)

		pixels[i*4+0] = b
		pixels[i*4+1] = g
		pixels[i*4+2] = r
		pixels[i*4+3] = a
	}

	return pixels, nil
}

// DecodeARGB4444 解码 ARGB4444 格式
func DecodeARGB4444(data []byte, width, height int) ([]byte, error) {
	// 验证尺寸
	if width <= 0 || height <= 0 || width > 8192 || height > 8192 {
		return nil, fmt.Errorf("invalid dimensions: %dx%d", width, height)
	}
	pixels := make([]byte, width*height*4)
	for i := 0; i < width*height; i++ {
		if i*2+1 >= len(data) {
			break
		}
		lo := data[i*2]
		hi := data[i*2+1]

		a := (hi & 0xF0)
		r := (hi & 0x0F) << 4
		g := lo & 0xF0
		b := (lo & 0x0F) << 4

		pixels[i*4+0] = b
		pixels[i*4+1] = g
		pixels[i*4+2] = r
		pixels[i*4+3] = a
	}
	return pixels, nil
}

// DecodeARGB8888SwapRB 解码 ARGB_8888 格式并交换 R/B 通道 (V2)
// 原始数据格式：BGRA (B, G, R, A)
// 输出格式：RGBA (R, G, B, A) - 交换 R 和 B
// 参考：NPK_ENCRYPTION_RESEARCH.md 13.2 节
func DecodeARGB8888SwapRB(data []byte) []byte {
	if len(data) == 0 {
		return data
	}
	pixels := make([]byte, len(data))
	for i := 0; i+3 < len(data); i += 4 {
		// 原始: B=data[i], G=data[i+1], R=data[i+2], A=data[i+3]
		// 输出: R=data[i+2], G=data[i+1], B=data[i], A=data[i+3]
		pixels[i]   = data[i+2]   // R
		pixels[i+1] = data[i+1]   // G
		pixels[i+2] = data[i]     // B
		pixels[i+3] = data[i+3]  // A
	}
	return pixels
}

// DecodeSpriteWithPalette 使用调色板解码 (V4)
func DecodeSpriteWithPalette(sprite *Sprite, palette []RGBA) ([]byte, error) {
	if sprite == nil {
		return nil, fmt.Errorf("sprite is nil")
	}
	if sprite.Type != ARGB_1555 {
		return DecodeSprite(sprite)
	}

	// 验证尺寸
	if sprite.Width <= 0 || sprite.Height <= 0 || sprite.Width > 8192 || sprite.Height > 8192 {
		return nil, fmt.Errorf("invalid sprite dimensions: %dx%d", sprite.Width, sprite.Height)
	}

	data := sprite.Data
	var err error

	if sprite.CompressMode == ZLIB {
		data, err = ZlibDecompress(data, sprite.Width*sprite.Height)
		if err != nil {
			return nil, err
		}
	}

	pixels := make([]byte, sprite.Width*sprite.Height*4)
	for i := 0; i < len(data) && i < sprite.Width*sprite.Height; i++ {
		idx := int(data[i]) % len(palette)
		if idx < 0 {
			idx = 0
		}
		c := palette[idx]
		pixels[i*4+0] = c.B
		pixels[i*4+1] = c.G
		pixels[i*4+2] = c.R
		// 处理透明度：如果调色板 Alpha 为 0，或者索引为 0（通常表示透明），则设为透明
		if c.A == 0 || idx == 0 {
			pixels[i*4+3] = 0
		} else {
			pixels[i*4+3] = c.A
		}
	}

	return pixels, nil
}


