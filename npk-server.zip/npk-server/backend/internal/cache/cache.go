package cache

import (
	"container/list"
	"sync"
	"time"
)

// Cache 缓存
type Cache struct {
	mu       sync.RWMutex
	items    map[string]*cacheItem
	lru      *list.List
	maxSize  int
	maxItems int

	// 命中率统计
	hits   int64
	misses int64
}

type cacheItem struct {
	key       string
	value     interface{}
	size      int
	createdAt time.Time
	element   *list.Element
}

// NewCache 创建缓存
func NewCache(maxSize, maxItems int) *Cache {
	return &Cache{
		items:    make(map[string]*cacheItem),
		lru:      list.New(),
		maxSize:  maxSize * 1024 * 1024, // MB to bytes
		maxItems: maxItems,
	}
}

// Set 设置缓存
func (c *Cache) Set(key string, value interface{}, size int) {
	c.mu.Lock()
	defer c.mu.Unlock()

	// 检查是否已存在
	if item, exists := c.items[key]; exists {
		c.lru.MoveToFront(item.element)
		item.value = value
		item.size = size
		item.createdAt = time.Now()
		return
	}

	// 创建新项
	item := &cacheItem{
		key:       key,
		value:     value,
		size:      size,
		createdAt: time.Now(),
	}
	item.element = c.lru.PushFront(item)
	c.items[key] = item

	// 检查是否需要淘汰
	c.evict()
}

// Get 获取缓存
func (c *Cache) Get(key string) (interface{}, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()

	item, exists := c.items[key]
	if !exists {
		c.misses++
		return nil, false
	}

	c.hits++
	c.lru.MoveToFront(item.element)
	return item.value, true
}

// Delete 删除缓存
func (c *Cache) Delete(key string) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if item, exists := c.items[key]; exists {
		c.lru.Remove(item.element)
		delete(c.items, key)
	}
}

// Clear 清空缓存
func (c *Cache) Clear() {
	c.mu.Lock()
	defer c.mu.Unlock()

	c.items = make(map[string]*cacheItem)
	c.lru = list.New()
}

// Size 获取缓存大小（字节）
func (c *Cache) Size() int {
	c.mu.RLock()
	defer c.mu.RUnlock()

	total := 0
	for _, item := range c.items {
		total += item.size
	}
	return total
}

// Count 获取缓存项数量
func (c *Cache) Count() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.items)
}

// HitRate 获取缓存命中率（百分比 0-100）
func (c *Cache) HitRate() float64 {
	c.mu.RLock()
	defer c.mu.RUnlock()

	total := c.hits + c.misses
	if total == 0 {
		return 0
	}
	return float64(c.hits) * 100 / float64(total)
}

// Hits 返回命中次数
func (c *Cache) Hits() int64 {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.hits
}

// Misses 返回未命中次数
func (c *Cache) Misses() int64 {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.misses
}

// evict 淘汰旧项
func (c *Cache) evict() {
	for {
		// 检查数量限制
		if c.maxItems > 0 && len(c.items) > c.maxItems {
			c.evictOne()
			continue
		}

		// 检查大小限制
		if c.maxSize > 0 && c.currentSize() > c.maxSize {
			c.evictOne()
			continue
		}

		break
	}
}

// evictOne 淘汰一项
func (c *Cache) evictOne() {
	if c.lru.Len() == 0 {
		return
	}

	element := c.lru.Back()
	if element == nil {
		return
	}

	item := element.Value.(*cacheItem)
	c.lru.Remove(element)
	delete(c.items, item.key)
}

// currentSize 当前大小
func (c *Cache) currentSize() int {
	total := 0
	for _, item := range c.items {
		total += item.size
	}
	return total
}

// ImageCache 图片缓存
type ImageCache struct {
	cache *Cache
}

// NewImageCache 创建图片缓存
func NewImageCache(maxSize, maxItems int) *ImageCache {
	return &ImageCache{
		cache: NewCache(maxSize, maxItems),
	}
}

// SetImage 设置图片缓存
func (c *ImageCache) SetImage(key string, data []byte) {
	c.cache.Set(key, data, len(data))
}

// GetImage 获取图片缓存
func (c *ImageCache) GetImage(key string) ([]byte, bool) {
	if v, ok := c.cache.Get(key); ok {
		return v.([]byte), true
	}
	return nil, false
}

// Delete 删除缓存
func (c *ImageCache) Delete(key string) {
	c.cache.Delete(key)
}

// DeleteByNpk 删除指定 NPK 的所有缓存
func (c *ImageCache) DeleteByNpk(npkName string) {
	c.cache.mu.Lock()
	defer c.cache.mu.Unlock()

	prefix := npkName + ":"
	for key, item := range c.cache.items {
		if len(key) >= len(prefix) && key[:len(prefix)] == prefix {
			c.cache.lru.Remove(item.element)
			delete(c.cache.items, key)
		}
	}
}

// Clear 清空缓存
func (c *ImageCache) Clear() {
	c.cache.Clear()
}

// Stats 缓存统计
func (c *ImageCache) Stats() map[string]interface{} {
	return map[string]interface{}{
		"count":     c.cache.Count(),
		"size":      c.cache.Size(),
		"hits":      c.cache.Hits(),
		"misses":    c.cache.Misses(),
		"hit_rate":  c.cache.HitRate(),
		"max_size":  c.cache.maxSize,
		"max_items": c.cache.maxItems,
	}
}

// ThumbnailCache 缩略图缓存
type ThumbnailCache struct {
	cache *Cache
}

// NewThumbnailCache 创建缩略图缓存
func NewThumbnailCache(maxItems int) *ThumbnailCache {
	return &ThumbnailCache{
		cache: NewCache(100, maxItems), // 100MB
	}
}

// SetThumbnail 设置缩略图
func (c *ThumbnailCache) SetThumbnail(npkName string, albumPath string, spriteIndex int, data []byte) {
	key := c.makeKey(npkName, albumPath, spriteIndex)
	c.cache.Set(key, data, len(data))
}

// GetThumbnail 获取缩略图
func (c *ThumbnailCache) GetThumbnail(npkName string, albumPath string, spriteIndex int) ([]byte, bool) {
	key := c.makeKey(npkName, albumPath, spriteIndex)
	if v, ok := c.cache.Get(key); ok {
		return v.([]byte), true
	}
	return nil, false
}

func (c *ThumbnailCache) makeKey(npkName, albumPath string, spriteIndex int) string {
	return npkName + ":" + albumPath + ":" + string(rune(spriteIndex))
}

// Clear 清空缓存
func (c *ThumbnailCache) Clear() {
	c.cache.Clear()
}

// Delete 删除缩略图缓存
func (c *ThumbnailCache) Delete(npkName string, albumPath string, spriteIndex int) {
	key := c.makeKey(npkName, albumPath, spriteIndex)
	c.cache.Delete(key)
}

// DeleteByNpk 删除指定 NPK 的所有缩略图缓存
func (c *ThumbnailCache) DeleteByNpk(npkName string) {
	c.cache.mu.Lock()
	defer c.cache.mu.Unlock()

	prefix := npkName + ":"
	for key, item := range c.cache.items {
		if len(key) >= len(prefix) && key[:len(prefix)] == prefix {
			c.cache.lru.Remove(item.element)
			delete(c.cache.items, key)
		}
	}
}
