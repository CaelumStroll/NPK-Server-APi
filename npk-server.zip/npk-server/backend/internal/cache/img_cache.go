package cache

import (
	"container/list"
	"fmt"
	"sync"
	"time"

	"npk-server/internal/npk"
)

// ImgCacheEntry IMG 缓存条目
type ImgCacheEntry struct {
	Key         string
	NpkName     string
	AlbumPath   string
	Album       *npk.Album
	Sprites     []*npk.Sprite
	Images      map[int]*npk.ImageData // 已解码的图片缓存（懒加载）
	TotalSize   int64                  // 当前缓存大小（字节）
	LastAccess  time.Time
	AccessCount int
	lruElem     *list.Element // LRU 链表元素
}

// ImgCachePool 全局 IMG 缓存池
type ImgCachePool struct {
	mu        sync.RWMutex
	entries   map[string]*ImgCacheEntry // key: npkName:albumPath
	lru       *list.List                // LRU 链表，队尾是最久未访问
	maxSize   int64                     // 最大内存（字节）
	maxItems  int                     // 最大条目数
	ttl       time.Duration             // 过期时间
	timer     *time.Timer               // 清理定时器
	stats     ImgCacheStats             // 统计信息
	totalSize int64                     // 当前总缓存大小
}

// ImgCacheStats 缓存统计
type ImgCacheStats struct {
	Hits      int64
	Misses    int64
	Evictions int64
}

// NewImgCachePool 创建 IMG 缓存池
// maxSizeMB: 最大内存（MB）
// maxItems: 最大条目数
// ttlMinutes: 过期时间（分钟）
func NewImgCachePool(maxSizeMB, maxItems, ttlMinutes int) *ImgCachePool {
	pool := &ImgCachePool{
		entries:  make(map[string]*ImgCacheEntry),
		lru:      list.New(),
		maxSize:  int64(maxSizeMB) * 1024 * 1024,
		maxItems: maxItems,
		ttl:      time.Duration(ttlMinutes) * time.Minute,
	}
	pool.startCleanupTimer()
	return pool
}

// cacheKey 生成缓存键
func cacheKey(npkName, albumPath string) string {
	return npkName + ":" + albumPath
}

// Load 加载 IMG 到缓存
func (p *ImgCachePool) Load(npkName, albumPath string, album *npk.Album, sprites []*npk.Sprite) error {
	key := cacheKey(npkName, albumPath)

	p.mu.Lock()
	defer p.mu.Unlock()

	// 如果已存在，更新访问时间
	if entry, ok := p.entries[key]; ok {
		entry.LastAccess = time.Now()
		entry.AccessCount++
		p.moveToFront(entry)
		return nil
	}

	// 检查是否需要淘汰
	p.evictIfNeeded()

	// 检查条目数限制
	if len(p.entries) >= p.maxItems {
		p.evictOne()
	}

	// 创建新条目
	entry := &ImgCacheEntry{
		Key:        key,
		NpkName:    npkName,
		AlbumPath:  albumPath,
		Album:      album,
		Sprites:    sprites,
		Images:     make(map[int]*npk.ImageData),
		TotalSize:  0,
		LastAccess: time.Now(),
	}

	// 添加到 LRU 链表头部（最新访问）
	entry.lruElem = p.lru.PushFront(entry)
	p.entries[key] = entry

	return nil
}

// GetImage 获取指定索引的图片（优先从缓存，未命中则解码并缓存）
func (p *ImgCachePool) GetImage(npkName, albumPath string, index int) (*npk.ImageData, error) {
	key := cacheKey(npkName, albumPath)

	p.mu.Lock()
	entry, ok := p.entries[key]
	if !ok {
		p.mu.Unlock()
		p.stats.Misses++
		return nil, fmt.Errorf("cache miss: %s", key)
	}

	// 检查图片是否已缓存
	if img, exists := entry.Images[index]; exists {
		entry.LastAccess = time.Now()
		entry.AccessCount++
		p.moveToFront(entry)
		p.stats.Hits++
		p.mu.Unlock()
		return img, nil
	}
	p.mu.Unlock()

	p.stats.Misses++
	return nil, fmt.Errorf("image not cached: %s[%d]", key, index)
}

// CacheImage 将解码后的图片存入缓存
func (p *ImgCachePool) CacheImage(npkName, albumPath string, index int, img *npk.ImageData) error {
	if img == nil {
		return nil
	}

	key := cacheKey(npkName, albumPath)
	imgSize := int64(img.Width * img.Height * 4) // RGBA = 4 bytes per pixel

	p.mu.Lock()
	defer p.mu.Unlock()

	entry, ok := p.entries[key]
	if !ok {
		return fmt.Errorf("entry not found: %s", key)
	}

	// 如果该索引已有缓存，先减去旧的大小
	if oldImg, exists := entry.Images[index]; exists {
		oldSize := int64(oldImg.Width * oldImg.Height * 4)
		entry.TotalSize -= oldSize
		p.totalSize -= oldSize
	}

	// 检查内存限制
	if p.totalSize+imgSize > p.maxSize {
		// 尝试淘汰旧缓存
		for p.totalSize+imgSize > p.maxSize && p.lru.Len() > 0 {
			p.evictOne()
		}
	}

	// 存入缓存
	entry.Images[index] = img
	entry.TotalSize += imgSize
	p.totalSize += imgSize
	entry.LastAccess = time.Now()
	p.moveToFront(entry)

	return nil
}

// Release 释放指定 IMG 缓存
func (p *ImgCachePool) Release(npkName, albumPath string) {
	key := cacheKey(npkName, albumPath)

	p.mu.Lock()
	defer p.mu.Unlock()

	if entry, ok := p.entries[key]; ok {
		p.removeEntry(entry)
	}
}

// ReleaseAll 释放所有缓存
func (p *ImgCachePool) ReleaseAll() {
	p.mu.Lock()
	defer p.mu.Unlock()

	for _, entry := range p.entries {
		p.lru.Remove(entry.lruElem)
	}
	p.entries = make(map[string]*ImgCacheEntry)
	p.lru.Init()
	p.totalSize = 0
	p.stats = ImgCacheStats{}
}

// GetStatus 获取缓存状态
func (p *ImgCachePool) GetStatus() map[string]interface{} {
	p.mu.RLock()
	defer p.mu.RUnlock()

	items := make([]map[string]interface{}, 0, len(p.entries))
	for key, entry := range p.entries {
		items = append(items, map[string]interface{}{
			"key":          key,
			"npk_name":     entry.NpkName,
			"album_path":   entry.AlbumPath,
			"sprite_count": len(entry.Sprites),
			"cached_images": len(entry.Images),
			"total_size_mb": float64(entry.TotalSize) / 1024 / 1024,
			"loaded_at":    time.Now().Add(-time.Since(entry.LastAccess)).Format("15:04:05"),
			"last_access":  entry.LastAccess.Format("15:04:05"),
			"access_count": entry.AccessCount,
		})
	}

	hitRate := float64(0)
	if p.stats.Hits+p.stats.Misses > 0 {
		hitRate = float64(p.stats.Hits) / float64(p.stats.Hits+p.stats.Misses) * 100
	}

	return map[string]interface{}{
		"items":        items,
		"count":        len(p.entries),
		"total_size_mb": float64(p.totalSize) / 1024 / 1024,
		"max_size_mb":  float64(p.maxSize) / 1024 / 1024,
		"hit_rate":     hitRate,
		"hits":         p.stats.Hits,
		"misses":       p.stats.Misses,
		"evictions":    p.stats.Evictions,
	}
}

// IsCached 检查是否已缓存
func (p *ImgCachePool) IsCached(npkName, albumPath string) bool {
	p.mu.RLock()
	defer p.mu.RUnlock()

	_, ok := p.entries[cacheKey(npkName, albumPath)]
	return ok
}

// 内部方法：移动到 LRU 链表头部
func (p *ImgCachePool) moveToFront(entry *ImgCacheEntry) {
	if entry.lruElem != nil {
		p.lru.MoveToFront(entry.lruElem)
	}
}

// 内部方法：移除条目
func (p *ImgCachePool) removeEntry(entry *ImgCacheEntry) {
	if entry.lruElem != nil {
		p.lru.Remove(entry.lruElem)
	}
	delete(p.entries, entry.Key)
	p.totalSize -= entry.TotalSize
	p.stats.Evictions++
}

// 内部方法：淘汰一个条目（LRU）
func (p *ImgCachePool) evictOne() {
	elem := p.lru.Back()
	if elem == nil {
		return
	}

	entry := elem.Value.(*ImgCacheEntry)
	p.removeEntry(entry)
}

// 内部方法：检查并淘汰
func (p *ImgCachePool) evictIfNeeded() {
	for p.totalSize > p.maxSize && p.lru.Len() > 0 {
		p.evictOne()
	}
}

// 内部方法：启动清理定时器
func (p *ImgCachePool) startCleanupTimer() {
	p.timer = time.AfterFunc(p.ttl/2, func() {
		p.cleanupExpired()
		p.startCleanupTimer() // 递归启动下一次
	})
}

// 内部方法：清理过期条目
func (p *ImgCachePool) cleanupExpired() {
	p.mu.Lock()
	defer p.mu.Unlock()

	now := time.Now()
	expiredKeys := make([]string, 0)

	for key, entry := range p.entries {
		if now.Sub(entry.LastAccess) > p.ttl {
			expiredKeys = append(expiredKeys, key)
		}
	}

	for _, key := range expiredKeys {
		if entry, ok := p.entries[key]; ok {
			p.removeEntry(entry)
		}
	}
}

// TotalSize 计算当前总大小
func (s *ImgCacheStats) TotalSize() int64 {
	// 这个需要在 ImgCachePool 中实时计算
	return 0
}

// Stop 停止缓存池
func (p *ImgCachePool) Stop() {
	if p.timer != nil {
		p.timer.Stop()
	}
}
