package api

import (
	"fmt"
	"log"
	"os"

	"github.com/gin-gonic/gin"
)

// getMusicDBStats 获取音乐数据库统计信息
// GET /api/db/music/stats
func (s *Server) getMusicDBStats(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	stats, err := s.musicSvc.GetMusicStats()
	if err != nil {
		respondInternalError(c, "获取音乐统计失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"music_count":    stats.TotalCount,
		"total_size":     stats.TotalSize,
		"total_duration": stats.TotalDuration,
	})
}

// cleanupMusicDB 清理音乐数据库中的无效记录
// POST /api/db/music/cleanup
func (s *Server) cleanupMusicDB(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	musicRecords, _, err := s.musicSvc.ListMusic("", 1, 100000)
	if err != nil {
		respondInternalError(c, "获取音乐列表失败: "+err.Error())
		return
	}

	var deletedCount int
	var invalidFiles []string

	for _, m := range musicRecords {
		if _, statErr := os.Stat(m.Path); os.IsNotExist(statErr) {
			if delErr := s.musicSvc.DeleteMusic(m.ID); delErr == nil {
				deletedCount++
				invalidFiles = append(invalidFiles, m.Path)
			}
		}
	}

	msg := fmt.Sprintf("清理完成：删除 %d 条无效音乐记录", deletedCount)
	if deletedCount > 0 {
		msg = fmt.Sprintf("清理完成：删除 %d 条无效音乐记录（文件已不存在）", deletedCount)
	}

	respondSuccess(c, gin.H{
		"message":       msg,
		"deleted_count": deletedCount,
		"invalid_files": invalidFiles,
	})
}

// rebuildMusicDB 重建音乐数据库
// POST /api/db/music/rebuild
func (s *Server) rebuildMusicDB(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	oldStats, _ := s.musicSvc.GetMusicStats()
	oldCount := 0
	if oldStats != nil {
		oldCount = oldStats.TotalCount
	}

	var totalScanned int
	musicDirs := s.cfg.MusicDirs
	log.Printf("[rebuildMusicDB] 当前配置的音乐目录: %v (len=%d)", musicDirs, len(musicDirs))

	if len(musicDirs) == 0 {
		respondBadRequest(c, "未配置音乐目录，请在 设置 → 音乐目录 中添加目录后保存，再执行重建")
		return
	}

	for _, dir := range musicDirs {
		log.Printf("[rebuildMusicDB] 扫描目录: %s", dir)
		records, err := s.musicSvc.RescanDir(dir)
		if err != nil {
			log.Printf("[rebuildMusicDB] 扫描目录 %s 失败: %v", dir, err)
			continue
		}
		log.Printf("[rebuildMusicDB] 扫描目录 %s 完成，获取 %d 条记录", dir, len(records))
		totalScanned += len(records)
	}

	newStats, _ := s.musicSvc.GetMusicStats()
	newCount := 0
	if newStats != nil {
		newCount = newStats.TotalCount
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("重建完成：原 %d 条记录，现 %d 条记录", oldCount, newCount),
		"old_count":     oldCount,
		"new_count":     newCount,
		"scanned_count": totalScanned,
	})
}

// compactMusicDB 压缩音乐数据库（VACUUM）
// POST /api/db/music/compact
func (s *Server) compactMusicDB(c *gin.Context) {
	if err := s.db.Compact(); err != nil {
		respondInternalError(c, "压缩数据库失败: "+err.Error())
		return
	}

	dbSize, _ := s.db.GetDBSize()
	respondSuccess(c, gin.H{
		"message": "音乐数据库压缩完成",
		"db_size": dbSize,
	})
}
