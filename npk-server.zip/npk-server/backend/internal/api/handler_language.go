package api

import (
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/gin-gonic/gin"
)

func (s *Server) listLanguages(c *gin.Context) {
	langDir := s.getLanguageDir()
	entries, err := os.ReadDir(langDir)
	if err != nil {
		c.JSON(http.StatusOK, Response{Code: 0, Data: []string{}})
		return
	}

	var languages []string
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		name := entry.Name()
		if strings.HasSuffix(name, ".json") {
			languages = append(languages, strings.TrimSuffix(name, ".json"))
		}
	}

	c.JSON(http.StatusOK, Response{Code: 0, Data: languages})
}

func (s *Server) getLanguage(c *gin.Context) {
	locale := c.Param("locale")
	if locale == "" {
		c.JSON(http.StatusBadRequest, Response{Code: -1, Message: "missing locale"})
		return
	}

	locale = strings.TrimSuffix(locale, ".json")
	if strings.Contains(locale, "/") || strings.Contains(locale, "\\") || strings.Contains(locale, "..") {
		c.JSON(http.StatusBadRequest, Response{Code: -1, Message: "invalid locale"})
		return
	}

	langDir := s.getLanguageDir()
	filePath := filepath.Join(langDir, locale+".json")

	data, err := os.ReadFile(filePath)
	if err != nil {
		c.JSON(http.StatusNotFound, Response{Code: -1, Message: "language not found"})
		return
	}

	c.Header("Content-Type", "application/json; charset=utf-8")
	c.Header("Cache-Control", "no-cache")
	c.Writer.Write(data)
}

func (s *Server) getLanguageDir() string {
	if execDir != "" {
		dir := filepath.Join(execDir, "language")
		if _, err := os.Stat(dir); err == nil {
			return dir
		}
	}
	return "language"
}
