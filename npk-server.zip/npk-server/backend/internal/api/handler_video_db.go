package api

import (
	"fmt"
	"log"
	"os"

	"github.com/gin-gonic/gin"
)

// getVideoDBStats 获取视频数据库统计信息
// GET /api/db/videos/stats
func (s *Server) getVideoDBStats(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	stats, err := s.videoSvc.GetVideoStats()
	if err != nil {
		respondInternalError(c, "获取视频统计失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"video_count":     stats.TotalCount,
		"total_size":      stats.TotalSize,
		"encrypted_count": stats.EncryptedCount,
		"total_duration":  stats.TotalDuration,
	})
}

// cleanupVideoDB 清理视频数据库中的无效记录
// POST /api/db/videos/cleanup
// 删除数据库中存在但实际文件已不存在的视频记录
func (s *Server) cleanupVideoDB(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	// 获取所有视频记录
	videos, _, err := s.videoSvc.ListVideos("", 1, 10000)
	if err != nil {
		respondInternalError(c, "获取视频列表失败: "+err.Error())
		return
	}

	var deletedCount int
	var invalidFiles []string

	// 检查每个视频文件是否存在
	for _, video := range videos {
		if _, statErr := os.Stat(video.Path); os.IsNotExist(statErr) {
			// 文件不存在，删除数据库记录
			if delErr := s.videoSvc.DeleteVideo(video.ID); delErr == nil {
				deletedCount++
				invalidFiles = append(invalidFiles, video.Path)
			}
		}
	}

	msg := fmt.Sprintf("清理完成：删除 %d 条无效视频记录", deletedCount)
	if deletedCount > 0 {
		msg = fmt.Sprintf("清理完成：删除 %d 条无效视频记录（文件已不存在）", deletedCount)
	}

	respondSuccess(c, gin.H{
		"message":         msg,
		"deleted_count":   deletedCount,
		"invalid_files":   invalidFiles,
	})
}

// rebuildVideoDB 重建视频数据库
// POST /api/db/videos/rebuild
// 清空视频表并重新扫描所有视频目录
func (s *Server) rebuildVideoDB(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	// 获取当前视频数量
	oldStats, _ := s.videoSvc.GetVideoStats()
	oldCount := 0
	if oldStats != nil {
		oldCount = oldStats.TotalCount
	}

	// 清空视频表 - 通过遍历所有目录并调用 RescanDir（它会先删除再扫描）
	// 首先获取所有现有目录
	var totalScanned int
	videoDirs := s.cfg.VideoDirs

	// 如果没有配置目录，返回警告
	if len(videoDirs) == 0 {
		respondBadRequest(c, "未配置视频目录，请在设置中添加视频目录")
		return
	}

	// 重新扫描所有视频目录
	for _, dir := range videoDirs {
		log.Printf("[rebuildVideoDB] 扫描目录: %s", dir)
		records, err := s.videoSvc.RescanDir(dir)
		if err != nil {
			log.Printf("[rebuildVideoDB] 扫描目录 %s 失败: %v", dir, err)
			// 继续扫描其他目录
			continue
		}
		log.Printf("[rebuildVideoDB] 扫描目录 %s 完成，获取 %d 条记录", dir, len(records))
		totalScanned += len(records)
	}

	// 获取新的统计
	newStats, _ := s.videoSvc.GetVideoStats()
	newCount := 0
	if newStats != nil {
		newCount = newStats.TotalCount
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("重建完成：原 %d 条记录，现 %d 条记录", oldCount, newCount),
		"old_count":     oldCount,
		"new_count":     newCount,
		"scanned_count": totalScanned,
	})
}

// compactVideoDB 压缩视频数据库（VACUUM）
// POST /api/db/videos/compact
// 重建数据库文件，回收碎片空间
func (s *Server) compactVideoDB(c *gin.Context) {
	if err := s.db.Compact(); err != nil {
		respondInternalError(c, "压缩数据库失败: "+err.Error())
		return
	}

	dbSize, _ := s.db.GetDBSize()
	respondSuccess(c, gin.H{
		"message": "视频数据库压缩完成",
		"db_size": dbSize,
	})
}
