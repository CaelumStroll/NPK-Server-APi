package api

import (
	"encoding/json"
	"fmt"
	"net/http"
	"path/filepath"
	"strconv"

	"github.com/gin-gonic/gin"

	"npk-server/internal/database"
	"npk-server/internal/npk"
)

// getAlbumPreview 获取 Album 组合预览
func (s *Server) getAlbumPreview(c *gin.Context) {
	name := c.Query("npk")
	albumPath := c.Query("album")
	mode := c.DefaultQuery("mode", "combined")
	frameIndex, _ := strconv.Atoi(c.DefaultQuery("frame", "-1"))

	if frameIndex >= 0 {
		data, err := s.npkSvc.GetAnimationFrame(name, albumPath, frameIndex)
		if err != nil {
			respondInternalError(c, err.Error())
			return
		}
		c.Data(http.StatusOK, "image/png", data)
		return
	}

	data, err := s.npkSvc.GetAlbumPreview(name, albumPath, mode)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Data(http.StatusOK, "image/png", data)
}

// getAlbumFrames 获取 Album 的帧详情列表
func (s *Server) getAlbumFrames(c *gin.Context) {
	name := c.Query("npk")
	albumPath := c.Query("album")

	album, err := s.npkSvc.GetAlbum(name, albumPath)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	var dbAlbum *database.AlbumRecord
	if s.db != nil {
		npkFile, err := s.db.GetNpkFileByName(name)
		if err == nil && npkFile != nil {
			dbAlbum, _ = s.db.GetAlbumByPath(npkFile.ID, albumPath)
		}
	}

	// 构建 sprite 索引映射，用于 Link 帧查找目标
	spriteMap := make(map[int]*npk.Sprite)
	for _, sp := range album.Sprites {
		spriteMap[sp.Index] = sp
	}

	frames := make([]map[string]interface{}, len(album.Sprites))
	for i, sp := range album.Sprites {
		frameInfo := map[string]interface{}{
			"index":        sp.Index,
			"x":            sp.X,
			"y":            sp.Y,
			"width":        sp.Width,
			"height":       sp.Height,
			"frame_width":  sp.FrameWidth,
			"frame_height": sp.FrameHeight,
			"type":         int(sp.Type),
			"type_name":    sp.Type.String(),
			"compress":     int(sp.CompressMode),
		}

		// Link 帧处理：填充引用信息和使用目标帧的尺寸
		if sp.Type == npk.LINK {
			frameInfo["is_link"] = true
			if sp.Target != nil {
				frameInfo["target_index"] = sp.Target.Index
				frameInfo["target_valid"] = true
				frameInfo["link_status"] = "normal"
				// 使用引用目标的尺寸
				frameInfo["width"] = sp.Target.Width
				frameInfo["height"] = sp.Target.Height
				frameInfo["frame_width"] = sp.Target.FrameWidth
				frameInfo["frame_height"] = sp.Target.FrameHeight
				frameInfo["x"] = sp.Target.X
				frameInfo["y"] = sp.Target.Y
			} else {
				frameInfo["target_index"] = sp.TargetIndex
				frameInfo["target_valid"] = false
				// 尝试通过 TargetIndex 查找目标
				if sp.TargetIndex >= 0 {
					if target, ok := spriteMap[sp.TargetIndex]; ok {
						if target.Index == sp.Index {
							// 循环引用
							frameInfo["link_status"] = "circular"
						} else {
							frameInfo["target_valid"] = true
							frameInfo["link_status"] = "normal"
							frameInfo["width"] = target.Width
							frameInfo["height"] = target.Height
							frameInfo["frame_width"] = target.FrameWidth
							frameInfo["frame_height"] = target.FrameHeight
							frameInfo["x"] = target.X
							frameInfo["y"] = target.Y
						}
					} else {
						frameInfo["link_status"] = "null"
					}
				} else {
					frameInfo["link_status"] = "null"
				}
			}
		} else {
			frameInfo["is_link"] = false
		}

		if album.Version == 5 && album.TextureInfos != nil {
			if texInfo, ok := album.TextureInfos[sp.Index]; ok && texInfo.Texture != nil {
				frameInfo["texture_index"] = texInfo.Texture.Index
			}
		}
		frames[i] = frameInfo
	}

	// 构建 palette_json（V4+ 调色板信息）
	paletteJSON := "[]"
	if album.Version >= 4 && len(album.Tables) > 0 {
		paletteData, err := json.Marshal(album.Tables)
		if err == nil {
			paletteJSON = string(paletteData)
		}
	}

	// 构建 dds_info_json（V5 DDS 纹理信息）
	ddsInfoJSON := "[]"
	if album.Version == 5 && album.TextureInfos != nil {
		type ddsEntry struct {
			Index     int `json:"index"`
			Type      int `json:"type"`
			Width     int `json:"width"`
			Height    int `json:"height"`
			X         int `json:"x"`
			Y         int `json:"y"`
			RX        int `json:"rx"`
			RY        int `json:"ry"`
			Top       int `json:"top"`
		}
		entries := make([]ddsEntry, 0)
		for _, texInfo := range album.TextureInfos {
			if texInfo.Texture != nil {
				entries = append(entries, ddsEntry{
					Index:  texInfo.Texture.Index,
					Type:   int(texInfo.Texture.Type),
					Width:  texInfo.Texture.Width,
					Height: texInfo.Texture.Height,
					X:      texInfo.LeftUp.X,
					Y:      texInfo.LeftUp.Y,
					RX:     texInfo.RightDown.X,
					RY:     texInfo.RightDown.Y,
					Top:    texInfo.Top,
				})
			}
		}
		data, err := json.Marshal(entries)
		if err == nil {
			ddsInfoJSON = string(data)
		}
	}

	respondSuccess(c, gin.H{
		"album_name":    filepath.Base(albumPath),
		"album_path":    albumPath,
		"version":       album.Version.String(),
		"total":         len(frames),
		"frame_count":   len(frames),
		"frames":        frames,
		"palette_json":  paletteJSON,
		"dds_info_json": ddsInfoJSON,
		"file_type":     func() int { if dbAlbum != nil { return dbAlbum.FileType }; return 0 }(),
		"offset":        func() int64 { if dbAlbum != nil { return dbAlbum.Offset }; return album.Offset }(),
		"size":          func() int64 { if dbAlbum != nil { return dbAlbum.Size }; return album.Length }(),
	})
}

// exportAlbumGif 导出 Album 为 GIF
func (s *Server) exportAlbumGif(c *gin.Context) {
	name := c.Query("npk")
	albumPath := c.Query("album")
	fps, _ := strconv.Atoi(c.DefaultQuery("fps", "12"))
	removeBlack := c.Query("removeBlack") == "true"

	data, err := s.npkSvc.ExportAlbumGif(name, albumPath, fps, removeBlack)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=%s.gif", filepath.Base(albumPath)))
	c.Data(http.StatusOK, "image/gif", data)
}

// loadImgCache 加载 IMG 到内存缓存
func (s *Server) loadImgCache(c *gin.Context) {
	var req struct {
		NpkName   string `json:"npk_name" binding:"required"`
		AlbumPath string `json:"album_path" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if err := s.npkSvc.LoadImgToCache(req.NpkName, req.AlbumPath); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "已加载到内存"})
}

// releaseImgCache 释放指定 IMG 的内存缓存
func (s *Server) releaseImgCache(c *gin.Context) {
	npkName := c.Query("npk_name")
	albumPath := c.Query("album_path")
	s.npkSvc.ReleaseImgCache(npkName, albumPath)
	respondSuccess(c, gin.H{"message": "已释放"})
}

// releaseAllImgCache 释放所有 IMG 缓存
func (s *Server) releaseAllImgCache(c *gin.Context) {
	s.npkSvc.ReleaseAllImgCache()
	respondSuccess(c, gin.H{"message": "已释放全部"})
}

// getImgCacheStatus 获取 IMG 缓存状态
func (s *Server) getImgCacheStatus(c *gin.Context) {
	status := s.npkSvc.GetImgCacheStatus()
	respondSuccess(c, status)
}