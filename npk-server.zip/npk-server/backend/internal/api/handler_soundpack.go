package api

import (
	"archive/zip"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"

	"npk-server/internal/database"
	"npk-server/internal/video"
)

// listSoundPacks 获取音效包列表
// GET /api/soundpacks/list?query=
func (s *Server) listSoundPacks(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	query := c.Query("query")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("size", "100000"))

	sp, total, err := s.soundpackSvc.ListSoundPacks(query, page, pageSize)
	if err != nil {
		respondInternalError(c, "获取音效包列表失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"items": sp,
		"total": total,
	})
}

// getSoundPackStats 获取音效包统计
// GET /api/soundpacks/stats
func (s *Server) getSoundPackStats(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	stats, err := s.soundpackSvc.GetSoundPackStats()
	if err != nil {
		respondInternalError(c, "获取统计失败: "+err.Error())
		return
	}

	respondSuccess(c, stats)
}

// getSoundPack 获取音效包详情
// GET /api/soundpacks/:id
func (s *Server) getSoundPack(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	sp, err := s.soundpackSvc.GetSoundPack(int64(id))
	if err != nil || sp == nil {
		respondNotFound(c, "音效包不存在")
		return
	}

	respondSuccess(c, sp)
}

// scanSoundPacks 扫描音效包目录
// POST /api/soundpacks/scan
func (s *Server) scanSoundPacks(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	var req struct {
		Dir string `json:"dir"`
	}
	_ = c.ShouldBindJSON(&req)

	var count int
	var err error
	if req.Dir != "" {
		var records []*database.SoundPackRecord
		records, err = s.soundpackSvc.ScanDir(req.Dir)
		count = len(records)
	} else {
		dirs := s.cfg.SoundPackDirs
		if len(dirs) == 0 {
			respondBadRequest(c, "未配置音效目录，请在设置中添加 SoundPacks 目录")
			return
		}
		log.Printf("[scanSoundPacks] 扫描目录: %v", dirs)
		var records []*database.SoundPackRecord
		records, err = s.soundpackSvc.ScanAll()
		count = len(records)
	}
	if err != nil {
		log.Printf("[scanSoundPacks] 扫描失败: %v", err)
		respondInternalError(c, "扫描失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"scanned_count": count,
		"message":       fmt.Sprintf("扫描完成，共发现 %d 个音效包", count),
	})
}

// deleteSoundPack 删除音效包
// DELETE /api/soundpacks/:id?delete_file=true
func (s *Server) deleteSoundPack(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	deleteFile := c.Query("delete_file") == "true"

	if deleteFile {
		sp, err := s.soundpackSvc.GetSoundPack(int64(id))
		if err == nil && sp != nil && sp.Path != "" {
			if err := os.Remove(sp.Path); err != nil && !os.IsNotExist(err) {
				respondInternalError(c, "删除文件失败: "+err.Error())
				return
			}
			log.Printf("[deleteSoundPack] 已删除文件: %s", sp.Path)
		}
	}

	if err := s.soundpackSvc.DeleteSoundPack(int64(id)); err != nil {
		respondInternalError(c, "删除记录失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "已删除", "file_deleted": deleteFile})
}

// batchDeleteSoundPacks 批量删除音效包
// POST /api/soundpacks/batch-delete
func (s *Server) batchDeleteSoundPacks(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	var req struct {
		IDs        []int64 `json:"ids"`
		DeleteFile bool    `json:"delete_file"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}
	if len(req.IDs) == 0 {
		respondBadRequest(c, "请选择要删除的音效包")
		return
	}

	var filesDeleted int
	if req.DeleteFile {
		spList, err := s.soundpackSvc.GetSoundPacksByIDs(req.IDs)
		if err == nil {
			for _, sp := range spList {
				if sp.Path != "" {
					if err := os.Remove(sp.Path); err != nil && !os.IsNotExist(err) {
						log.Printf("[batchDeleteSoundPacks] 删除文件失败: %s", sp.Path)
					} else if err == nil {
						filesDeleted++
					}
				}
			}
		}
	}

	deletedCount, err := s.soundpackSvc.DeleteSoundPacksByIDs(req.IDs)
	if err != nil {
		respondInternalError(c, "删除失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("已删除 %d 条记录", deletedCount),
		"files_deleted": filesDeleted,
	})
}

// decryptSoundPack 解密音效包
// POST /api/soundpacks/:id/decrypt
func (s *Server) decryptSoundPack(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	entries, err := s.soundpackSvc.DecryptSoundPack(int64(id))
	if err != nil {
		respondInternalError(c, "解密失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":      "解密完成",
		"entries":      entries,
		"entries_count": len(entries),
	})
}

// getSoundPackEntries 获取音效包条目列表
// GET /api/soundpacks/:id/entries
func (s *Server) getSoundPackEntries(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	entries, err := s.soundpackSvc.GetSoundPackEntries(int64(id))
	if err != nil {
		respondInternalError(c, "获取条目失败: "+err.Error())
		return
	}

	sp, _ := s.soundpackSvc.GetSoundPack(int64(id))
	respondSuccess(c, gin.H{
		"items":       entries,
		"total":       len(entries),
		"soundpack":   sp,
	})
}

// streamSoundPackEntry 流式播放 OGG 条目
// GET /api/soundpacks/:id/entries/:eid/stream
func (s *Server) streamSoundPackEntry(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	eid, err := parseIntParam(c, "eid")
	if err != nil {
		return
	}

	data, entry, record, err := s.soundpackSvc.ReadSoundPackEntryData(int64(eid))
	if err != nil {
		respondNotFound(c, "条目不存在: "+err.Error())
		return
	}
	_ = entry
	_ = record

	size := int64(len(data))

	c.Header("Content-Type", "audio/ogg")
	c.Header("Accept-Ranges", "bytes")

	rangeHeader := c.GetHeader("Range")
	if rangeHeader == "" {
		c.Header("Content-Length", strconv.FormatInt(size, 10))
		c.Status(http.StatusOK)
		c.Writer.Write(data)
		return
	}

	ranges := parseRangeHeader(rangeHeader, size)
	if ranges == nil {
		c.Header("Content-Range", fmt.Sprintf("bytes */%d", size))
		c.Status(http.StatusRequestedRangeNotSatisfiable)
		return
	}

	start, end := ranges[0], ranges[1]
	if end >= size {
		end = size - 1
	}
	contentLength := end - start + 1

	c.Header("Content-Range", fmt.Sprintf("bytes %d-%d/%d", start, end, size))
	c.Header("Content-Length", strconv.FormatInt(contentLength, 10))
	c.Status(http.StatusPartialContent)
	c.Writer.Write(data[start : end+1])
}

// downloadSoundPackEntry 下载 OGG 条目
// GET /api/soundpacks/:id/entries/:eid/download
func (s *Server) downloadSoundPackEntry(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	eid, err := parseIntParam(c, "eid")
	if err != nil {
		return
	}

	data, entry, _, err := s.soundpackSvc.ReadSoundPackEntryData(int64(eid))
	if err != nil {
		respondNotFound(c, "条目不存在: "+err.Error())
		return
	}

	c.Header("Content-Type", "audio/ogg")
	c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+entryToExportName(entry.EntryPath))
	c.Header("Content-Length", strconv.FormatInt(int64(len(data)), 10))
	c.Status(http.StatusOK)
	c.Writer.Write(data)
}

// convertSoundPackEntry 转换 OGG 条目格式
// GET /api/soundpacks/:id/entries/:eid/convert?target_format=mp3
func (s *Server) convertSoundPackEntry(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	eid, err := parseIntParam(c, "eid")
	if err != nil {
		return
	}

	targetFormat := strings.ToLower(c.Query("target_format"))
	if targetFormat == "" {
		respondBadRequest(c, "请提供 target_format 参数")
		return
	}

	supportedFormats := map[string]bool{"mp3": true, "ogg": true, "wav": true, "flac": true}
	if !supportedFormats[targetFormat] {
		respondBadRequest(c, "不支持的转换格式: "+targetFormat)
		return
	}

	data, entry, record, err := s.soundpackSvc.ReadSoundPackEntryData(int64(eid))
	if err != nil {
		respondNotFound(c, "条目不存在: "+err.Error())
		return
	}

	tmpDir := os.TempDir()
	tmpInput := filepath.Join(tmpDir, fmt.Sprintf("soundpack_tmp_%d.ogg", eid))
	tmpOutput := filepath.Join(tmpDir, fmt.Sprintf("soundpack_tmp_%d.%s", eid, targetFormat))
	defer os.Remove(tmpInput)
	defer os.Remove(tmpOutput)

	if err := os.WriteFile(tmpInput, data, 0644); err != nil {
		respondInternalError(c, "写入临时文件失败")
		return
	}

	cmd := exec.Command(video.FindFFmpeg(), "-i", tmpInput, "-y", tmpOutput)
	ffOutput, err := cmd.CombinedOutput()
	if err != nil {
		log.Printf("[convertSoundPackEntry] FFmpeg错误: %s", string(ffOutput))
		respondInternalError(c, "转换失败: "+err.Error())
		return
	}

	outputData, err := os.ReadFile(tmpOutput)
	if err != nil {
		respondInternalError(c, "读取转换结果失败")
		return
	}

	baseName := entry.EntryName[:len(entry.EntryName)-len(filepath.Ext(entry.EntryName))]
	downloadName := baseName + "." + targetFormat

	c.Header("Content-Type", "application/octet-stream")
	c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+downloadName)
	c.Header("Content-Length", strconv.FormatInt(int64(len(outputData)), 10))
	c.Status(http.StatusOK)
	c.Writer.Write(outputData)

	_ = record
}

// importOGGToSoundPack 导入 OGG 到音效包
// POST /api/soundpacks/:id/entries/import
func (s *Server) importOGGToSoundPack(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	entryPath := c.PostForm("entry_path")
	file, _, err := c.Request.FormFile("file")
	if err != nil {
		respondBadRequest(c, "请上传 OGG 文件")
		return
	}
	defer file.Close()

	oggData, err := io.ReadAll(file)
	if err != nil {
		respondInternalError(c, "读取文件失败")
		return
	}

	if entryPath == "" {
		respondBadRequest(c, "请提供 entry_path（NPK 内部路径）")
		return
	}

	entry, err := s.soundpackSvc.ImportOGGToSoundPack(int64(id), entryPath, oggData)
	if err != nil {
		respondInternalError(c, "导入失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message": "导入成功",
		"entry":   entry,
	})
}

// renameSoundPackEntry 重命名条目
// PUT /api/soundpacks/:id/entries/:eid/rename
func (s *Server) renameSoundPackEntry(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	eid, err := parseIntParam(c, "eid")
	if err != nil {
		return
	}

	var req struct {
		NewPath string `json:"new_path"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || req.NewPath == "" {
		respondBadRequest(c, "请提供新路径")
		return
	}

	id, _ := parseIntParam(c, "id")

	// 检测同名冲突
	existing, _ := s.soundpackSvc.GetSoundPackEntries(int64(id))
	for _, e := range existing {
		if e.ID == int64(eid) {
			continue
		}
		if e.EntryPath == req.NewPath || e.EntryName == filepath.Base(req.NewPath) {
			respondConflict(c, "路径或文件名已存在: "+req.NewPath)
			return
		}
	}

	if err := s.soundpackSvc.UpdateSoundPackEntryPath(int64(eid), req.NewPath); err != nil {
		respondInternalError(c, "重命名失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "重命名成功"})
}

// deleteSoundPackEntry 删除条目
// DELETE /api/soundpacks/:id/entries/:eid
func (s *Server) deleteSoundPackEntry(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	eid, err := parseIntParam(c, "eid")
	if err != nil {
		return
	}

	if err := s.soundpackSvc.DeleteSoundPackEntryData(int64(eid)); err != nil {
		respondInternalError(c, "删除失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "已删除"})
}

// batchDeleteSoundPackEntries 批量删除条目
// POST /api/soundpacks/:id/entries/batch-delete
func (s *Server) batchDeleteSoundPackEntries(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	var req struct {
		EntryIDs []int64 `json:"entry_ids"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || len(req.EntryIDs) == 0 {
		respondBadRequest(c, "请选择要删除的条目")
		return
	}

	deleted, err := s.soundpackSvc.BatchDeleteSoundPackEntries(req.EntryIDs)
	if err != nil {
		respondInternalError(c, "删除失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("已删除 %d 个条目", deleted),
		"deleted_count": deleted,
	})
	_ = id
}

// rebuildSoundPack 重新解密（重建索引）
// POST /api/soundpacks/:id/rebuild
func (s *Server) rebuildSoundPack(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	entries, err := s.soundpackSvc.DecryptSoundPack(int64(id))
	if err != nil {
		respondInternalError(c, "重建失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":       "重建完成",
		"entries_count": len(entries),
	})
}

// batchExportSoundPackEntries 批量导出 OGG 条目（ZIP，支持格式转换）
// POST /api/soundpacks/:id/entries/batch-export
func (s *Server) batchExportSoundPackEntries(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	var req struct {
		EntryIDs     []int64 `json:"entry_ids"`
		TargetFormat string  `json:"target_format"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || len(req.EntryIDs) == 0 {
		respondBadRequest(c, "请选择要导出的条目")
		return
	}

	targetFormat := "ogg"
	if req.TargetFormat != "" {
		targetFormat = strings.ToLower(req.TargetFormat)
	}

	spName := fmt.Sprintf("soundpack_%d", id)
	sp, _ := s.soundpackSvc.GetSoundPack(int64(id))
	if sp != nil {
		spName = strings.TrimSuffix(sp.Name, ".npk")
	}

	entries, err := s.soundpackSvc.GetSoundPackEntries(int64(id))
	if err != nil {
		respondInternalError(c, "获取条目失败: "+err.Error())
		return
	}

	entryMap := make(map[int64]*database.SoundPackEntry)
	for _, e := range entries {
		entryMap[e.ID] = e
	}

	// 收集导出数据
	type exportItem struct {
		filename string
		data     []byte
	}
	var items []exportItem

	for _, eid := range req.EntryIDs {
		entry, ok := entryMap[eid]
		if !ok {
			continue
		}

		oggData, _, _, err := s.soundpackSvc.ReadSoundPackEntryData(eid)
		if err != nil {
			log.Printf("[batchExport] 读取 %s 失败: %v", entry.EntryPath, err)
			continue
		}

		var outputData []byte
		ext := targetFormat
		if targetFormat == "ogg" {
			outputData = oggData
		} else {
			tmpDir := os.TempDir()
			tmpIn, _ := os.CreateTemp(tmpDir, "sp_export_*.ogg")
			tmpOut, _ := os.CreateTemp(tmpDir, "sp_export_*."+targetFormat)
			tmpIn.Write(oggData)
			tmpIn.Close()
			defer os.Remove(tmpIn.Name())
			defer os.Remove(tmpOut.Name())

			cmd := exec.Command(video.FindFFmpeg(), "-i", tmpIn.Name(), "-y", tmpOut.Name())
			if ffOut, err := cmd.CombinedOutput(); err != nil {
				log.Printf("[batchExport] FFmpeg 转换失败 %s: %s", entry.EntryPath, string(ffOut))
				continue
			}
			outputData, err = os.ReadFile(tmpOut.Name())
			if err != nil {
				continue
			}
		}

		// 命名: 目录@文件名，其中 / 替换为 _
		baseName := entryToExportName(entry.EntryPath)
		if ext != "" && !strings.HasSuffix(baseName, "."+ext) {
			baseName = strings.TrimSuffix(baseName, filepath.Ext(baseName)) + "." + ext
		}
		exportName := baseName

		items = append(items, exportItem{filename: exportName, data: outputData})
	}

	if len(items) == 0 {
		respondInternalError(c, "没有可导出的条目")
		return
	}

	// 打包 ZIP
	zipPath := filepath.Join(os.TempDir(), fmt.Sprintf("soundpack_export_%d.zip", id))
	defer os.Remove(zipPath)

	zipFile, err := os.Create(zipPath)
	if err != nil {
		respondInternalError(c, "创建ZIP失败")
		return
	}
	defer zipFile.Close()

	zipWriter := zip.NewWriter(zipFile)
	for _, item := range items {
		w, err := zipWriter.Create(item.filename)
		if err != nil {
			continue
		}
		w.Write(item.data)
	}
	zipWriter.Close()
	zipFile.Close()

	zipData, err := os.ReadFile(zipPath)
	if err != nil {
		respondInternalError(c, "读取ZIP失败")
		return
	}

	c.Header("Content-Type", "application/zip")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename*=UTF-8''%s_export.zip", spName))
	c.Header("Content-Length", strconv.FormatInt(int64(len(zipData)), 10))
	c.Status(http.StatusOK)
	c.Writer.Write(zipData)
}

// batchImportOGGToSoundPack 批量导入 OGG 文件
// POST /api/soundpacks/:id/entries/batch-import
func (s *Server) batchImportOGGToSoundPack(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	form, err := c.MultipartForm()
	if err != nil {
		respondBadRequest(c, "请上传文件")
		return
	}

	files := form.File["files"]
	if len(files) == 0 {
		respondBadRequest(c, "请选择文件")
		return
	}

	// 获取现有条目做重复检查
	existingEntries, _ := s.soundpackSvc.GetSoundPackEntries(int64(id))
	existingPaths := make(map[string]bool)
	for _, e := range existingEntries {
		existingPaths[e.EntryPath] = true
		existingPaths[e.EntryName] = true
	}

	type result struct {
		Filename string `json:"filename"`
		Path     string `json:"path"`
		Status   string `json:"status"`
		Error    string `json:"error,omitempty"`
	}

	var results []result
	imported := 0
	skipped := 0
	errors := 0

	for _, fh := range files {
		basename := fh.Filename
		r := result{Filename: basename}

		// 解析路径: sounds_amb@amb_cave_01.ogg -> sounds/amb/amb_cave_01.ogg
		ext := filepath.Ext(basename)
		nameWithoutExt := strings.TrimSuffix(basename, ext)

		var entryPath string
		if idx := strings.Index(nameWithoutExt, "@"); idx != -1 {
			pathPart := strings.ReplaceAll(nameWithoutExt[:idx], "_", "/")
			filePart := nameWithoutExt[idx+1:]
			entryPath = pathPart + "/" + filePart + ext
		} else {
			// 没有 @ 符号，直接作为扁平路径：文件名
			entryPath = fmt.Sprintf("imported/%s", basename)
		}

		r.Path = entryPath

		// 检查路径重复
		if existingPaths[entryPath] {
			r.Status = "skipped"
			r.Error = "路径重复"
			skipped++
			results = append(results, r)
			continue
		}

		// 检查文件名重复（但路径不同）
		filenameDup := false
		for _, e := range existingEntries {
			if e.EntryName == filepath.Base(entryPath) && e.EntryPath != entryPath {
				filenameDup = true
				break
			}
		}
		if filenameDup {
			r.Status = "skipped"
			r.Error = "文件名与其他路径重复"
			skipped++
			results = append(results, r)
			continue
		}

		file, err := fh.Open()
		if err != nil {
			r.Status = "error"
			r.Error = "无法打开文件"
			errors++
			results = append(results, r)
			continue
		}

		oggData, err := io.ReadAll(file)
		file.Close()
		if err != nil {
			r.Status = "error"
			r.Error = "读取文件失败"
			errors++
			results = append(results, r)
			continue
		}

		if ext != ".ogg" {
			// 非 OGG 格式，尝试用 FFmpeg 转换
			tmpDir := os.TempDir()
			tmpIn, _ := os.CreateTemp(tmpDir, "sp_import_*"+ext)
			tmpOut, _ := os.CreateTemp(tmpDir, "sp_import_*.ogg")
			tmpIn.Write(oggData)
			tmpIn.Close()
			defer os.Remove(tmpIn.Name())
			defer os.Remove(tmpOut.Name())

			cmd := exec.Command(video.FindFFmpeg(), "-i", tmpIn.Name(), "-y", tmpOut.Name())
			if ffOut, err := cmd.CombinedOutput(); err != nil {
				log.Printf("[batchImport] FFmpeg 转换失败 %s: %s", basename, string(ffOut))
				r.Status = "error"
				r.Error = "格式转换失败"
				errors++
				results = append(results, r)
				continue
			}
			oggData, err = os.ReadFile(tmpOut.Name())
			if err != nil {
				r.Status = "error"
				r.Error = "读取转换结果失败"
				errors++
				results = append(results, r)
				continue
			}
		}

		_, err = s.soundpackSvc.ImportOGGToSoundPack(int64(id), entryPath, oggData)
		if err != nil {
			r.Status = "error"
			r.Error = err.Error()
			errors++
		} else {
			r.Status = "imported"
			existingPaths[entryPath] = true
			existingPaths[filepath.Base(entryPath)] = true
			imported++
		}
		results = append(results, r)
	}

	respondSuccess(c, gin.H{
		"message":  fmt.Sprintf("导入完成：成功 %d，跳过 %d，失败 %d", imported, skipped, errors),
		"imported": imported,
		"skipped":  skipped,
		"errors":   errors,
		"results":  results,
	})
}

func entryToExportName(entryPath string) string {
	dir := filepath.Dir(entryPath)
	name := filepath.Base(entryPath)
	dirName := strings.ReplaceAll(dir, "/", "_")
	if dirName == "." {
		return name
	}
	return dirName + "@" + name
}
