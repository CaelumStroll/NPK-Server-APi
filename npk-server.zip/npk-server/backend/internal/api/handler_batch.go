package api

import (
	"fmt"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"

	"npk-server/internal/service"
)

// batchExport 创建批量导出任务
func (s *Server) batchExport(c *gin.Context) {
	var req service.ExportRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: " + err.Error())
		return
	}

	taskID := s.batchSvc.CreateExportTask(req)

	respondAccepted(c, gin.H{
		"task_id":      taskID,
		"status_url":   "/api/batch/status/" + taskID,
		"download_url": "/api/batch/download/" + taskID,
	})
}

// batchExportStatus 获取批量导出任务状态
func (s *Server) batchExportStatus(c *gin.Context) {
	taskID := c.Param("taskId")

	task, exists := s.batchSvc.GetTask(taskID)
	if !exists {
		respondNotFound(c, "任务不存在")
		return
	}

	respondSuccess(c, task)
}

// batchExportDownload 下载批量导出结果
func (s *Server) batchExportDownload(c *gin.Context) {
	taskID := c.Param("taskId")

	if subTaskFileName := s.batchSvc.GetSubTaskFileName(taskID); subTaskFileName != "" {
		filePath := s.batchSvc.GetTaskFilePath(taskID)
		c.Header("Content-Type", "application/zip")
		c.Header("Content-Disposition", fmt.Sprintf("attachment; filename*=UTF-8''%s", url.QueryEscape(subTaskFileName)))
		c.File(filePath)
		return
	}

	task, exists := s.batchSvc.GetTask(taskID)
	if !exists {
		respondNotFound(c, "任务不存在")
		return
	}

	if task.Status != service.TaskStatusCompleted {
		respondBadRequest(c, "任务尚未完成")
		return
	}

	if task.Result != nil && len(task.Result.FileURLs) > 0 {
		if len(task.Result.FileURLs) == 1 {
			subTaskID := strings.TrimPrefix(task.Result.FileURLs[0], "/api/batch/download/")
			if subTaskFileName := s.batchSvc.GetSubTaskFileName(subTaskID); subTaskFileName != "" {
				filePath := s.batchSvc.GetTaskFilePath(subTaskID)
				c.Header("Content-Type", "application/zip")
				c.Header("Content-Disposition", fmt.Sprintf("attachment; filename*=UTF-8''%s", url.QueryEscape(subTaskFileName)))
				c.File(filePath)
				return
			}
		}
		respondSuccess(c, gin.H{"files": task.Result.FileURLs, "sizes": task.Result.FileSizes})
		return
	}

	filePath := s.batchSvc.GetTaskFilePath(taskID)
	fileName := fmt.Sprintf("export_%s.zip", task.CreatedAt.Format("20060102_150405"))
	c.Header("Content-Type", "application/zip")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename*=UTF-8''%s", url.QueryEscape(fileName)))
	c.File(filePath)
}