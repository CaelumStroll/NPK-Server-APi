package api

import (
	"log"
	"strings"

	"github.com/gin-gonic/gin"

	"npk-server/internal/service"
)

// TreeNode 目录树节点（用于 NPK 目录树）
type TreeNode struct {
	Name     string      `json:"name"`
	Children []*TreeNode `json:"children,omitempty"`
	IsLeaf   bool        `json:"is_leaf"`
	Path     string      `json:"path,omitempty"`
}

// listNpk 获取 NPK 文件列表
func (s *Server) listNpk(c *gin.Context) {
	files := s.npkSvc.ListNpkFiles()

	result := make([]map[string]interface{}, len(files))
	for i, f := range files {
		result[i] = map[string]interface{}{
			"name":               f.Name,
			"path":               f.Path,
			"size":               f.Size,
			"modified":           f.Modified,
			"img_count":          len(f.Albums),
			"format_type":        f.FormatType,
			"encryption_verified": f.EncryptionVerified,
		}
	}

	respondSuccess(c, result)
}

// listNpkPaginated 分页获取 NPK 文件列表
func (s *Server) listNpkPaginated(c *gin.Context) {
	query := c.Query("q")
	page, pageSize := parsePaginationParams(c)

	records, total, err := s.db.ListNpkFilesPaginated(query, page, pageSize)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	result := make([]map[string]interface{}, len(records))
	for i, f := range records {
		result[i] = map[string]interface{}{
			"id":                   f.ID,
			"name":                 f.Name,
			"path":                 f.Path,
			"size":                 f.Size,
			"modified":             f.ModifiedAt,
			"img_count":            f.ImgCount,
			"format_type":          f.FormatType,
			"encryption_verified":  f.EncryptionVerified,
		}
	}

	respondSuccess(c, gin.H{
		"items":     result,
		"total":     total,
		"page":      page,
		"page_size": pageSize,
	})
}

// getNpkInfo 获取 NPK 文件详细信息
func (s *Server) getNpkInfo(c *gin.Context) {
	name := decodePathParam(c, "name")

	info, err := s.npkSvc.GetNpkInfo(name)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	albums := make([]map[string]interface{}, len(info.Albums))
	for i, a := range info.Albums {
		albums[i] = map[string]interface{}{
			"path":         a.Path,
			"name":         a.Name,
			"version":      a.Version.String(),
			"sprite_count": a.SpriteCount,
			"target_path":  a.TargetPath,
		}
	}

	respondSuccess(c, gin.H{
		"name":     info.Name,
		"path":     info.Path,
		"size":     info.Size,
		"modified": info.Modified,
		"albums":   albums,
	})
}

// getNpkTree 获取 NPK 目录树结构
func (s *Server) getNpkTree(c *gin.Context) {
	name := decodePathParam(c, "name")

	info, err := s.npkSvc.GetNpkInfo(name)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	tree := buildTree(info.Albums)
	respondSuccess(c, tree)
}

// buildTree 构建 Album 目录树
func buildTree(albums []*service.AlbumInfo) []*TreeNode {
	root := make(map[string]*TreeNode)

	for _, album := range albums {
		parts := strings.Split(album.Path, "/")
		current := root

		for i, part := range parts {
			if part == "" {
				continue
			}

			if _, exists := current[part]; !exists {
				current[part] = &TreeNode{
					Name:     part,
					Children: make([]*TreeNode, 0),
					IsLeaf:   i == len(parts)-1,
					Path:     strings.Join(parts[:i+1], "/"),
				}
			}

			if i < len(parts)-1 {
				if len(current[part].Children) == 0 {
					current[part].Children = make([]*TreeNode, 0)
				}
				current = make(map[string]*TreeNode)
				for _, child := range current[part].Children {
					current[child.Name] = child
				}
			}
		}
	}

	result := make([]*TreeNode, 0, len(root))
	for _, node := range root {
		result = append(result, node)
	}

	return result
}

// scanNpk 扫描 NPK 目录
func (s *Server) scanNpk(c *gin.Context) {
	var req struct {
		Path string `json:"path"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求")
		return
	}

	path := req.Path
	if path == "" {
		for _, dir := range s.cfg.NpkDirs {
			if err := s.npkSvc.ScanDirectory(dir, nil); err != nil {
				log.Printf("扫描目录失败 %s: %v", dir, err)
			}
		}
	} else {
		if err := s.npkSvc.ScanDirectory(path, nil); err != nil {
			respondInternalError(c, err.Error())
			return
		}
	}

	respondSuccess(c, gin.H{"message": "扫描完成"})
}

// saveNpk 保存 NPK 文件
func (s *Server) saveNpk(c *gin.Context) {
	name := decodePathParam(c, "name")

	if err := s.npkSvc.SaveNpk(name); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "保存成功"})
}

// deleteNpk 删除 NPK 文件
func (s *Server) deleteNpk(c *gin.Context) {
	name := decodePathParam(c, "name")

	if err := s.npkSvc.DeleteNpk(name); err != nil {
		respondInternalError(c, "删除失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "删除成功", "name": name})
}