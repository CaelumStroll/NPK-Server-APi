package api

import (
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"npk-server/internal/video"

	"npk-server/internal/database"
)

// listMusic 获取音乐列表
// GET /api/music/list?query=&format=
func (s *Server) listMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	query := c.Query("query")
	format := c.Query("format")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("size", "100000"))

	var musicRecords []*database.MusicRecord
	var total int
	var err error

	if format != "" && format != "all" {
		musicRecords, total, err = s.musicSvc.SearchMusic(query, format, page, pageSize)
	} else {
		musicRecords, total, err = s.musicSvc.ListMusic(query, page, pageSize)
	}

	if err != nil {
		respondInternalError(c, "获取音乐列表失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"items": musicRecords,
		"total": total,
	})
}

// getMusicStats 获取音乐统计信息
// GET /api/music/stats
func (s *Server) getMusicStats(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	stats, err := s.musicSvc.GetMusicStats()
	if err != nil {
		respondInternalError(c, "获取音乐统计失败: "+err.Error())
		return
	}

	respondSuccess(c, stats)
}

// getMusic 根据ID获取音乐详情
// GET /api/music/:id
func (s *Server) getMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	m, err := s.musicSvc.GetMusic(int64(id))
	if err != nil {
		respondNotFound(c, "音乐不存在")
		return
	}

	respondSuccess(c, m)
}

// scanMusic 扫描音乐目录
// POST /api/music/scan  body: {"dir": "/path"} 或空（扫描全部）
func (s *Server) scanMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	var req struct {
		Dir string `json:"dir"`
	}
	_ = c.ShouldBindJSON(&req)

	var count int
	var err error
	if req.Dir != "" {
		var records []*database.MusicRecord
		records, err = s.musicSvc.ScanDir(req.Dir)
		count = len(records)
	} else {
		dirs := s.cfg.MusicDirs
		if len(dirs) == 0 {
			respondBadRequest(c, "未配置音乐目录，请在设置中添加 Music 目录")
			return
		}
		log.Printf("[scanMusic] 扫描目录: %v", dirs)
		var records []*database.MusicRecord
		records, err = s.musicSvc.ScanAll()
		count = len(records)
	}
	if err != nil {
		log.Printf("[scanMusic] 扫描失败: %v", err)
		respondInternalError(c, "扫描音乐失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"scanned_count": count,
		"message":       fmt.Sprintf("扫描完成，共发现 %d 个音频文件", count),
	})
}

// deleteMusic 删除音乐记录，可选同时删除文件
// DELETE /api/music/:id?delete_file=true
func (s *Server) deleteMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	deleteFile := c.Query("delete_file") == "true"

	if deleteFile {
		m, err := s.musicSvc.GetMusic(int64(id))
		if err != nil {
			respondInternalError(c, "获取音乐信息失败: "+err.Error())
			return
		}
		if m != nil && m.Path != "" {
			if err := os.Remove(m.Path); err != nil && !os.IsNotExist(err) {
				respondInternalError(c, "删除文件失败: "+err.Error())
				return
			}
			log.Printf("[deleteMusic] 已删除文件: %s", m.Path)
		}
	}

	if err := s.musicSvc.DeleteMusic(int64(id)); err != nil {
		respondInternalError(c, "删除音乐记录失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":      "音乐已删除",
		"file_deleted": deleteFile,
	})
}

// batchDeleteMusic 批量删除音乐
// POST /api/music/batch-delete
func (s *Server) batchDeleteMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	var req struct {
		IDs        []int64 `json:"ids"`
		DeleteFile bool    `json:"delete_file"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if len(req.IDs) == 0 {
		respondBadRequest(c, "请选择要删除的音乐")
		return
	}

	var filesDeleted int

	if req.DeleteFile {
		musicRecords, err := s.musicSvc.GetMusicByIDs(req.IDs)
		if err != nil {
			respondInternalError(c, "获取音乐信息失败: "+err.Error())
			return
		}
		for _, m := range musicRecords {
			if m.Path != "" {
				if err := os.Remove(m.Path); err != nil && !os.IsNotExist(err) {
					log.Printf("[batchDeleteMusic] 删除文件失败: %s, err: %v", m.Path, err)
				} else if err == nil {
					filesDeleted++
					log.Printf("[batchDeleteMusic] 已删除文件: %s", m.Path)
				}
			}
		}
	}

	deletedCount, err := s.musicSvc.DeleteMusicByIDs(req.IDs)
	if err != nil {
		respondInternalError(c, "删除音乐记录失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("已删除 %d 条记录", deletedCount),
		"files_deleted": filesDeleted,
	})
}

// streamMusic 流式播放音频文件
// GET /api/music/:id/stream
func (s *Server) streamMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	m, err := s.musicSvc.GetMusic(int64(id))
	if err != nil || m == nil {
		respondNotFound(c, "音乐不存在")
		return
	}

	filePath := m.Path
	if _, statErr := os.Stat(filePath); statErr != nil {
		respondNotFound(c, "音频文件不存在: "+filePath)
		return
	}

	serveAudioStream(c, filePath)
}

// serveAudioStream 统一的音频流服务
func serveAudioStream(c *gin.Context, filePath string) {
	file, err := os.Open(filePath)
	if err != nil {
		respondNotFound(c, "音频文件不存在")
		return
	}
	defer file.Close()

	stat, err := file.Stat()
	if err != nil {
		respondInternalError(c, "获取文件信息失败")
		return
	}
	size := stat.Size()

	ext := strings.ToLower(filepath.Ext(filePath))
	contentType := getAudioContentType(ext)

	c.Header("Content-Type", contentType)
	c.Header("Accept-Ranges", "bytes")

	rangeHeader := c.GetHeader("Range")
	if rangeHeader == "" {
		c.Header("Content-Length", strconv.FormatInt(size, 10))
		c.Status(http.StatusOK)
		io.Copy(c.Writer, file)
		return
	}

	ranges := parseRangeHeader(rangeHeader, size)
	if ranges == nil {
		c.Header("Content-Range", fmt.Sprintf("bytes */%d", size))
		c.Status(http.StatusRequestedRangeNotSatisfiable)
		return
	}

	start, end := ranges[0], ranges[1]
	if end >= size {
		end = size - 1
	}
	contentLength := end - start + 1

	c.Status(http.StatusPartialContent)
	c.Header("Content-Range", fmt.Sprintf("bytes %d-%d/%d", start, end, size))
	c.Header("Content-Length", strconv.FormatInt(contentLength, 10))

	if _, err := file.Seek(start, io.SeekStart); err != nil {
		log.Printf("音频 Seek 失败: %v", err)
		return
	}

	limitedReader := io.LimitReader(file, contentLength)
	io.Copy(c.Writer, limitedReader)
}

func getAudioContentType(ext string) string {
	switch ext {
	case ".mp3":
		return "audio/mpeg"
	case ".ogg", ".opus":
		return "audio/ogg"
	case ".flac":
		return "audio/flac"
	case ".wav":
		return "audio/wav"
	case ".m4a", ".aac":
		return "audio/mp4"
	case ".wma":
		return "audio/x-ms-wma"
	default:
		return "application/octet-stream"
	}
}

// convertMusic 使用FFmpeg转换音频格式
// POST /api/music/:id/convert  body: {"target_format": "mp3"}
func (s *Server) convertMusic(c *gin.Context) {
	if s.musicSvc == nil {
		respondInternalError(c, "音乐服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	var req struct {
		TargetFormat string `json:"target_format"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || req.TargetFormat == "" {
		respondBadRequest(c, "请提供目标格式")
		return
	}

	targetFormat := strings.ToLower(req.TargetFormat)
	supportedFormats := map[string]string{
		"mp3":  "mp3",
		"ogg":  "ogg",
		"flac": "flac",
		"wav":  "wav",
		"m4a":  "m4a",
		"aac":  "aac",
	}

	targetExt, ok := supportedFormats[targetFormat]
	if !ok {
		respondBadRequest(c, "不支持的转换格式: "+targetFormat)
		return
	}

	m, err := s.musicSvc.GetMusic(int64(id))
	if err != nil || m == nil {
		respondNotFound(c, "音乐不存在")
		return
	}

	filePath := m.Path
	if _, statErr := os.Stat(filePath); statErr != nil {
		respondNotFound(c, "音频文件不存在: "+filePath)
		return
	}

	// 构建输出文件名
	baseName := m.Name[:len(m.Name)-len(filepath.Ext(m.Name))]
	outputName := baseName + "." + targetExt
	sourceDir := filepath.Dir(filePath)
	outputPath := filepath.Join(sourceDir, outputName)

	// 检查目标文件是否已存在
	if _, err := os.Stat(outputPath); err == nil {
		respondInternalError(c, "目标文件已存在: "+outputPath)
		return
	}

	// 使用FFmpeg转码
	cmd := exec.Command(video.FindFFmpeg(),
		"-i", filePath,
		"-y",
		outputPath,
	)

	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Printf("[convertMusic] FFmpeg错误: %s", string(output))
		respondInternalError(c, "音频转换失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":     "转换成功",
		"output_path": outputPath,
		"output_name": outputName,
	})
}
