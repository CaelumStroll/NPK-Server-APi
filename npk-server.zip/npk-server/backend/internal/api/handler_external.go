package api

import (
	"io"
	"log"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"

	"npk-server/internal/service"
)

// getExternalNpkAlbums 获取外部 NPK 的 Album 列表（支持路径或上传）
func (s *Server) getExternalNpkAlbums(c *gin.Context) {
	// 优先处理文件上传
	file, err := c.FormFile("file")
	if err == nil && file != nil {
		f, _ := file.Open()
		data, _ := io.ReadAll(f)
		f.Close()
		albums, key, err := s.npkSvc.UploadExternalNpk(file.Filename, data)
		if err != nil {
			respondInternalError(c, err.Error())
			return
		}
		respondSuccess(c, gin.H{"albums": albums, "key": key, "total": len(albums)})
		return
	}

	npkPath := c.Query("npkPath")
	if npkPath == "" {
		respondBadRequest(c, "缺少 npkPath 参数或上传文件")
		return
	}

	if !isValidExternalNpkPath(npkPath) {
		respondBadRequest(c, "无效的 NPK 文件路径")
		return
	}

	foundPath := s.findNpkFile(npkPath)
	albums, err := s.npkSvc.GetExternalNpkAlbums(foundPath)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, albums)
}

// getExternalNpkFrame 获取外部 NPK 的帧图像（支持路径或缓存 key）
func (s *Server) getExternalNpkFrame(c *gin.Context) {
	npkPath := c.Query("npkPath")
	albumPath := c.Query("albumPath")
	frameIndexStr := c.Query("frameIndex")
	widthStr := c.DefaultQuery("width", "0")
	heightStr := c.DefaultQuery("height", "0")
	format := c.DefaultQuery("format", "png")
	qualityStr := c.DefaultQuery("quality", "90")
	cacheKey := c.Query("key")

	frameIndex, err := strconv.Atoi(frameIndexStr)
	if err != nil || frameIndex < 0 {
		respondBadRequest(c, "无效的帧索引")
		return
	}

	width, _ := strconv.Atoi(widthStr)
	height, _ := strconv.Atoi(heightStr)
	quality, _ := strconv.Atoi(qualityStr)

	// 优先使用缓存 key
	if cacheKey != "" {
		data, err := s.npkSvc.GetExternalNpkFrameByCache(cacheKey, albumPath, frameIndex, width, height, format, quality)
		if err != nil {
			respondInternalError(c, err.Error())
			return
		}
		c.Header("Content-Type", "image/"+format)
		c.Writer.Write(data)
		return
	}

	// 在配置的 NPK 目录中查找文件
	foundPath := s.findNpkFile(npkPath)

	data, err := s.npkSvc.GetExternalNpkFrame(foundPath, albumPath, frameIndex, width, height, format, quality)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	contentType := "image/png"
	if format == "jpeg" || format == "jpg" {
		contentType = "image/jpeg"
	}
	c.Data(http.StatusOK, contentType, data)
}

// uploadExternalImg 上传外部 IMG 文件
func (s *Server) uploadExternalImg(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		respondBadRequest(c, "获取上传文件失败: " + err.Error())
		return
	}

	// 验证文件大小
	if file.Size > maxFileUploadSize {
		respondBadRequest(c, "文件大小超过限制")
		return
	}

	// 验证文件扩展名
	fileName := file.Filename
	ext := strings.ToLower(filepath.Ext(fileName))
	if ext != ".img" {
		respondBadRequest(c, "只支持 .img 文件")
		return
	}

	// 读取文件内容
	src, err := file.Open()
	if err != nil {
		respondInternalError(c, "打开文件失败: " + err.Error())
		return
	}
	defer src.Close()

	data, err := io.ReadAll(src)
	if err != nil {
		respondInternalError(c, "读取文件失败: " + err.Error())
		return
	}

	// 上传到服务层
	key, album, err := s.npkSvc.UploadExternalImg(fileName, data)
	if err != nil {
		respondInternalError(c, "处理文件失败: " + err.Error())
		return
	}

	// 包装成单元素数组返回
	albums := []*service.AlbumInfo{album}
	respondSuccess(c, gin.H{"data": albums, "key": key})
}

// loadExternalImgAlbum 加载单个外部 IMG 文件的信息
func (s *Server) loadExternalImgAlbum(c *gin.Context) {
	imgPath := c.Query("imgPath")
	if imgPath == "" {
		respondBadRequest(c, "缺少 imgPath 参数")
		return
	}

	// 如果是缓存 key，则不需要验证路径
	isCacheKey := strings.Contains(imgPath, ":")
	if !isCacheKey {
		// 验证路径：防止路径遍历攻击
		if !isValidExternalNpkPath(imgPath) {
			if strings.Contains(imgPath, "..") || strings.Contains(imgPath, "../") || strings.Contains(imgPath, "..\\") {
				respondBadRequest(c, "无效的 IMG 文件路径")
				return
			}
		}
	}

	log.Printf("加载外部 IMG: %s", imgPath)

	album, err := s.npkSvc.LoadExternalImgAlbum(imgPath)
	if err != nil {
		log.Printf("加载外部 IMG 失败: %v", err)
		respondInternalError(c, "处理请求失败: " + err.Error())
		return
	}

	log.Printf("加载外部 IMG 成功: %s, 帧数量: %d", album.Name, album.SpriteCount)

	// 包装成和外部 NPK 类似的单元素数组返回
	albums := []*service.AlbumInfo{album}
	respondSuccess(c, albums)
}

// getExternalImgFrame 获取单个外部 IMG 文件的指定帧图像
func (s *Server) getExternalImgFrame(c *gin.Context) {
	imgPath := c.Query("imgPath")
	frameIndexStr := c.Query("frameIndex")
	widthStr := c.DefaultQuery("width", "0")
	heightStr := c.DefaultQuery("height", "0")
	format := c.DefaultQuery("format", "png")
	qualityStr := c.DefaultQuery("quality", "90")

	if imgPath == "" || frameIndexStr == "" {
		respondBadRequest(c, "缺少必要参数")
		return
	}

	// 如果是缓存 key，则不需要验证路径
	isCacheKey := strings.Contains(imgPath, ":")
	if !isCacheKey {
		// 验证路径：防止路径遍历攻击
		if strings.Contains(imgPath, "..") || strings.Contains(imgPath, "../") || strings.Contains(imgPath, "..\\") {
			respondBadRequest(c, "无效的 IMG 文件路径")
			return
		}
	}

	frameIndex, err := strconv.Atoi(frameIndexStr)
	if err != nil {
		respondBadRequest(c, "无效的 frameIndex")
		return
	}

	width, _ := strconv.Atoi(widthStr)
	height, _ := strconv.Atoi(heightStr)
	quality, _ := strconv.Atoi(qualityStr)

	data, err := s.npkSvc.GetExternalImgFrame(imgPath, frameIndex, width, height, format, quality)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	contentType := "image/png"
	if format == "jpeg" || format == "jpg" {
		contentType = "image/jpeg"
	}
	c.Data(http.StatusOK, contentType, data)
}
// downloadExternalNpk 下载编辑后的外部 NPK
func (s *Server) downloadExternalNpk(c *gin.Context) {
	key := c.Query("key")
	if key == "" {
		respondBadRequest(c, "缺少 key 参数")
		return
	}

	data, name, err := s.npkSvc.SaveExternalNpk(key, nil)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+name)
	c.Data(http.StatusOK, "application/octet-stream", data)
}
