package api

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// getLibraryStats 获取资源库统计信息
func (s *Server) getLibraryStats(c *gin.Context) {
	stats, err := s.librarySvc.GetStats()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}
	respondSuccess(c, stats)
}

// searchLibrary 搜索资源库
func (s *Server) searchLibrary(c *gin.Context) {
	query := c.Query("q")
	assetType := c.Query("type")
	page, pageSize := parsePaginationParams(c)

	results, total, err := s.librarySvc.SearchAssets(query, assetType, page, pageSize)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"results": results, "total": total, "page": page, "size": pageSize})
}

// getTags 获取所有标签
func (s *Server) getTags(c *gin.Context) {
	tags, err := s.db.GetTags()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}
	respondSuccess(c, tags)
}

// getDuplicateAlbums 获取重复的 Album
func (s *Server) getDuplicateAlbums(c *gin.Context) {
	results, err := s.db.GetDuplicateAlbums()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}
	respondSuccess(c, results)
}

// createTag 创建标签
func (s *Server) createTag(c *gin.Context) {
	var req struct {
		Name  string `json:"name" binding:"required"`
		Color string `json:"color"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少 name 参数")
		return
	}

	if existing, _ := s.db.GetTagByName(req.Name); existing != nil {
		c.JSON(http.StatusConflict, Response{Code: int(CodeError), Message: "标签已存在", Data: existing})
		return
	}

	id, err := s.db.CreateTag(req.Name, req.Color)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	tag, _ := s.db.GetTagByID(id)
	respondSuccess(c, tag)
}

// updateTag 更新标签
func (s *Server) updateTag(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		respondBadRequest(c, "无效的标签 ID")
		return
	}

	var req struct {
		Name  string `json:"name" binding:"required"`
		Color string `json:"color"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少 name 参数")
		return
	}

	if err := s.db.UpdateTag(id, req.Name, req.Color); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	tag, _ := s.db.GetTagByID(id)
	respondSuccess(c, tag)
}

// deleteTag 删除标签
func (s *Server) deleteTag(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		respondBadRequest(c, "无效的标签 ID")
		return
	}

	if err := s.db.DeleteTag(id); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "已删除"})
}

// updateAssetTags 更新资源的标签
func (s *Server) updateAssetTags(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		respondBadRequest(c, "无效的资源 ID")
		return
	}

	var req struct {
		AssetType string  `json:"asset_type" binding:"required"`
		TagIDs    []int64 `json:"tag_ids"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少 asset_type 或 tag_ids 参数")
		return
	}

	switch req.AssetType {
	case "npk":
		if err := s.clearNpkTags(id); err != nil {
			respondInternalError(c, err.Error())
			return
		}
		for _, tagID := range req.TagIDs {
			if err := s.db.AddTagToNPK(id, tagID); err != nil {
				respondInternalError(c, err.Error())
				return
			}
		}
	case "album":
		if err := s.clearAlbumTags(id); err != nil {
			respondInternalError(c, err.Error())
			return
		}
		for _, tagID := range req.TagIDs {
			if err := s.db.AddTagToAlbum(id, tagID); err != nil {
				respondInternalError(c, err.Error())
				return
			}
		}
	case "sprite":
		if err := s.clearSpriteTags(id); err != nil {
			respondInternalError(c, err.Error())
			return
		}
		for _, tagID := range req.TagIDs {
			if err := s.db.AddTagToSprite(id, tagID); err != nil {
				respondInternalError(c, err.Error())
				return
			}
		}
	default:
		respondBadRequest(c, "无效的 asset_type，支持: npk, album, sprite")
		return
	}

	respondSuccess(c, gin.H{"message": "标签已更新"})
}

// searchByTags 按标签搜索资源
func (s *Server) searchByTags(c *gin.Context) {
	tagIDsStr := c.Query("tag_ids")
	assetType := c.Query("asset_type")

	if tagIDsStr == "" {
		respondBadRequest(c, "缺少 tag_ids 参数")
		return
	}

	var tagIDs []int64
	for _, s := range strings.Split(tagIDsStr, ",") {
		id, err := strconv.ParseInt(strings.TrimSpace(s), 10, 64)
		if err != nil {
			respondBadRequest(c, "无效的 tag_id: "+s)
			return
		}
		tagIDs = append(tagIDs, id)
	}

	result, err := s.db.SearchAssetsByTags(tagIDs, assetType)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, result)
}

// getNpkTags 获取 NPK 的标签
func (s *Server) getNpkTags(c *gin.Context) {
	name := decodePathParam(c, "name")
	record, err := s.db.GetNpkFileByName(name)
	if err != nil {
		respondNotFound(c, "NPK 不存在")
		return
	}

	tags, err := s.db.GetTagsByNPKID(record.ID)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, tags)
}

// addNpkTag 给 NPK 添加标签
func (s *Server) addNpkTag(c *gin.Context) {
	name := decodePathParam(c, "name")
	record, err := s.db.GetNpkFileByName(name)
	if err != nil {
		respondNotFound(c, "NPK 不存在")
		return
	}

	var req struct {
		TagID int64 `json:"tag_id" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少 tag_id 参数")
		return
	}

	if err := s.db.AddTagToNPK(record.ID, req.TagID); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "标签已添加"})
}

// removeNpkTag 移除 NPK 的标签
func (s *Server) removeNpkTag(c *gin.Context) {
	name := decodePathParam(c, "name")
	record, err := s.db.GetNpkFileByName(name)
	if err != nil {
		respondNotFound(c, "NPK 不存在")
		return
	}

	tagID, err := strconv.ParseInt(c.Param("tagId"), 10, 64)
	if err != nil {
		respondBadRequest(c, "无效的标签 ID")
		return
	}

	if err := s.db.RemoveTagFromNPK(record.ID, tagID); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "标签已移除"})
}

// getFolders 获取文件夹树
func (s *Server) getFolders(c *gin.Context) {
	tree, err := s.librarySvc.GetTree()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}
	respondSuccess(c, tree)
}

// clearNpkTags 清除 NPK 的所有标签
func (s *Server) clearNpkTags(npkID int64) error {
	tags, err := s.db.GetTagsByNPKID(npkID)
	if err != nil { return err }
	for _, tag := range tags {
		if err := s.db.RemoveTagFromNPK(npkID, tag.ID); err != nil { return err }
	}
	return nil
}

// clearAlbumTags 清除 Album 的所有标签
func (s *Server) clearAlbumTags(albumID int64) error {
	tags, err := s.db.GetTagsByAlbumID(albumID)
	if err != nil { return err }
	for _, tag := range tags {
		if err := s.db.RemoveTagFromAlbum(albumID, tag.ID); err != nil { return err }
	}
	return nil
}

// clearSpriteTags 清除 Sprite 的所有标签
func (s *Server) clearSpriteTags(spriteID int64) error {
	tags, err := s.db.GetTagsBySpriteID(spriteID)
	if err != nil { return err }
	for _, tag := range tags {
		if err := s.db.RemoveTagFromSprite(spriteID, tag.ID); err != nil { return err }
	}
	return nil
}
