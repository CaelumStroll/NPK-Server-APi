package api

import (
	"fmt"
	"image"
	"image/color"
	"io/fs"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-contrib/static"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"

	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/service"
	"npk-server/internal/system"
	"npk-server/internal/web"
	wsHub "npk-server/internal/websocket"
)

// Server API 服务器
type Server struct {
	cfg         *config.Config
	db          *database.Database
	npkSvc      service.NpkAggregate
	videoSvc    service.VideoManager
	musicSvc    *service.MusicService
	soundpackSvc *service.SoundPackService
	librarySvc  service.LibraryManager
	batchSvc    service.BatchManager
	hub         *wsHub.Hub
	collector   *system.Collector
	router      *gin.Engine
	rateLimiter *RateLimiter

	// 批量响应缓存（用于 album-batch 等频繁调用的 API）
	batchCache      map[string]*BatchCacheEntry
	batchCacheMutex sync.RWMutex

	// 转换任务
	convertTaskCounter int
	convertTasks       map[string]*ConvertTask

	audioXmlPath string // 当前打开的 audio.xml 文件路径
}

// BatchCacheEntry 批量响应缓存条目
type BatchCacheEntry struct {
	Result    []byte
	CreatedAt time.Time
}

// ConvertTask NPK 版本转换任务
type ConvertTask struct {
	ID           string
	Status       string
	StatusText   string
	TargetVer    string
	OutputFormat string
	Total        int
	Completed    int
	Skipped      int
	OutputPath   string
	Error        string
	CreatedAt    time.Time
	UpdatedAt    time.Time
}

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

var execDir string

// SetExecDir 设置工作目录（exe 所在目录）
func SetExecDir(dir string) {
	execDir = dir
}

// 分页常量
const (
	defaultPage         = 1
	defaultPageSize     = 50
	maxPageSize         = 200
	minPageSize         = 1
	vacuumIntervalHours = 24
	batchTaskRetentionDays = 7
	maxFileUploadSize   = 10 * 1024 * 1024
)

// 允许的文件上传类型
var allowedImageExtensions = map[string]bool{
	".png":  true,
	".jpg":  true,
	".jpeg": true,
	".gif":  true,
	".bmp":  true,
	".tif":  true,
	".tiff": true,
}

var allowedImageMimeTypes = map[string]bool{
	"image/png":  true,
	"image/jpeg": true,
	"image/gif":  true,
	"image/bmp":  true,
	"image/tiff": true,
}

// cacheStatsAdapter 适配 NpkAggregate 的缓存统计到 CacheProvider 接口
type cacheStatsAdapter struct {
	npkSvc service.NpkAggregate
}

func (a *cacheStatsAdapter) Stats() map[string]interface{} {
	return a.npkSvc.GetCacheStats()
}

// NewServer 创建服务器
func NewServer(cfg *config.Config, db *database.Database, npkSvc *service.NpkService, videoSvc *service.VideoService, musicSvc *service.MusicService, soundpackSvc *service.SoundPackService) *Server {
	cacheAdapter := &cacheStatsAdapter{npkSvc: npkSvc}
	collector := system.NewCollector()
	collector.SetCacheStatsFunc(npkSvc.GetCacheStats)

	batchSvc := service.NewBatchService(npkSvc)
	rateLimiter := NewRateLimiter(500, time.Millisecond*100)

	go func() {
		ticker := time.NewTicker(5 * time.Minute)
		defer ticker.Stop()
		for range ticker.C {
			rateLimiter.CleanupExpiredBuckets()
		}
	}()

	go func() {
		ticker := time.NewTicker(time.Hour * time.Duration(vacuumIntervalHours))
		defer ticker.Stop()
		for range ticker.C {
			log.Println("Performing scheduled database maintenance...")
			if _, err := db.CleanupOldBatchTasks(batchTaskRetentionDays); err != nil {
				log.Printf("Cleanup old batch tasks failed: %v", err)
			}
			if err := db.Vacuum(); err != nil {
				log.Printf("Database vacuum failed: %v", err)
			}
		}
	}()

	return &Server{
		cfg:              cfg,
		db:               db,
		npkSvc:           npkSvc,
		videoSvc:         videoSvc,
		musicSvc:         musicSvc,
		soundpackSvc:     soundpackSvc,
		librarySvc:       service.NewLibraryService(db, cacheAdapter),
		batchSvc:         batchSvc,
		hub:              wsHub.NewHub(),
		collector:        collector,
		rateLimiter:      rateLimiter,
		batchCache:       make(map[string]*BatchCacheEntry),
		convertTasks:     make(map[string]*ConvertTask),
	}
}

// Setup 设置路由
func (s *Server) Setup() *gin.Engine {
	gin.SetMode(gin.ReleaseMode)
	execDir, _ = os.Getwd()

	router := gin.New()
	router.Use(gin.Logger())
	router.Use(gin.Recovery())
	router.UseRawPath = true
	router.UnescapePathValues = false

	router.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Content-Type", "Accept", "Authorization"},
		ExposeHeaders:    []string{"Content-Length", "Content-Disposition"},
		AllowCredentials: true,
	}))

	api := router.Group("/api", s.rateLimiter.Limit())
	{
		s.registerNpkRoutes(api)
		s.registerNpkTagRoutes(api)
		s.registerAssetRoutes(api)
		s.registerAnimationRoutes(api)
		s.registerCacheRoutes(api)
		s.registerAlbumRoutes(api)
		s.registerLibraryRoutes(api)
		s.registerSpriteRoutes(api)
		s.registerExternalRoutes(api)
		s.registerBatchRoutes(api)
		s.registerToolRoutes(api)
		s.registerSettingsRoutes(api)
		s.registerDBRoutes(api)
		s.registerVideoDBRoutes(api)
		s.registerVideoRoutes(api)
		s.registerMusicRoutes(api)
		s.registerMusicDBRoutes(api)
		s.registerSoundPackRoutes(api)
		s.registerSoundPackDBRoutes(api)
		s.registerXmlEditorRoutes(api)
		s.registerDebugRoutes(api)
		s.registerLanguageRoutes(api)
	}

	s.registerCompatRoutes(router)

	// V2 批量图片 API
	v2 := router.Group("/api/v2")
	{
		v2.POST("/album/frames", s.v2AlbumFrames)
	}

	router.GET("/ws/preview/:sessionId", s.handleWebSocket)
	router.GET("/ws/system", s.handleSystemWebSocket)
	router.GET("/ws/logs", s.handleLogWebSocket)

	s.setupStaticFiles(router)

	s.router = router
	return router
}

// setupStaticFiles 设置静态文件服务
func (s *Server) setupStaticFiles(router *gin.Engine) {
	localWeb := "./web"
	if _, err := os.Stat(localWeb); err == nil {
		// 开发模式
		router.GET("/assets/*filepath", func(c *gin.Context) {
			static.Serve("/assets", static.LocalFile(localWeb, false))(c)
		})
		router.GET("/vite.svg", func(c *gin.Context) { c.File(filepath.Join(localWeb, "vite.svg")) })
		router.GET("/town.html", func(c *gin.Context) { c.File(filepath.Join(localWeb, "town.html")) })
		router.GET("/encrypt.html", func(c *gin.Context) { c.File(filepath.Join(localWeb, "encrypt.html")) })
		router.GET("/docs/*filepath", func(c *gin.Context) {
			static.Serve("/docs", static.LocalFile(localWeb, false))(c)
		})
		router.GET("/avatars/*filepath", s.serveAvatarFile)
		router.GET("/tools/*filepath", s.serveToolFile)
		router.NoRoute(func(c *gin.Context) {
			if strings.HasPrefix(c.Request.URL.Path, "/api/") || strings.HasPrefix(c.Request.URL.Path, "/ws") {
				c.JSON(404, Response{Code: 404, Message: "API not found"})
				return
			}
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			c.File(filepath.Join(localWeb, "index.html"))
		})
		log.Println("使用本地前端文件:", localWeb)
	} else {
		// 生产模式
		distFS, err := fs.Sub(web.DistFS, web.DistDir)
		if err != nil {
			log.Printf("警告: 嵌入前端文件加载失败: %v", err)
			return
		}
		fileServer := http.FileServer(http.FS(distFS))
		router.GET("/assets/*filepath", func(c *gin.Context) {
			c.Request.URL.Path = "/assets/" + c.Param("filepath")
			c.Header("Cache-Control", "public, max-age=31536000, immutable")
			fileServer.ServeHTTP(c.Writer, c.Request)
		})
		router.GET("/vite.svg", func(c *gin.Context) {
			c.Header("Cache-Control", "no-cache")
			fileServer.ServeHTTP(c.Writer, c.Request)
		})
		router.GET("/town.html", func(c *gin.Context) {
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			fileServer.ServeHTTP(c.Writer, c.Request)
		})
		router.GET("/encrypt.html", func(c *gin.Context) {
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			fileServer.ServeHTTP(c.Writer, c.Request)
		})
		router.GET("/docs/*filepath", func(c *gin.Context) {
			c.Request.URL.Path = "/docs/" + c.Param("filepath")
			fileServer.ServeHTTP(c.Writer, c.Request)
		})
		router.GET("/avatars/*filepath", s.serveAvatarFile)
		router.GET("/tools/*filepath", s.serveToolFile)
		router.NoRoute(func(c *gin.Context) {
			if strings.HasPrefix(c.Request.URL.Path, "/api/") || strings.HasPrefix(c.Request.URL.Path, "/ws") {
				c.JSON(404, Response{Code: 404, Message: "API not found"})
				return
			}
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			c.Request.URL.Path = "/"
			fileServer.ServeHTTP(c.Writer, c.Request)
		})
		log.Println("使用嵌入前端文件 (embed)")
	}
}

// serveAvatarFile 服务头像文件
func (s *Server) serveAvatarFile(c *gin.Context) {
	filePath := c.Param("filepath")
	filePath = strings.TrimPrefix(filePath, "/")
	fullPath := filepath.Join(execDir, "avatars", filePath)
	if _, err := os.Stat(fullPath); err == nil {
		c.File(fullPath)
	} else {
		// 回退：也检查相对路径
		fullPath = filepath.Join("avatars", filePath)
		if _, err := os.Stat(fullPath); err == nil {
			c.File(fullPath)
		} else {
			c.JSON(404, Response{Code: 404, Message: "头像不存在"})
		}
	}
}

// serveToolFile 服务工具文件（HTML/JS/CSS 等静态资源）
func (s *Server) serveToolFile(c *gin.Context) {
	filePath := c.Param("filepath")
	filePath = strings.TrimPrefix(filePath, "/")
	ext := strings.ToLower(filepath.Ext(filePath))

	allowed := map[string]bool{
		".html": true, ".htm": true,
		".js": true, ".mjs": true,
		".css": true,
		".json": true,
		".png": true, ".jpg": true, ".jpeg": true, ".gif": true, ".svg": true, ".webp": true,
		".woff": true, ".woff2": true, ".ttf": true, ".eot": true,
		".map": true, ".ico": true, ".mp3": true, ".ogg": true, ".wav": true, ".ogv": true,
	}

	// 无扩展名或目录路径 → 尝试 index.html
	if filePath == "" || strings.HasSuffix(filePath, "/") || (!allowed[ext] && ext == "") {
		indexPath := strings.TrimRight(filePath, "/") + "/index.html"
		fullPath := filepath.Join(execDir, "tools", indexPath)
		if _, err := os.Stat(fullPath); err == nil {
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			c.File(fullPath)
			return
		}
		fullPath = filepath.Join("tools", indexPath)
		if _, err := os.Stat(fullPath); err == nil {
			c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
			c.File(fullPath)
			return
		}
	}

	if !allowed[ext] {
		c.JSON(403, Response{Code: 403, Message: "不支持的文件类型: " + ext})
		return
	}

	c.Header("Cache-Control", "no-cache, no-store, must-revalidate")
	fullPath := filepath.Join(execDir, "tools", filePath)
	if _, err := os.Stat(fullPath); err == nil {
		c.File(fullPath)
		return
	}
	fullPath = filepath.Join("tools", filePath)
	if _, err := os.Stat(fullPath); err == nil {
		c.File(fullPath)
		return
	}
	c.JSON(404, Response{Code: 404, Message: "工具不存在"})
}

// Run 运行服务器
func (s *Server) Run() error {
	go s.hub.Run()
	return s.router.Run(fmt.Sprintf(":%d", s.cfg.ServerPort))
}

// 辅助函数

// parsePaginationParams 解析并验证分页参数
func parsePaginationParams(c *gin.Context) (int, int) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", strconv.Itoa(defaultPage)))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("size", strconv.Itoa(defaultPageSize)))
	if page < defaultPage {
		page = defaultPage
	}
	if pageSize < minPageSize {
		pageSize = minPageSize
	} else if pageSize > maxPageSize {
		pageSize = maxPageSize
	}
	return page, pageSize
}

// validateUploadedFile 验证上传文件的合法性
func validateUploadedFile(file *multipart.FileHeader) error {
	if file.Size > maxFileUploadSize {
		return fmt.Errorf("文件大小不能超过 10MB")
	}
	ext := strings.ToLower(filepath.Ext(file.Filename))
	if !allowedImageExtensions[ext] {
		return fmt.Errorf("不支持的文件类型: %s", ext)
	}
	if file.Header != nil {
		contentType := file.Header.Get("Content-Type")
		if contentType != "" && !allowedImageMimeTypes[contentType] {
			return fmt.Errorf("不支持的文件 Content-Type: %s", contentType)
		}
	}
	return nil
}

// sanitizeErrorMessage 脱敏错误信息
func sanitizeErrorMessage(err error) string {
	if err == nil { return "" }
	return "处理请求失败"
}

// getQueryInt 获取整数查询参数
func getQueryInt(c *gin.Context, key string, defaultValue int) int {
	val, err := strconv.Atoi(c.Query(key))
	if err != nil { return defaultValue }
	return val
}

// isValidExternalNpkPath 验证外部 NPK 文件路径
func isValidExternalNpkPath(path string) bool {
	if strings.Contains(path, "..") { return false }
	ext := strings.ToLower(filepath.Ext(path))
	if ext != ".npk" { return false }
	if len(path) > 1024 { return false }
	return true
}

// findNpkFile 在配置的 NPK 目录中查找文件
func (s *Server) findNpkFile(path string) string {
	if filepath.IsAbs(path) {
		if _, err := os.Stat(path); err == nil { return path }
	}
	fileName := filepath.Base(path)
	for _, npkDir := range s.cfg.NpkDirs {
		fullPath := filepath.Join(npkDir, path)
		if _, err := os.Stat(fullPath); err == nil { return fullPath }
		fullPath = filepath.Join(npkDir, fileName)
		if _, err := os.Stat(fullPath); err == nil { return fullPath }
		if foundPath := s.findNpkFileInDir(npkDir, fileName); foundPath != "" { return foundPath }
	}
	return path
}

// findNpkFileInDir 在目录中递归查找文件
func (s *Server) findNpkFileInDir(dir, fileName string) string {
	var foundPath string
	filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil { return nil }
		if !info.IsDir() && strings.EqualFold(info.Name(), fileName) {
			foundPath = path
			return filepath.SkipAll
		}
		return nil
	})
	return foundPath
}

// inferNpkNameFromImgPath 从 IMG 路径推断 NPK 名称
func inferNpkNameFromImgPath(imgPath string) string {
	parts := strings.Split(imgPath, "/")
	if len(parts) > 0 {
		return parts[0]
	}
	return ""
}

// routeGroupDefs 定义路由分组规则（按路径前缀匹配）
var routeGroupDefs = []struct {
	prefix string
	group  string
}{
	{"/npk/", "NPK管理"},
	{"/cache/", "IMG缓存"},
	{"/library/", "资源库"},
	{"/batch/", "批量操作"},
	{"/settings", "设置"},
	{"/db/", "数据库"},
	{"/external-npk/", "外部NPK"},
	{"/external-img/", "外部IMG"},
	{"/tools/", "工具箱"},
	{"/avatars/", "头像"},
	{"/debug/", "调试"},
	{"/health", "兼容API"},
	{"/npks/", "兼容API"},
	{"/frame/", "兼容API"},
	{"/frames/", "兼容API"},
	{"/overlay", "兼容API"},
}

// classifyRouteGroup 根据路径前缀确定分组
func classifyRouteGroup(path string) string {
	for _, def := range routeGroupDefs {
		if strings.Contains(path, def.prefix) {
			return def.group
		}
	}
	return "其他"
}

// parseVersionString 解析版本字符串（V1/V2/V4/V5/V6）
func parseVersionString(ver string) int {
	switch strings.ToUpper(ver) {
	case "V1":
		return 1
	case "V2":
		return 2
	case "V4":
		return 4
	case "V5":
		return 5
	case "V6":
		return 6
	default:
		return 2 // 默认 V2
	}
}

// parseHexColor 解析十六进制颜色字符串
func parseHexColor(hex string) (color.Color, error) {
	hex = strings.TrimPrefix(hex, "#")
	if len(hex) == 3 {
		// 扩展 #RGB 为 #RRGGBB
		hex = string([]byte{
			hex[0], hex[0],
			hex[1], hex[1],
			hex[2], hex[2],
		})
	}
	if len(hex) != 6 {
		return color.Black, fmt.Errorf("无效的颜色格式: #%s", hex)
	}
	r, err := strconv.ParseUint(hex[0:2], 16, 8)
	if err != nil {
		return color.Black, err
	}
	g, err := strconv.ParseUint(hex[2:4], 16, 8)
	if err != nil {
		return color.Black, err
	}
	b, err := strconv.ParseUint(hex[4:6], 16, 8)
	if err != nil {
		return color.Black, err
	}
	return color.RGBA{R: uint8(r), G: uint8(g), B: uint8(b), A: 255}, nil
}

// applyOpacity 应用透明度到图像
func applyOpacity(img image.Image, opacity float64) image.Image {
	bounds := img.Bounds()
	result := image.NewRGBA(bounds)

	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			r, g, b, a := img.At(x, y).RGBA()
			newA := uint32(float64(a) * opacity)
			result.SetRGBA(x, y, color.RGBA{
				R: uint8(r >> 8),
				G: uint8(g >> 8),
				B: uint8(b >> 8),
				A: uint8(newA >> 8),
			})
		}
	}

	return result
}