package api

import (
	"fmt"
	"log"
	"os"

	"github.com/gin-gonic/gin"
)

// getSoundPackDBStats 获取音效数据库统计
// GET /api/db/soundpacks/stats
func (s *Server) getSoundPackDBStats(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	stats, err := s.soundpackSvc.GetSoundPackStats()
	if err != nil {
		respondInternalError(c, "获取统计失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"soundpack_count": stats.TotalCount,
		"total_size":      stats.TotalSize,
		"total_ogg_count": stats.TotalOggCount,
	})
}

// cleanupSoundPackDB 清理无效记录
// POST /api/db/soundpacks/cleanup
func (s *Server) cleanupSoundPackDB(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	spList, _, err := s.soundpackSvc.ListSoundPacks("", 1, 100000)
	if err != nil {
		respondInternalError(c, "获取列表失败: "+err.Error())
		return
	}

	var deletedCount int
	var invalidFiles []string
	for _, sp := range spList {
		if _, statErr := os.Stat(sp.Path); os.IsNotExist(statErr) {
			if delErr := s.soundpackSvc.DeleteSoundPack(sp.ID); delErr == nil {
				deletedCount++
				invalidFiles = append(invalidFiles, sp.Path)
			}
		}
	}

	msg := fmt.Sprintf("清理完成：删除 %d 条无效记录", deletedCount)
	respondSuccess(c, gin.H{
		"message":       msg,
		"deleted_count": deletedCount,
		"invalid_files": invalidFiles,
	})
}

// rebuildSoundPackDB 重建数据库
// POST /api/db/soundpacks/rebuild
func (s *Server) rebuildSoundPackDB(c *gin.Context) {
	if s.soundpackSvc == nil {
		respondInternalError(c, "音效服务未初始化")
		return
	}

	dirs := s.cfg.SoundPackDirs
	log.Printf("[rebuildSoundPackDB] 当前配置的音效目录: %v (len=%d)", dirs, len(dirs))
	if len(dirs) == 0 {
		respondBadRequest(c, "未配置音效目录，请在 设置 → 音效目录(SoundPacks) 中添加目录后保存，再执行重建")
		return
	}

	oldStats, _ := s.soundpackSvc.GetSoundPackStats()
	oldCount := 0
	if oldStats != nil {
		oldCount = oldStats.TotalCount
	}

	var totalScanned int

	for _, dir := range dirs {
		log.Printf("[rebuildSoundPackDB] 扫描目录: %s", dir)
		records, err := s.soundpackSvc.RescanDir(dir)
		if err != nil {
			log.Printf("[rebuildSoundPackDB] 扫描目录 %s 失败: %v", dir, err)
			continue
		}
		log.Printf("[rebuildSoundPackDB] 目录 %s 完成，获取 %d 条记录", dir, len(records))
		totalScanned += len(records)
	}

	newStats, _ := s.soundpackSvc.GetSoundPackStats()
	newCount := 0
	if newStats != nil {
		newCount = newStats.TotalCount
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("重建完成：原 %d 条，现 %d 条", oldCount, newCount),
		"old_count":     oldCount,
		"new_count":     newCount,
		"scanned_count": totalScanned,
	})
}

// compactSoundPackDB 压缩数据库
// POST /api/db/soundpacks/compact
func (s *Server) compactSoundPackDB(c *gin.Context) {
	if err := s.db.Compact(); err != nil {
		respondInternalError(c, "压缩失败: "+err.Error())
		return
	}
	dbSize, _ := s.db.GetDBSize()
	respondSuccess(c, gin.H{
		"message": "压缩完成",
		"db_size": dbSize,
	})
}
