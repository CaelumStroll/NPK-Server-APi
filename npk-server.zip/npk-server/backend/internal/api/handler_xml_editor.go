package api

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"

	"npk-server/internal/database"

	"github.com/gin-gonic/gin"
)

// s.audioXmlPath 已移至 Server.s.audioXmlPath 字段

func (s *Server) InitAudioXml() {
	path := s.cfg.AudioXmlPath
	if path == "" {
		path = "audio.xml"
	}
	s.audioXmlPath = path

	// 检查数据库中是否已有数据
	_, total, _, _ := s.db.ListAudioXml("", "all", 1, 1)
	if total > 0 {
		log.Printf("[audioXml] 数据库已有 %d 条记录，跳过导入", total)
		return
	}

	// 从 XML 导入
	if _, err := os.Stat(path); os.IsNotExist(err) {
		log.Printf("[audioXml] 文件不存在: %s，使用空数据库", path)
		return
	}
	stats, err := s.db.ImportAudioXml(path)
	if err != nil {
		log.Printf("[audioXml] 导入失败: %v", err)
		return
	}
	log.Printf("[audioXml] 导入完成: %d EFFECT, %d RANDOM, %d GROUP, %d MUSIC, %d AMBIENT",
		stats.EffectCount, stats.RandomCount, stats.GroupCount, stats.MusicCount, stats.AmbientCount)
}

// ==================== Handlers ====================

func (s *Server) listXmlAudio(c *gin.Context) {
	query := strings.ToLower(c.Query("query"))
	typeFilter := c.Query("type")

	records, total, stats, err := s.db.ListAudioXml(query, typeFilter, 1, -1)
	if err != nil {
		respondInternalError(c, "查询失败: "+err.Error())
		return
	}
	if records == nil {
		records = []*database.AudioXmlRecord{}
	}

	respondSuccess(c, gin.H{
		"items": records,
		"total": total,
		"stats": gin.H{
			"effect_count":  stats.EffectCount,
			"random_count":  stats.RandomCount,
			"group_count":   stats.GroupCount,
			"music_count":   stats.MusicCount,
			"ambient_count": stats.AmbientCount,
		},
	})
}

func (s *Server) getXmlAudioEntry(c *gin.Context) {
	entryType := c.Param("type")
	entryID := c.Param("id")

	entry, err := s.db.GetAudioXmlEntry(entryType, entryID)
	if err != nil {
		for _, altType := range []string{"AMBIENT", "MUSIC", "EFFECT", "GROUP", "RANDOM"} {
			if altType == entryType {
				continue
			}
			entry, err = s.db.GetAudioXmlEntry(altType, entryID)
			if err == nil {
				break
			}
		}
	}
	if err != nil {
		respondNotFound(c, "条目不存在")
		return
	}

	// 如果是 GROUP，自动解析所有 ITEM 引用的文件
	if entry.Type == "GROUP" && len(entry.Items) > 0 {
		for i := range entry.Items {
			ref, refErr := s.db.GetAudioXmlEntry("", entry.Items[i].Tag)
			if refErr == nil && ref.File != "" {
				entry.Items[i].File = ref.File
			}
		}
	}

	respondSuccess(c, entry)
}

func (s *Server) saveXmlAudioEntry(c *gin.Context) {
	var entry database.AudioXmlRecord
	if err := c.ShouldBindJSON(&entry); err != nil || entry.ID == "" || entry.Type == "" {
		respondBadRequest(c, "数据不完整")
		return
	}
	if err := s.db.UpsertAudioXmlEntry(&entry); err != nil {
		respondInternalError(c, "保存失败: "+err.Error())
		return
	}
	respondSuccess(c, gin.H{"message": "保存成功"})
}

func (s *Server) deleteXmlAudioEntry(c *gin.Context) {
	if err := s.db.DeleteAudioXmlEntry(c.Param("type"), c.Param("id")); err != nil {
		respondNotFound(c, "删除失败: "+err.Error())
		return
	}
	respondSuccess(c, gin.H{"message": "已删除"})
}

func (s *Server) exportAudioXml(c *gin.Context) {
	if s.audioXmlPath == "" {
		respondBadRequest(c, "未打开 XML 文件")
		return
	}
	if err := s.db.ExportAudioXml(s.audioXmlPath); err != nil {
		respondInternalError(c, "导出失败: "+err.Error())
		return
	}
	respondSuccess(c, gin.H{"message": "已导出到 " + s.audioXmlPath})
}

func (s *Server) checkMissingXmlFiles(c *gin.Context) {
	records, _, _, err := s.db.ListAudioXml("", "all", 1, -1)
	if err != nil {
		respondInternalError(c, "查询失败: "+err.Error())
		return
	}

	// 收集需检查的文件（去重）
	fileList := make([]string, 0)
	fileIndex := make(map[string]bool)
	for _, r := range records {
		if r.File == "" || strings.TrimSpace(r.File) == "" {
			continue
		}
		if r.Type != "EFFECT" && r.Type != "MUSIC" && r.Type != "AMBIENT" {
			continue
		}
		fp := strings.ReplaceAll(r.File, "\\", "/")
		if !fileIndex[fp] {
			fileIndex[fp] = true
			fileList = append(fileList, fp)
		}
	}

	// 批量查数据库（所有文件一次性 SQL）
	musicFiles := s.db.FindAudioXmlFilesInMusic(fileList)
	soundpackFiles := s.db.FindAudioXmlFilesInSoundPack(fileList)

	// 磁盘检查（先查音乐/音效数据库命中则跳过）
	baseDir := filepath.Dir(s.audioXmlPath)
	missingSet := make(map[string]bool)
	for _, fp := range fileList {
		if musicFiles[fp] || soundpackFiles[fp] {
			continue
		}
		if _, err := os.Stat(filepath.Join(baseDir, fp)); err == nil {
			continue
		}
		if _, err := os.Stat(filepath.FromSlash(fp)); err == nil {
			continue
		}
		missingSet[fp] = true
	}

	// 组装结果
	var missing []map[string]string
	for _, r := range records {
		fp := strings.ReplaceAll(r.File, "\\", "/")
		if missingSet[fp] {
			missing = append(missing, map[string]string{"type": r.Type, "id": r.ID, "file": r.File})
		}
	}
	respondSuccess(c, gin.H{"missing": missing, "count": len(missing)})
}

func (s *Server) reloadAudioXml(c *gin.Context) {
	if s.audioXmlPath != "" {
		if _, err := s.db.ImportAudioXml(s.audioXmlPath); err != nil {
			respondInternalError(c, "重载失败: "+err.Error())
			return
		}
	}
	respondSuccess(c, gin.H{"message": "重新加载完成"})
}

// xmlFileExists 检查音频文件是否存在
func (s *Server) xmlFileExists(filePath string, fullCheck bool) bool {
	filePath = strings.ReplaceAll(filePath, "\\", "/")

	// 1. 拼接 audio.xml 所在目录
	baseDir := filepath.Dir(s.audioXmlPath)
	if _, err := os.Stat(filepath.Join(baseDir, filePath)); err == nil {
		return true
	}
	// 2. 直接路径
	if _, err := os.Stat(filepath.FromSlash(filePath)); err == nil {
		return true
	}
	if !fullCheck {
		return false
	}
	// 3. 数据库全量匹配
	if s.db.FindAudioXmlFileInMusic(filePath) {
		return true
	}
	if s.db.FindAudioXmlFileInSoundPack(filePath) {
		return true
	}
	return false
}

func (s *Server) streamXmlAudioFile(c *gin.Context) {
	filePath := c.Query("file")
	if filePath == "" {
		respondBadRequest(c, "缺少 file 参数")
		return
	}
	filePath = strings.ReplaceAll(filePath, "\\", "/")

	serveFile := func(absPath string) bool {
		if _, err := os.Stat(absPath); err == nil {
			serveAudioStream(c, absPath)
			return true
		}
		return false
	}

	baseDir := filepath.Dir(s.audioXmlPath)
	if serveFile(filepath.Join(baseDir, filePath)) {
		return
	}
	if serveFile(filepath.FromSlash(filePath)) {
		return
	}

	// 音乐数据库搜索
	if s.musicSvc != nil {
		baseName := filepath.Base(filePath)
		records, _, _ := s.musicSvc.ListMusic(baseName, 1, 50)
		for _, m := range records {
			if strings.EqualFold(m.Name, baseName) || strings.HasSuffix(strings.ReplaceAll(m.Path, "\\", "/"), filePath) {
				serveAudioStream(c, m.Path)
				return
			}
		}
	}

	// 音效包搜索（直接走索引查询）
	if s.soundpackSvc != nil {
		entry, _ := s.soundpackSvc.FindEntryByPath(filePath)
		if entry != nil {
			data, _, _, err := s.soundpackSvc.ReadSoundPackEntryData(entry.ID)
			if err == nil {
				c.Header("Content-Type", "audio/ogg")
				c.Header("Content-Length", fmt.Sprintf("%d", len(data)))
				c.Status(200)
				c.Writer.Write(data)
				return
			}
		}
	}

	respondNotFound(c, "音频文件未找到: "+filePath)
}

func (s *Server) openXmlFile(c *gin.Context) {
	var req struct{ Path string `json:"path"` }
	if err := c.ShouldBindJSON(&req); err != nil || req.Path == "" {
		respondBadRequest(c, "请提供 XML 文件路径")
		return
	}
	if _, err := os.Stat(req.Path); os.IsNotExist(err) {
		respondNotFound(c, "文件不存在: "+req.Path)
		return
	}

	// 导入到数据库（清空旧数据）
	stats, err := s.db.ImportAudioXml(req.Path)
	if err != nil {
		respondInternalError(c, "加载失败: "+err.Error())
		return
	}
	s.audioXmlPath = req.Path
	s.cfg.AudioXmlPath = req.Path
	s.cfg.Save()

	respondSuccess(c, gin.H{
		"message": "加载成功",
		"path":    req.Path,
		"stats": gin.H{
			"effect_count":  stats.EffectCount,
			"random_count":  stats.RandomCount,
			"group_count":   stats.GroupCount,
			"music_count":   stats.MusicCount,
			"ambient_count": stats.AmbientCount,
		},
	})
}

func (s *Server) listXmlFiles(c *gin.Context) {
	dir := c.Query("dir")
	if dir == "" {
		for _, md := range s.cfg.MusicDirs {
			if md != "" {
				parent := strings.TrimRight(md, "/\\")
				parent = strings.TrimSuffix(strings.TrimSuffix(parent, "/Music"), "\\Music")
				parent = strings.TrimSuffix(strings.TrimSuffix(parent, "/music"), "\\music")
				if parent != "" {
					dir = parent
					break
				}
			}
		}
		if dir == "" {
			dir = filepath.Dir(s.audioXmlPath)
		}
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		respondInternalError(c, "读取目录失败: "+err.Error())
		return
	}
	var files []map[string]interface{}
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		name := e.Name()
		if strings.HasSuffix(strings.ToLower(name), ".xml") {
			info, _ := e.Info()
			size := int64(0)
			if info != nil {
				size = info.Size()
			}
			files = append(files, map[string]interface{}{"name": name, "path": filepath.Join(dir, name), "size": size})
		}
	}
	respondSuccess(c, gin.H{"dir": dir, "files": files})
}
