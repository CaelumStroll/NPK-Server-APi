package api

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

// getSettings 获取应用设置
func (s *Server) getSettings(c *gin.Context) {
	// 获取缓存统计
	cacheStats := s.npkSvc.GetCacheStats()

	// 计算缓存使用百分比
	cacheMaxSizeBytes := int64(s.cfg.CacheMaxSize) * 1024 * 1024
	cacheUsedSize := int64(0)
	if cacheStats["size"] != nil {
		cacheUsedSize = int64(cacheStats["size"].(int))
	}
	cachePercent := 0.0
	if cacheMaxSizeBytes > 0 {
		cachePercent = float64(cacheUsedSize) * 100 / float64(cacheMaxSizeBytes)
	}

	// 缓存命中率
	cacheHitRate := 0.0
	if cacheStats["hit_rate"] != nil {
		cacheHitRate = cacheStats["hit_rate"].(float64)
	}

	respondSuccess(c, gin.H{
		"server_port":       s.cfg.ServerPort,
		"data_dir":          s.cfg.DataDir,
		"cache_dir":         s.cfg.CacheDir,
		"npk_dirs":          s.cfg.NpkDirs,
		"video_dirs":        s.cfg.VideoDirs,
		"music_dirs":        s.cfg.MusicDirs,
		"soundpack_dirs":    s.cfg.SoundPackDirs,
		"audio_xml_path":    s.cfg.AudioXmlPath,
		"auto_scan":         s.cfg.AutoScan,
		"thumbnail_size":    s.cfg.ThumbnailSize,
		"cache_max_size":    s.cfg.CacheMaxSize,
		"ws_stats_interval": s.cfg.WsStatsInterval,
		"enable_log_ws":     s.cfg.EnableLogWS,
		"language":              s.cfg.Language,
		"splash_avatar_image":  s.cfg.SplashAvatarImage,
		"splash_intro_text":    s.cfg.SplashIntroText,
		"dashboard_groups":     s.cfg.DashboardGroups,
		"dashboard_active_group": s.cfg.DashboardActiveGroup,
		// 缓存实际使用数据
		"cache_count":      cacheStats["count"],
		"cache_used_bytes": cacheUsedSize,
		"cache_used_mb":    float64(cacheUsedSize) / 1024 / 1024,
		"cache_percent":    cachePercent,
		"cache_hit_rate":   cacheHitRate,
		"cache_hits":       cacheStats["hits"],
		"cache_misses":     cacheStats["misses"],
	})
}

// updateSettings 更新应用设置
func (s *Server) updateSettings(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求")
		return
	}

	for key, value := range req {
		if key == "soundpack_dirs" || key == "music_dirs" {
			log.Printf("[updateSettings] %s = %v", key, value)
		}
		if err := s.cfg.Set(key, value); err != nil {
			respondInternalError(c, "设置失败: " + err.Error())
			return
		}
	}

	// 保存配置到文件
	if err := s.cfg.Save(); err != nil {
		respondInternalError(c, "保存配置失败: " + err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "设置已更新"})
}

// addNpkDir 添加 NPK 目录
func (s *Server) addNpkDir(c *gin.Context) {
	var req struct {
		Path string `json:"path" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少 path 参数")
		return
	}

	log.Printf("[addNpkDir] 请求添加: %s", req.Path)

	if _, err := os.Stat(req.Path); os.IsNotExist(err) {
		log.Printf("[addNpkDir] 目录不存在: %s", req.Path)
		respondBadRequest(c, "目录不存在: "+req.Path)
		return
	}

	for _, dir := range s.cfg.NpkDirs {
		if dir == req.Path {
			log.Printf("[addNpkDir] 目录已存在: %s", req.Path)
			respondBadRequest(c, "目录已存在")
			return
		}
	}

	if err := s.cfg.AddNpkDir(req.Path); err != nil {
		log.Printf("[addNpkDir] 添加失败: %v", err)
		respondInternalError(c, "添加失败: "+err.Error())
		return
	}

	log.Printf("[addNpkDir] 添加成功，当前目录数: %d", len(s.cfg.NpkDirs))
	// saveUnlocked 内部会自动调用 DerivePaths
	s.cfg.Save()
	respondSuccess(c, gin.H{
		"message":  "目录已添加",
		"npk_dirs": s.cfg.NpkDirs,
	})
}

// removeNpkDir 移除 NPK 目录
func (s *Server) removeNpkDir(c *gin.Context) {
	var req struct {
		Path string `json:"path" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少 path 参数")
		return
	}

	found := false
	for _, dir := range s.cfg.NpkDirs {
		if dir == req.Path {
			found = true
			break
		}
	}
	if !found {
		respondBadRequest(c, "目录不存在")
		return
	}

	if err := s.cfg.RemoveNpkDir(req.Path); err != nil {
		respondInternalError(c, "移除失败: "+err.Error())
		return
	}
	respondSuccess(c, gin.H{"message": "目录已移除"})
}

// listAvatars 获取头像列表
func (s *Server) listAvatars(c *gin.Context) {
	avatarsDir := filepath.Join(execDir, "avatars")

	if _, err := os.Stat(avatarsDir); os.IsNotExist(err) {
		respondSuccess(c, []string{})
		return
	}

	files, err := os.ReadDir(avatarsDir)
	if err != nil {
		respondInternalError(c, "读取目录失败")
		return
	}

	avatars := make([]string, 0)
	for _, f := range files {
		if !f.IsDir() {
			ext := strings.ToLower(filepath.Ext(f.Name()))
			if ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".gif" || ext == ".webp" {
				avatars = append(avatars, "/avatars/"+f.Name())
			}
		}
	}

	respondSuccess(c, avatars)
}

// uploadAvatar 上传自定义头像到 avatars 目录
// POST /api/avatars/upload
func (s *Server) uploadAvatar(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		respondBadRequest(c, "请选择图片文件")
		return
	}

	ext := strings.ToLower(filepath.Ext(file.Filename))
	if ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".gif" {
		respondBadRequest(c, "仅支持 JPG/PNG/GIF 格式")
		return
	}

	avatarsDir := filepath.Join(execDir, "avatars")
	if err := os.MkdirAll(avatarsDir, 0755); err != nil {
		respondInternalError(c, "创建目录失败")
		return
	}

	// 生成唯一文件名
	timestamp := time.Now().UnixMilli()
	filename := fmt.Sprintf("avatar_%d%s", timestamp, ext)
	destPath := filepath.Join(avatarsDir, filename)

	if err := c.SaveUploadedFile(file, destPath); err != nil {
		respondInternalError(c, "保存文件失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":  "上传成功",
		"filename": filename,
		"url":      "/avatars/" + filename,
	})
}

// listRoutes 获取所有 API 路由（调试用）
func (s *Server) listRoutes(c *gin.Context) {
	routes := s.router.Routes()
	result := make([]map[string]string, 0, len(routes))
	for _, r := range routes {
		result = append(result, map[string]string{
			"method": r.Method,
			"path":   r.Path,
		})
	}
	respondSuccess(c, result)
}