package api

import (
	"net/http"
	"regexp"

	"github.com/gin-gonic/gin"
)

var (
	npkNamePattern   = regexp.MustCompile(`^[\w.-]+$`)
	albumPathPattern = regexp.MustCompile(`^[\w./\\-]+$`)
)

func sendError(c *gin.Context, code int, message string) {
	respondError(c, code, message)
	c.Abort()
}

func validateRequiredParam(c *gin.Context, name, value string) bool {
	if value == "" {
		sendError(c, http.StatusBadRequest, "缺少必填参数: "+name)
		return false
	}
	return true
}

func validateNpkName(c *gin.Context, name string) bool {
	if !npkNamePattern.MatchString(name) {
		sendError(c, http.StatusBadRequest, "无效的 NPK 文件名")
		return false
	}
	return true
}

func validateAlbumPath(c *gin.Context, path string) bool {
	if !albumPathPattern.MatchString(path) {
		sendError(c, http.StatusBadRequest, "无效的 Album 路径")
		return false
	}
	return true
}

func validateIndex(c *gin.Context, index int) bool {
	if index < 0 {
		sendError(c, http.StatusBadRequest, "索引必须大于等于 0")
		return false
	}
	return true
}

func ValidateNpkAndAlbum() gin.HandlerFunc {
	return func(c *gin.Context) {
		name := decodePathParam(c, "name")
		if !validateRequiredParam(c, "name", name) {
			return
		}
		if !validateNpkName(c, name) {
			return
		}

		albumPath := c.Query("album")
		if albumPath != "" && !validateAlbumPath(c, albumPath) {
			return
		}

		c.Next()
	}
}

func ValidateNpkOnly() gin.HandlerFunc {
	return func(c *gin.Context) {
		name := decodePathParam(c, "name")
		if !validateRequiredParam(c, "name", name) {
			return
		}
		if !validateNpkName(c, name) {
			return
		}
		c.Next()
	}
}

func ValidateAlbumPreview() gin.HandlerFunc {
	return func(c *gin.Context) {
		name := c.Query("npk")
		if !validateRequiredParam(c, "npk", name) {
			return
		}
		if !validateNpkName(c, name) {
			return
		}

		albumPath := c.Query("album")
		if !validateRequiredParam(c, "album", albumPath) {
			return
		}
		if !validateAlbumPath(c, albumPath) {
			return
		}

		c.Next()
	}
}