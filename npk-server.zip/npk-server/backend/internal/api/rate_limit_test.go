package api

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
)

func setupTestRouter(rl *RateLimiter) *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(rl.Limit())
	r.GET("/test", func(c *gin.Context) {
		c.String(http.StatusOK, "ok")
	})
	return r
}

func TestRateLimiterBlocksExcess(t *testing.T) {
	rl := NewRateLimiter(10, time.Minute)
	router := setupTestRouter(rl)

	allowed := 0
	blocked := 0

	for i := 0; i < 15; i++ {
		req, _ := http.NewRequest("GET", "/test", nil)
		req.RemoteAddr = "192.168.1.1:12345"
		w := httptest.NewRecorder()
		router.ServeHTTP(w, req)

		if w.Code == http.StatusOK {
			allowed++
		} else if w.Code == http.StatusTooManyRequests {
			blocked++
		}
	}

	if allowed != 10 {
		t.Errorf("allowed %d requests, want 10", allowed)
	}
	if blocked != 5 {
		t.Errorf("blocked %d requests, want 5", blocked)
	}
}

func TestRateLimiterSeparateIPs(t *testing.T) {
	rl := NewRateLimiter(5, time.Minute)
	router := setupTestRouter(rl)

	for _, ip := range []string{"10.0.0.1:1", "10.0.0.2:2", "10.0.0.3:3"} {
		for i := 0; i < 6; i++ {
			req, _ := http.NewRequest("GET", "/test", nil)
			req.RemoteAddr = ip
			w := httptest.NewRecorder()
			router.ServeHTTP(w, req)
			if i < 5 && w.Code != http.StatusOK {
				t.Errorf("IP %s request %d: expected 200, got %d", ip, i, w.Code)
			}
			if i == 5 && w.Code != http.StatusTooManyRequests {
				t.Errorf("IP %s request %d: expected 429, got %d", ip, i, w.Code)
			}
		}
	}
}

func TestRateLimiterCleanup(t *testing.T) {
	rl := NewRateLimiter(10, time.Millisecond)

	bucket := rl.getBucket("test_ip")
	rl.mu.Lock()
	originalCount := len(rl.buckets)
	bucket.lastRefill = time.Now().Add(-10 * time.Minute)
	rl.mu.Unlock()

	if originalCount == 0 {
		t.Fatal("bucket should exist")
	}

	rl.CleanupExpiredBuckets()

	rl.mu.Lock()
	afterLen := len(rl.buckets)
	rl.mu.Unlock()

	if afterLen != 0 {
		t.Errorf("buckets count = %d, want 0 after cleanup", afterLen)
	}
}
