package api

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"image"
	"image/draw"
	"image/png"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"

	"npk-server/internal/npk"
)

// compatHealth 健康检查
func (s *Server) compatHealth(c *gin.Context) {
	respondSuccess(c, gin.H{
		"message":   "OK",
		"timestamp": time.Now().Format("2006-01-02T15:04:05"),
	})
}

// compatListNpks 获取 NPK 列表（兼容 API）
func (s *Server) compatListNpks(c *gin.Context) {
	dbFiles, err := s.db.ListNpkFiles()
	if err != nil {
		respondInternalError(c, "查询数据库失败: "+err.Error())
		return
	}

	list := make([]map[string]interface{}, 0, len(dbFiles))
	for _, f := range dbFiles {
		list = append(list, map[string]interface{}{
			"id":          f.ID,
			"name":        f.Name,
			"path":        f.Path,
			"file_size":   f.Size,
			"modified_at": f.ModifiedAt.Format(time.RFC3339),
			"is_indexed":  1,
		})
	}

	respondSuccess(c, gin.H{"total": len(list), "list": list})
}

// compatListImgs 获取 IMG 列表（兼容 API）
func (s *Server) compatListImgs(c *gin.Context) {
	npkId, err := strconv.Atoi(c.Param("npkId"))
	if err != nil {
		respondBadRequest(c, "无效的 npkId，必须为数字")
		return
	}

	npkName, err := s.findNpkNameById(npkId)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	info, err := s.npkSvc.GetNpkInfo(npkName)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	dbAlbums, _ := s.db.GetAlbumsByNpkID(int64(npkId))
	albumIdMap := make(map[string]int64)
	for _, a := range dbAlbums {
		albumIdMap[a.Path] = a.ID
	}

	list := make([]map[string]interface{}, 0, len(info.Albums))
	for _, album := range info.Albums {
		albumDBId := albumIdMap[album.Path]
		name := album.Path
		if idx := strings.LastIndex(album.Path, "/"); idx >= 0 {
			name = album.Path[idx+1:]
		}
		versionStr := ""
		if album.Version > 0 {
			versionStr = fmt.Sprintf("V%d", album.Version)
		}

		list = append(list, map[string]interface{}{
			"id":           albumDBId,
			"path":         album.Path,
			"name":         name,
			"sprite_count": album.SpriteCount,
			"version":      versionStr,
		})
	}

	respondSuccess(c, gin.H{"npk_id": npkId, "npk_name": npkName, "total": len(list), "list": list})
}

// compatListFramesByQuery 获取帧列表（兼容 API）
func (s *Server) compatListFramesByQuery(c *gin.Context) {
	npkId, err := strconv.Atoi(c.Param("npkId"))
	if err != nil {
		respondBadRequest(c, "无效的 npkId，必须为数字")
		return
	}

	imgPath := c.Query("imgPath")
	if imgPath == "" {
		respondBadRequest(c, "缺少 imgPath 参数")
		return
	}

	npkName, err := s.findNpkNameById(npkId)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	album, err := s.npkSvc.GetAlbum(npkName, imgPath)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	frames := make([]map[string]interface{}, 0, len(album.Sprites))
	for _, sp := range album.Sprites {
		frameInfo := map[string]interface{}{
			"index":        sp.Index,
			"x":            sp.X,
			"y":            sp.Y,
			"width":        sp.Width,
			"height":       sp.Height,
			"frame_width":  sp.FrameWidth,
			"frame_height": sp.FrameHeight,
			"type":         int(sp.Type),
			"type_name":    sp.Type.String(),
			"compress":     int(sp.CompressMode),
		}
		if album.Version == 5 && album.TextureInfos != nil {
			if texInfo, ok := album.TextureInfos[sp.Index]; ok && texInfo.Texture != nil {
				frameInfo["texture_rect"] = map[string]int{
					"lu_x": texInfo.LeftUp.X,
					"lu_y": texInfo.LeftUp.Y,
					"rd_x": texInfo.RightDown.X,
					"rd_y": texInfo.RightDown.Y,
				}
			}
		}
		frames = append(frames, frameInfo)
	}

	respondSuccess(c, gin.H{
		"npk_id":        npkId,
		"npk_name":      npkName,
		"img_name":      imgPath,
		"version":       int(album.Version),
		"frame_count":   len(frames),
		"frames":        frames,
	})
}

// compatFrameByPath 通过路径获取帧图片（兼容 API）
func (s *Server) compatFrameByPath(c *gin.Context) {
	imgPath := c.Query("imgPath")
	if imgPath == "" {
		respondBadRequest(c, "缺少 imgPath 参数")
		return
	}

	index := getQueryInt(c, "index", 0)
	npkName := c.Query("npk")

	var err error
	var data []byte
	if npkName != "" {
		data, err = s.npkSvc.GetSpriteImage(npkName, imgPath, index, 0, 0, false)
	} else {
		npkName, albumPath, resolveErr := s.resolveNpkAlbum(imgPath)
		if resolveErr != nil {
			log.Printf("[compatFrameByPath] 解析路径失败: imgPath=%s, err=%v", imgPath, resolveErr)
			respondNotFound(c, resolveErr.Error())
			return
		}
		data, err = s.npkSvc.GetSpriteImage(npkName, albumPath, index, 0, 0, false)
	}
	if err != nil {
		log.Printf("[compatFrameByPath] 获取帧图片失败: imgPath=%s, index=%d, err=%v", imgPath, index, err)
		respondInternalError(c, err.Error())
		return
	}

	c.Data(http.StatusOK, "image/png", data)
}

// compatFramesBatch 批量获取帧图片（兼容 API）
func (s *Server) compatFramesBatch(c *gin.Context) {
	var req struct {
		Items []struct {
			ImgPath    string `json:"imgPath"`
			FrameIndex int    `json:"frameIndex"`
		} `json:"items"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if len(req.Items) == 0 {
		respondSuccess(c, gin.H{"total": 0, "unique": 0, "images": []interface{}{}})
		return
	}

	type itemKey struct {
		ImgPath    string
		FrameIndex int
	}
	seen := make(map[itemKey]bool)
	uniqueItems := make([]struct {
		ImgPath    string
		FrameIndex int
	}, 0)

	for _, item := range req.Items {
		key := itemKey{item.ImgPath, item.FrameIndex}
		if !seen[key] {
			seen[key] = true
			uniqueItems = append(uniqueItems, struct {
				ImgPath    string
				FrameIndex int
			}{item.ImgPath, item.FrameIndex})
		}
	}

	images := make([]map[string]interface{}, 0, len(uniqueItems))
	for _, item := range uniqueItems {
		npkName, albumPath, err := s.resolveNpkAlbum(item.ImgPath)
		if err != nil { continue }

		sprite, _, err := s.npkSvc.GetSprite(npkName, albumPath, item.FrameIndex)
		if err != nil { continue }

		data, err := s.npkSvc.GetSpriteImage(npkName, albumPath, item.FrameIndex, 0, 0, false)
		if err != nil { continue }

		key := fmt.Sprintf("%s_%d", item.ImgPath, item.FrameIndex)
		images = append(images, map[string]interface{}{
			"Key":        key,
			"ImgPath":    item.ImgPath,
			"FrameIndex": item.FrameIndex,
			"Width":      sprite.Width,
			"Height":     sprite.Height,
			"OffsetX":    sprite.X,
			"OffsetY":    sprite.Y,
			"Data":       "data:image/png;base64," + base64.StdEncoding.EncodeToString(data),
		})
	}

	respondSuccess(c, gin.H{"total": len(req.Items), "unique": len(uniqueItems), "images": images})
}

// compatAlbumBatch 批量获取 Album 帧（高效版本）
func (s *Server) compatAlbumBatch(c *gin.Context) {
	var req struct {
		Items []struct {
			ImgPath      string `json:"imgPath"`
			FrameIndices []int  `json:"frameIndices"`
			NpkName      string `json:"npkName"`
		} `json:"items"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if len(req.Items) == 0 {
		respondSuccess(c, gin.H{"total": 0, "images": []interface{}{}})
		return
	}

	cacheKey := generateRequestCacheKey(req.Items)

	s.batchCacheMutex.RLock()
	if cached, ok := s.batchCache[cacheKey]; ok {
		if time.Since(cached.CreatedAt) < 5*time.Minute {
			s.batchCacheMutex.RUnlock()
			c.DataFromReader(http.StatusOK, int64(len(cached.Result)), "application/json", bytes.NewReader(cached.Result), nil)
			return
		}
	}
	s.batchCacheMutex.RUnlock()

	type albumCache struct {
		NpkName   string
		AlbumPath string
		Album     *npk.Album
	}
	albumCacheMap := make(map[string]*albumCache)

	images := make([]map[string]interface{}, 0)

	for _, item := range req.Items {
		ac, ok := albumCacheMap[item.ImgPath]
		if !ok {
			var npkName, albumPath string
			var err error

			if item.NpkName != "" {
				npkName = item.NpkName
				albumPath = item.ImgPath
			} else {
				npkName, albumPath, err = s.resolveNpkAlbum(item.ImgPath)
				if err != nil {
					continue
				}
			}

			album, err := s.npkSvc.GetAlbum(npkName, albumPath)
			if err != nil {
				continue
			}

			ac = &albumCache{NpkName: npkName, AlbumPath: albumPath, Album: album}
			albumCacheMap[item.ImgPath] = ac
		}

		for _, frameIndex := range item.FrameIndices {
			if frameIndex < 0 || frameIndex >= len(ac.Album.Sprites) {
				continue
			}

			data, err := s.npkSvc.GetSpriteImage(ac.NpkName, ac.AlbumPath, frameIndex, 0, 0, false)
			if err != nil {
				continue
			}

			sp := ac.Album.Sprites[frameIndex]
			images = append(images, map[string]interface{}{
				"Key":        fmt.Sprintf("%s_%d", item.ImgPath, frameIndex),
				"ImgPath":    item.ImgPath,
				"FrameIndex": frameIndex,
				"Width":      sp.Width,
				"Height":     sp.Height,
				"OffsetX":    sp.X,
				"OffsetY":    sp.Y,
				"Data":       "data:image/png;base64," + base64.StdEncoding.EncodeToString(data),
			})
		}
	}

	result := Response{Code: int(CodeSuccess), Message: "success", Data: gin.H{"total": len(req.Items), "images": images}}
	resultBytes, _ := json.Marshal(result)

	s.batchCacheMutex.Lock()
	s.batchCache[cacheKey] = &BatchCacheEntry{Result: resultBytes, CreatedAt: time.Now()}
	s.batchCacheMutex.Unlock()

	c.Data(http.StatusOK, "application/json", resultBytes)
}

// compatOverlay 图层叠加（兼容 API）
func (s *Server) compatOverlay(c *gin.Context) {
	var req struct {
		Items []struct {
			ImgPath    string `json:"imgPath"`
			FrameIndex int    `json:"frameIndex"`
			X          int    `json:"x"`
			Y          int    `json:"y"`
		} `json:"items"`
		Width  int `json:"width"`
		Height int `json:"height"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	canvas := image.NewRGBA(image.Rect(0, 0, req.Width, req.Height))

	for _, item := range req.Items {
		npkName, albumPath, err := s.resolveNpkAlbum(item.ImgPath)
		if err != nil { continue }

		data, err := s.npkSvc.GetSpriteImage(npkName, albumPath, item.FrameIndex, 0, 0, false)
		if err != nil { continue }

		img, err := png.Decode(bytes.NewReader(data))
		if err != nil { continue }

		draw.Draw(canvas, image.Rect(item.X, item.Y, item.X+img.Bounds().Dx(), item.Y+img.Bounds().Dy()), img, image.Point{}, draw.Over)
	}

	var buf bytes.Buffer
	png.Encode(&buf, canvas)
	c.Data(http.StatusOK, "image/png", buf.Bytes())
}

// 辅助函数

func generateRequestCacheKey(items interface{}) string {
	data, _ := json.Marshal(items)
	return fmt.Sprintf("%x", sha256.Sum256(data))
}

func (s *Server) findNpkNameById(npkId int) (string, error) {
	record, err := s.db.GetNpkFile(int64(npkId))
	if err != nil {
		return "", fmt.Errorf("NPK 不存在: ID=%d", npkId)
	}
	return record.Name, nil
}

// resolveNpkAlbum 解析 imgPath 为 (npkName, albumPath)
type npkAlbumEntry struct{ Npk, Album string }
var npkAlbumCache sync.Map

func (s *Server) resolveNpkAlbum(imgPath string) (string, string, error) {
	// 统一路径分隔符
	imgPath = strings.ReplaceAll(imgPath, "\\", "/")

	if cached, ok := npkAlbumCache.Load(imgPath); ok {
		entry := cached.(npkAlbumEntry)
		return entry.Npk, entry.Album, nil
	}

	npkName, albumPath, resolveErr := s.resolveImgPath(imgPath)
	if resolveErr == nil {
		if _, err := s.npkSvc.GetAlbum(npkName, albumPath); err == nil {
			npkAlbumCache.Store(imgPath, npkAlbumEntry{npkName, albumPath})
			return npkName, albumPath, nil
		}
	}

	searchPath := imgPath
	for {
		// 1. 优先数据库索引查询（毫秒级）
		npkRecord, albumRecord, err := s.db.FindAlbumByPath(searchPath)
		if err == nil && npkRecord != nil {
			realAlbumPath := albumRecord.Path
			if realAlbumPath == "" { realAlbumPath = searchPath }
			npkAlbumCache.Store(imgPath, npkAlbumEntry{npkRecord.Name, realAlbumPath})
			return npkRecord.Name, realAlbumPath, nil
		}
		// 2. 回退：遍历内存 NPK 列表
		for _, info := range s.npkSvc.ListNpkFiles() {
			if _, err := s.npkSvc.GetAlbum(info.Name, searchPath); err == nil {
				npkAlbumCache.Store(imgPath, npkAlbumEntry{info.Name, searchPath})
				return info.Name, searchPath, nil
			}
		}

		slashIdx := strings.Index(searchPath, "/")
		if slashIdx < 0 { break }
		searchPath = searchPath[slashIdx+1:]
		if searchPath == "" { break }
	}

	if resolveErr != nil {
		log.Printf("[resolveNpkAlbum] 失败: imgPath=%s err=%v", imgPath, resolveErr)
		return "", "", resolveErr
	}
	log.Printf("[resolveNpkAlbum] 失败: imgPath=%s", imgPath)
	return npkName, albumPath, fmt.Errorf("album 未找到: %s", imgPath)
}

func (s *Server) resolveImgPath(imgPath string) (string, string, error) {
	parts := strings.SplitN(imgPath, "/", 2)
	if len(parts) < 2 {
		return "", "", fmt.Errorf("无效的 imgPath 格式: %s", imgPath)
	}
	npkName := parts[0]
	albumPath := parts[1]
	return npkName, albumPath, nil
}