package api

import (
	"encoding/base64"
	"fmt"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// getAnimationInfo 获取动画信息
func (s *Server) getAnimationInfo(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")

	anim, err := s.npkSvc.GetAnimation(name, albumPath)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	frames := make([]map[string]interface{}, len(anim.Frames))
	for i, f := range anim.Frames {
		frames[i] = map[string]interface{}{
			"index":  f.Sprite.Index,
			"delay":  f.Delay,
			"width":  f.Image.Width,
			"height": f.Image.Height,
			"x":      f.OffsetX,
			"y":      f.OffsetY,
		}
	}

	respondSuccess(c, gin.H{
		"name":        anim.Name,
		"width":       anim.Width,
		"height":      anim.Height,
		"frame_count": len(anim.Frames),
		"frames":      frames,
	})
}

// getAnimationFrame 获取动画帧图像
func (s *Server) getAnimationFrame(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	frameIndex, _ := strconv.Atoi(c.Param("fid"))

	data, err := s.npkSvc.GetAnimationFrame(name, albumPath, frameIndex)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Data(http.StatusOK, "image/png", data)
}

// previewAnimationFrames 预览动画帧
func (s *Server) previewAnimationFrames(c *gin.Context) {
	var req struct {
		Indices []int `json:"indices"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求")
		return
	}

	name := decodePathParam(c, "name")
	albumPath := c.Query("album")

	frames := make([]map[string]interface{}, len(req.Indices))
	for i, idx := range req.Indices {
		data, err := s.npkSvc.GetAnimationFrame(name, albumPath, idx)
		if err != nil {
			continue
		}
		frames[i] = map[string]interface{}{
			"index": idx,
			"image": "data:image/png;base64," + base64.StdEncoding.EncodeToString(data),
		}
	}

	respondSuccess(c, frames)
}

// exportGIF 导出 GIF
func (s *Server) exportGIF(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	fps, _ := strconv.Atoi(c.DefaultQuery("fps", "12"))
	framesParam := c.Query("frames")
	removeBlack := c.Query("removeBlack") == "true"

	var frameIndices []int
	if framesParam != "" {
		for _, s := range strings.Split(framesParam, ",") {
			if idx, err := strconv.Atoi(strings.TrimSpace(s)); err == nil {
				frameIndices = append(frameIndices, idx)
			}
		}
	}

	data, err := s.npkSvc.ExportGIFWithFrames(name, albumPath, fps, frameIndices, removeBlack)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=%s.gif", filepath.Base(albumPath)))
	c.Data(http.StatusOK, "image/gif", data)
}