package api

import (
	"fmt"
	"io"
	"log"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"

	"npk-server/internal/service"
)

// renameAlbum 重命名 Album 路径
func (s *Server) renameAlbum(c *gin.Context) {
	name := decodePathParam(c, "name")

	var req struct {
		OldPath string `json:"old_path" binding:"required"`
		NewPath string `json:"new_path" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if err := s.npkSvc.RenameAlbum(name, req.OldPath, req.NewPath); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "重命名成功"})
}

// setAlbumTarget 设置 Album 引用目标
func (s *Server) setAlbumTarget(c *gin.Context) {
	name := decodePathParam(c, "name")

	var req struct {
		AlbumPath  string `json:"album_path" binding:"required"`
		TargetPath string `json:"target_path" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if req.AlbumPath == req.TargetPath {
		respondBadRequest(c, "不能引用自己")
		return
	}

	if err := s.npkSvc.SetAlbumTarget(name, req.AlbumPath, req.TargetPath); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "设置引用成功"})
}

// clearAlbumTarget 清除 Album 引用
func (s *Server) clearAlbumTarget(c *gin.Context) {
	name := decodePathParam(c, "name")

	var req struct {
		AlbumPath string `json:"album_path" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if err := s.npkSvc.ClearAlbumTarget(name, req.AlbumPath); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "清除引用成功"})
}

// exportAlbumCoords 导出 Album 的基准坐标
func (s *Server) exportAlbumCoords(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")

	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}

	coords, err := s.npkSvc.ExportAlbumCoords(name, albumPath)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	var sb strings.Builder
	for _, coord := range coords {
		sb.WriteString(fmt.Sprintf("%d,%d\n", coord.X, coord.Y))
	}

	c.Header("Content-Type", "text/plain; charset=utf-8")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=coords_%s.txt", filepath.Base(albumPath)))
	c.String(http.StatusOK, sb.String())
}

// importAlbumCoords 导入基准坐标
func (s *Server) importAlbumCoords(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.PostForm("album")

	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}

	file, err := c.FormFile("file")
	if err != nil {
		respondBadRequest(c, "请上传文件")
		return
	}

	src, err := file.Open()
	if err != nil {
		respondInternalError(c, "打开文件失败")
		return
	}
	defer src.Close()

	data, err := io.ReadAll(src)
	if err != nil {
		respondInternalError(c, "读取文件失败")
		return
	}

	updated, err := s.npkSvc.ImportAlbumCoords(name, albumPath, data)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": fmt.Sprintf("成功更新 %d 个坐标", updated)})
}

// compareAlbum 对比两个 Album
func (s *Server) compareAlbum(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath1 := c.Query("album1")
	albumPath2 := c.Query("album2")

	if albumPath1 == "" || albumPath2 == "" {
		respondBadRequest(c, "缺少 album1 或 album2 参数")
		return
	}

	added, deleted, modified, err := s.npkSvc.CompareAlbum(name, albumPath1, albumPath2)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"added": added, "deleted": deleted, "modified": modified})
}

// importImg 导入外部 IMG 文件
func (s *Server) importImg(c *gin.Context) {
	name := decodePathParam(c, "name")
	targetPath := c.PostForm("path")
	replaceStr := c.PostForm("replace")
	replace := replaceStr == "true" || replaceStr == "1"

	if targetPath == "" {
		respondBadRequest(c, "缺少 path 参数")
		return
	}

	file, fileHeader, err := c.Request.FormFile("file")
	if err != nil {
		respondBadRequest(c, "缺少文件: "+err.Error())
		return
	}
	defer file.Close()

	ext := strings.ToLower(filepath.Ext(fileHeader.Filename))
	if ext != ".img" {
		respondBadRequest(c, "只支持 .img 文件")
		return
	}

	if fileHeader.Size > maxFileUploadSize {
		respondBadRequest(c, "文件大小不能超过 10MB")
		return
	}

	imgData, err := io.ReadAll(file)
	if err != nil {
		respondInternalError(c, "读取文件失败: "+err.Error())
		return
	}

	if err := s.npkSvc.ImportImg(name, imgData, targetPath, replace); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "导入成功"})
}

// batchReplaceFromFolder 批量替换帧（从文件夹）
func (s *Server) batchReplaceFromFolder(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.PostForm("album")
	colorFormat := c.PostForm("color_format")
	autoResize := c.PostForm("auto_resize") == "true"
	startIndexStr := c.PostForm("start_index")

	startIndex := 0
	if startIndexStr != "" {
		if parsed, err := strconv.Atoi(startIndexStr); err == nil {
			startIndex = parsed
		}
	}

	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}

	form, err := c.MultipartForm()
	if err != nil {
		respondBadRequest(c, "解析表单失败: "+err.Error())
		return
	}

	files := form.File["files"]
	if len(files) == 0 {
		respondBadRequest(c, "没有上传文件")
		return
	}

	fileData := make(map[string][]byte)
	for _, file := range files {
		if err := validateUploadedFile(file); err != nil {
			continue
		}

		f, err := file.Open()
		if err != nil {
			continue
		}
		data, err := io.ReadAll(f)
		f.Close()
		if err != nil {
			continue
		}
		fileData[file.Filename] = data
	}

	if len(fileData) == 0 {
		respondBadRequest(c, "没有有效的文件被上传")
		return
	}

	replaced, imported, err := s.npkSvc.BatchReplaceFromFolder(name, albumPath, fileData, colorFormat, startIndex, autoResize)
	if err != nil {
		log.Printf("批量替换失败: %v", err)
		respondInternalError(c, sanitizeErrorMessage(err))
		return
	}

	message := fmt.Sprintf("替换 %d 个帧", replaced)
	if imported > 0 {
		message += fmt.Sprintf("，新增 %d 个帧", imported)
	}

	respondSuccess(c, gin.H{"message": message, "replaced": replaced, "imported": imported, "total": len(files)})
}

// batchImportSprites 批量导入帧
func (s *Server) batchImportSprites(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.PostForm("album")
	position := c.PostForm("position")
	replaceLinks := c.PostForm("replace_links") == "true"

	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}

	if position == "" {
		position = "end"
	}

	currentIndex := 0
	if idxStr := c.PostForm("current_index"); idxStr != "" {
		var err error
		currentIndex, err = strconv.Atoi(idxStr)
		if err != nil {
			currentIndex = 0
		}
	}

	colorFormat := c.PostForm("color_format")

	form, err := c.MultipartForm()
	if err != nil {
		respondBadRequest(c, "解析表单失败: "+err.Error())
		return
	}

	files := form.File["files"]
	if len(files) == 0 {
		respondBadRequest(c, "没有上传文件")
		return
	}

	fileData := make(map[string][]byte)
	for _, file := range files {
		if err := validateUploadedFile(file); err != nil {
			continue
		}

		f, err := file.Open()
		if err != nil {
			continue
		}
		data, err := io.ReadAll(f)
		f.Close()
		if err != nil {
			continue
		}
		fileData[file.Filename] = data
	}

	if len(fileData) == 0 {
		respondBadRequest(c, "没有有效的文件被上传")
		return
	}

	count, err := s.npkSvc.BatchImportSprites(name, albumPath, service.BatchImportPosition(position), currentIndex, replaceLinks, colorFormat, fileData)
	if err != nil {
		log.Printf("批量导入失败: %v", err)
		respondInternalError(c, sanitizeErrorMessage(err))
		return
	}

	respondSuccess(c, gin.H{
		"message":  fmt.Sprintf("成功导入 %d 个帧", count),
		"imported": count,
		"total":    len(files),
	})
}

// deleteAlbum 删除整个 Album (IMG)
func (s *Server) deleteAlbum(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("path")

	if albumPath == "" {
		respondBadRequest(c, "缺少 path 参数")
		return
	}

	if err := s.npkSvc.DeleteAlbum(name, albumPath); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "删除成功"})
}