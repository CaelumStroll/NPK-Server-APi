package api

import (
	"fmt"
	"log"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"npk-server/internal/service"
)

// getDBStats 获取数据库统计信息
func (s *Server) getDBStats(c *gin.Context) {
	stats, err := s.db.GetStats()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	dbSize, _ := s.db.GetDBSize()

	respondSuccess(c, gin.H{
		"npk_count":    stats.NpkCount,
		"album_count":  stats.AlbumCount,
		"sprite_count": stats.SpriteCount,
		"total_size":   stats.TotalSize,
		"db_size":      dbSize,
	})
}

// getDBTables 获取数据库表统计
func (s *Server) getDBTables(c *gin.Context) {
	tableStats, err := s.db.GetTableStats()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}
	respondSuccess(c, tableStats)
}

// cleanupDB 清理数据库中的无效记录
func (s *Server) cleanupDB(c *gin.Context) {
	deletedNpks, deletedAlbums, deletedSprites, err := s.db.Cleanup()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	msg := fmt.Sprintf("清理完成：删除 %d 个无效 NPK，清理 %d 个无效 Album，清理 %d 个无效 Sprite",
		deletedNpks, deletedAlbums, deletedSprites)

	respondSuccess(c, gin.H{
		"message":       msg,
		"deleted_npks":  deletedNpks,
		"deleted_albums": deletedAlbums,
		"deleted_sprites": deletedSprites,
	})
}

// compactDB 压缩数据库
func (s *Server) compactDB(c *gin.Context) {
	if err := s.db.Compact(); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	dbSize, _ := s.db.GetDBSize()
	respondSuccess(c, gin.H{"db_size": dbSize})
}

// incrementalUpdate 增量更新数据库
func (s *Server) incrementalUpdate(c *gin.Context) {
	totalResult := &service.IncrementalResult{}

	for _, dir := range s.cfg.NpkDirs {
		result, err := s.npkSvc.ScanDirectoryIncremental(dir)
		if err != nil {
			log.Printf("增量更新目录失败 %s: %v", dir, err)
			continue
		}
		totalResult.TotalNpks += result.TotalNpks
		totalResult.ScannedNpks += result.ScannedNpks
		totalResult.SkippedNpks += result.SkippedNpks
		totalResult.NpkChanged += result.NpkChanged
		totalResult.AlbumsChanged += result.AlbumsChanged
		totalResult.NewNpks += result.NewNpks
		totalResult.DeletedNpks += result.DeletedNpks
	}

	msg := fmt.Sprintf("增量更新完成：扫描 %d 个 NPK，跳过 %d 个未变更，%d 个 NPK 变更，%d 个 Album 变更，新增 %d 个，删除 %d 个",
		totalResult.ScannedNpks, totalResult.SkippedNpks,
		totalResult.NpkChanged, totalResult.AlbumsChanged,
		totalResult.NewNpks, totalResult.DeletedNpks)

	respondSuccess(c, gin.H{"message": msg, "data": totalResult})
}

// exportDB 导出数据库为 JSON
func (s *Server) exportDB(c *gin.Context) {
	data, err := s.db.ExportAllJSON()
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Header("Content-Disposition", "attachment; filename=npk-database-export.json")
	c.Data(http.StatusOK, "application/json", data)
}

// rebuildDB 重建数据库
func (s *Server) rebuildDB(c *gin.Context) {
	if err := s.db.ClearAll(); err != nil {
		respondInternalError(c, "清空数据库失败: " + err.Error())
		return
	}

	s.npkSvc.ClearCache()

	scannedDirs := 0
	for _, dir := range s.cfg.NpkDirs {
		if err := s.npkSvc.ScanDirectory(dir, nil); err != nil {
			log.Printf("扫描目录失败 %s: %v", dir, err)
		} else {
			scannedDirs++
		}
	}

	npkCount := s.npkSvc.GetFileCount()
	albumCount := 0
	if stats, err := s.db.GetStats(); err == nil {
		albumCount = stats.AlbumCount
	}

	respondSuccess(c, gin.H{
		"message":     "重建完成",
		"scanned_dirs": scannedDirs,
		"npk_count":    npkCount,
		"album_count":  albumCount,
	})
}

// deleteNpkFromDB 从数据库删除指定 NPK 记录
func (s *Server) deleteNpkFromDB(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		respondBadRequest(c, "无效的 ID")
		return
	}

	// 获取 NPK 名称用于清理内存缓存
	npkRecord, err := s.db.GetNpkFile(id)
	if err != nil {
		respondNotFound(c, "NPK 不存在")
		return
	}

	// 从数据库删除
	if err := s.db.DeleteNpkFileWithRelations(id); err != nil {
		respondInternalError(c, "删除失败: " + err.Error())
		return
	}

	// 从内存缓存中移除
	s.npkSvc.RemoveFromCache(npkRecord.Name)

	respondSuccess(c, gin.H{"message": "删除成功"})
}