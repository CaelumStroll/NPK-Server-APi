package api

import (
	"fmt"
	"log"
	"time"

	"github.com/gin-gonic/gin"

	wsHub "npk-server/internal/websocket"
)

// handleWebSocket 处理预览 WebSocket 连接
func (s *Server) handleWebSocket(c *gin.Context) {
	sessionId := c.Param("sessionId")

	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("WebSocket 升级失败: %v", err)
		return
	}

	connection := wsHub.NewConnection(sessionId, conn, s.hub)
	s.hub.Register(connection)

	go connection.WritePump()
	connection.ReadPump(func(msg *wsHub.Message) {
		switch msg.Type {
		case "ping":
			s.hub.SendTo(sessionId, &wsHub.Message{
				Type: "pong",
				Payload: map[string]interface{}{
					"timestamp": msg.Payload["timestamp"],
				},
			})
		}
	})
}

// handleSystemWebSocket 系统状态 WebSocket
func (s *Server) handleSystemWebSocket(c *gin.Context) {
	log.Printf("[WebSocket] System stats connection request from %s", c.Request.RemoteAddr)
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("[WebSocket] Upgrade failed: %v", err)
		return
	}

	clientID := fmt.Sprintf("system-%d", time.Now().UnixNano())
	log.Printf("[WebSocket] System stats client connected: %s", clientID)
	connection := wsHub.NewConnection(clientID, conn, s.hub)
	s.hub.Register(connection)

	go connection.WritePump()

	// 立即发送一次
	s.sendSystemStats(clientID)

	// 每 N 秒采集并发送
	interval := s.cfg.WsStatsInterval
	if interval <= 0 {
		interval = 3
	}
	ticker := time.NewTicker(time.Duration(interval) * time.Second)
	defer ticker.Stop()

	done := make(chan struct{})
	go func() {
		connection.ReadPump(func(msg *wsHub.Message) {
			if msg.Type == "ping" {
				s.hub.SendTo(clientID, &wsHub.Message{
					Type: "pong",
					Payload: map[string]interface{}{"timestamp": time.Now().Unix()},
				})
			}
		})
		close(done)
	}()

	for {
		select {
		case <-ticker.C:
			s.sendSystemStats(clientID)
		case <-done:
			return
		}
	}
}

// sendSystemStats 采集并发送系统指标
func (s *Server) sendSystemStats(clientID string) {
	data := s.collector.CollectWithCache()
	s.hub.SendTo(clientID, &wsHub.Message{
		Type:    "system_stats",
		Payload: data,
	})
}

// handleLogWebSocket 日志 WebSocket
func (s *Server) handleLogWebSocket(c *gin.Context) {
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("[WebSocket] Log upgrade failed: %v", err)
		return
	}

	clientID := fmt.Sprintf("log-%d", time.Now().UnixNano())
	connection := wsHub.NewConnection(clientID, conn, s.hub)
	s.hub.Register(connection)

	go connection.WritePump()

	connection.ReadPump(func(msg *wsHub.Message) {
		if msg.Type == "ping" {
			s.hub.SendTo(clientID, &wsHub.Message{
				Type: "pong",
				Payload: map[string]interface{}{"timestamp": time.Now().Unix()},
			})
		}
	})
}