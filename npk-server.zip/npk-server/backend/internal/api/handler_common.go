package api

import (
	"net/http"
	"net/url"
	"strconv"

	"github.com/gin-gonic/gin"
)

// ResponseCode 响应状态码
type ResponseCode int

const (
	CodeSuccess ResponseCode = 0
	CodeError   ResponseCode = 1
)

// Response 统一响应结构
type Response struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data,omitempty"`
}

// respondSuccess 返回成功响应
func respondSuccess(c *gin.Context, data interface{}) {
	c.JSON(http.StatusOK, Response{
		Code:    int(CodeSuccess),
		Message: "success",
		Data:    data,
	})
}

// respondError 返回错误响应
func respondError(c *gin.Context, code int, message string) {
	c.JSON(code, Response{
		Code:    int(CodeError),
		Message: message,
	})
}

// respondBadRequest 返回 400 错误
func respondBadRequest(c *gin.Context, message string) {
	respondError(c, http.StatusBadRequest, message)
}

// respondNotFound 返回 404 错误
func respondNotFound(c *gin.Context, message string) {
	respondError(c, http.StatusNotFound, message)
}

// respondInternalError 返回 500 错误
func respondInternalError(c *gin.Context, message string) {
	respondError(c, http.StatusInternalServerError, message)
}

// respondAccepted 返回 202 已接受
func respondAccepted(c *gin.Context, data interface{}) {
	c.JSON(http.StatusAccepted, Response{
		Code:    int(CodeSuccess),
		Message: "accepted",
		Data:    data,
	})
}

// respondConflict 返回 409 冲突
func respondConflict(c *gin.Context, message string) {
	c.JSON(http.StatusConflict, Response{
		Code:    int(CodeError),
		Message: message,
	})
}

// respondNotImplemented 返回 501 未实现
func respondNotImplemented(c *gin.Context, message string) {
	c.JSON(http.StatusNotImplemented, Response{
		Code:    int(CodeError),
		Message: message,
	})
}

// parseIntParam 解析整数路径参数
func parseIntParam(c *gin.Context, param string) (int, error) {
	value, err := strconv.Atoi(c.Param(param))
	if err != nil {
		respondBadRequest(c, "无效的参数: "+param)
		return 0, err
	}
	return value, nil
}

// parseIntQuery 解析整数查询参数，带默认值
func parseIntQuery(c *gin.Context, key string, defaultValue int) int {
	valueStr := c.DefaultQuery(key, strconv.Itoa(defaultValue))
	value, err := strconv.Atoi(valueStr)
	if err != nil {
		return defaultValue
	}
	return value
}

// parseBoolQuery 解析布尔查询参数，带默认值
func parseBoolQuery(c *gin.Context, key string, defaultValue bool) bool {
	valueStr := c.DefaultQuery(key, "")
	if valueStr == "" {
		return defaultValue
	}
	value, err := strconv.ParseBool(valueStr)
	if err != nil {
		return defaultValue
	}
	return value
}

// getQueryString 获取查询参数，带默认值
func getQueryString(c *gin.Context, key, defaultValue string) string {
	value := c.Query(key)
	if value == "" {
		return defaultValue
	}
	return value
}

// decodePathParam 解码路径参数（处理 URL 编码）
func decodePathParam(c *gin.Context, param string) string {
	encoded := c.Param(param)
	decoded, err := url.PathUnescape(encoded)
	if err != nil {
		return encoded
	}
	return decoded
}
