package api

import (
	"strconv"

	"github.com/gin-gonic/gin"
)

// clearSpriteImage 清空帧图像（变为全透明）
func (s *Server) clearSpriteImage(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}
	index, err := strconv.Atoi(c.Param("index"))
	if err != nil {
		respondBadRequest(c, "无效的索引")
		return
	}

	if err := s.npkSvc.ClearSpriteImage(name, albumPath, index); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "清空成功"})
}

// resetSprite 重置帧属性（撤回未保存修改）
func (s *Server) resetSprite(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}
	index, err := strconv.Atoi(c.Param("index"))
	if err != nil {
		respondBadRequest(c, "无效的索引")
		return
	}

	if err := s.npkSvc.ResetSprite(name, albumPath, index); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "重置成功"})
}

// trimImage 裁剪帧的透明边缘
func (s *Server) trimImage(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}
	index, err := strconv.Atoi(c.Param("index"))
	if err != nil {
		respondBadRequest(c, "无效的索引")
		return
	}

	dx, dy, err := s.npkSvc.TrimImage(name, albumPath, index)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "裁剪成功", "dx": dx, "dy": dy})
}

// canvasImage 画布化帧
func (s *Server) canvasImage(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	if albumPath == "" {
		respondBadRequest(c, "缺少 album 参数")
		return
	}
	index, err := strconv.Atoi(c.Param("index"))
	if err != nil {
		respondBadRequest(c, "无效的索引")
		return
	}

	var req struct {
		TargetX      int `json:"targetX"`
		TargetY      int `json:"targetY"`
		TargetWidth  int `json:"targetWidth"`
		TargetHeight int `json:"targetHeight"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少画布参数")
		return
	}

	if err := s.npkSvc.CanvasImage(name, albumPath, index, req.TargetX, req.TargetY, req.TargetWidth, req.TargetHeight); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "画布化成功"})
}