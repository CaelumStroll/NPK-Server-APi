package api

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"

	"npk-server/internal/database"
	videopkg "npk-server/internal/video"
)

// ---------------------------------------------------------------------------
// 视频管理 API
// ---------------------------------------------------------------------------

// listVideos 获取视频列表（全量），支持 query 搜索参数
// GET /api/videos/list?query=
func (s *Server) listVideos(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	query := c.Query("query")
	// 返回全量数据，不分页
	videos, total, err := s.videoSvc.ListVideos(query, 1, 100000)
	if err != nil {
		respondInternalError(c, "获取视频列表失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"items": videos,
		"total": total,
	})
}

// getVideoStats 获取视频统计信息
// GET /api/videos/stats
func (s *Server) getVideoStats(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	stats, err := s.videoSvc.GetVideoStats()
	if err != nil {
		respondInternalError(c, "获取视频统计失败: "+err.Error())
		return
	}

	respondSuccess(c, stats)
}

// getVideo 根据 ID 获取视频详情
// GET /api/videos/:id
func (s *Server) getVideo(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	video, err := s.videoSvc.GetVideo(int64(id))
	if err != nil {
		respondNotFound(c, "视频不存在")
		return
	}

	respondSuccess(c, video)
}

// scanVideos 扫描所有视频目录
// POST /api/videos/scan  body: {"dir": "/path"} 或空（扫描全部）
func (s *Server) scanVideos(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	var req struct {
		Dir string `json:"dir"`
	}
	// 允许空 body（扫描全部目录）
	_ = c.ShouldBindJSON(&req)

	var count int
	var err error
	if req.Dir != "" {
		var records []*database.VideoRecord
		records, err = s.videoSvc.ScanDir(req.Dir)
		count = len(records)
	} else {
		var records []*database.VideoRecord
		records, err = s.videoSvc.ScanAll()
		count = len(records)
	}
	if err != nil {
		respondInternalError(c, "扫描视频失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"scanned_count": count,
		"message":       fmt.Sprintf("扫描完成，共发现 %d 个视频", count),
	})
}

// scanVideoDir 扫描指定目录
// POST /api/videos/scan-dir  body: {"dir": "/path"}
func (s *Server) scanVideoDir(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	var req struct {
		Dir string `json:"dir"`
	}
	if err := c.ShouldBindJSON(&req); err != nil || req.Dir == "" {
		respondBadRequest(c, "请提供有效的目录路径")
		return
	}

	records, err := s.videoSvc.ScanDir(req.Dir)
	count := len(records)
	if err != nil {
		respondInternalError(c, "扫描目录失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"scanned_count": count,
		"dir":           req.Dir,
		"message":       fmt.Sprintf("目录 %s 扫描完成，共发现 %d 个视频", req.Dir, count),
	})
}

// decryptVideo 解密指定视频
// POST /api/videos/:id/decrypt
func (s *Server) decryptVideo(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	outputPath, err := s.videoSvc.DecryptVideo(int64(id))
	if err != nil {
		respondInternalError(c, "解密视频失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"output_path": outputPath,
		"message":     "视频解密成功",
	})
}

// encryptVideo 加密指定视频
// POST /api/videos/:id/encrypt
func (s *Server) encryptVideo(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	outputPath, err := s.videoSvc.EncryptVideo(int64(id))
	if err != nil {
		respondInternalError(c, "加密视频失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"output_path": outputPath,
		"message":     "视频加密成功",
	})
}

// deleteVideo 删除视频记录，可选同时删除文件
// DELETE /api/videos/:id?delete_file=true
func (s *Server) deleteVideo(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	// 检查是否同时删除文件
	deleteFile := c.Query("delete_file") == "true"

	if deleteFile {
		// 先获取视频信息以获取文件路径
		video, err := s.videoSvc.GetVideo(int64(id))
		if err != nil {
			respondInternalError(c, "获取视频信息失败: " + err.Error())
			return
		}
		if video != nil && video.Path != "" {
			// 删除文件
			if err := os.Remove(video.Path); err != nil && !os.IsNotExist(err) {
				respondInternalError(c, "删除文件失败: "+err.Error())
				return
			}
			log.Printf("[deleteVideo] 已删除文件: %s", video.Path)
		}
	}

	if err := s.videoSvc.DeleteVideo(int64(id)); err != nil {
		respondInternalError(c, "删除视频记录失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message": "视频已删除",
		"file_deleted": deleteFile,
	})
}

// ---------------------------------------------------------------------------
// 视频流 API
// ---------------------------------------------------------------------------

// videoContentType 根据文件扩展名返回 Content-Type
func videoContentType(ext string) string {
	ext = strings.ToLower(ext)
	switch ext {
	case ".avi":
		return "video/x-msvideo"
	case ".bk2":
		// BK2 解密后是 AVI，但先返回二进制流让浏览器自动识别
		return "application/octet-stream"
	case ".mp4":
		return "video/mp4"
	case ".webm":
		return "video/webm"
	case ".mkv":
		return "video/x-matroska"
	default:
		return "application/octet-stream"
	}
}

// isEncryptedExt 判断文件是否为加密格式
func isEncryptedExt(ext string) bool {
	ext = strings.ToLower(ext)
	return ext == ".bk2"
}

// serveVideoContent 处理视频流式传输（支持 Range 请求）
// data: 解密后的视频数据（可选），如果提供则直接返回内存数据
func serveVideoContent(c *gin.Context, filePath string, data []byte) {
	var size int64
	var reader io.ReadSeeker
	var contentType string

	if data != nil {
		// 内存数据（解密后的内容）
		size = int64(len(data))
		reader = bytes.NewReader(data)
		// 解密后的视频是 AVI 格式
		contentType = "video/x-msvideo"
	} else {
		// 文件数据
		file, err := os.Open(filePath)
		if err != nil {
			respondNotFound(c, "视频文件不存在")
			return
		}
		defer file.Close()

		stat, err := file.Stat()
		if err != nil {
			respondInternalError(c, "获取文件信息失败")
			return
		}
		size = stat.Size()
		reader = file

		ext := strings.ToLower(filepath.Ext(filePath))
		contentType = videoContentType(ext)
	}
	fileName := filepath.Base(filePath)

	serveVideoStream(c, reader, size, contentType, fileName)
}

// serveVideoStream 统一的视频流服务（支持自定义 Reader）
// reader: 实现 io.ReadSeeker 的读取器（文件或解密流）
// size: 内容总大小
// contentType: MIME 类型
// fileName: 文件名（用于 Content-Disposition）
func serveVideoStream(c *gin.Context, reader io.ReadSeeker, size int64, contentType, fileName string) {
	c.Header("Content-Type", contentType)
	c.Header("Content-Disposition", "inline; filename*=UTF-8''"+fileName)
	c.Header("Accept-Ranges", "bytes")

	rangeHeader := c.GetHeader("Range")
	if rangeHeader == "" {
		// 无 Range 请求，返回完整文件
		c.Header("Content-Length", strconv.FormatInt(size, 10))
		c.Status(http.StatusOK)
		written, err := io.Copy(c.Writer, reader)
		if err != nil {
			log.Printf("视频流写入失败: %v, 已写入: %d bytes", err, written)
		}
		return
	}

	// 处理 Range 请求（支持视频拖动）
	ranges := parseRangeHeader(rangeHeader, size)
	if ranges == nil {
		c.Header("Content-Range", fmt.Sprintf("bytes */%d", size))
		c.Status(http.StatusRequestedRangeNotSatisfiable)
		return
	}

	start, end := ranges[0], ranges[1]
	if end >= size {
		end = size - 1
	}
	contentLength := end - start + 1

	c.Status(http.StatusPartialContent)
	c.Header("Content-Range", fmt.Sprintf("bytes %d-%d/%d", start, end, size))
	c.Header("Content-Length", strconv.FormatInt(contentLength, 10))

	if _, err := reader.Seek(start, io.SeekStart); err != nil {
		log.Printf("视频 Seek 失败: %v", err)
		return
	}

	limitedReader := io.LimitReader(reader, contentLength)
	written, err := io.Copy(c.Writer, limitedReader)
	if err != nil {
		log.Printf("视频 Range 流写入失败: %v, 已写入: %d bytes", err, written)
	}
}

// parseRangeHeader 解析 Range 请求头，返回 [start, end]
func parseRangeHeader(rangeHeader string, fileSize int64) []int64 {
	// 格式: bytes=start-end
	if !strings.HasPrefix(rangeHeader, "bytes=") {
		return nil
	}
	rangeSpec := strings.TrimPrefix(rangeHeader, "bytes=")
	parts := strings.SplitN(rangeSpec, "-", 2)
	if len(parts) != 2 {
		return nil
	}

	var start, end int64
	var err error

	if parts[0] == "" {
		// 格式: bytes=-suffix（取最后 N 字节）
		suffix, err := strconv.ParseInt(parts[1], 10, 64)
		if err != nil || suffix <= 0 {
			return nil
		}
		start = fileSize - suffix
		if start < 0 {
			start = 0
		}
		end = fileSize - 1
	} else {
		start, err = strconv.ParseInt(parts[0], 10, 64)
		if err != nil || start < 0 || start >= fileSize {
			return nil
		}
		if parts[1] == "" {
			// 格式: bytes=start-（从 start 到文件末尾）
			end = fileSize - 1
		} else {
			end, err = strconv.ParseInt(parts[1], 10, 64)
			if err != nil || end < start {
				return nil
			}
		}
	}

	return []int64{start, end}
}

// streamVideo 流式传输视频（使用 FFmpeg 转码为 MP4）
// GET /api/videos/:id/stream?decrypt=true&res=800x600
// res 参数: original(原始), 800x600(默认), 1066x600
func (s *Server) streamVideo(c *gin.Context) {
	s.transcodeVideo(c, "inline")
}

func (s *Server) downloadVideo(c *gin.Context) {
	s.transcodeVideo(c, "attachment")
}

// transcodeVideo 使用 FFmpeg 转码视频并流式输出（自动处理加密/解密）
func (s *Server) transcodeVideo(c *gin.Context, disposition string) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	id, err := parseIntParam(c, "id")
	if err != nil {
		return
	}

	decrypt := parseBoolQuery(c, "decrypt", false)
	resStr := c.Query("res")
	if resStr == "" {
		resStr = "800x600"
	}
	res := videopkg.ParseResolution(resStr)

	video, err := s.videoSvc.GetVideo(int64(id))
	if err != nil {
		respondNotFound(c, "视频不存在")
		return
	}

	filePath := video.Path
	if _, statErr := os.Stat(filePath); statErr != nil {
		respondNotFound(c, "视频文件不存在: "+filePath)
		return
	}

	needDecrypt := decrypt && video.IsEncrypted

	var transcoder *videopkg.FFmpegTranscoder
	var output io.Reader

	if needDecrypt {
		data, err := os.ReadFile(filePath)
		if err != nil {
			respondInternalError(c, "读取文件失败: "+err.Error())
			return
		}
		crypto := videopkg.NewNeopleCrypto()
		decryptedData, err := crypto.Decrypt(data)
		if err != nil {
			respondInternalError(c, "解密失败: "+err.Error())
			return
		}
		transcoder, output, err = videopkg.NewFFmpegTranscoderFromData(decryptedData, res)
	} else {
		transcoder, output, err = videopkg.NewFFmpegTranscoder(filePath, res)
	}
	if err != nil {
		respondInternalError(c, "启动 FFmpeg 失败: "+err.Error())
		return
	}
	defer transcoder.Kill()

	downloadName := strings.TrimSuffix(filepath.Base(filePath), filepath.Ext(filePath)) + ".mp4"
	c.Header("Content-Type", "video/mp4")
	c.Header("Content-Disposition", fmt.Sprintf("%s; filename*=UTF-8''%s", disposition, downloadName))
	c.Status(http.StatusOK)
	io.Copy(c.Writer, output)
}

// playVideo 按路径播放视频（支持解密后传输）
func (s *Server) playVideo(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}
	filePath := c.Query("path")
	if filePath == "" {
		respondBadRequest(c, "请提供视频文件路径")
		return
	}
	if strings.Contains(filePath, "..") {
		respondBadRequest(c, "无效的文件路径")
		return
	}
	if _, err := os.Stat(filePath); err != nil {
		respondNotFound(c, "视频文件不存在: "+filePath)
		return
	}
	decrypt := parseBoolQuery(c, "decrypt", false)
	isEncrypted := isEncryptedExt(filepath.Ext(filePath))
	reader, size, contentType, err := s.videoSvc.OpenVideoStream(filePath, decrypt && isEncrypted)
	if err != nil {
		respondInternalError(c, "打开视频流失败: "+err.Error())
		return
	}
	defer reader.Close()
	serveVideoStream(c, reader, size, contentType, filepath.Base(filePath))
}

// batchDeleteVideos 批量删除视频
// POST /api/videos/batch-delete
func (s *Server) batchDeleteVideos(c *gin.Context) {
	if s.videoSvc == nil {
		respondInternalError(c, "视频服务未初始化")
		return
	}

	var req struct {
		IDs        []int64 `json:"ids"`
		DeleteFile bool    `json:"delete_file"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if len(req.IDs) == 0 {
		respondBadRequest(c, "请选择要删除的视频")
		return
	}

	var deletedCount int64
	var filesDeleted int

	// 如果需要删除文件，先获取视频信息
	if req.DeleteFile {
		videos, err := s.videoSvc.GetVideosByIDs(req.IDs)
		if err != nil {
			respondInternalError(c, "获取视频信息失败: "+err.Error())
			return
		}
		for _, v := range videos {
			if v.Path != "" {
				if err := os.Remove(v.Path); err != nil && !os.IsNotExist(err) {
					log.Printf("[batchDeleteVideos] 删除文件失败: %s, err: %v", v.Path, err)
				} else if err == nil {
					filesDeleted++
					log.Printf("[batchDeleteVideos] 已删除文件: %s", v.Path)
				}
			}
		}
	}

	// 删除数据库记录
	deletedCount, err := s.videoSvc.DeleteVideosByIDs(req.IDs)
	if err != nil {
		respondInternalError(c, "删除视频记录失败: "+err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"message":       fmt.Sprintf("已删除 %d 条记录", deletedCount),
		"files_deleted": filesDeleted,
	})
}
