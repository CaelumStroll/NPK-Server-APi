package api

import (
	"encoding/base64"
	"fmt"
	"log"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"npk-server/internal/npk"
)

// listAssets 获取资源列表（Album 或 Sprite）
func (s *Server) listAssets(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	page, pageSize := parsePaginationParams(c)

	if albumPath == "" {
		info, err := s.npkSvc.GetNpkInfo(name)
		if err != nil {
			respondNotFound(c, err.Error())
			return
		}
		respondSuccess(c, gin.H{"albums": info.Albums, "total": len(info.Albums)})
		return
	}

	album, err := s.npkSvc.GetAlbum(name, albumPath)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	start := (page - 1) * pageSize
	end := start + pageSize
	if end > len(album.Sprites) { end = len(album.Sprites) }

	sprites := make([]map[string]interface{}, end-start)
	for i := start; i < end; i++ {
		sp := album.Sprites[i]
		sprites[i-start] = map[string]interface{}{
			"index":        sp.Index,
			"type":         sp.Type.String(),
			"width":        sp.Width,
			"height":       sp.Height,
			"x":            sp.X,
			"y":            sp.Y,
			"frame_width":  sp.FrameWidth,
			"frame_height": sp.FrameHeight,
			"is_link":      sp.Type == npk.LINK,
			"data_size":    sp.Length,
		}
	}

	respondSuccess(c, gin.H{"sprites": sprites, "total": len(album.Sprites), "page": page, "size": pageSize})
}

// getAssetInfo 获取单个 Sprite 详细信息
func (s *Server) getAssetInfo(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	index, _ := strconv.Atoi(c.Param("index"))

	sprite, album, err := s.npkSvc.GetSprite(name, albumPath, index)
	if err != nil {
		respondNotFound(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{
		"index":        sprite.Index,
		"type":         sprite.Type.String(),
		"compress":     sprite.CompressMode.String(),
		"width":        sprite.Width,
		"height":       sprite.Height,
		"x":            sprite.X,
		"y":            sprite.Y,
		"frame_width":  sprite.FrameWidth,
		"frame_height": sprite.FrameHeight,
		"is_link":      sprite.Target != nil,
		"version":      album.Version.String(),
		"data_size":    sprite.Length,
	})
}

// getAssetImage 获取 Sprite 图像
func (s *Server) getAssetImage(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	index, _ := strconv.Atoi(c.Param("index"))
	width, _ := strconv.Atoi(c.DefaultQuery("w", "0"))
	height, _ := strconv.Atoi(c.DefaultQuery("h", "0"))
	format := c.DefaultQuery("format", "png")
	noCompress := c.Query("nocompress") == "1"

	const maxSize = 4096
	if width > maxSize || height > maxSize {
		respondBadRequest(c, fmt.Sprintf("图片尺寸不能超过 %dx%d", maxSize, maxSize))
		return
	}

	data, err := s.npkSvc.GetSpriteImage(name, albumPath, index, width, height, noCompress)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	if format == "base64" {
		respondSuccess(c, gin.H{"image": "data:image/png;base64," + base64.StdEncoding.EncodeToString(data)})
		return
	}

	c.Data(http.StatusOK, "image/png", data)
}

// getAssetThumbnail 获取 Sprite 缩略图
func (s *Server) getAssetThumbnail(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	index, _ := strconv.Atoi(c.Param("index"))

	data, err := s.npkSvc.GetThumbnail(name, albumPath, index)
	if err != nil {
		respondInternalError(c, err.Error())
		return
	}

	c.Data(http.StatusOK, "image/png", data)
}

// replaceAsset 替换 Sprite 图像
func (s *Server) replaceAsset(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	index, _ := strconv.Atoi(c.Param("index"))
	colorFormat := c.PostForm("color_format")
	autoResize := c.PostForm("auto_resize") == "true"

	file, err := c.FormFile("file")
	if err != nil {
		respondBadRequest(c, "请上传文件")
		return
	}

	if err := validateUploadedFile(file); err != nil {
		respondBadRequest(c, err.Error())
		return
	}

	if err := s.npkSvc.ReplaceSprite(name, albumPath, index, file, colorFormat, autoResize); err != nil {
		log.Printf("替换精灵失败: %v", err)
		respondInternalError(c, sanitizeErrorMessage(err))
		return
	}

	respondSuccess(c, gin.H{"message": "替换成功"})
}

// addFrame 添加新帧
func (s *Server) addFrame(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")

	file, err := c.FormFile("file")
	if err != nil {
		respondBadRequest(c, "请上传文件")
		return
	}

	if err := validateUploadedFile(file); err != nil {
		respondBadRequest(c, err.Error())
		return
	}

	if err := s.npkSvc.AddSprite(name, albumPath, file); err != nil {
		log.Printf("AddSprite failed: %v", err)
		respondInternalError(c, sanitizeErrorMessage(err))
		return
	}

	respondSuccess(c, gin.H{"message": "添加成功"})
}

// addLinkFrame 添加链接帧
func (s *Server) addLinkFrame(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")

	var req struct {
		TargetIndex int    `json:"target_index"`
		Position    string `json:"position"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	position := req.Position
	if position == "" { position = "end" }

	if err := s.npkSvc.AddLinkSprite(name, albumPath, req.TargetIndex, position); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "添加成功"})
}

// modifyLinkTarget 修改链接帧目标
func (s *Server) modifyLinkTarget(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	spriteIndex, _ := strconv.Atoi(c.Param("index"))

	var req struct {
		TargetIndex int `json:"target_index"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if err := s.npkSvc.ModifyLinkTarget(name, albumPath, spriteIndex, req.TargetIndex); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "修改成功"})
}

// updateFrame 更新帧属性
func (s *Server) updateFrame(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	index, _ := strconv.Atoi(c.Param("index"))
	frameIndex, _ := strconv.Atoi(c.Param("fid"))

	spriteIndex := frameIndex
	if spriteIndex == 0 { spriteIndex = index }

	var req struct {
		X           int `json:"x"`
		Y           int `json:"y"`
		Width       int `json:"width"`
		Height      int `json:"height"`
		FrameWidth  int `json:"frame_width"`
		FrameHeight int `json:"frame_height"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}

	if err := s.npkSvc.UpdateFrame(name, albumPath, spriteIndex, req.X, req.Y, req.Width, req.Height, req.FrameWidth, req.FrameHeight); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "更新成功"})
}

// deleteAsset 删除帧
func (s *Server) deleteAsset(c *gin.Context) {
	name := decodePathParam(c, "name")
	albumPath := c.Query("album")
	index, _ := strconv.Atoi(c.Param("index"))

	if err := s.npkSvc.DeleteFrame(name, albumPath, index); err != nil {
		respondInternalError(c, err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "删除成功"})
}

// replaceColor 替换颜色（尚未实现）
func (s *Server) replaceColor(c *gin.Context) {
	respondNotImplemented(c, "颜色替换功能尚未实现")
}