package api

import (
	"encoding/base64"
	"fmt"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"

	"npk-server/internal/npk"
)

type v2FrameRequest struct {
	Path         string `json:"path"`
	FrameIndex   int    `json:"frameIndex"`
	FrameIndices []int  `json:"frameIndices"`
}

type v2BatchRequest struct {
	Items []v2FrameRequest `json:"items"`
}

type v2FrameResponse struct {
	Path        string `json:"path"`
	FrameIndex  int    `json:"frameIndex"`
	Data        string `json:"data"`
	Width       int    `json:"width"`
	Height      int    `json:"height"`
	OffsetX     int    `json:"offsetX"`
	OffsetY     int    `json:"offsetY"`
	FrameWidth  int    `json:"frameWidth"`
	FrameHeight int    `json:"frameHeight"`
	Type        string `json:"type"`
	NpkName     string `json:"npkName"`
}

func (s *Server) v2AlbumFrames(c *gin.Context) {
	var req v2BatchRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: "+err.Error())
		return
	}
	if len(req.Items) == 0 {
		respondSuccess(c, gin.H{"images": []v2FrameResponse{}})
		return
	}

	type frameTask struct {
		reqIdx    int
		origPath  string
		frameIdx  int
		npkName   string
		albumPath string
	}

	// 展开所有帧请求，保持原始顺序
	tasks := make([]frameTask, 0)
	for i, item := range req.Items {
		npkName, albumPath, err := s.resolveNpkAlbum(item.Path)
		if err != nil {
			log.Printf("[v2AlbumFrames] 路径解析失败: %s, err=%v", item.Path, err)
			continue
		}
		if len(item.FrameIndices) > 0 {
			for _, fi := range item.FrameIndices {
				tasks = append(tasks, frameTask{i, item.Path, fi, npkName, albumPath})
			}
		} else {
			tasks = append(tasks, frameTask{i, item.Path, item.FrameIndex, npkName, albumPath})
		}
	}

	// 按 album 缓存避免重复加载
	type albumCache struct {
		npkName, albumPath string
		album              *npk.Album
	}
	albumMap := make(map[string]*albumCache)

	frames := make([]v2FrameResponse, 0, len(tasks))

	for _, t := range tasks {
		key := t.npkName + "|" + t.albumPath
		ac, ok := albumMap[key]
		if !ok {
			album, err := s.npkSvc.GetAlbum(t.npkName, t.albumPath)
			if err != nil {
				log.Printf("[v2AlbumFrames] GetAlbum 失败: %s/%s", t.npkName, t.albumPath)
				continue
			}
			ac = &albumCache{t.npkName, t.albumPath, album}
			albumMap[key] = ac
		}

		if t.frameIdx < 0 || t.frameIdx >= len(ac.album.Sprites) {
			continue
		}
		sp := ac.album.Sprites[t.frameIdx]
		if sp.Type == npk.LINK && sp.Target != nil {
			sp = sp.Target
		}

		data, err := s.npkSvc.GetSpriteImage(ac.npkName, ac.albumPath, t.frameIdx, 0, 0, false)
		if err != nil {
			log.Printf("[v2AlbumFrames] GetSpriteImage 失败: %s/%s/%d", ac.npkName, ac.albumPath, t.frameIdx)
			continue
		}

		frames = append(frames, v2FrameResponse{
			Path:        t.origPath,
			FrameIndex:  t.frameIdx,
			Data:        "data:image/png;base64," + base64.StdEncoding.EncodeToString(data),
			Width:       sp.Width,
			Height:      sp.Height,
			OffsetX:     sp.X,
			OffsetY:     sp.Y,
			FrameWidth:  sp.FrameWidth,
			FrameHeight: sp.FrameHeight,
			Type:        sp.Type.String(),
			NpkName:     ac.npkName,
		})
	}

	c.JSON(http.StatusOK, Response{
		Code:    int(CodeSuccess),
		Message: fmt.Sprintf("success, %d images", len(frames)),
		Data:    gin.H{"images": frames},
	})
}
