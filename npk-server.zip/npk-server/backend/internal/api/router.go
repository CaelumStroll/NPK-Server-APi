package api

import "github.com/gin-gonic/gin"

func (s *Server) registerNpkRoutes(api *gin.RouterGroup) {
	api.GET("/npk/list", s.listNpk)
	api.GET("/npk/list/paginated", s.listNpkPaginated)
	api.GET("/npk/:name/info", s.getNpkInfo)
	api.GET("/npk/:name/tree", s.getNpkTree)
	api.POST("/npk/scan", s.scanNpk)
	api.POST("/npk/:name/save", s.saveNpk)
	api.DELETE("/npk/:name", s.deleteNpk)
}

func (s *Server) registerNpkTagRoutes(api *gin.RouterGroup) {
	api.GET("/npk/:name/tags", s.getNpkTags)
	api.POST("/npk/:name/tags", s.addNpkTag)
	api.DELETE("/npk/:name/tags/:tagId", s.removeNpkTag)
}

func (s *Server) registerAssetRoutes(api *gin.RouterGroup) {
	api.GET("/npk/:name/assets", s.listAssets)
	api.GET("/npk/:name/assets/:index", s.getAssetInfo)
	api.GET("/npk/:name/assets/:index/image", s.getAssetImage)
	api.GET("/npk/:name/assets/:index/thumbnail", s.getAssetThumbnail)
}

func (s *Server) registerAnimationRoutes(api *gin.RouterGroup) {
	api.GET("/npk/:name/assets/:index/ani/info", s.getAnimationInfo)
	api.GET("/npk/:name/assets/:index/ani/frame/:fid", s.getAnimationFrame)
	api.POST("/npk/:name/assets/:index/ani/preview", s.previewAnimationFrames)
	api.GET("/npk/:name/assets/:index/ani/export.gif", s.exportGIF)
}

func (s *Server) registerCacheRoutes(api *gin.RouterGroup) {
	api.POST("/cache/img/load", s.loadImgCache)
	api.DELETE("/cache/img/release", s.releaseImgCache)
	api.DELETE("/cache/img/release-all", s.releaseAllImgCache)
	api.GET("/cache/img/status", s.getImgCacheStatus)
}

func (s *Server) registerAlbumRoutes(api *gin.RouterGroup) {
	api.GET("/npk/preview", s.getAlbumPreview)
	api.GET("/npk/frames", s.getAlbumFrames)
	api.GET("/npk/album/export.gif", s.exportAlbumGif)
	api.PUT("/npk/:name/album/rename", s.renameAlbum)
	api.GET("/npk/:name/album/compare", s.compareAlbum)
	api.POST("/npk/:name/import-img", s.importImg)
	api.POST("/npk/:name/assets/batch-replace", s.batchReplaceFromFolder)
	api.POST("/npk/:name/assets/batch-import", s.batchImportSprites)
	api.DELETE("/npk/:name/album", s.deleteAlbum)
	api.POST("/npk/:name/album/set-target", s.setAlbumTarget)
	api.DELETE("/npk/:name/album/target", s.clearAlbumTarget)
	api.GET("/npk/:name/album/export-coords", s.exportAlbumCoords)
	api.POST("/npk/:name/album/import-coords", s.importAlbumCoords)
}

func (s *Server) registerLibraryRoutes(api *gin.RouterGroup) {
	api.GET("/library/stats", s.getLibraryStats)
	api.GET("/library/search", s.searchLibrary)
	api.GET("/library/tags", s.getTags)
	api.POST("/library/tags", s.createTag)
	api.PUT("/library/tags/:id", s.updateTag)
	api.DELETE("/library/tags/:id", s.deleteTag)
	api.PUT("/library/assets/:id/tags", s.updateAssetTags)
	api.GET("/library/search/by-tags", s.searchByTags)
	api.GET("/library/folders", s.getFolders)
	api.GET("/library/duplicates", s.getDuplicateAlbums)
}

func (s *Server) registerSpriteRoutes(api *gin.RouterGroup) {
	api.POST("/npk/:name/assets/:index/replace", s.replaceAsset)
	api.POST("/npk/:name/assets/add", s.addFrame)
	api.POST("/npk/:name/assets/add-link", s.addLinkFrame)
	api.PUT("/npk/:name/assets/:index/modify-link", s.modifyLinkTarget)
	api.PUT("/npk/:name/assets/:index/frame/:fid", s.updateFrame)
	api.DELETE("/npk/:name/assets/:index", s.deleteAsset)
	api.POST("/npk/:name/assets/:index/color", s.replaceColor)
	api.POST("/npk/:name/assets/:index/clear", s.clearSpriteImage)
	api.POST("/npk/:name/assets/:index/reset", s.resetSprite)
	api.POST("/npk/:name/assets/:index/trim", s.trimImage)
	api.POST("/npk/:name/assets/:index/canvas", s.canvasImage)
}

func (s *Server) registerExternalRoutes(api *gin.RouterGroup) {
	api.GET("/external-npk/albums", s.getExternalNpkAlbums)
	api.POST("/external-npk/albums", s.getExternalNpkAlbums)
	api.GET("/external-npk/frame", s.getExternalNpkFrame)
	api.POST("/external-img/upload", s.uploadExternalImg)
	api.GET("/external-img/info", s.loadExternalImgAlbum)
	api.GET("/external-img/frame", s.getExternalImgFrame)
	api.GET("/external-npk/download", s.downloadExternalNpk)
}

func (s *Server) registerBatchRoutes(api *gin.RouterGroup) {
	api.POST("/batch/export", s.batchExport)
	api.GET("/batch/status/:taskId", s.batchExportStatus)
	api.GET("/batch/download/:taskId", s.batchExportDownload)
}

func (s *Server) registerToolRoutes(api *gin.RouterGroup) {
	api.POST("/tools/convert-upload", s.convertUpload)
	api.GET("/tools/convert-download/:taskId", s.convertDownload)
	api.GET("/tools/convert-status/:taskId", s.getConvertStatus)
	api.GET("/avatars/list", s.listAvatars)
	api.POST("/avatars/upload", s.uploadAvatar)
	api.GET("/tools/list", s.listTools)
	api.POST("/tools/open", s.openTool)
	api.POST("/tools/open-folder", s.openFolder)
	api.GET("/tools/scan-config", s.scanConfigDirectory)
	api.POST("/tools/create-config", s.createToolConfig)
	api.DELETE("/tools/delete-config", s.deleteToolConfig)
}

func (s *Server) registerSettingsRoutes(api *gin.RouterGroup) {
	api.GET("/settings", s.getSettings)
	api.PUT("/settings", s.updateSettings)
	api.POST("/settings/npk-dir", s.addNpkDir)
	api.DELETE("/settings/npk-dir", s.removeNpkDir)
}

func (s *Server) registerDBRoutes(api *gin.RouterGroup) {
	api.GET("/db/stats", s.getDBStats)
	api.GET("/db/tables", s.getDBTables)
	api.POST("/db/cleanup", s.cleanupDB)
	api.POST("/db/compact", s.compactDB)
	api.POST("/db/incremental", s.incrementalUpdate)
	api.GET("/db/export", s.exportDB)
	api.POST("/db/rebuild", s.rebuildDB)
	api.DELETE("/db/npk/:id", s.deleteNpkFromDB)
}

func (s *Server) registerVideoDBRoutes(api *gin.RouterGroup) {
	api.GET("/db/videos/stats", s.getVideoDBStats)
	api.POST("/db/videos/cleanup", s.cleanupVideoDB)
	api.POST("/db/videos/rebuild", s.rebuildVideoDB)
	api.POST("/db/videos/compact", s.compactVideoDB)
}

func (s *Server) registerVideoRoutes(api *gin.RouterGroup) {
	api.GET("/videos/list", s.listVideos)
	api.GET("/videos/stats", s.getVideoStats)
	api.GET("/videos/:id", s.getVideo)
	api.POST("/videos/scan", s.scanVideos)
	api.POST("/videos/scan-dir", s.scanVideoDir)
	api.POST("/videos/:id/decrypt", s.decryptVideo)
	api.POST("/videos/:id/encrypt", s.encryptVideo)
	api.DELETE("/videos/:id", s.deleteVideo)
	api.POST("/videos/batch-delete", s.batchDeleteVideos)
	api.GET("/videos/:id/stream", s.streamVideo)
	api.GET("/videos/:id/download", s.downloadVideo)
	api.GET("/videos/play", s.playVideo)
}

func (s *Server) registerMusicRoutes(api *gin.RouterGroup) {
	api.GET("/music/list", s.listMusic)
	api.GET("/music/stats", s.getMusicStats)
	api.GET("/music/:id", s.getMusic)
	api.POST("/music/scan", s.scanMusic)
	api.DELETE("/music/:id", s.deleteMusic)
	api.POST("/music/batch-delete", s.batchDeleteMusic)
	api.GET("/music/:id/stream", s.streamMusic)
	api.POST("/music/:id/convert", s.convertMusic)
}

func (s *Server) registerMusicDBRoutes(api *gin.RouterGroup) {
	api.GET("/db/music/stats", s.getMusicDBStats)
	api.POST("/db/music/cleanup", s.cleanupMusicDB)
	api.POST("/db/music/rebuild", s.rebuildMusicDB)
	api.POST("/db/music/compact", s.compactMusicDB)
}

func (s *Server) registerSoundPackRoutes(api *gin.RouterGroup) {
	api.GET("/soundpacks/list", s.listSoundPacks)
	api.GET("/soundpacks/stats", s.getSoundPackStats)
	api.GET("/soundpacks/:id", s.getSoundPack)
	api.POST("/soundpacks/scan", s.scanSoundPacks)
	api.DELETE("/soundpacks/:id", s.deleteSoundPack)
	api.POST("/soundpacks/batch-delete", s.batchDeleteSoundPacks)
	api.POST("/soundpacks/:id/decrypt", s.decryptSoundPack)
	api.GET("/soundpacks/:id/entries", s.getSoundPackEntries)
	api.POST("/soundpacks/:id/rebuild", s.rebuildSoundPack)
	api.GET("/soundpacks/:id/entries/:eid/stream", s.streamSoundPackEntry)
	api.GET("/soundpacks/:id/entries/:eid/download", s.downloadSoundPackEntry)
	api.GET("/soundpacks/:id/entries/:eid/convert", s.convertSoundPackEntry)
	api.POST("/soundpacks/:id/entries/import", s.importOGGToSoundPack)
	api.POST("/soundpacks/:id/entries/batch-export", s.batchExportSoundPackEntries)
	api.POST("/soundpacks/:id/entries/batch-import", s.batchImportOGGToSoundPack)
	api.POST("/soundpacks/:id/entries/batch-delete", s.batchDeleteSoundPackEntries)
	api.PUT("/soundpacks/:id/entries/:eid/rename", s.renameSoundPackEntry)
	api.DELETE("/soundpacks/:id/entries/:eid", s.deleteSoundPackEntry)
}

func (s *Server) registerSoundPackDBRoutes(api *gin.RouterGroup) {
	api.GET("/db/soundpacks/stats", s.getSoundPackDBStats)
	api.POST("/db/soundpacks/cleanup", s.cleanupSoundPackDB)
	api.POST("/db/soundpacks/rebuild", s.rebuildSoundPackDB)
	api.POST("/db/soundpacks/compact", s.compactSoundPackDB)
}

func (s *Server) registerXmlEditorRoutes(api *gin.RouterGroup) {
	api.GET("/xml-audio/list", s.listXmlAudio)
	api.GET("/xml-audio/entry/:type/:id", s.getXmlAudioEntry)
	api.POST("/xml-audio/entry", s.saveXmlAudioEntry)
	api.DELETE("/xml-audio/entry/:type/:id", s.deleteXmlAudioEntry)
	api.POST("/xml-audio/reload", s.reloadAudioXml)
	api.GET("/xml-audio/stream", s.streamXmlAudioFile)
	api.POST("/xml-audio/open", s.openXmlFile)
	api.GET("/xml-audio/list-files", s.listXmlFiles)
	api.POST("/xml-audio/export", s.exportAudioXml)
	api.GET("/xml-audio/check-missing", s.checkMissingXmlFiles)
}

func (s *Server) registerLanguageRoutes(api *gin.RouterGroup) {
	api.GET("/language/list", s.listLanguages)
	api.GET("/language/:locale", s.getLanguage)
}

func (s *Server) registerDebugRoutes(api *gin.RouterGroup) {
	api.GET("/debug/routes", s.listRoutes)
}

func (s *Server) registerCompatRoutes(router *gin.Engine) {
	compatAPI := router.Group("/api")
	{
		compatAPI.GET("/health", s.compatHealth)
		compatAPI.GET("/npks", s.compatListNpks)
		compatAPI.GET("/npks/:npkId/imgs", s.compatListImgs)
		compatAPI.GET("/npks/:npkId/frames", s.compatListFramesByQuery)
		compatAPI.GET("/frame/by-path", s.compatFrameByPath)
		compatAPI.POST("/frames/batch", s.compatFramesBatch)
		compatAPI.POST("/frames/album-batch", s.compatAlbumBatch)
		compatAPI.POST("/overlay", s.compatOverlay)
	}
}
