package api

import (
	"testing"
)

func TestNpkNamePattern(t *testing.T) {
	tests := []struct {
		name     string
		expected bool
	}{
		{"sprite.npk", true},
		{"monster_01.NPK", true},
		{"test-file.npk", true},
		{"path/to/file.npk", false},
		{"file name.npk", false},
		{"", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := npkNamePattern.MatchString(tt.name)
			if result != tt.expected {
				t.Errorf("npkNamePattern.MatchString(%q) = %v, want %v", tt.name, result, tt.expected)
			}
		})
	}
}

func TestAlbumPathPattern(t *testing.T) {
	tests := []struct {
		path     string
		expected bool
	}{
		{"sprite_character", true},
		{"folder/subfolder", true},
		{"folder\\subfolder", true},
		{"valid_path-123", true},
		{"path with spaces", false},
		{"", false},
	}

	for _, tt := range tests {
		t.Run(tt.path, func(t *testing.T) {
			result := albumPathPattern.MatchString(tt.path)
			if result != tt.expected {
				t.Errorf("albumPathPattern.MatchString(%q) = %v, want %v", tt.path, result, tt.expected)
			}
		})
	}
}
