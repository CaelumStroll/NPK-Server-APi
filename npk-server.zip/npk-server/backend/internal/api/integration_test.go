package api

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/gin-gonic/gin"

	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/service"
)

func newTestServer(t *testing.T) (*Server, *gin.Engine, func()) {
	t.Helper()

	tmpDir := t.TempDir()
	dbPath := filepath.Join(tmpDir, "test.db")

	cfg := config.DefaultConfig()
	cfg.DatabasePath = dbPath
	cfg.DataDir = filepath.Join(tmpDir, "data")
	cfg.CacheDir = filepath.Join(tmpDir, "cache")
	cfg.EnableCache = true
	if err := cfg.EnsureDirs(); err != nil {
		t.Fatalf("EnsureDirs: %v", err)
	}

	db, err := database.NewDatabase(dbPath)
	if err != nil {
		t.Fatalf("NewDatabase: %v", err)
	}

	npkSvc := service.NewNpkService(cfg, db)
	videoSvc := service.NewVideoService(cfg, db)
	musicSvc := service.NewMusicService(cfg, db)
	soundpackSvc := service.NewSoundPackService(cfg, db)

	server := NewServer(cfg, db, npkSvc, videoSvc, musicSvc, soundpackSvc)
	router := server.Setup()

	cleanup := func() {
		db.Close()
		os.RemoveAll(tmpDir)
	}

	return server, router, cleanup
}

func TestHealthEndpoint(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/health", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("health status = %d, want 200", w.Code)
	}
}

func TestNPKListEmpty(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/npk/list", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("list status = %d, want 200", w.Code)
	}

	var resp Response
	json.Unmarshal(w.Body.Bytes(), &resp)
	if resp.Code != 0 {
		t.Errorf("response code = %d, want 0", resp.Code)
	}
}

func TestNPKListPaginated(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/npk/list/paginated?page=1&size=20", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("paginated status = %d, want 200", w.Code)
	}
}

func TestSettingsGet(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/settings", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("settings status = %d, want 200", w.Code)
	}

	var resp Response
	json.Unmarshal(w.Body.Bytes(), &resp)
	data, ok := resp.Data.(map[string]interface{})
	if !ok {
		t.Fatal("settings data is not a map")
	}
	if _, exists := data["server_port"]; !exists {
		t.Error("server_port missing from settings")
	}
}

func TestLibraryStats(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/library/stats", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("stats status = %d, want 200", w.Code)
	}
}

func TestLibrarySearch(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/library/search?q=test&page=1&size=10", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("search status = %d, want 200", w.Code)
	}
}

func TestVideoListEmpty(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/videos/list", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("video list status = %d, want 200", w.Code)
	}
}

func TestVideoStats(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/videos/stats", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	// 视频表可能未初始化，允许 200 或 500
	if w.Code != http.StatusOK && w.Code != http.StatusInternalServerError {
		t.Errorf("video stats status = %d", w.Code)
	}
}

func Test404Handling(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/nonexistent", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	// API 路径不匹配时返回 404 JSON
	if w.Code != http.StatusNotFound {
		t.Errorf("404 status = %d, want 404", w.Code)
	}
}

func TestNPKNotFound(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/npk/nonexistent_npk/info", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	// 缺失的 NPK 返回 404
	if w.Code != http.StatusNotFound {
		t.Errorf("info status = %d, want 404", w.Code)
	}
}

func TestDBStats(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/db/stats", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("db stats status = %d, want 200", w.Code)
	}
}

func TestDebugRoutes(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("GET", "/api/debug/routes", nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("debug routes status = %d, want 200", w.Code)
	}
}

func TestCORSHeaders(t *testing.T) {
	_, router, cleanup := newTestServer(t)
	defer cleanup()

	req := httptest.NewRequest("OPTIONS", "/api/health", nil)
	req.Header.Set("Origin", "http://localhost:3000")
	req.Header.Set("Access-Control-Request-Method", "GET")
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)

	if w.Code != http.StatusNoContent && w.Code != http.StatusOK {
		t.Errorf("CORS OPTIONS status = %d", w.Code)
	}
}
