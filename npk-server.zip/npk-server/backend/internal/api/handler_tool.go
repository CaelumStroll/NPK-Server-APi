package api

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	"npk-server/internal/npk"
)

// listTools 获取工具列表
func (s *Server) listTools(c *gin.Context) {
	toolsDir := filepath.Join(execDir, "tools")

	if _, err := os.Stat(toolsDir); os.IsNotExist(err) {
		log.Printf("[listTools] tools 目录不存在: %s", toolsDir)
		respondSuccess(c, []interface{}{})
		return
	}

	entries, err := os.ReadDir(toolsDir)
	if err != nil {
		log.Printf("[listTools] 读取 tools 目录失败: %v", err)
		respondInternalError(c, "读取 tools 目录失败: " + err.Error())
		return
	}

	log.Printf("[listTools] tools 目录: %s, 文件数: %d", toolsDir, len(entries))

	var tools []map[string]interface{}

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		name := entry.Name()
		ext := strings.ToLower(filepath.Ext(name))

		if ext != ".json" {
			continue
		}

		jsonPath := filepath.Join(toolsDir, name)
		log.Printf("[listTools] 发现工具配置: %s", name)
		jsonData, err := os.ReadFile(jsonPath)
		if err != nil {
			log.Printf("[listTools] 读取配置文件失败 %s: %v", name, err)
			continue
		}

		var config map[string]interface{}
		if err := json.Unmarshal(jsonData, &config); err != nil {
			continue
		}

		toolName, _ := config["name"].(string)
		toolType, _ := config["type"].(string)
		toolPath, _ := config["path"].(string)
		description, _ := config["description"].(string)
		icon, _ := config["icon"].(string)

		if toolName == "" || toolType == "" || toolPath == "" {
			continue
		}

		tool := map[string]interface{}{
			"name":        toolName,
			"description": description,
			"icon":        icon,
			"type":        toolType,
			"enabled":     true,
		}

		switch toolType {
		case "html", "py":
			filePath := filepath.Join(toolsDir, toolPath)
			if _, err := os.Stat(filePath); err != nil {
				tool["enabled"] = false
				tool["description"] = description + " (文件不存在)"
			}
			tool["path"] = "/tools/" + toolPath
		case "exe", "bat", "cmd", "ps1", "sh":
			filePath := filepath.Join(toolsDir, toolPath)
			if _, err := os.Stat(filePath); err != nil {
				tool["enabled"] = false
				tool["description"] = description + " (文件不存在)"
			}
			tool["path"] = filePath
		case "url":
			tool["path"] = toolPath
		default:
			continue
		}

		tools = append(tools, tool)
	}

	respondSuccess(c, tools)
}

// openTool 打开工具
func (s *Server) openTool(c *gin.Context) {
	var req struct {
		Path string `json:"path" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少文件路径")
		return
	}

	filePath := req.Path

	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		respondNotFound(c, "文件不存在")
		return
	}

	ext := strings.ToLower(filepath.Ext(filePath))
	supportedExts := []string{".exe", ".bat", ".cmd", ".py", ".ps1", ".sh", ".html"}

	isSupported := false
	for _, supported := range supportedExts {
		if ext == supported {
			isSupported = true
			break
		}
	}

	if !isSupported {
		respondBadRequest(c, fmt.Sprintf("不支持的文件类型: %s，仅支持: %s", ext, strings.Join(supportedExts, ", ")))
		return
	}

	var cmd *exec.Cmd
	switch ext {
	case ".exe", ".bat", ".cmd", ".ps1":
		cmd = exec.Command("cmd", "/c", "start", "", filePath)
	case ".py":
		cmd = exec.Command("python", filePath)
	case ".sh":
		cmd = exec.Command("bash", filePath)
	case ".html":
		cmd = exec.Command("cmd", "/c", "start", "", filePath)
	default:
		respondBadRequest(c, "不支持的文件类型")
		return
	}

	cmd.Dir = filepath.Dir(filePath)

	if err := cmd.Start(); err != nil {
		respondInternalError(c, "执行失败: " + err.Error())
		return
	}

	go func() { cmd.Wait() }()

	respondSuccess(c, gin.H{"message": "已启动: " + filepath.Base(filePath)})
}

// openFolder 在文件管理器中打开文件夹并选中文件
// POST /api/tools/open-folder
// 请求: { "path": "/path/to/file.avi" } - 如果是文件则选中该文件
func (s *Server) openFolder(c *gin.Context) {
	var req struct {
		Path string `json:"path" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "缺少路径")
		return
	}

	filePath := req.Path
	folderPath := filePath

	// 检查路径是否存在
	info, err := os.Stat(filePath)
	if err != nil {
		if os.IsNotExist(err) {
			respondNotFound(c, "路径不存在")
		} else {
			respondInternalError(c, "无法访问路径: "+err.Error())
		}
		return
	}

	isFile := !info.IsDir()
	if isFile {
		folderPath = filepath.Dir(filePath)
	}

	var cmd *exec.Cmd
	runtimeOS := runtime.GOOS
	switch runtimeOS {
	case "darwin":
		// macOS: 使用 open -R 选中文件，或 open 打开文件夹
		if isFile {
			cmd = exec.Command("open", "-R", filePath)
		} else {
			cmd = exec.Command("open", folderPath)
		}
	case "windows":
		// Windows: 使用 explorer /select 选中文件
		if isFile {
			cmd = exec.Command("explorer", "/select,"+filePath)
		} else {
			cmd = exec.Command("explorer", folderPath)
		}
	case "linux":
		// Linux: 大多数文件管理器不支持直接选中文件，只打开文件夹
		cmd = exec.Command("xdg-open", folderPath)
	default:
		respondBadRequest(c, "不支持的操作系统: "+runtimeOS)
		return
	}

	if err := cmd.Start(); err != nil {
		respondInternalError(c, "打开失败: "+err.Error())
		return
	}

	go func() { cmd.Wait() }()

	respondSuccess(c, gin.H{"message": "已在文件管理器中打开"})
}

// convertUpload 上传 NPK 文件进行版本转换
func (s *Server) convertUpload(c *gin.Context) {
	targetVersion := c.PostForm("target_version")
	if targetVersion == "" {
		targetVersion = "V2"
	}
	outputFormat := c.PostForm("output_format")
	if outputFormat == "" {
		outputFormat = "npk"
	}

	form, err := c.MultipartForm()
	if err != nil {
		respondBadRequest(c, "解析上传文件失败: " + err.Error())
		return
	}

	files := form.File["files"]
	if len(files) == 0 {
		respondBadRequest(c, "未上传任何文件")
		return
	}

	var npkFiles []*multipart.FileHeader
	for _, f := range files {
		if strings.HasSuffix(strings.ToLower(f.Filename), ".npk") {
			npkFiles = append(npkFiles, f)
		}
	}

	if len(npkFiles) == 0 {
		respondBadRequest(c, "未找到 NPK 文件")
		return
	}

	s.convertTaskCounter++
	taskID := fmt.Sprintf("convert_%d", s.convertTaskCounter)
	task := &ConvertTask{
		ID:           taskID,
		Status:       "pending",
		StatusText:   "等待开始",
		TargetVer:    targetVersion,
		OutputFormat: outputFormat,
		Total:        len(npkFiles),
		Completed:    0,
		CreatedAt:    time.Now(),
		UpdatedAt:    time.Now(),
	}
	s.convertTasks[taskID] = task

	go s.runConvertNpkTask(task, npkFiles)

	respondAccepted(c, gin.H{
		"task_id":    taskID,
		"total":      len(npkFiles),
		"status_url": "/api/tools/convert-status/" + taskID,
	})
}

// getConvertStatus 获取转换任务状态
func (s *Server) getConvertStatus(c *gin.Context) {
	taskID := c.Param("taskId")

	task, exists := s.convertTasks[taskID]
	if !exists {
		respondNotFound(c, "任务不存在")
		return
	}

	respondSuccess(c, gin.H{
		"task_id":     task.ID,
		"status":      task.Status,
		"status_text": task.StatusText,
		"total":       task.Total,
		"completed":   task.Completed,
		"skipped":     task.Skipped,
		"created_at":  task.CreatedAt,
		"updated_at":  task.UpdatedAt,
		"output_path": task.OutputPath,
		"error":       task.Error,
	})
}

// convertDownload 下载转换结果
func (s *Server) convertDownload(c *gin.Context) {
	taskID := c.Param("taskId")

	task, exists := s.convertTasks[taskID]
	if !exists {
		respondNotFound(c, "任务不存在")
		return
	}

	if task.Status != "completed" {
		respondBadRequest(c, "任务尚未完成")
		return
	}

	if task.OutputPath == "" {
		respondNotFound(c, "输出文件不存在")
		return
	}

	c.Header("Content-Type", "application/zip")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=converted_%s.zip", taskID))
	c.File(task.OutputPath)
}

// scanConfigDirectory 扫描配置目录
func (s *Server) scanConfigDirectory(c *gin.Context) {
	path := c.Query("path")
	if path == "" {
		respondBadRequest(c, "缺少 path 参数")
		return
	}

	if _, err := os.Stat(path); os.IsNotExist(err) {
		respondNotFound(c, "目录不存在")
		return
	}

	entries, err := os.ReadDir(path)
	if err != nil {
		respondInternalError(c, "读取目录失败: " + err.Error())
		return
	}

	files := make([]map[string]interface{}, 0)
	for _, entry := range entries {
		info, err := entry.Info()
		if err != nil {
			continue
		}
		files = append(files, map[string]interface{}{
			"name":     entry.Name(),
			"is_dir":   entry.IsDir(),
			"size":     info.Size(),
			"modified": info.ModTime().Format(time.RFC3339),
		})
	}

	respondSuccess(c, gin.H{"path": path, "files": files})
}

// createToolConfig 创建工具配置
func (s *Server) createToolConfig(c *gin.Context) {
	var req struct {
		Name        string `json:"name" binding:"required"`
		Type        string `json:"type" binding:"required"`
		Path        string `json:"path" binding:"required"`
		Description string `json:"description"`
		Icon        string `json:"icon"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondBadRequest(c, "无效的请求: " + err.Error())
		return
	}

	toolsDir := filepath.Join(execDir, "tools")
	if _, err := os.Stat(toolsDir); os.IsNotExist(err) {
		os.MkdirAll(toolsDir, 0755)
	}

	configPath := filepath.Join(toolsDir, req.Name + ".json")
	config := map[string]interface{}{
		"name":        req.Name,
		"type":        req.Type,
		"path":        req.Path,
		"description": req.Description,
		"icon":        req.Icon,
	}

	configData, _ := json.MarshalIndent(config, "", "  ")
	if err := os.WriteFile(configPath, configData, 0644); err != nil {
		respondInternalError(c, "保存配置失败: " + err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "配置已创建"})
}

// deleteToolConfig 删除工具配置
func (s *Server) deleteToolConfig(c *gin.Context) {
	name := c.Query("name")
	if name == "" {
		respondBadRequest(c, "缺少 name 参数")
		return
	}

	toolsDir := filepath.Join(execDir, "tools")
	configPath := filepath.Join(toolsDir, name + ".json")

	if _, err := os.Stat(configPath); os.IsNotExist(err) {
		respondNotFound(c, "配置不存在")
		return
	}

	if err := os.Remove(configPath); err != nil {
		respondInternalError(c, "删除失败: " + err.Error())
		return
	}

	respondSuccess(c, gin.H{"message": "配置已删除"})
}

// runConvertNpkTask 执行 NPK 版本转换任务
func (s *Server) runConvertNpkTask(task *ConvertTask, files []*multipart.FileHeader) {
	task.Status = "running"
	task.StatusText = "正在解析 NPK..."
	task.UpdatedAt = time.Now()

	// 解析目标版本
	versionNum := 2
	switch task.TargetVer {
	case "V2": versionNum = 2
	case "V4": versionNum = 4
	case "V5": versionNum = 5
	case "V6": versionNum = 6
	}

	tmpDir, err := os.MkdirTemp("", "npk_convert_*")
	if err != nil {
		task.Status = "failed"
		task.StatusText = "创建临时目录失败"
		task.Error = err.Error()
		task.UpdatedAt = time.Now()
		return
	}
	defer os.RemoveAll(tmpDir)

	task.StatusText = "正在提取和转换 IMG..."
	task.UpdatedAt = time.Now()

	for i, file := range files {
		task.StatusText = fmt.Sprintf("正在处理 %d/%d: %s", i+1, task.Total, file.Filename)
		task.UpdatedAt = time.Now()

		f, err := file.Open()
		if err != nil { log.Printf("打开文件失败: %v", err); continue }
		data, err := io.ReadAll(f)
		f.Close()
		if err != nil { log.Printf("读取文件失败: %v", err); continue }

		reader := bytes.NewReader(data)
		npkFile, err := npk.ReadNpk(reader)
		if err != nil { log.Printf("解析 NPK 失败: %v", err); continue }

		s.convertToNpkFile(npkFile, reader, versionNum, task, file.Filename, tmpDir)

		task.Completed++
	}

	zipPath := filepath.Join(os.TempDir(), fmt.Sprintf("converted_%s.zip", task.ID))
	if err := createZipFromDir(zipPath, tmpDir); err != nil {
		task.Status = "failed"
		task.StatusText = "创建 ZIP 失败"
		task.Error = err.Error()
		task.UpdatedAt = time.Now()
		return
	}

	task.Status = "completed"
	msg := fmt.Sprintf("转换完成，成功 %d 个", task.Completed)
	if task.Skipped > 0 {
		msg += fmt.Sprintf("，跳过 %d 个（版本不兼容）", task.Skipped)
	}
	task.StatusText = msg
	task.OutputPath = zipPath
	task.UpdatedAt = time.Now()
}

// createZipFromDir 从目录创建 ZIP 文件
// convertToNpkFile 将转换后的 Album 打包为 NPK 文件
func (s *Server) convertToNpkFile(npkFile *npk.NpkFile, reader io.ReadSeeker, versionNum int, task *ConvertTask, origName string, tmpDir string) {
	convertedAlbums := make([]*npk.Album, 0, len(npkFile.Indexes))
	for _, idx := range npkFile.Indexes {
		reader.Seek(0, io.SeekStart)
		album, err := npk.ReadAlbum(reader, idx)
		if err != nil { log.Printf("[Convert] 读取 %s 失败: %v", idx.Path, err); continue }

		converted, err := s.npkSvc.ConvertImgVersionAlbum(album, versionNum)
		if err != nil { log.Printf("[Convert] %s 转换失败: %v", idx.Path, err); continue }
		convertedAlbums = append(convertedAlbums, converted)
	}

	if len(convertedAlbums) == 0 { return }
	baseName := strings.TrimSuffix(origName, filepath.Ext(origName))
	npkName := baseName + "_Ex.npk"
	npkPath := filepath.Join(tmpDir, npkName)
	if err := npk.WriteNpk(npkPath, convertedAlbums, nil, nil, 0, npkName); err != nil {
		log.Printf("[Convert] 写入 NPK %s 失败: %v", npkName, err)
	}
}

func createZipFromDir(zipPath string, srcDir string) error {
	zipFile, err := os.Create(zipPath)
	if err != nil {
		return err
	}
	defer zipFile.Close()

	zipWriter := zip.NewWriter(zipFile)
	defer zipWriter.Close()

	return filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}

		relPath, _ := filepath.Rel(srcDir, path)
		writer, err := zipWriter.Create(relPath)
		if err != nil {
			return err
		}

		file, err := os.Open(path)
		if err != nil {
			return err
		}
		defer file.Close()

		_, err = io.Copy(writer, file)
		return err
	})
}