package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultConfig(t *testing.T) {
	cfg := DefaultConfig()

	if cfg.ServerPort != 8556 {
		t.Errorf("default ServerPort = %d, want 8556", cfg.ServerPort)
	}
	if cfg.ServerHost != "0.0.0.0" {
		t.Errorf("default ServerHost = %s, want 0.0.0.0", cfg.ServerHost)
	}
}

func TestLoadSaveCycle(t *testing.T) {
	tmpDir := t.TempDir()
	configPath := filepath.Join(tmpDir, "config.json")

	cfg := DefaultConfig()
	cfg.configPath = configPath
	cfg.ServerPort = 9999
	cfg.DataDir = "/tmp/test_data"

	if err := cfg.Save(); err != nil {
		t.Fatalf("Save failed: %v", err)
	}

	loaded, err := Load(configPath)
	if err != nil {
		t.Fatalf("Load failed: %v", err)
	}

	if loaded.ServerPort != 9999 {
		t.Errorf("ServerPort = %d, want 9999", loaded.ServerPort)
	}
	if loaded.DataDir != "/tmp/test_data" {
		t.Errorf("DataDir = %s, want /tmp/test_data", loaded.DataDir)
	}
}

func TestLoadMissingFile(t *testing.T) {
	cfg, err := Load("/tmp/nonexistent_path_config.json")
	if err != nil {
		t.Fatalf("Load should create default config, got error: %v", err)
	}
	if cfg == nil {
		t.Fatal("expected non-nil config")
	}
}

func TestSetAndSave(t *testing.T) {
	tmpDir := t.TempDir()
	configPath := filepath.Join(tmpDir, "config.json")

	cfg := DefaultConfig()
	cfg.configPath = configPath
	cfg.Save()

	if err := cfg.SetAndSave("server_port", float64(7777)); err != nil {
		t.Fatalf("SetAndSave failed: %v", err)
	}

	reloaded, _ := Load(configPath)
	if reloaded.ServerPort != 7777 {
		t.Errorf("ServerPort = %d, want 7777", reloaded.ServerPort)
	}
}

func TestEnsureDirs(t *testing.T) {
	tmpDir := t.TempDir()

	cfg := DefaultConfig()
	cfg.DataDir = filepath.Join(tmpDir, "data")
	cfg.CacheDir = filepath.Join(tmpDir, "cache")

	if err := cfg.EnsureDirs(); err != nil {
		t.Fatalf("EnsureDirs failed: %v", err)
	}

	for _, dir := range []string{cfg.DataDir, cfg.CacheDir} {
		if info, err := os.Stat(dir); err != nil || !info.IsDir() {
			t.Errorf("directory %s was not created", dir)
		}
	}
}

func TestThreadSafeAccess(t *testing.T) {
	cfg := DefaultConfig()

	done := make(chan bool)
	for i := 0; i < 10; i++ {
		go func() {
			for j := 0; j < 100; j++ {
				_ = cfg.ServerPort
				cfg.Get("server_port")
			}
			done <- true
		}()
	}

	for i := 0; i < 10; i++ {
		<-done
	}
}
