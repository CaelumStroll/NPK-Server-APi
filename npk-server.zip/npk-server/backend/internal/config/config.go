package config

import (
	"encoding/json"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

// Config 配置
type Config struct {
	mu sync.RWMutex

	// 配置文件路径
	configPath string

	// 服务器配置
	ServerPort    int    `json:"server_port"`
	ServerHost    string `json:"server_host"`
	AllowOrigins  string `json:"allow_origins"`

	// 数据目录
	DataDir    string `json:"data_dir"`
	CacheDir   string `json:"cache_dir"`
	DatabasePath string `json:"database_path"`

	// NPK 配置
	NpkDirs    []string `json:"npk_dirs"`
	AutoScan   bool     `json:"auto_scan"`
	ScanInterval int    `json:"scan_interval"` // 秒

	// 视频目录配置
	VideoDirs  []string `json:"video_dirs"`

	// 音乐目录配置
	MusicDirs  []string `json:"music_dirs"`

	// 音效目录配置
	SoundPackDirs []string `json:"soundpack_dirs"`

	// audio.xml 配置路径
	AudioXmlPath string `json:"audio_xml_path"`

	// 缓存配置
	EnableCache     bool `json:"enable_cache"`
	CacheMaxSize    int  `json:"cache_max_size"`    // MB
	ThumbnailSize   int  `json:"thumbnail_size"`    // 像素
	MaxCacheItems   int  `json:"max_cache_items"`

	// 性能配置
	MaxGoroutines   int  `json:"max_goroutines"`
	RequestTimeout  int  `json:"request_timeout"` // 秒

	// 日志配置
	LogLevel    string `json:"log_level"`
	LogFile     string `json:"log_file"`
	EnableLogWS bool   `json:"enable_log_ws"` // 是否启用日志 WebSocket

	// WebSocket 配置
	WsStatsInterval int `json:"ws_stats_interval"` // 系统状态推送间隔（秒）

	// UI 配置
	Language          string      `json:"language"`
	SplashAvatarImage string      `json:"splash_avatar_image"`
	SplashIntroText   string      `json:"splash_intro_text"`
	DashboardGroups   interface{} `json:"dashboard_groups,omitempty"`
	DashboardActiveGroup string   `json:"dashboard_active_group,omitempty"`
}

// DefaultConfig 默认配置
func DefaultConfig() *Config {
	return &Config{
		ServerPort:     8556,
		ServerHost:     "0.0.0.0",
		AllowOrigins:   "*",
		DataDir:        "./data",
		CacheDir:       "./cache",
		DatabasePath:   "./data/npk.db",
		NpkDirs:        []string{},
		VideoDirs:      []string{},
		MusicDirs:      []string{},
		SoundPackDirs:  []string{},
		AutoScan:       true,
		ScanInterval:   300,
		EnableCache:    true,
		CacheMaxSize:   500,
		ThumbnailSize:  128,
		MaxCacheItems:  1000,
		MaxGoroutines:  10,
		RequestTimeout: 30,
		LogLevel:        "info",
		LogFile:         "",
		EnableLogWS:     true,
		WsStatsInterval: 3,
		Language:         "zh-CN",
		SplashAvatarImage: "/avatars/avatar_01.JPG",
		SplashIntroText:  "",
	}
}

// Load 从文件加载配置
func Load(path string) (*Config, error) {
	cfg := DefaultConfig()
	cfg.configPath = path

	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			// 文件不存在，使用默认配置并保存
			if err := cfg.Save(); err != nil {
				return nil, err
			}
			return cfg, nil
		}
		return nil, err
	}

	if err := json.Unmarshal(data, cfg); err != nil {
		return nil, err
	}

	// 自动推导缺失路径
	cfg.DerivePaths()

	return cfg, nil
}

// Save 保存配置到文件
func (c *Config) Save() error {
	c.mu.Lock()
	defer c.mu.Unlock()

	return c.saveUnlocked()
}

// DnfBasePath 根据第一个 NPK 目录推导 DNF 根目录
func (c *Config) DnfBasePath() string {
	for _, d := range c.NpkDirs {
		if d != "" {
			parent := strings.TrimRight(d, "/\\")
			// 去掉末尾的 ImagePacks2 或 imagepacks2
			parent = strings.TrimSuffix(strings.TrimSuffix(parent, "/ImagePacks2"), "\\ImagePacks2")
			parent = strings.TrimSuffix(strings.TrimSuffix(parent, "/imagepacks2"), "\\imagepacks2")
			if parent != d { // 成功剥离了 ImagePacks2
				return parent
			}
		}
	}
	return ""
}

// DerivePaths 从 NPK 根目录推导其他路径（如果未手动设置则自动填充）
func (c *Config) DerivePaths() {
	base := c.DnfBasePath()
	if base == "" {
		return
	}
	if len(c.MusicDirs) == 0 {
		c.MusicDirs = []string{filepath.Join(base, "Music")}
	}
	if len(c.SoundPackDirs) == 0 {
		c.SoundPackDirs = []string{filepath.Join(base, "SoundPacks")}
	}
	if len(c.VideoDirs) == 0 {
		c.VideoDirs = []string{filepath.Join(base, "Video")}
	}
	if c.AudioXmlPath == "" {
		c.AudioXmlPath = filepath.Join(base, "Audio.xml")
	}
}

// saveUnlocked 内部保存方法（不加锁）
func (c *Config) saveUnlocked() error {
	// 每次保存前自动推导路径（无则补，有则不动）
	c.DerivePaths()

	if c.configPath == "" {
		c.configPath = "config.json"
	}

	// 确保目录存在
	dir := filepath.Dir(c.configPath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	data, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}

	log.Printf("[config] 保存到 %s (npk_dirs=%v)", c.configPath, c.NpkDirs)
	return os.WriteFile(c.configPath, data, 0644)
}

// Get 获取配置值
func (c *Config) Get(key string) interface{} {
	c.mu.RLock()
	defer c.mu.RUnlock()

	switch key {
	case "server_port":
		return c.ServerPort
	case "server_host":
		return c.ServerHost
	case "data_dir":
		return c.DataDir
	case "cache_dir":
		return c.CacheDir
	case "npk_dirs":
		return c.NpkDirs
	case "video_dirs":
		return c.VideoDirs
	case "music_dirs":
		return c.MusicDirs
	case "soundpack_dirs":
		return c.SoundPackDirs
	case "audio_xml_path":
		return c.AudioXmlPath
	case "auto_scan":
		return c.AutoScan
	case "thumbnail_size":
		return c.ThumbnailSize
	case "cache_max_size":
		return c.CacheMaxSize
	case "language":
		return c.Language
	case "splash_avatar_image":
		return c.SplashAvatarImage
	case "splash_intro_text":
		return c.SplashIntroText
	case "dashboard_groups":
		return c.DashboardGroups
	case "dashboard_active_group":
		return c.DashboardActiveGroup
	default:
		return nil
	}
}

// Set 设置配置值
func (c *Config) Set(key string, value interface{}) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	switch key {
	case "server_port":
		switch v := value.(type) {
		case int:
			c.ServerPort = v
		case float64:
			c.ServerPort = int(v)
		}
	case "server_host":
		if v, ok := value.(string); ok {
			c.ServerHost = v
		}
	case "data_dir":
		if v, ok := value.(string); ok {
			c.DataDir = v
		}
	case "cache_dir":
		if v, ok := value.(string); ok {
			c.CacheDir = v
		}
	case "npk_dirs":
		switch v := value.(type) {
		case []string:
			c.NpkDirs = v
		case []interface{}:
			dirs := make([]string, 0, len(v))
			for _, item := range v {
				if s, ok := item.(string); ok {
					dirs = append(dirs, s)
				}
			}
			c.NpkDirs = dirs
		}
		c.DerivePaths() // 自动推导其他路径
	case "video_dirs":
		switch v := value.(type) {
		case []string:
			c.VideoDirs = v
		case []interface{}:
			dirs := make([]string, 0, len(v))
			for _, item := range v {
				if s, ok := item.(string); ok {
					dirs = append(dirs, s)
				}
			}
			c.VideoDirs = dirs
		}
	case "music_dirs":
		switch v := value.(type) {
		case []string:
			c.MusicDirs = v
		case []interface{}:
			dirs := make([]string, 0, len(v))
			for _, item := range v {
				if s, ok := item.(string); ok {
					dirs = append(dirs, s)
				}
			}
			c.MusicDirs = dirs
		}
	case "soundpack_dirs":
		switch v := value.(type) {
		case []string:
			c.SoundPackDirs = v
		case []interface{}:
			dirs := make([]string, 0, len(v))
			for _, item := range v {
				if s, ok := item.(string); ok {
					dirs = append(dirs, s)
				}
			}
			c.SoundPackDirs = dirs
		}
	case "audio_xml_path":
		if v, ok := value.(string); ok {
			c.AudioXmlPath = v
		}
	case "auto_scan":
		switch v := value.(type) {
		case bool:
			c.AutoScan = v
		}
	case "thumbnail_size":
		switch v := value.(type) {
		case int:
			c.ThumbnailSize = v
		case float64:
			c.ThumbnailSize = int(v)
		}
	case "cache_max_size":
		switch v := value.(type) {
		case int:
			c.CacheMaxSize = v
		case float64:
			c.CacheMaxSize = int(v)
		}
	case "ws_stats_interval":
		switch v := value.(type) {
		case int:
			c.WsStatsInterval = v
		case float64:
			c.WsStatsInterval = int(v)
		}
	case "enable_log_ws":
		switch v := value.(type) {
		case bool:
			c.EnableLogWS = v
		}
	case "language":
		if v, ok := value.(string); ok {
			c.Language = v
		}
	case "splash_avatar_image":
		if v, ok := value.(string); ok {
			c.SplashAvatarImage = v
		}
	case "splash_intro_text":
		if v, ok := value.(string); ok {
			c.SplashIntroText = v
		}
	case "dashboard_groups":
		c.DashboardGroups = value
	case "dashboard_active_group":
		if v, ok := value.(string); ok {
			c.DashboardActiveGroup = v
		}
	}

	return nil
}

// SetAndSave 设置配置值并保存
func (c *Config) SetAndSave(key string, value interface{}) error {
	if err := c.Set(key, value); err != nil {
		return err
	}
	return c.Save()
}

// AddNpkDir 添加 NPK 目录
func (c *Config) AddNpkDir(dir string) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	// 检查是否已存在
	for _, d := range c.NpkDirs {
		if d == dir {
			return nil
		}
	}

	c.NpkDirs = append(c.NpkDirs, dir)
	return c.saveUnlocked()
}

// RemoveNpkDir 移除 NPK 目录
func (c *Config) RemoveNpkDir(dir string) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	for i, d := range c.NpkDirs {
		if d == dir {
			c.NpkDirs = append(c.NpkDirs[:i], c.NpkDirs[i+1:]...)
			break
		}
	}

	return c.saveUnlocked()
}

// EnsureDirs 确保必要的目录存在
func (c *Config) EnsureDirs() error {
	c.mu.Lock()
	defer c.mu.Unlock()

	dirs := []string{c.DataDir, c.CacheDir}
	for _, dir := range dirs {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return err
		}
	}
	return nil
}

// Clone 克隆配置
func (c *Config) Clone() *Config {
	if c == nil {
		return nil
	}
	c.mu.RLock()
	defer c.mu.RUnlock()

	dirs := make([]string, len(c.NpkDirs))
	copy(dirs, c.NpkDirs)

	videoDirs := make([]string, len(c.VideoDirs))
	copy(videoDirs, c.VideoDirs)

	musicDirs := make([]string, len(c.MusicDirs))
	copy(musicDirs, c.MusicDirs)

	soundPackDirs := make([]string, len(c.SoundPackDirs))
	copy(soundPackDirs, c.SoundPackDirs)

	return &Config{
		configPath:     c.configPath,
		ServerPort:     c.ServerPort,
		ServerHost:     c.ServerHost,
		AllowOrigins:   c.AllowOrigins,
		DataDir:        c.DataDir,
		CacheDir:       c.CacheDir,
		DatabasePath:   c.DatabasePath,
		NpkDirs:        dirs,
		VideoDirs:      videoDirs,
		MusicDirs:      musicDirs,
		SoundPackDirs:  soundPackDirs,
		AutoScan:       c.AutoScan,
		ScanInterval:   c.ScanInterval,
		EnableCache:    c.EnableCache,
		CacheMaxSize:   c.CacheMaxSize,
		ThumbnailSize:  c.ThumbnailSize,
		MaxCacheItems:  c.MaxCacheItems,
		MaxGoroutines:  c.MaxGoroutines,
		RequestTimeout: c.RequestTimeout,
		LogLevel:       c.LogLevel,
		LogFile:        c.LogFile,
		EnableLogWS:    c.EnableLogWS,
		WsStatsInterval: c.WsStatsInterval,
		AudioXmlPath:   c.AudioXmlPath,
	}
}
