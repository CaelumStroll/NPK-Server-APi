package music

import (
	"encoding/binary"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// AudioFile 音频文件信息结构体
type AudioFile struct {
	Name      string     // 文件名
	Path      string     // 文件完整路径
	Size      int64      // 文件大小（字节）
	Format    string     // 文件格式（如 "MP3", "OGG", "FLAC", "WAV" 等）
	Info      *AudioInfo // 音频详细信息
	ScannedAt time.Time  // 扫描时间
}

// AudioInfo 音频元信息
type AudioInfo struct {
	Duration   float64 // 时长（秒）
	SampleRate int     // 采样率（Hz）
	Channels   int     // 声道数
	Bitrate    int     // 比特率（kbps）
	FileSize   int64   // 文件大小
	Format     string  // 格式
}

var supportedAudioExtensions = map[string]bool{
	".mp3":  true,
	".ogg":  true,
	".flac": true,
	".wav":  true,
	".m4a":  true,
	".aac":  true,
	".wma":  true,
	".opus": true,
}

const audioHeaderReadSize = 256 * 1024

// ScanMusicDir 递归扫描目录中的音频文件
func ScanMusicDir(dir string) ([]AudioFile, error) {
	info, err := os.Stat(dir)
	if err != nil {
		return nil, fmt.Errorf("无法访问目录: %w", err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("路径不是目录: %s", dir)
	}

	var files []AudioFile
	now := time.Now()

	err = filepath.WalkDir(dir, func(path string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		if d.IsDir() {
			return nil
		}

		ext := strings.ToLower(filepath.Ext(d.Name()))
		if !supportedAudioExtensions[ext] {
			return nil
		}

		fileInfo, err := d.Info()
		if err != nil {
			return nil
		}

		af := AudioFile{
			Name:      d.Name(),
			Path:      path,
			Size:      fileInfo.Size(),
			Format:    GetAudioFormat(d.Name()),
			ScannedAt: now,
		}

		header, err := readFileHeader(path, audioHeaderReadSize)
		if err == nil && len(header) > 0 {
			af.Info = ParseAudioInfo(header, af.Size, af.Format)
		}

		files = append(files, af)
		return nil
	})

	if err != nil {
		return nil, fmt.Errorf("扫描目录失败: %w", err)
	}

	return files, nil
}

func readFileHeader(path string, size int) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	buf := make([]byte, size)
	n, err := file.Read(buf)
	if err != nil && n == 0 {
		return nil, err
	}
	return buf[:n], nil
}

// GetAudioFormat 根据文件扩展名获取音频格式名称
func GetAudioFormat(filename string) string {
	ext := strings.ToLower(filepath.Ext(filename))
	switch ext {
	case ".mp3":
		return "MP3"
	case ".ogg":
		return "OGG"
	case ".flac":
		return "FLAC"
	case ".wav":
		return "WAV"
	case ".m4a":
		return "M4A"
	case ".aac":
		return "AAC"
	case ".wma":
		return "WMA"
	case ".opus":
		return "OPUS"
	default:
		return strings.ToUpper(strings.TrimPrefix(ext, "."))
	}
}

// ParseAudioInfo 解析音频文件头部获取元信息
func ParseAudioInfo(data []byte, fileSize int64, format string) *AudioInfo {
	switch format {
	case "MP3":
		return parseMP3Info(data, fileSize)
	case "FLAC":
		return parseFLACInfo(data, fileSize)
	case "OGG", "OPUS":
		return parseOGGInfo(data, fileSize)
	case "WAV":
		return parseWAVInfo(data, fileSize)
	case "M4A", "AAC":
		return parseM4AInfo(data, fileSize)
	default:
		return &AudioInfo{FileSize: fileSize, Format: format}
	}
}

// MP3 frame header bitrate table (kbps) for MPEG1 Layer3
var mp3Bitrates = [16]int{0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0}
var mp3SampleRates = [4]int{44100, 48000, 32000, 0}

func parseMP3Info(data []byte, fileSize int64) *AudioInfo {
	info := &AudioInfo{FileSize: fileSize, Format: "MP3"}

	// skip ID3v2 tag
	offset := 0
	if len(data) > 10 && string(data[0:3]) == "ID3" {
		// ID3v2: size is 4 bytes synchsafe integer at bytes 6-9
		tagSize := int(data[6])<<21 | int(data[7])<<14 | int(data[8])<<7 | int(data[9])
		offset = tagSize + 10
	}

	// find first valid MPEG frame sync (11 bits of 1)
	for offset < len(data)-4 {
		if data[offset] == 0xFF && (data[offset+1]&0xE0) == 0xE0 {
			header := binary.BigEndian.Uint32(data[offset : offset+4])
			version := (header >> 19) & 0x3
			layer := (header >> 17) & 0x3
			bitrateIndex := (header >> 12) & 0xF
			sampleRateIndex := (header >> 10) & 0x3
			// channelMode := (header >> 6) & 0x3

			if version != 3 || layer != 1 { // MPEG1 Layer3
				offset++
				continue
			}

			if bitrateIndex > 0 && bitrateIndex < 16 && sampleRateIndex < 3 {
				bitrate := mp3Bitrates[bitrateIndex]
				sampleRate := mp3SampleRates[sampleRateIndex]

				if bitrate > 0 && sampleRate > 0 {
					info.Bitrate = bitrate
					info.SampleRate = sampleRate
					info.Channels = 2
					if fileSize > 0 && bitrate > 0 {
						info.Duration = float64(fileSize-int64(offset)) * 8 / float64(bitrate*1000)
					}
					return info
				}
			}
		}
		offset++
	}

	return info
}

func parseFLACInfo(data []byte, fileSize int64) *AudioInfo {
	info := &AudioInfo{FileSize: fileSize, Format: "FLAC"}

	if len(data) < 42 || string(data[0:4]) != "fLaC" {
		return info
	}

	// parse STREAMINFO block
	offset := 4
	for offset < len(data)-4 {
		isLast := (data[offset] & 0x80) != 0
		blockType := data[offset] & 0x7F
		blockSize := int(data[offset+1])<<16 | int(data[offset+2])<<8 | int(data[offset+3])

		if blockType == 0 && offset+4+blockSize <= len(data) { // STREAMINFO
			streamInfo := data[offset+4 : offset+4+blockSize]
			if len(streamInfo) >= 18 {
				sampleRate := int(streamInfo[10])<<12 | int(streamInfo[11])<<4 | int(streamInfo[12])>>4
				channels := (int(streamInfo[12])&0x0E)>>1 + 1
				bitsPerSample := (int(streamInfo[12])&0x01)<<4 | (int(streamInfo[13])>>4&0x0F) + 1
				totalSamples := int64(streamInfo[13]&0x0F)<<32 | int64(streamInfo[14])<<24 | int64(streamInfo[15])<<16 | int64(streamInfo[16])<<8 | int64(streamInfo[17])

				info.SampleRate = sampleRate
				info.Channels = channels
				_ = bitsPerSample
				if sampleRate > 0 && totalSamples > 0 {
					info.Duration = float64(totalSamples) / float64(sampleRate)
				}
				if info.Duration > 0 && fileSize > 0 {
					info.Bitrate = int(float64(fileSize) * 8 / info.Duration / 1000)
				}
			}
			return info
		}

		offset += 4 + blockSize
		if isLast {
			break
		}
	}

	return info
}

func parseOGGInfo(data []byte, fileSize int64) *AudioInfo {
	info := &AudioInfo{FileSize: fileSize, Format: "OGG"}

	if len(data) < 27 || string(data[0:4]) != "OggS" {
		return info
	}

	// search for Vorbis identification header
	offset := 0
	for offset < len(data)-7 {
		// find "vorbis" signature in an Ogg page
		if string(data[offset:offset+4]) == "OggS" && offset+27 <= len(data) {
			pageSegments := int(data[offset+26])
			if offset+27+pageSegments > len(data) {
				break
			}

			pageDataOffset := offset + 27 + pageSegments
			if pageDataOffset+7 > len(data) {
				break
			}

			packetType := data[pageDataOffset]
			if packetType == 1 && string(data[pageDataOffset:pageDataOffset+7]) == "\x01vorbis" && pageDataOffset+11 <= len(data) {
				// Vorbis identification header
				channels := int(data[pageDataOffset+11])
				sampleRate := int(binary.LittleEndian.Uint32(data[pageDataOffset+12 : pageDataOffset+16]))
				// maxBitrate := int(binary.LittleEndian.Uint32(data[pageDataOffset+16 : pageDataOffset+20]))
				// nomBitrate := int(binary.LittleEndian.Uint32(data[pageDataOffset+20 : pageDataOffset+24]))

				info.SampleRate = sampleRate
				info.Channels = channels

				// estimate duration from last page
				if sampleRate > 0 && len(data) >= 27 {
					// find last Ogg page for granule position
					lastGranule := int64(0)
					for searchOff := 0; searchOff < len(data)-27; searchOff++ {
						if string(data[searchOff:searchOff+4]) == "OggS" && searchOff+14 <= len(data) {
							granule := int64(binary.LittleEndian.Uint64(data[searchOff+6 : searchOff+14]))
							if granule > lastGranule {
								lastGranule = granule
							}
						}
					}
					if lastGranule > 0 {
						info.Duration = float64(lastGranule) / float64(sampleRate)
					}
				}
				return info
			}
		}

		// jump to next Ogg page
		if string(data[offset:offset+4]) == "OggS" && offset+27 <= len(data) {
			pageSegments := int(data[offset+26])
			totalLen := 0
			for i := 0; i < pageSegments && offset+27+i < len(data); i++ {
				totalLen += int(data[offset+27+i])
			}
			offset += 27 + pageSegments + totalLen
		} else {
			break
		}
	}

	return info
}

func parseWAVInfo(data []byte, fileSize int64) *AudioInfo {
	info := &AudioInfo{FileSize: fileSize, Format: "WAV"}

	if len(data) < 44 || string(data[0:4]) != "RIFF" || string(data[8:12]) != "WAVE" {
		return info
	}

	// find fmt chunk
	offset := 12
	for offset < len(data)-8 {
		chunkID := string(data[offset : offset+4])
		chunkSize := int(binary.LittleEndian.Uint32(data[offset+4 : offset+8]))

		if chunkID == "fmt " && offset+8+16 <= len(data) {
			fmtData := data[offset+8 : offset+8+chunkSize]
			audioFormat := int(binary.LittleEndian.Uint16(fmtData[0:2]))
			channels := int(binary.LittleEndian.Uint16(fmtData[2:4]))
			sampleRate := int(binary.LittleEndian.Uint32(fmtData[4:8]))
			byteRate := int(binary.LittleEndian.Uint32(fmtData[8:12]))
			// blockAlign := int(binary.LittleEndian.Uint16(fmtData[12:14]))
			// bitsPerSample := int(binary.LittleEndian.Uint16(fmtData[14:16]))

			info.SampleRate = sampleRate
			info.Channels = channels
			if audioFormat == 1 { // PCM
				info.Bitrate = byteRate * 8 / 1000
			}
		}

		if chunkID == "data" && info.SampleRate > 0 {
			dataSize := chunkSize
			if info.Bitrate > 0 {
				info.Duration = float64(dataSize) * 8 / float64(info.Bitrate*1000)
			}
		}

		offset += 8 + chunkSize
		if chunkSize%2 != 0 {
			offset++
		}
	}

	return info
}

func parseM4AInfo(data []byte, fileSize int64) *AudioInfo {
	info := &AudioInfo{FileSize: fileSize, Format: "M4A"}

	if len(data) < 8 {
		return info
	}

	// parse ISO base media file format (MP4/M4A boxes)
	offset := 0
	for offset < len(data)-8 {
		boxSize := int(binary.BigEndian.Uint32(data[offset : offset+4]))
		boxType := string(data[offset+4 : offset+8])

		if boxSize < 8 || offset+boxSize > len(data) {
			break
		}

		if boxType == "moov" || boxType == "trak" || boxType == "mdia" || boxType == "minf" || boxType == "stbl" {
			// recurse into container boxes
			parseMP4Boxes(data[offset+8:offset+boxSize], info)
		}

		if boxType == "mdhd" && offset+8+24 <= len(data) {
			mdhdData := data[offset+8 : offset+8+24]
			version := mdhdData[0]
			if version == 0 {
				// timescale at offset 12, duration at offset 16
				timescale := int(binary.BigEndian.Uint32(mdhdData[12:16]))
				duration := int(binary.BigEndian.Uint32(mdhdData[16:20]))
				if timescale > 0 {
					info.Duration = float64(duration) / float64(timescale)
				}
			}
		}

		offset += int(boxSize)
	}

	if info.Duration > 0 && fileSize > 0 {
		info.Bitrate = int(float64(fileSize) * 8 / info.Duration / 1000)
	}

	return info
}

func parseMP4Boxes(data []byte, info *AudioInfo) {
	offset := 0
	for offset < len(data)-8 {
		boxSize := int(binary.BigEndian.Uint32(data[offset : offset+4]))
		boxType := string(data[offset+4 : offset+8])

		if boxSize < 8 || offset+boxSize > len(data) {
			break
		}

		if boxType == "mp4a" && offset+8+16 <= len(data) {
			mp4aData := data[offset+8 : offset+8+min(boxSize-8, 16)]
			if len(mp4aData) >= 16 {
				info.Channels = int(binary.BigEndian.Uint16(mp4aData[8:10]))
				info.SampleRate = int(binary.BigEndian.Uint32(mp4aData[12:16]) >> 16)
			}
		}

		offset += int(boxSize)
	}
}
