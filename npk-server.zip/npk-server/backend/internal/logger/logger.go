package logger

import (
	"io"
	"log"
	"os"
	"sync"
)

// LogHub 日志中心，支持多路输出
type LogHub struct {
	mu        sync.RWMutex
	writers   map[string]*LogWriter
	original  io.Writer
}

// LogWriter 日志写入器
type LogWriter struct {
	ID      string
	Ch      chan string
	Closed  bool
}

var (
	instance *LogHub
	once     sync.Once
)

// GetHub 获取单例
func GetHub() *LogHub {
	once.Do(func() {
		instance = &LogHub{
			writers:  make(map[string]*LogWriter),
			original: os.Stdout,
		}
		// 重定向标准 log 输出到 hub
		log.SetOutput(instance)
	})
	return instance
}

// Write 实现 io.Writer 接口
func (h *LogHub) Write(p []byte) (n int, err error) {
	// 写入原始输出
	n, err = h.original.Write(p)
	if err != nil {
		return n, err
	}

	// 广播到所有注册的 writer
	h.mu.RLock()
	writers := make([]*LogWriter, 0, len(h.writers))
	for _, w := range h.writers {
		if !w.Closed {
			writers = append(writers, w)
		}
	}
	h.mu.RUnlock()

	line := string(p)
	for _, w := range writers {
		select {
		case w.Ch <- line:
		default:
			// channel 满了，丢弃
		}
	}

	return n, nil
}

// Register 注册一个新的日志接收器
func (h *LogHub) Register(id string) *LogWriter {
	h.mu.Lock()
	defer h.mu.Unlock()

	// 如果已存在，先关闭旧的
	if old, exists := h.writers[id]; exists {
		old.Closed = true
		close(old.Ch)
	}

	writer := &LogWriter{
		ID: id,
		Ch: make(chan string, 100),
	}
	h.writers[id] = writer
	return writer
}

// Unregister 注销日志接收器
func (h *LogHub) Unregister(id string) {
	h.mu.Lock()
	defer h.mu.Unlock()

	if w, exists := h.writers[id]; exists {
		w.Closed = true
		close(w.Ch)
		delete(h.writers, id)
	}
}
