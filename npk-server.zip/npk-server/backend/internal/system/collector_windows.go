//go:build windows
// +build windows

package system

import (
	"os/exec"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Stats struct {
	CPUPercent    float64 `json:"cpu_percent"`
	MemPercent    float64 `json:"mem_percent"`
	MemUsedGB     float64 `json:"mem_used_gb"`
	MemTotalGB    float64 `json:"mem_total_gb"`
	DiskPercent   float64 `json:"disk_percent"`
	DiskUsedGB    float64 `json:"disk_used_gb"`
	DiskTotalGB   float64 `json:"disk_total_gb"`
	Goroutines    int     `json:"goroutines"`
	HeapAllocMB   float64 `json:"heap_alloc_mb"`
	HeapSysMB     float64 `json:"heap_sys_mb"`
	UptimeSeconds int64   `json:"uptime_seconds"`
}

type Collector struct {
	mu         sync.RWMutex
	stats      Stats
	startTime  time.Time
	cacheStats func() map[string]interface{}
}

func NewCollector() *Collector {
	return &Collector{
		startTime: time.Now(),
	}
}

func (c *Collector) SetCacheStatsFunc(fn func() map[string]interface{}) {
	c.cacheStats = fn
}

func (c *Collector) Collect() Stats {
	stats := Stats{
		UptimeSeconds: int64(time.Since(c.startTime).Seconds()),
		Goroutines:    runtime.NumGoroutine(),
	}

	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	stats.HeapAllocMB = float64(m.HeapAlloc) / 1024 / 1024
	stats.HeapSysMB = float64(m.HeapSys) / 1024 / 1024

	// Windows 系统信息采集
	stats.MemTotalGB, stats.MemUsedGB, stats.MemPercent = readMemInfoWindows()
	stats.DiskTotalGB, stats.DiskUsedGB, stats.DiskPercent = readDiskInfoWindows()
	stats.CPUPercent = readCPUWindows()

	c.mu.Lock()
	c.stats = stats
	c.mu.Unlock()

	return stats
}

func (c *Collector) GetStats() Stats {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.stats
}

func (c *Collector) CollectWithCache() map[string]interface{} {
	stats := c.Collect()

	result := map[string]interface{}{
		"cpu_percent":    round2(stats.CPUPercent),
		"mem_percent":    round2(stats.MemPercent),
		"mem_used":      round2(stats.MemUsedGB),
		"mem_total":     round2(stats.MemTotalGB),
		"disk_percent":  round2(stats.DiskPercent),
		"disk_used":    round2(stats.DiskUsedGB),
		"disk_total":   round2(stats.DiskTotalGB),
		"goroutines":    stats.Goroutines,
		"heap_alloc_mb": round2(stats.HeapAllocMB),
		"heap_sys_mb":   round2(stats.HeapSysMB),
		"uptime_seconds": stats.UptimeSeconds,
	}

	if c.cacheStats != nil {
		cacheData := c.cacheStats()
		size := toInt(cacheData["size"])
		maxSize := toInt(cacheData["max_size"])
		count := toInt(cacheData["count"])
		hits := toInt64(cacheData["hits"])
		misses := toInt64(cacheData["misses"])
		hitRate := toFloat64(cacheData["hit_rate"])

		result["cache_used_mb"] = round2(float64(size) / 1024 / 1024)
		result["cache_size"] = size
		result["cache_max_size"] = maxSize
		result["cache_max_size_mb"] = round2(float64(maxSize) / 1024 / 1024)
		if maxSize > 0 {
			result["cache_percent"] = round2(float64(size) * 100 / float64(maxSize))
		} else {
			result["cache_percent"] = 0
		}
		result["cache_count"] = count
		result["cache_hits"] = hits
		result["cache_misses"] = misses
		result["cache_hit_rate"] = hitRate
	} else {
		result["cache_used_mb"] = 0
		result["cache_size"] = 0
		result["cache_max_size"] = 0
		result["cache_max_size_mb"] = 0
		result["cache_percent"] = 0
		result["cache_count"] = 0
		result["cache_hits"] = 0
		result["cache_misses"] = 0
		result["cache_hit_rate"] = 0
	}

	return result
}

func (c *Collector) GetStatsWithCache() map[string]interface{} {
	return c.CollectWithCache()
}

// ==================== Windows ====================

func readMemInfoWindows() (totalGB, usedGB, percent float64) {
	// 使用 wmic 获取物理内存信息
	cmd := exec.Command("wmic", "OS", "get", "TotalVisibleMemorySize,FreePhysicalMemory", "/format:list")
	out, err := cmd.Output()
	if err != nil {
		// 回退到 Go 运行时数据
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		totalGB = float64(m.Sys) / 1024 / 1024 / 1024
		usedGB = float64(m.HeapAlloc) / 1024 / 1024 / 1024
		percent = float64(m.HeapAlloc) * 100 / float64(m.Sys)
		return
	}

	lines := strings.Split(string(out), "\n")
	var totalKB, freeKB uint64

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "TotalVisibleMemorySize=") {
			val, _ := strconv.ParseUint(strings.TrimPrefix(line, "TotalVisibleMemorySize="), 10, 64)
			totalKB = val
		} else if strings.HasPrefix(line, "FreePhysicalMemory=") {
			val, _ := strconv.ParseUint(strings.TrimPrefix(line, "FreePhysicalMemory="), 10, 64)
			freeKB = val
		}
	}

	if totalKB > 0 {
		usedKB := totalKB - freeKB
		totalGB = float64(totalKB) / 1024 / 1024
		usedGB = float64(usedKB) / 1024 / 1024
		percent = float64(usedKB) * 100 / float64(totalKB)
	}
	return
}

func readDiskInfoWindows() (totalGB, usedGB, percent float64) {
	// 使用 wmic 获取磁盘信息
	cmd := exec.Command("wmic", "logicaldisk", "where", "DeviceID='C:'", "get", "Size,FreeSpace", "/format:list")
	out, err := cmd.Output()
	if err != nil {
		return 0, 0, 0
	}

	lines := strings.Split(string(out), "\n")
	var totalBytes, freeBytes uint64

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "Size=") && !strings.HasPrefix(line, "FreeSpace=") {
			val, _ := strconv.ParseUint(strings.TrimPrefix(line, "Size="), 10, 64)
			totalBytes = val
		} else if strings.HasPrefix(line, "FreeSpace=") {
			val, _ := strconv.ParseUint(strings.TrimPrefix(line, "FreeSpace="), 10, 64)
			freeBytes = val
		}
	}

	if totalBytes > 0 {
		usedBytes := totalBytes - freeBytes
		totalGB = float64(totalBytes) / 1024 / 1024 / 1024
		usedGB = float64(usedBytes) / 1024 / 1024 / 1024
		percent = float64(usedBytes) * 100 / float64(totalBytes)
	}
	return
}

func readCPUWindows() float64 {
	// 使用 wmic 获取 CPU 使用率
	cmd := exec.Command("wmic", "cpu", "get", "loadpercentage", "/format:list")
	out, err := cmd.Output()
	if err != nil {
		return 0
	}

	lines := strings.Split(string(out), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "LoadPercentage=") {
			val, _ := strconv.ParseFloat(strings.TrimPrefix(line, "LoadPercentage="), 64)
			return val
		}
	}
	return 0
}

// ==================== 辅助函数 ====================

var BuildInfo, _ = debug.ReadBuildInfo()

func round2(v float64) float64 {
	return float64(int(v*100)) / 100
}

func toInt(v interface{}) int {
	switch val := v.(type) {
	case int:
		return val
	case int64:
		return int(val)
	case int32:
		return int(val)
	case float64:
		return int(val)
	case float32:
		return int(val)
	default:
		return 0
	}
}

func toInt64(v interface{}) int64 {
	switch val := v.(type) {
	case int64:
		return val
	case int:
		return int64(val)
	case int32:
		return int64(val)
	case float64:
		return int64(val)
	case float32:
		return int64(val)
	default:
		return 0
	}
}

func toFloat64(v interface{}) float64 {
	switch val := v.(type) {
	case float64:
		return val
	case float32:
		return float64(val)
	case int:
		return float64(val)
	case int64:
		return float64(val)
	default:
		return 0
	}
}
