//go:build !linux && !darwin
// +build !linux,!darwin

package system

// readMemInfo 非 Linux/Darwin 平台的内存信息读取（stub）
func readMemInfo() (totalGB, usedGB, percent float64) {
	return 0, 0, 0
}

// readDiskInfo 非 Linux/Darwin 平台的磁盘信息读取（stub）
func readDiskInfo(path string) (totalGB, usedGB, percent float64) {
	return 0, 0, 0
}

// readCPU 非 Linux/Darwin 平台的 CPU 使用率读取（stub）
func readCPU() float64 {
	return 0
}
