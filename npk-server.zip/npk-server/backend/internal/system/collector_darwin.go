//go:build darwin
// +build darwin

package system

import (
	"bufio"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"syscall"
)

func readMemInfo() (totalGB, usedGB, percent float64) {
	// 使用 sysctl 获取总内存
	totalOut, err := exec.Command("sysctl", "-n", "hw.memsize").Output()
	if err != nil {
		return
	}
	totalBytes, _ := strconv.ParseUint(strings.TrimSpace(string(totalOut)), 10, 64)
	if totalBytes == 0 {
		return
	}

	// 使用 vm_stat 获取页面信息
	vmOut, err := exec.Command("vm_stat").Output()
	if err != nil {
		return
	}

	// 解析页面大小（vm_stat 第一行）
	pageSize := uint64(4096)
	firstLine := strings.Split(string(vmOut), "\n")[0]
	if psStr := strings.TrimPrefix(firstLine, "Mach Virtual Memory Statistics: (page size of "); psStr != firstLine {
		psStr = strings.TrimSuffix(psStr, " bytes)")
		if v, err := strconv.ParseUint(strings.TrimSpace(psStr), 10, 64); err == nil && v > 0 {
			pageSize = v
		}
	}

	// 解析各类页面计数
	var activePages, wiredPages, speculativePages uint64
	for _, line := range strings.Split(string(vmOut), "\n") {
		// 去掉行尾的 "."
		line = strings.TrimRight(line, ".")
		fields := strings.Fields(line)
		if len(fields) < 3 {
			continue
		}
		// 格式: "Pages active:    123456" -> fields = ["Pages", "active:", "123456"]
		valueStr := fields[len(fields)-1]
		value, err := strconv.ParseUint(valueStr, 10, 64)
		if err != nil {
			continue
		}

		lineLower := strings.ToLower(line)
		if strings.Contains(lineLower, "pages active") && !strings.Contains(lineLower, "inactive") {
			activePages = value
		} else if strings.Contains(lineLower, "pages wired") {
			wiredPages = value
		} else if strings.Contains(lineLower, "pages speculative") {
			speculativePages = value
		}
	}

	// 已用 = active + wired + speculative
	usedBytes := (activePages + wiredPages + speculativePages) * pageSize

	totalGB = float64(totalBytes) / 1024 / 1024 / 1024
	usedGB = float64(usedBytes) / 1024 / 1024 / 1024
	percent = float64(usedBytes) * 100 / float64(totalBytes)
	return
}

func sysctlUint64(name string) uint64 {
	out, err := exec.Command("sysctl", "-n", name).Output()
	if err != nil {
		return 0
	}
	val, _ := strconv.ParseUint(strings.TrimSpace(string(out)), 10, 64)
	return val
}

func readDiskInfo(path string) (totalGB, usedGB, percent float64) {
	var stat syscall.Statfs_t
	if err := syscall.Statfs(path, &stat); err != nil {
		return
	}
	total := stat.Blocks * uint64(stat.Bsize)
	free := stat.Bavail * uint64(stat.Bsize)
	used := total - free
	if total > 0 {
		totalGB = float64(total) / 1024 / 1024 / 1024
		usedGB = float64(used) / 1024 / 1024 / 1024
		percent = float64(used) * 100 / float64(total)
	}
	return
}

func readCPU() float64 {
	// 使用 ps 获取 CPU 空闲率
	out, err := exec.Command("ps", "-A", "-o", "%cpu=").Output()
	if err != nil {
		return 0
	}

	scanner := bufio.NewScanner(strings.NewReader(string(out)))
	var totalCPU float64
	count := 0
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if val, err := strconv.ParseFloat(line, 64); err == nil {
			totalCPU += val
			count++
		}
	}

	// ps 显示的是每个进程的 CPU%，需要除以 CPU 核心数
	if count > 0 {
		cpuCount := runtime.NumCPU()
		return totalCPU / float64(cpuCount)
	}
	return 0
}
