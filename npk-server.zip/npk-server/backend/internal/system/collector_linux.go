//go:build linux
// +build linux

package system

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
	"sync"
	"syscall"
)

func readMemInfo() (totalGB, usedGB, percent float64) {
	file, err := os.Open("/proc/meminfo")
	if err != nil {
		return
	}
	defer file.Close()

	var memTotal, memAvailable uint64
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		fields := strings.Fields(scanner.Text())
		if len(fields) < 2 {
			continue
		}
		key := strings.TrimSuffix(fields[0], ":")
		value, _ := strconv.ParseUint(fields[1], 10, 64)
		value *= 1024 // KB -> Bytes

		switch key {
		case "MemTotal":
			memTotal = value
		case "MemAvailable":
			memAvailable = value
		}
	}

	if memTotal > 0 {
		used := memTotal - memAvailable
		totalGB = float64(memTotal) / 1024 / 1024 / 1024
		usedGB = float64(used) / 1024 / 1024 / 1024
		percent = float64(used) * 100 / float64(memTotal)
	}
	return
}

func readDiskInfo(path string) (totalGB, usedGB, percent float64) {
	var stat syscall.Statfs_t
	if err := syscall.Statfs(path, &stat); err != nil {
		return
	}
	total := stat.Blocks * uint64(stat.Bsize)
	free := stat.Bavail * uint64(stat.Bsize)
	used := total - free
	if total > 0 {
		totalGB = float64(total) / 1024 / 1024 / 1024
		usedGB = float64(used) / 1024 / 1024 / 1024
		percent = float64(used) * 100 / float64(total)
	}
	return
}

var (
	cpuPrevTotal uint64
	cpuPrevIdle  uint64
	cpuMu        sync.Mutex
)

func readCPU() float64 {
	file, err := os.Open("/proc/stat")
	if err != nil {
		return 0
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	if !scanner.Scan() {
		return 0
	}

	fields := strings.Fields(scanner.Text())
	if len(fields) < 5 || fields[0] != "cpu" {
		return 0
	}

	var user, nice, system, idle uint64
	fmt.Sscanf(fields[1], "%d", &user)
	fmt.Sscanf(fields[2], "%d", &nice)
	fmt.Sscanf(fields[3], "%d", &system)
	fmt.Sscanf(fields[4], "%d", &idle)

	total := user + nice + system + idle

	cpuMu.Lock()
	defer cpuMu.Unlock()

	if cpuPrevTotal == 0 {
		cpuPrevTotal = total
		cpuPrevIdle = idle
		return 0
	}

	totalDiff := total - cpuPrevTotal
	idleDiff := idle - cpuPrevIdle
	cpuPrevTotal = total
	cpuPrevIdle = idle

	if totalDiff > 0 {
		return float64(totalDiff-idleDiff) * 100 / float64(totalDiff)
	}
	return 0
}
