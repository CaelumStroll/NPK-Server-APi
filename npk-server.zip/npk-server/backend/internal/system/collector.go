//go:build linux || darwin
// +build linux darwin

package system

import (
	"runtime"
	"runtime/debug"
	"sync"
	"time"
)

// Stats 系统指标
type Stats struct {
	CPUPercent    float64 `json:"cpu_percent"`
	MemPercent    float64 `json:"mem_percent"`
	MemUsedGB     float64 `json:"mem_used_gb"`
	MemTotalGB    float64 `json:"mem_total_gb"`
	DiskPercent   float64 `json:"disk_percent"`
	DiskUsedGB    float64 `json:"disk_used_gb"`
	DiskTotalGB   float64 `json:"disk_total_gb"`
	Goroutines    int     `json:"goroutines"`
	HeapAllocMB   float64 `json:"heap_alloc_mb"`
	HeapSysMB     float64 `json:"heap_sys_mb"`
	UptimeSeconds int64   `json:"uptime_seconds"`
}

// Collector 系统指标采集器
type Collector struct {
	mu         sync.RWMutex
	stats      Stats
	startTime  time.Time
	cacheStats func() map[string]interface{}
}

// NewCollector 创建采集器
func NewCollector() *Collector {
	return &Collector{
		startTime: time.Now(),
	}
}

// SetCacheStatsFunc 设置缓存统计函数
func (c *Collector) SetCacheStatsFunc(fn func() map[string]interface{}) {
	c.cacheStats = fn
}

// Collect 采集系统指标
func (c *Collector) Collect() Stats {
	stats := Stats{
		UptimeSeconds: int64(time.Since(c.startTime).Seconds()),
		Goroutines:    runtime.NumGoroutine(),
	}

	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	stats.HeapAllocMB = float64(m.HeapAlloc) / 1024 / 1024
	stats.HeapSysMB = float64(m.HeapSys) / 1024 / 1024

	// 根据操作系统选择采集方式
	switch runtime.GOOS {
	case "linux":
		stats.MemTotalGB, stats.MemUsedGB, stats.MemPercent = readMemInfo()
		stats.DiskTotalGB, stats.DiskUsedGB, stats.DiskPercent = readDiskInfo("/")
		stats.CPUPercent = readCPU()
	case "darwin":
		stats.MemTotalGB, stats.MemUsedGB, stats.MemPercent = readMemInfo()
		stats.DiskTotalGB, stats.DiskUsedGB, stats.DiskPercent = readDiskInfo("/")
		stats.CPUPercent = readCPU()
	default:
		// Windows 或其他系统，使用 Go 运行时数据估算
		stats.MemTotalGB = float64(m.Sys) / 1024 / 1024 / 1024
		stats.MemUsedGB = float64(m.HeapAlloc) / 1024 / 1024 / 1024
		stats.MemPercent = float64(m.HeapAlloc) * 100 / float64(m.Sys)
		stats.CPUPercent = 0
	}

	c.mu.Lock()
	c.stats = stats
	c.mu.Unlock()

	return stats
}

// GetStats 获取最近一次采集的指标
func (c *Collector) GetStats() Stats {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.stats
}

// CollectWithCache 采集系统指标 + 缓存统计
func (c *Collector) CollectWithCache() map[string]interface{} {
	stats := c.Collect()

	result := map[string]interface{}{
		"cpu_percent":    round2(stats.CPUPercent),
		"mem_percent":    round2(stats.MemPercent),
		"mem_used":       round2(stats.MemUsedGB),
		"mem_total":      round2(stats.MemTotalGB),
		"disk_percent":   round2(stats.DiskPercent),
		"disk_used":      round2(stats.DiskUsedGB),
		"disk_total":     round2(stats.DiskTotalGB),
		"goroutines":     stats.Goroutines,
		"heap_alloc_mb":  round2(stats.HeapAllocMB),
		"heap_sys_mb":    round2(stats.HeapSysMB),
		"uptime_seconds": stats.UptimeSeconds,
	}

	if c.cacheStats != nil {
		cacheData := c.cacheStats()
		size := toInt(cacheData["size"])
		maxSize := toInt(cacheData["max_size"])
		count := toInt(cacheData["count"])
		hits := toInt64(cacheData["hits"])
		misses := toInt64(cacheData["misses"])
		hitRate := toFloat64(cacheData["hit_rate"])

		result["cache_used_mb"] = round2(float64(size) / 1024 / 1024)
		result["cache_size"] = size
		result["cache_max_size"] = maxSize
		result["cache_max_size_mb"] = round2(float64(maxSize) / 1024 / 1024)
		if maxSize > 0 {
			result["cache_percent"] = round2(float64(size) * 100 / float64(maxSize))
		} else {
			result["cache_percent"] = 0
		}
		result["cache_count"] = count
		result["cache_hits"] = hits
		result["cache_misses"] = misses
		result["cache_hit_rate"] = hitRate
	} else {
		result["cache_used_mb"] = 0
		result["cache_size"] = 0
		result["cache_max_size"] = 0
		result["cache_max_size_mb"] = 0
		result["cache_percent"] = 0
		result["cache_count"] = 0
		result["cache_hits"] = 0
		result["cache_misses"] = 0
		result["cache_hit_rate"] = 0
	}

	return result
}

var BuildInfo, _ = debug.ReadBuildInfo()

func round2(v float64) float64 {
	return float64(int(v*100)) / 100
}

func toInt(v interface{}) int {
	switch val := v.(type) {
	case int:
		return val
	case int64:
		return int(val)
	case int32:
		return int(val)
	case float64:
		return int(val)
	case float32:
		return int(val)
	default:
		return 0
	}
}

func toInt64(v interface{}) int64 {
	switch val := v.(type) {
	case int64:
		return val
	case int:
		return int64(val)
	case int32:
		return int64(val)
	case float64:
		return int64(val)
	case float32:
		return int64(val)
	default:
		return 0
	}
}

func toFloat64(v interface{}) float64 {
	switch val := v.(type) {
	case float64:
		return val
	case float32:
		return float64(val)
	case int:
		return float64(val)
	case int64:
		return float64(val)
	default:
		return 0
	}
}
