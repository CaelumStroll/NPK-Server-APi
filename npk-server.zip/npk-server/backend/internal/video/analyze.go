package video

import (
	"encoding/binary"
	"path/filepath"
	"strings"
)

// VideoInfo 视频文件信息结构体
// 包含视频的分辨率、帧数、帧率、时长等元数据信息
type VideoInfo struct {
	Width       int     // 视频宽度（像素）
	Height      int     // 视频高度（像素）
	FrameCount  int     // 视频帧总数
	AudioCount  int     // 音频帧总数
	FPS         float64 // 帧率（帧/秒）
	Duration    float64 // 视频时长（秒）
	IsEncrypted bool    // 是否为 Neople 加密视频
	FileSize    int64   // 文件大小（字节）
	Format      string  // 文件格式（如 "AVI", "BK2", "MP4" 等）
}

// AnalyzeVideo 分析视频数据，提取视频元信息
// 如果视频已加密，会先解密再分析 AVI 头部信息
// data: 视频文件的原始数据
// isEncrypted: 是否为 Neople 加密视频
func AnalyzeVideo(data []byte, isEncrypted bool) *VideoInfo {
	info := &VideoInfo{
		FileSize:    int64(len(data)),
		IsEncrypted: isEncrypted,
	}

	var videoData []byte
	var err error

	// 如果已加密，先解密
	if isEncrypted {
		crypto := NewNeopleCrypto()
		videoData, err = crypto.Decrypt(data)
		if err != nil {
			// 解密失败时返回基本信息
			return info
		}
	} else {
		videoData = data
	}

	// 数据不足以判断格式
	if len(videoData) < 12 {
		return info
	}

	// 仅支持解析 AVI 格式的头部信息
	header1 := string(videoData[0:4])
	header2 := string(videoData[8:12])
	if header1 == "RIFF" && header2 == "AVI " {
		parseAVIInfo(videoData, info)
	} else {
	}

	return info
}

// parseAVIInfo 解析 AVI 文件头部，提取视频分辨率、帧率、帧数等信息
// AVI 文件结构：RIFF header -> LIST hdrl -> LIST movi
func parseAVIInfo(data []byte, info *VideoInfo) {
	offset := 12 // 跳过 RIFF header（12 字节）

	for offset < len(data)-8 {
		chunkID := string(data[offset : offset+4])
		chunkSize := int(binary.LittleEndian.Uint32(data[offset+4 : offset+8]))

		// 防止越界
		if offset+8+chunkSize > len(data) {
			break
		}

		// 处理 LIST 块
		if chunkID == "LIST" && offset+12 <= len(data) {
			listType := string(data[offset+8 : offset+12])

			switch listType {
			case "movi":
				// movi 列表包含实际的音视频帧数据
				moviData := data[offset+12 : offset+8+chunkSize]
				info.FrameCount, info.AudioCount = countFrames(moviData)
			case "hdrl":
				// hdrl 列表包含流头部信息（分辨率、帧率等）
				parseHeader(data[offset+12:offset+8+chunkSize], info)
			}
		}

		// 移动到下一个块（AVI 块按 2 字节对齐）
		offset += 8 + chunkSize
		if chunkSize%2 != 0 {
			offset++
		}
	}

	// 计算视频时长
	if info.FPS > 0 && info.FrameCount > 0 {
		info.Duration = float64(info.FrameCount) / info.FPS
	}
}

// countFrames 统计 movi 列表中的视频帧和音频帧数量
// 视频帧标识: "00dc" (DIB compressed)
// 音频帧标识: "01wb" (waveform buffer)
func countFrames(data []byte) (videoFrames, audioFrames int) {
	offset := 0

	for offset < len(data)-8 {
		frameID := string(data[offset : offset+4])
		frameSize := int(binary.LittleEndian.Uint32(data[offset+4 : offset+8]))

		if frameSize > 0 && offset+8+frameSize <= len(data) {
			switch frameID {
			case "00dc":
				videoFrames++
			case "01wb":
				audioFrames++
			}
		}

		// 移动到下一帧（按 2 字节对齐）
		offset += 8 + frameSize
		if frameSize%2 != 0 {
			offset++
		}
	}

	return videoFrames, audioFrames
}

// parseHeader 解析 AVI 头部列表中的流信息
// 从 strh（流头部）中提取帧率，从 strf（流格式）中提取分辨率
func parseHeader(data []byte, info *VideoInfo) {
	offset := 0
	currentStreamType := "" // 记录当前流类型

	for offset < len(data)-8 {
		chunkID := string(data[offset : offset+4])
		chunkSize := int(binary.LittleEndian.Uint32(data[offset+4 : offset+8]))

		switch chunkID {
		case "strh":
			// 流头部结构（Stream Header）
			dataOffset := offset + 8
			if dataOffset+28 <= len(data) {
				currentStreamType = string(data[dataOffset : dataOffset+4])
				if currentStreamType == "vids" {
					scale := binary.LittleEndian.Uint32(data[dataOffset+20 : dataOffset+24])
					rate := binary.LittleEndian.Uint32(data[dataOffset+24 : dataOffset+28])
					if scale > 0 {
						info.FPS = float64(rate) / float64(scale)
					}
				}
			}
		case "strf":
			// 流格式结构 - 只有视频流才解析 BITMAPINFOHEADER
			if currentStreamType == "vids" {
				dataOffset := offset + 8
				if dataOffset+12 <= len(data) {
					w := int(binary.LittleEndian.Uint32(data[dataOffset+4 : dataOffset+8]))
					h := int(binary.LittleEndian.Uint32(data[dataOffset+8 : dataOffset+12]))
					// 过滤异常值：宽高应在合理范围内
					if w > 0 && w <= 7680 && h > 0 && h <= 4320 {
						info.Width = w
						info.Height = h
					}
				}
			}
			currentStreamType = "" // 重置流类型
		case "LIST":
			if offset+12 <= len(data) {
				listType := string(data[offset+8 : offset+12])
				if listType == "strl" {
					listData := data[offset+12 : offset+8+chunkSize]
					parseHeader(listData, info)
				}
			}
		}

		offset += 8 + chunkSize
		if chunkSize%2 != 0 {
			offset++
		}
	}
}

// GetVideoFormat 根据文件扩展名获取视频格式名称
// 支持的格式: .avi, .bk2, .mp4, .webm, .mkv
func GetVideoFormat(filename string) string {
	ext := strings.ToLower(filepath.Ext(filename))
	switch ext {
	case ".avi":
		return "AVI"
	case ".bk2":
		return "BK2"
	case ".mp4":
		return "MP4"
	case ".webm":
		return "WebM"
	case ".mkv":
		return "MKV"
	default:
		return strings.ToUpper(strings.TrimPrefix(ext, "."))
	}
}
