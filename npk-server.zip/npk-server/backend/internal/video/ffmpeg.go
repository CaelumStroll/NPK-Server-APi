package video

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
)

func FindFFmpeg() string {
	return findFFmpeg()
}

func findFFmpeg() string {
	// 获取可执行文件所在目录
	execPath, err := os.Executable()
	if err == nil {
		execDir := filepath.Dir(execPath)

		// 在不同平台上 FFmpeg 的可执行文件名
		candidates := []string{
			filepath.Join(execDir, ffmpegName()),
			filepath.Join(execDir, "tools", "ffmpeg", ffmpegName()),
		}

		for _, p := range candidates {
			if _, err := os.Stat(p); err == nil {
				return p
			}
		}
	}

	// 回退到 PATH 中的 ffmpeg
	return "ffmpeg"
}

func ffmpegName() string {
	if runtime.GOOS == "windows" {
		return "ffmpeg.exe"
	}
	return "ffmpeg"
}

// Resolution 分辨率选项
type Resolution string

const (
	ResOriginal Resolution = "original" // 原始分辨率
	Res800x600  Resolution = "800x600"  // 800x600 (默认)
	Res1066x600 Resolution = "1066x600" // 1066x600
)

// FFmpegTranscoder FFmpeg 转码器
type FFmpegTranscoder struct {
	inputPath  string
	outputPipe io.Reader
	cmd        *exec.Cmd
}

// getScaleFilter 根据分辨率选项获取缩放滤镜
func getScaleFilter(res Resolution) string {
	fmt.Printf("[DEBUG] getScaleFilter called with res: %q (string: %s)\n", res, string(res))
	switch res {
	case ResOriginal:
		// 原始分辨率，不做缩放
		fmt.Printf("[DEBUG] -> ResOriginal, returning empty\n")
		return ""
	case Res1066x600:
		// 1066x600 分辨率，使用明确格式并设置像素比例
		fmt.Printf("[DEBUG] -> Res1066x600, returning scale=w=1066:h=600:force_original_aspect_ratio=disable:flags=lanczos,setsar=1:1\n")
		return "scale=w=1066:h=600:force_original_aspect_ratio=disable:flags=lanczos,setsar=1:1"
	case Res800x600, "":
		// 默认 800x600，使用明确格式并设置像素比例
		fmt.Printf("[DEBUG] -> Res800x600, returning scale=w=800:h=600:force_original_aspect_ratio=disable:flags=lanczos,setsar=1:1\n")
		return "scale=w=800:h=600:force_original_aspect_ratio=disable:flags=lanczos,setsar=1:1"
	default:
		// 尝试解析自定义分辨率，如 "1280x720"
		fmt.Printf("[DEBUG] -> default, returning scale=%s:force_original_aspect_ratio=disable:flags=lanczos,setsar=1:1\n", string(res))
		return "scale=" + string(res) + ":force_original_aspect_ratio=disable:flags=lanczos,setsar=1:1"
	}
}

// NewFFmpegTranscoder 创建新的 FFmpeg 转码器
// inputPath: 输入文件路径（支持 AVI 或解密后的数据）
// res: 目标分辨率选项
// 返回: 转码器实例、输出流、错误
func NewFFmpegTranscoder(inputPath string, res Resolution) (*FFmpegTranscoder, io.Reader, error) {
	// 构建 FFmpeg 命令参数
	args := []string{
		"-i", inputPath,
	}

	// 添加视频滤镜（如果有）
	filter := getScaleFilter(res)
	if filter != "" {
		args = append(args, "-vf", filter)
	}

	// 添加编码参数
	args = append(args,
		"-c:v", "libx264",
		"-preset", "medium",
		"-crf", "18",
		"-tune", "fastdecode",
		"-profile:v", "high",
		"-level", "4.2",
		"-c:a", "aac",
		"-b:a", "192k",
		"-movflags", "frag_keyframe+empty_moov+default_base_moof",
		"-f", "mp4",
		"-",
	)

	cmd := exec.Command(findFFmpeg(), args...) 

	// 获取 stdout pipe
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, nil, fmt.Errorf("创建 stdout pipe 失败: %w", err)
	}

	// 获取 stderr pipe（用于错误处理）
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return nil, nil, fmt.Errorf("创建 stderr pipe 失败: %w", err)
	}

	// 启动 FFmpeg
	if err := cmd.Start(); err != nil {
		return nil, nil, fmt.Errorf("启动 FFmpeg 失败: %w", err)
	}

	// 在后台读取 stderr（避免阻塞）
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := stderr.Read(buf)
			if n > 0 {
				// 可以在这里记录 FFmpeg 日志
				// fmt.Printf("FFmpeg: %s", string(buf[:n]))
			}
			if err != nil {
				break
			}
		}
	}()

	return &FFmpegTranscoder{
		inputPath:  inputPath,
		outputPipe: stdout,
		cmd:        cmd,
	}, stdout, nil
}

// NewFFmpegTranscoderFromData 从内存数据创建 FFmpeg 转码器
// data: 解密后的视频数据
// res: 目标分辨率选项
// 返回: 转码器实例、输出流、错误
func NewFFmpegTranscoderFromData(data []byte, res Resolution) (*FFmpegTranscoder, io.Reader, error) {
	// 构建 FFmpeg 命令参数
	args := []string{
		"-i", "-", // 从 stdin 读取
	}

	// 添加视频滤镜（如果有）
	filter := getScaleFilter(res)
	if filter != "" {
		args = append(args, "-vf", filter)
	}

	// 添加编码参数
	args = append(args,
		"-c:v", "libx264",
		"-preset", "medium",
		"-crf", "18",
		"-tune", "fastdecode",
		"-profile:v", "high",
		"-level", "4.2",
		"-c:a", "aac",
		"-b:a", "192k",
		"-movflags", "frag_keyframe+empty_moov+default_base_moof",
		"-f", "mp4",
		"-",
	)

	cmd := exec.Command(findFFmpeg(), args...)

	// 获取 stdin pipe
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return nil, nil, fmt.Errorf("创建 stdin pipe 失败: %w", err)
	}

	// 获取 stdout pipe
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, nil, fmt.Errorf("创建 stdout pipe 失败: %w", err)
	}

	// 启动 FFmpeg
	if err := cmd.Start(); err != nil {
		return nil, nil, fmt.Errorf("启动 FFmpeg 失败: %w", err)
	}

	// 在后台写入数据到 stdin
	go func() {
		defer stdin.Close()
		stdin.Write(data)
	}()

	return &FFmpegTranscoder{
		inputPath:  "memory",
		outputPipe: stdout,
		cmd:        cmd,
	}, stdout, nil
}

// Wait 等待 FFmpeg 转码完成
func (t *FFmpegTranscoder) Wait() error {
	return t.cmd.Wait()
}

// Kill 强制终止 FFmpeg 进程
func (t *FFmpegTranscoder) Kill() error {
	return t.cmd.Process.Kill()
}

// ParseResolution 解析分辨率字符串
func ParseResolution(s string) Resolution {
	switch s {
	case "original":
		return ResOriginal
	case "1066x600":
		return Res1066x600
	case "800x600", "":
		return Res800x600
	default:
		// 验证自定义分辨率格式 (如 "1280x720")
		if len(s) > 3 && len(s) < 12 {
			return Resolution(s)
		}
		return Res800x600
	}
}

// GetResolutionDimensions 获取分辨率的宽高
func GetResolutionDimensions(res Resolution) (width, height int) {
	switch res {
	case ResOriginal:
		return 0, 0 // 表示原始分辨率
	case Res1066x600:
		return 1066, 600
	case Res800x600, "":
		return 800, 600
	default:
		// 尝试解析自定义分辨率
		var w, h int
		fmt.Sscanf(string(res), "%dx%d", &w, &h)
		if w > 0 && h > 0 {
			return w, h
		}
		return 800, 600
	}
}

// ResolutionToString 将分辨率转换为字符串
func ResolutionToString(res Resolution) string {
	w, h := GetResolutionDimensions(res)
	if w == 0 && h == 0 {
		return "original"
	}
	return strconv.Itoa(w) + "x" + strconv.Itoa(h)
}
