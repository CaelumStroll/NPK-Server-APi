package video

import (
	"bytes"
	"testing"
)

func TestIsAVI(t *testing.T) {
	if IsAVI(nil) {
		t.Error("nil should not be AVI")
	}
	if IsAVI([]byte("RIFF")) {
		t.Error("too short should not be AVI")
	}

	aviHeader := []byte("RIFF\x00\x00\x00\x00AVI ")
	if !IsAVI(aviHeader) {
		t.Error("valid AVI header should be detected")
	}
}

func TestIsEncrypted(t *testing.T) {
	if IsEncrypted(nil) {
		t.Error("nil should not be encrypted")
	}
	if IsEncrypted([]byte("Neople")) {
		t.Error("too short signature should not match")
	}

	sig := make([]byte, 32)
	copy(sig, neopleSignature)
	if !IsEncrypted(sig) {
		t.Error("Neople signature should be detected as encrypted")
	}
}

func TestEncryptDecryptRoundtrip(t *testing.T) {
	crypto := NewNeopleCrypto()

	original := make([]byte, 5000)
	for i := range original {
		original[i] = byte(i % 256)
	}

	encrypted, err := crypto.Encrypt(original)
	if err != nil {
		t.Fatalf("encrypt failed: %v", err)
	}

	if !IsEncrypted(encrypted) {
		t.Error("encrypted data should have Neople signature")
	}

	decrypted, err := crypto.Decrypt(encrypted)
	if err != nil {
		t.Fatalf("decrypt failed: %v", err)
	}

	if !bytes.Equal(original, decrypted) {
		t.Error("decrypted data does not match original")
	}
}

func TestEncryptDecryptSmallData(t *testing.T) {
	crypto := NewNeopleCrypto()

	original := []byte{0x01, 0x02, 0x03, 0x04, 0x05}

	encrypted, err := crypto.Encrypt(original)
	if err != nil {
		t.Fatalf("encrypt failed: %v", err)
	}

	decrypted, err := crypto.Decrypt(encrypted)
	if err != nil {
		t.Fatalf("decrypt failed: %v", err)
	}

	if !bytes.Equal(original, decrypted) {
		t.Errorf("small data: got %v, want %v", decrypted, original)
	}
}

func TestDecryptInvalidData(t *testing.T) {
	crypto := NewNeopleCrypto()

	_, err := crypto.Decrypt([]byte("bad data"))
	if err == nil {
		t.Error("expected error for invalid data")
	}

	_, err = crypto.Decrypt(nil)
	if err == nil {
		t.Error("expected error for nil")
	}
}
