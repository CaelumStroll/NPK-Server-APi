package video

import (
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// VideoFile 视频文件信息结构体
// 用于目录扫描结果，包含文件路径、大小、格式和视频元信息
type VideoFile struct {
	Name        string     // 文件名
	Path        string     // 文件完整路径
	Size        int64      // 文件大小（字节）
	Format      string     // 文件格式（如 "AVI", "BK2", "MP4" 等）
	IsEncrypted bool       // 是否为 Neople 加密视频
	Info        *VideoInfo // 视频详细信息（可能为 nil，取决于是否成功解析）
	ScannedAt   time.Time  // 扫描时间
}

// headerReadSize 扫描时读取的文件头部大小（8KB）
// 足够用于判断加密状态和解析 AVI 头部信息，避免读取大文件
const headerReadSize = 8192

// aviHeaderReadSize AVI 文件头部读取大小（512KB）
// AVI 文件的 hdrl LIST 可能较大，需要更多数据来解析分辨率和帧率
const aviHeaderReadSize = 512 * 1024

// supportedExtensions 支持扫描的视频文件扩展名
var supportedExtensions = map[string]bool{
	".avi":  true,
	".bk2":  true,
	".mp4":  true,
	".webm": true,
	".mkv":  true,
}

// ScanVideoDir 递归扫描目录中的视频文件
// 支持的格式: .avi, .bk2, .mp4, .webm, .mkv
// 只读取文件头部（前 8KB）来判断加密状态和格式，不读取整个文件
// dir: 要扫描的目录路径
// 返回: 扫描到的视频文件列表
func ScanVideoDir(dir string) ([]VideoFile, error) {
	// 验证目录是否存在
	info, err := os.Stat(dir)
	if err != nil {
		return nil, fmt.Errorf("无法访问目录: %w", err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("路径不是目录: %s", dir)
	}

	var files []VideoFile
	now := time.Now()

	// 递归遍历目录
	err = filepath.WalkDir(dir, func(path string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			// 跳过无法访问的文件/目录，继续扫描
			return nil
		}

		// 跳过目录
		if d.IsDir() {
			return nil
		}

		// 检查文件扩展名是否在支持列表中
		ext := strings.ToLower(filepath.Ext(d.Name()))
		if !supportedExtensions[ext] {
			return nil
		}

		// 获取文件信息
		fileInfo, err := d.Info()
		if err != nil {
			return nil
		}

		vf := VideoFile{
			Name:      d.Name(),
			Path:      path,
			Size:      fileInfo.Size(),
			Format:    GetVideoFormat(d.Name()),
			ScannedAt: now,
		}

		// 对于 AVI 文件，直接读取整个文件解析视频信息（包括加密文件）
		if vf.Format == "AVI" {
			// 读取整个文件解析 AVI 信息
			data, err := os.ReadFile(path)
			if err == nil && len(data) > 0 {
				vf.IsEncrypted = IsEncrypted(data)
				// 解析视频信息（支持加密和未加密文件）
				vf.Info = AnalyzeVideo(data, vf.IsEncrypted)
				if vf.Info != nil {
					vf.Info.FileSize = vf.Size
					vf.Info.IsEncrypted = vf.IsEncrypted
				}
			}
		} else {
			// 其他格式，只读取头部
			header, err := readFileHeader(path, headerReadSize)
			if err == nil && len(header) > 0 {
				vf.IsEncrypted = IsEncrypted(header)
				vf.Info = &VideoInfo{
					Format:   vf.Format,
					FileSize: vf.Size,
				}
			}
		}

		files = append(files, vf)
		return nil
	})

	if err != nil {
		return nil, fmt.Errorf("扫描目录失败: %w", err)
	}

	return files, nil
}

// readFileHeader 读取文件头部指定大小的数据
// path: 文件路径
// size: 要读取的最大字节数
// 返回: 文件头部数据
func readFileHeader(path string, size int) ([]byte, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	buf := make([]byte, size)
	n, err := file.Read(buf)
	if err != nil && n == 0 {
		return nil, err
	}

	return buf[:n], nil
}
