package video

import (
	"encoding/binary"
	"fmt"
)

// NeopleCrypto Neople 视频加解密器
// 用于处理 Neople Video File 格式（.bk2 / 加密 .avi）的加密和解密操作。
// 加密算法：媒体数据前 1024 字节为明文，之后的数据与前 1024 字节偏移处的数据进行 XOR 运算。
type NeopleCrypto struct{}

// NewNeopleCrypto 创建一个新的 NeopleCrypto 实例
func NewNeopleCrypto() *NeopleCrypto {
	return &NeopleCrypto{}
}

// neopleSignature Neople 加密视频的文件签名标识
const neopleSignature = "Neople Video Fil"

// headerSize Neople 加密文件头大小（0x20 = 32 字节）
const headerSize = 0x20

// xorBlockSize XOR 加密的块大小（1024 字节）
const xorBlockSize = 1024

// IsEncrypted 检测数据是否为 Neople 加密视频
// 通过检查文件头部 16 字节签名 "Neople Video Fil" 来判断
func IsEncrypted(data []byte) bool {
	if len(data) < 16 {
		return false
	}
	return string(data[0:16]) == neopleSignature
}

// IsAVI 检测数据是否为标准 AVI 文件
// 通过检查 RIFF 头和 AVI 类型标识来判断
func IsAVI(data []byte) bool {
	if len(data) < 12 {
		return false
	}
	return string(data[0:4]) == "RIFF" && string(data[8:12]) == "AVI "
}

// Decrypt 解密 Neople 加密视频数据
//
// Neople 加密文件格式：
//
//	偏移    大小  说明
//	0x00    16   签名: "Neople Video Fil"
//	0x10    4    uint32: 条目数量 (固定为 1)
//	0x14    4    uint32: 版本号 (固定为 1)
//	0x18    4    uint32: 原始文件大小 (Little Endian)
//	0x1C    4    uint32: 对齐后大小 (Little Endian)
//	0x20    N    媒体数据（部分加密）
//
// 解密算法：
//   - 媒体数据前 1024 字节为明文，直接复制
//   - 1024 字节之后的数据：OUT[i] = BIN[i] XOR OUT[i - 1024]
func (c *NeopleCrypto) Decrypt(data []byte) ([]byte, error) {
	if len(data) < headerSize {
		return nil, fmt.Errorf("文件太小，无法解密")
	}

	// 验证签名
	signature := string(data[0x00:0x10])
	if signature != neopleSignature {
		return nil, fmt.Errorf("无效的 Neople 文件签名: %s", signature)
	}

	// 读取原始文件大小
	originalSize := binary.LittleEndian.Uint32(data[0x18:0x1C])

	// 媒体数据从 0x20 开始
	mediaData := data[headerSize:]
	outputData := make([]byte, len(mediaData))

	// 前 1024 字节为明文，直接复制
	copySize := xorBlockSize
	if len(mediaData) < copySize {
		copySize = len(mediaData)
	}
	copy(outputData[:copySize], mediaData[:copySize])

	// 1024 字节之后的数据进行 XOR 解密
	if len(mediaData) > xorBlockSize {
		for i := xorBlockSize; i < len(mediaData); i++ {
			outputData[i] = mediaData[i] ^ outputData[i-xorBlockSize]
		}
	}

	// 截断到原始文件大小
	if int(originalSize) < len(outputData) {
		outputData = outputData[:originalSize]
	}

	return outputData, nil
}

// Encrypt 将视频数据加密为 Neople 格式
//
// 加密算法：
//   - 前 1024 字节为明文，直接复制
//   - 1024 字节之后的数据：OUT[i] = videoData[i] XOR videoData[i - 1024]
//   - 数据按 1024 字节对齐
func (c *NeopleCrypto) Encrypt(videoData []byte) ([]byte, error) {
	videoSize := len(videoData)

	// 按 1024 字节对齐
	alignedSize := ((videoSize + xorBlockSize - 1) / xorBlockSize) * xorBlockSize

	// 准备媒体数据缓冲区
	mediaData := make([]byte, alignedSize)
	copy(mediaData, videoData)

	// 对 1024 字节之后的数据进行 XOR 加密
	if alignedSize > xorBlockSize {
		for i := xorBlockSize; i < alignedSize; i++ {
			if i < videoSize {
				mediaData[i] = videoData[i] ^ videoData[i-xorBlockSize]
			} else {
				// 对齐填充部分用 0 进行 XOR
				mediaData[i] = 0 ^ videoData[i-xorBlockSize]
			}
		}
	}

	// 构建文件头
	header := make([]byte, headerSize)
	copy(header[0x00:0x10], []byte(neopleSignature)) // 签名
	binary.LittleEndian.PutUint32(header[0x10:0x14], 1)           // 条目数量
	binary.LittleEndian.PutUint32(header[0x14:0x18], 1)           // 版本号
	binary.LittleEndian.PutUint32(header[0x18:0x1C], uint32(videoSize))   // 原始大小
	binary.LittleEndian.PutUint32(header[0x1C:0x20], uint32(alignedSize)) // 对齐后大小

	return append(header, mediaData...), nil
}
