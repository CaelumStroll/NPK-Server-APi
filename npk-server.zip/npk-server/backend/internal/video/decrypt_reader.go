package video

import (
	"encoding/binary"
	"fmt"
	"io"
	"os"
)

// DecryptReader 实现 io.ReadSeeker 接口，支持流式解密 Neople 加密视频
// 按需读取文件块并实时解密，不缓存整个文件
type DecryptReader struct {
	file       *os.File
	fileSize   int64
	mediaSize  int64
	origSize   int64
	pos        int64 // 当前读取位置（相对于解密后的数据）
	xorBlock   []byte // 用于 XOR 的 1024 字节缓冲区
}

// NewDecryptReader 创建一个新的流式解密 Reader
// path: 加密文件路径
// 返回: DecryptReader 实例、解密后的文件大小、错误
func NewDecryptReader(path string) (*DecryptReader, int64, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, 0, fmt.Errorf("打开文件失败: %w", err)
	}

	// 读取文件头
	header := make([]byte, headerSize)
	if _, err := io.ReadFull(file, header); err != nil {
		file.Close()
		return nil, 0, fmt.Errorf("读取文件头失败: %w", err)
	}

	// 验证签名
	if string(header[0x00:0x10]) != neopleSignature {
		file.Close()
		return nil, 0, fmt.Errorf("无效的 Neople 文件签名")
	}

	// 获取原始文件大小和对齐后大小
	origSize := int64(binary.LittleEndian.Uint32(header[0x18:0x1C]))
	alignedSize := int64(binary.LittleEndian.Uint32(header[0x1C:0x20]))

	// 获取文件总大小
	stat, err := file.Stat()
	if err != nil {
		file.Close()
		return nil, 0, fmt.Errorf("获取文件信息失败: %w", err)
	}

	// 媒体数据大小 = 文件总大小 - 头大小
	mediaSize := stat.Size() - headerSize
	if mediaSize != alignedSize {
		// 如果大小不匹配，使用实际大小
		mediaSize = alignedSize
	}

	return &DecryptReader{
		file:      file,
		fileSize:  stat.Size(),
		mediaSize: mediaSize,
		origSize:  origSize,
		pos:       0,
		xorBlock:  make([]byte, xorBlockSize),
	}, origSize, nil
}

// Read 实现 io.Reader 接口
// 从解密后的数据流中读取数据
func (r *DecryptReader) Read(p []byte) (n int, err error) {
	if r.pos >= r.origSize {
		return 0, io.EOF
	}

	// 计算需要读取的字节数
	toRead := int64(len(p))
	remaining := r.origSize - r.pos
	if toRead > remaining {
		toRead = remaining
	}

	// 分段读取并解密
	var totalRead int
	for totalRead < int(toRead) {
		n, err := r.readAndDecryptBlock(r.pos, p[totalRead:toRead])
		if err != nil && err != io.EOF {
			return totalRead, err
		}
		totalRead += n
		r.pos += int64(n)
		if n == 0 || err == io.EOF {
			break
		}
	}

	return totalRead, nil
}

// readAndDecryptBlock 读取并解密一个数据块
// pos: 解密后的数据位置
// p: 目标缓冲区
func (r *DecryptReader) readAndDecryptBlock(pos int64, p []byte) (int, error) {
	// 计算在媒体数据中的位置
	mediaPos := headerSize + pos

	// 读取原始数据
	buf := make([]byte, len(p))
	n, err := r.file.ReadAt(buf, mediaPos)
	if err != nil && err != io.EOF {
		return 0, err
	}
	if n == 0 {
		return 0, io.EOF
	}

	// 解密数据
	for i := 0; i < n; i++ {
		absPos := pos + int64(i)
		if absPos < xorBlockSize {
			// 前 1024 字节是明文
			p[i] = buf[i]
		} else {
			// 1024 字节之后需要 XOR
			// OUT[i] = BIN[i] XOR OUT[i - 1024]
			// 我们需要获取 OUT[i - 1024]，这需要递归计算
			// 为了性能，我们使用缓存的 xorBlock
			xorIdx := absPos % xorBlockSize
			if absPos < xorBlockSize*2 {
				// 第一个 XOR 块，使用明文作为 XOR 源
				// 需要读取明文块
				if r.xorBlock[0] == 0 {
					// 缓存明文块
					r.file.ReadAt(r.xorBlock, headerSize)
				}
				p[i] = buf[i] ^ r.xorBlock[xorIdx]
			} else {
				// 后续的块，使用前一个解密块作为 XOR 源
				// 这需要更复杂的缓存策略
				// 简化处理：直接计算（性能较差但正确）
				prevPos := absPos - xorBlockSize
				prevByte := r.getDecryptedByte(prevPos)
				p[i] = buf[i] ^ prevByte
			}
		}
	}

	return n, err
}

// getDecryptedByte 获取指定位置的解密后字节（用于 XOR 计算）
func (r *DecryptReader) getDecryptedByte(pos int64) byte {
	if pos < xorBlockSize {
		// 明文区域
		buf := make([]byte, 1)
		r.file.ReadAt(buf, headerSize+pos)
		return buf[0]
	}
	// XOR 区域，需要递归计算
	// 读取原始字节
	buf := make([]byte, 1)
	r.file.ReadAt(buf, headerSize+pos)
	origByte := buf[0]
	// 获取前一个块的字节
	prevByte := r.getDecryptedByte(pos - xorBlockSize)
	return origByte ^ prevByte
}

// Seek 实现 io.Seeker 接口
// 支持 HTTP Range 请求
func (r *DecryptReader) Seek(offset int64, whence int) (int64, error) {
	var newPos int64

	switch whence {
	case io.SeekStart:
		newPos = offset
	case io.SeekCurrent:
		newPos = r.pos + offset
	case io.SeekEnd:
		newPos = r.origSize + offset
	default:
		return 0, fmt.Errorf("无效的 whence 值: %d", whence)
	}

	if newPos < 0 {
		return 0, fmt.Errorf("无效的位置: %d", newPos)
	}
	if newPos > r.origSize {
		newPos = r.origSize
	}

	r.pos = newPos
	return r.pos, nil
}

// Close 关闭 Reader
func (r *DecryptReader) Close() error {
	if r.file != nil {
		return r.file.Close()
	}
	return nil
}

// Size 返回解密后的文件大小
func (r *DecryptReader) Size() int64 {
	return r.origSize
}
