package service

import (
	"time"

	"npk-server/internal/npk"
)

const (
	MaxEditedSpritesSize = 500 * 1024 * 1024
)

type externalImgEntry struct {
	data       []byte
	album      *npk.Album
	info       *AlbumInfo
	loadedAt   time.Time
}

type animCacheEntry struct {
	Animation  *npk.Animation
	Album      *npk.Album
	LoadedAt   time.Time
	LastAccess time.Time
}

type NpkFileInfo struct {
	Name      string
	Path      string
	Size      int64
	Modified  time.Time
	Albums    []*AlbumInfo
	Scanned   time.Time
	IsLoaded  bool

	ImgCount           int
	SHA256Hash         string
	FormatType         int
	EncryptionVerified bool
}

type AlbumInfo struct {
	Path        string
	Name        string
	Version     npk.ImgVersion
	SpriteCount int
	Sprites     []*SpriteInfo
	Textures    []*TextureInfo

	FileType    int
	Offset      int64
	Size        int64
	PaletteJSON string
	DDSInfoJSON string

	Target     *AlbumInfo
	TargetPath string
}

type TextureInfo struct {
	Index  int `json:"index"`
	Width  int `json:"width"`
	Height int `json:"height"`
	Type   int `json:"type"`
}

type SpriteInfo struct {
	Index         int
	OriginalIndex int
	Type          npk.ColorBits
	CompressMode  npk.CompressMode
	Width         int
	Height        int
	X             int
	Y             int
	FrameWidth    int
	FrameHeight   int
	IsLink        bool
	TargetIndex   int
	Target        *SpriteInfo
	DataSize      int
	IsModified    bool
}

type SpriteDocument struct {
	Index                   int
	Type                    npk.ColorBits
	CompressMode            npk.CompressMode
	Width, Height           int
	X, Y                    int
	FrameWidth, FrameHeight int
	RawData                 []byte
	BGRAData                []byte
	IsModified              bool
	IsLink                  bool
	TargetIndex             int
	Target                  *SpriteDocument
}

type AlbumDocument struct {
	Path         string
	OriginalPath string
	Name         string
	Version      npk.ImgVersion
	Sprites      []*SpriteDocument
	Textures     []*npk.Texture
	Tables       [][]npk.RGBA
	TextureInfos map[int]*npk.TextureInfo
	IsLoaded     bool
	LastAccess   time.Time

	Target     *AlbumDocument
	TargetPath string
}

type NpkDocument struct {
	Name       string
	Path       string
	Size       int64
	Modified   time.Time
	Albums     []*AlbumDocument
	IsLoaded   bool
	LastAccess time.Time
}
