package service

import (
	"fmt"
	"io"
	"log"
	"os"
	"sync"

	"npk-server/internal/cache"
	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/npk"
)

// NpkService NPK 服务
type NpkService struct {
	cfg    *config.Config
	db     *database.Database
	cache  *cache.ImageCache
	thumbs *cache.ThumbnailCache
	imgCache *cache.ImgCachePool // 全局 IMG 缓存池

	mu            sync.RWMutex
	files         map[string]*NpkFileInfo // name -> info
	openFile      map[string]*os.File     // path -> file
	editedSprites map[string][]byte       // key: "npkName:albumPath:index" -> BGRA 数据
	editedSpritesSize int64               // 编辑缓存总大小（字节）
	documents     map[string]*NpkDocument // npkName → 完整内存文档（含像素数据）

	// NPK 详情缓存（LRU）
	npkDetailCache   map[string]*NpkFileInfo // name -> info (完整详情)
	npkDetailOrder   []string                // LRU 顺序
	npkDetailMaxSize int                     // 最大缓存数量

	// 外部 IMG 文件缓存
	externalImgCache map[string]*externalImgEntry
	externalImgOrder []string
	externalImgMaxSize int

	// 外部 NPK 文件缓存
	externalNpkCache map[string][]byte
}

// NewNpkService 创建 NPK 服务
func NewNpkService(cfg *config.Config, db *database.Database) *NpkService {
	return &NpkService{
		cfg:              cfg,
		db:               db,
		cache:            cache.NewImageCache(cfg.CacheMaxSize, cfg.MaxCacheItems),
		thumbs:           cache.NewThumbnailCache(cfg.MaxCacheItems),
		imgCache:         cache.NewImgCachePool(500, 50, 10), // 500MB, 50条目, 10分钟TTL
		files:            make(map[string]*NpkFileInfo),
		openFile:         make(map[string]*os.File),
		editedSprites:    make(map[string][]byte),
		documents:        make(map[string]*NpkDocument),
		npkDetailCache:   make(map[string]*NpkFileInfo),
		npkDetailOrder:   make([]string, 0),
		npkDetailMaxSize: 200, // 最多缓存 200 个 NPK 详情
		externalImgCache: make(map[string]*externalImgEntry),
		externalImgOrder: make([]string, 0),
		externalImgMaxSize: 20,
		externalNpkCache:  make(map[string][]byte), // 最多缓存 20 个外部 IMG
	}
}

// setEditedSprite 设置编辑缓存，带大小限制检查
// 如果超过限制，返回错误提示用户先保存
func (s *NpkService) setEditedSprite(key string, data []byte) error {
	dataSize := int64(len(data))

	// 检查是否超过总限制
	if s.editedSpritesSize+dataSize > MaxEditedSpritesSize {
		return fmt.Errorf("编辑缓存超过 %d MB 限制，请先保存当前修改", MaxEditedSpritesSize/1024/1024)
	}

	// 如果 key 已存在，先减去旧数据大小
	if oldData, exists := s.editedSprites[key]; exists {
		s.editedSpritesSize -= int64(len(oldData))
	}

	// 存储新数据
	s.editedSprites[key] = data
	s.editedSpritesSize += dataSize

	return nil
}

// deleteEditedSprite 删除编辑缓存，更新大小统计
func (s *NpkService) deleteEditedSprite(key string) {
	if data, exists := s.editedSprites[key]; exists {
		s.editedSpritesSize -= int64(len(data))
		delete(s.editedSprites, key)
	}
}

// getNpkDetailFromCache 从缓存获取 NPK 详情
func (s *NpkService) getNpkDetailFromCache(name string) (*NpkFileInfo, bool) {
	if info, exists := s.npkDetailCache[name]; exists {
		// 更新 LRU 顺序
		s.updateNpkDetailLRU(name)
		return info, true
	}
	return nil, false
}

// setNpkDetailCache 设置 NPK 详情缓存（LRU）
func (s *NpkService) setNpkDetailCache(name string, info *NpkFileInfo) {
	// 如果已存在，先删除旧项
	if _, exists := s.npkDetailCache[name]; exists {
		delete(s.npkDetailCache, name)
		s.removeFromNpkDetailOrder(name)
	}

	// 检查是否需要淘汰
	if len(s.npkDetailCache) >= s.npkDetailMaxSize {
		s.evictNpkDetailCache()
	}

	// 添加新项
	s.npkDetailCache[name] = info
	s.npkDetailOrder = append(s.npkDetailOrder, name)
}

// LoadFromDatabase 从数据库加载 NPK 列表到内存（启动时调用）

// ScanDirectory 扫描目录（并发版本）

// ScanDirectoryIncremental 增量扫描目录
// 对比磁盘文件与内存/数据库，只处理变更的文件（并发版本）

// needRescan 检查文件是否需要重新扫描

// ScanFile 扫描文件

// ListNpkFiles 列出 NPK 文件

// GetFileCount 获取内存中的 NPK 文件数量

// GetNpkInfo 获取 NPK 详细信息
// 优化版本：使用 LRU 缓存，最多缓存 50 个 NPK 详情

// loadNpkDetail 加载 NPK 详细信息

// detectExistingReferences 检测 NPK 原有的引用关系
// 通过相同的 offset + length 来识别引用关系

// updateAlbumsMetadata 只更新 albums 表的元数据，不保存 sprites

// syncToDatabase 将 NPK 详细信息同步到数据库（包括 sprites，用于完整导出）
// 优化版本：使用批量插入 sprites，速度提升 10~50 倍

// ClearCache 清空所有缓存

// GetCacheStats 获取缓存统计信息

// RemoveFromCache 从缓存中移除指定 NPK

// DeleteNpk 删除 NPK 文件（磁盘文件 + 数据库记录 + 内存缓存）

// copyFile 复制文件
func (s *NpkService) copyFile(src, dst string) error {
	sourceFile, err := os.Open(src)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	destFile, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer destFile.Close()

	if _, err := io.Copy(destFile, sourceFile); err != nil {
		return err
	}

	return nil
}

// verifyNpk 验证 NPK 文件是否完整可读
func (s *NpkService) verifyNpk(filePath string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return fmt.Errorf("打开文件失败: %w", err)
	}
	defer file.Close()

	// 检测加密类型
	formatType, err := npk.DetectNpkEncryptionType(file)
	if err != nil {
		formatType = 0 // 默认标准加密
	}
	log.Printf("[verifyNpk] 文件: %s, 加密类型: %d", filePath, formatType)

	// 根据加密类型读取 NPK
	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return fmt.Errorf("读取 NPK 头失败: %w", err)
	}
	log.Printf("[verifyNpk] 读取到 %d 个 Albums", len(npkFile.Indexes))

	// 尝试读取每个 Album
	for _, idx := range npkFile.Indexes {
		log.Printf("[verifyNpk] 验证 Album: %s", idx.Path)
		album, err := npk.ReadAlbum(file, idx)
		if err != nil {
			return fmt.Errorf("读取 Album %s 失败: %w", idx.Path, err)
		}
		log.Printf("[verifyNpk]   Album %s 读取成功, %d 个 Sprites", idx.Path, len(album.Sprites))
		// 验证每个 sprite 的数据是否能正确解码
		for i, sprite := range album.Sprites {
			if sprite.Type == npk.LINK {
				continue
			}
			if len(sprite.Data) == 0 {
				continue
			}
			// 尝试解码 sprite 数据
			_, err := npk.DecodeSprite(sprite)
			if err != nil {
				log.Printf("[verifyNpk]   Album %s Sprite %d 解码失败: Type=%d, CompressMode=%d, DataLen=%d, Error=%v",
					idx.Path, i, sprite.Type, sprite.CompressMode, len(sprite.Data), err)
				return fmt.Errorf("验证 Album %s Sprite %d 失败: %w", idx.Path, i, err)
			}
		}
	}

	return nil
}

