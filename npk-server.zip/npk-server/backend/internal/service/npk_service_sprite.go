package service

import (
	"bytes"
	"fmt"
	"image"
	"image/png"
	"mime/multipart"
	"os"

	"github.com/nfnt/resize"

	"npk-server/internal/npk"
)

// GetAlbum 获取 Album（优先从内存，按需从磁盘加载）
func (s *NpkService) GetAlbum(npkName, albumPath string) (*npk.Album, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 尝试从内存文档加载
	albumDoc, err := s.loadAlbumToMemoryLocked(npkName, albumPath)
	if err != nil {
		return nil, err
	}

	// 将 AlbumDocument 转换回 npk.Album（兼容现有接口）
	album := &npk.Album{
		Path:         albumDoc.Path,
		Name:         albumDoc.Name,
		Version:      albumDoc.Version,
		Count:        len(albumDoc.Sprites),
		Sprites:      make([]*npk.Sprite, len(albumDoc.Sprites)),
		Textures:     albumDoc.Textures,
		Tables:       albumDoc.Tables,
		TextureInfos: albumDoc.TextureInfos,
		TargetPath:   albumDoc.TargetPath, // 复制引用目标路径
	}

	for i, sd := range albumDoc.Sprites {
		sprite := &npk.Sprite{
			Index:        sd.Index,
			Type:         sd.Type,
			CompressMode: sd.CompressMode,
			Width:        sd.Width,
			Height:       sd.Height,
			X:            sd.X,
			Y:            sd.Y,
			FrameWidth:   sd.FrameWidth,
			FrameHeight:  sd.FrameHeight,
			Parent:       album,
			TargetIndex:  sd.TargetIndex,
		}
		// 设置 LINK 帧的目标指针（使用独立的副本避免引用问题）
		if sd.IsLink && sd.TargetIndex >= 0 && sd.TargetIndex < len(albumDoc.Sprites) {
			targetSD := albumDoc.Sprites[sd.TargetIndex]
			sprite.Target = &npk.Sprite{
				Index:        targetSD.Index,
				Type:         targetSD.Type,
				CompressMode: targetSD.CompressMode,
				Width:        targetSD.Width,
				Height:       targetSD.Height,
				X:            targetSD.X,
				Y:            targetSD.Y,
				FrameWidth:   targetSD.FrameWidth,
				FrameHeight:  targetSD.FrameHeight,
				TargetIndex:  targetSD.TargetIndex,
				Parent:       album,
			}
			if targetSD.RawData != nil {
				sprite.Target.Data = make([]byte, len(targetSD.RawData))
				copy(sprite.Target.Data, targetSD.RawData)
			}
		}
		// 使用编辑后的 BGRA 数据或原始压缩数据
		if sd.BGRAData != nil {
			sprite.Data = nil // 已在渲染时使用 BGRAData
		} else {
			sprite.Data = make([]byte, len(sd.RawData))
			copy(sprite.Data, sd.RawData)
		}
		album.Sprites[i] = sprite
	}

	return album, nil
}

// GetSprite 获取 Sprite
func (s *NpkService) GetSprite(npkName, albumPath string, index int) (*npk.Sprite, *npk.Album, error) {
	album, err := s.GetAlbum(npkName, albumPath)
	if err != nil {
		return nil, nil, err
	}

	if index < 0 || index >= len(album.Sprites) {
		return nil, nil, fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	return album.Sprites[index], album, nil
}

// GetSpriteImage 获取 Sprite 图像
func (s *NpkService) GetSpriteImage(npkName, albumPath string, index int, width, height int, noCompress bool) ([]byte, error) {
	return s.GetSpriteImageFormat(npkName, albumPath, index, width, height, "png", 90, noCompress)
}

// GetSpriteImageFormat 获取 Sprite 图像（支持指定格式）
func (s *NpkService) GetSpriteImageFormat(npkName, albumPath string, index int, width, height int, format string, quality int, noCompress bool) ([]byte, error) {
	var img *npk.ImageData
	var err error

	// 跳过缓存，直接重新解码（解决旧缓存问题）
	{
		// 3. 从内存文档获取
		s.mu.Lock()
		albumDoc, err := s.loadAlbumToMemoryLocked(npkName, albumPath)
		s.mu.Unlock()

		if err != nil {
			return nil, err
		}

		if index < 0 || index >= len(albumDoc.Sprites) {
			return nil, fmt.Errorf("Sprite 索引超出范围: %d", index)
		}

		sd := albumDoc.Sprites[index]

		// 使用编辑后的 BGRA 数据或从原始数据解码
		if sd.BGRAData != nil {
			img = &npk.ImageData{
				Width:  sd.Width,
				Height: sd.Height,
				Pixels: sd.BGRAData,
				IsV5:   false,
			}
		} else {
			// 处理普通帧或 LINK 帧
			var tmpSprite *npk.Sprite

			if sd.IsLink && sd.Target != nil {
				// LINK 帧：使用已设置好的 Target 属性
				targetSD := sd.Target
				tmpSprite = &npk.Sprite{
					Index:        targetSD.Index,
					Type:         targetSD.Type,
					CompressMode: targetSD.CompressMode,
					Width:        targetSD.Width,
					Height:       targetSD.Height,
					X:            targetSD.X,
					Y:            targetSD.Y,
					FrameWidth:   targetSD.FrameWidth,
					FrameHeight:  targetSD.FrameHeight,
					Data:         targetSD.RawData,
				}
			} else {
				// 普通帧
				tmpSprite = &npk.Sprite{
					Index:        sd.Index,
					Type:         sd.Type,
					CompressMode: sd.CompressMode,
					Width:        sd.Width,
					Height:       sd.Height,
					X:            sd.X,
					Y:            sd.Y,
					FrameWidth:   sd.FrameWidth,
					FrameHeight:  sd.FrameHeight,
					Data:         sd.RawData,
				}
			}

			tmpAlbum := &npk.Album{
				Version:      albumDoc.Version,
				Tables:       albumDoc.Tables,
				TextureInfos: albumDoc.TextureInfos,
			}

			// 输出精灵实际像素尺寸（Width×Height），不包含帧域画布
			img, err = npk.DecodeSpriteFrame(tmpSprite, tmpAlbum, tmpSprite.Width, tmpSprite.Height, 0, 0)
			if err != nil {
				return nil, err
			}
		}
	}

	// 缩放
	if width > 0 && height > 0 {
		img = s.resizeImage(img, width, height)
	}

	var data []byte
	if noCompress && format == "png" {
		data, err = img.ToPNGNoCompression()
	} else {
		data, err = img.Encode(format, quality)
	}
	if err != nil {
		return nil, err
	}

	// 暂时禁用缓存，解决旧缓存问题
	// s.cache.SetImage(cacheKey, data)

	return data, nil
}

// GetThumbnail 获取缩略图
func (s *NpkService) GetThumbnail(npkName, albumPath string, index int) ([]byte, error) {
	// 检查缓存
	if data, ok := s.thumbs.GetThumbnail(npkName, albumPath, index); ok {
		return data, nil
	}

	data, err := s.GetSpriteImage(npkName, albumPath, index, s.cfg.ThumbnailSize, s.cfg.ThumbnailSize, false)
	if err != nil {
		return nil, err
	}

	s.thumbs.SetThumbnail(npkName, albumPath, index, data)
	return data, nil
}

// ReplaceSprite 替换 Sprite
func (s *NpkService) ReplaceSprite(npkName, albumPath string, index int, file *multipart.FileHeader, colorFormat string, autoResize bool) error {
	// 打开上传的文件
	src, err := file.Open()
	if err != nil {
		return fmt.Errorf("打开上传文件失败: %w", err)
	}
	defer src.Close()

	// 解码图片
	img, _, err := image.Decode(src)
	if err != nil {
		return fmt.Errorf("解码图片失败: %w", err)
	}

	// 将 image 转换为 BGRA 字节
	bgraData := npk.ImageToBGRA(img)

	// 从内存中找到对应的 NPK → Album → Sprite
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	if index < 0 || index >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	spriteInfo := albumInfo.Sprites[index]

	// 检查是否是引用帧，引用帧不能直接替换
	if spriteInfo.Type == npk.LINK {
		return fmt.Errorf("不能直接替换引用帧。请先将引用帧转换为普通帧，或者修改其引用的目标帧")
	}

	// 获取新图片的尺寸（直接使用图片自身尺寸）
	bounds := img.Bounds()
	newWidth := bounds.Dx()
	newHeight := bounds.Dy()

	// 根据颜色格式确定类型和压缩模式
	replaceType := spriteInfo.Type
	replaceCompressMode := spriteInfo.CompressMode
	if colorFormat != "" {
		switch colorFormat {
		case "ARGB_1555":
			replaceType = npk.ARGB_1555
			replaceCompressMode = npk.ZLIB
		case "ARGB_4444":
			replaceType = npk.ARGB_4444
			replaceCompressMode = npk.ZLIB
		case "ARGB_8888":
			replaceType = npk.ARGB_8888
			replaceCompressMode = npk.ZLIB
		case "DXT_5":
			replaceType = npk.DXT_5
			replaceCompressMode = npk.DDS_ZLIB
		}
	}

	// 更新 Sprite 信息
	spriteInfo.Type = replaceType
	spriteInfo.CompressMode = replaceCompressMode
	spriteInfo.Width = newWidth
	spriteInfo.Height = newHeight
	spriteInfo.FrameWidth = newWidth
	spriteInfo.FrameHeight = newHeight

	// 将 BGRA 数据存储到编辑缓存（带大小限制）
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	if err := s.setEditedSprite(editKey, bgraData); err != nil {
		return err
	}

	// 同步更新 documents 中的 BGRAData
	if doc, ok := s.documents[npkName]; ok {
		for _, albumDoc := range doc.Albums {
			if albumDoc.Path == albumPath {
				if !albumDoc.IsLoaded {
					// 先加载 album 到内存
					loadedAlbum, loadErr := s.loadAlbumToMemoryLocked(npkName, albumPath)
					if loadErr != nil {
						return fmt.Errorf("加载 Album 失败: %w", loadErr)
					}
					albumDoc = loadedAlbum
				}
				if index < len(albumDoc.Sprites) {
					albumDoc.Sprites[index].BGRAData = bgraData
					albumDoc.Sprites[index].Width = newWidth
					albumDoc.Sprites[index].Height = newHeight
					albumDoc.Sprites[index].FrameWidth = newWidth
					albumDoc.Sprites[index].FrameHeight = newHeight
					albumDoc.Sprites[index].Type = replaceType
					albumDoc.Sprites[index].CompressMode = replaceCompressMode
					albumDoc.Sprites[index].IsModified = true
				}
				break
			}
		}
	}

	// 标记 NPK 信息为已加载，避免从磁盘重新加载覆盖修改
	info.IsLoaded = true

	// 更新缓存
	s.setNpkDetailCache(npkName, info)

	// 清除图片缓存
	cacheKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.cache.Delete(cacheKey)
	s.thumbs.Delete(npkName, albumPath, index)

	return nil
}

// TrimImage 裁剪帧的透明边缘
// 参考 ExtractorSharp Sprite.TrimImage()
// 返回裁剪后的新坐标偏移 (dx, dy)
func (s *NpkService) TrimImage(npkName, albumPath string, index int) (dx, dy int, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return 0, 0, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return 0, 0, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	if index < 0 || index >= len(albumInfo.Sprites) {
		return 0, 0, fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	// 获取当前帧的 BGRA 数据
	bgraData, err := s.getSpriteBGRAData(npkName, albumPath, index)
	if err != nil {
		return 0, 0, fmt.Errorf("获取帧数据失败: %w", err)
	}

	spriteInfo := albumInfo.Sprites[index]
	width := spriteInfo.Width
	height := spriteInfo.Height

	// 扫描非透明区域边界
	// 参考 ExtractorSharp Bitmap.Scan()
	left, top, right, bottom := scanNonTransparentRegion(bgraData, width, height)

	// 如果整个图片都是透明的，不裁剪
	if left >= right || top >= bottom {
		return 0, 0, nil
	}

	newWidth := right - left
	newHeight := bottom - top

	// 裁剪后的数据
	newBgraData := make([]byte, newWidth*newHeight*4)
	for y := 0; y < newHeight; y++ {
		for x := 0; x < newWidth; x++ {
			srcIdx := ((top + y) * width + (left + x)) * 4
			dstIdx := (y * newWidth + x) * 4
			newBgraData[dstIdx+0] = bgraData[srcIdx+0]
			newBgraData[dstIdx+1] = bgraData[srcIdx+1]
			newBgraData[dstIdx+2] = bgraData[srcIdx+2]
			newBgraData[dstIdx+3] = bgraData[srcIdx+3]
		}
	}

	// 更新帧数据
	npkDoc, docExists := s.documents[npkName]
	if docExists {
		for _, albumDoc := range npkDoc.Albums {
			if albumDoc.Path == albumPath {
				if index < len(albumDoc.Sprites) {
					sd := albumDoc.Sprites[index]
					sd.BGRAData = newBgraData
					sd.Width = newWidth
					sd.Height = newHeight
					sd.X += left // 坐标偏移
					sd.Y += top
					sd.IsModified = true
					dx = left
					dy = top
				}
				break
			}
		}
	}

	// 更新编辑缓存
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	if err := s.setEditedSprite(editKey, newBgraData); err != nil {
		return 0, 0, fmt.Errorf("更新编辑缓存失败: %w", err)
	}

	// 清除图片缓存
	cacheKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.cache.Delete(cacheKey)
	s.thumbs.Delete(npkName, albumPath, index)

	return dx, dy, nil
}

// CanvasImage 画布化帧（扩展画布到指定尺寸）
// 参考 ExtractorSharp Sprite.CanvasImage(Rectangle target)
// 新画布的左上角为 (targetX, targetY)，尺寸为 (targetWidth, targetHeight)
func (s *NpkService) CanvasImage(npkName, albumPath string, index, targetX, targetY, targetWidth, targetHeight int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	if index < 0 || index >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	// 获取当前帧的 BGRA 数据
	bgraData, err := s.getSpriteBGRAData(npkName, albumPath, index)
	if err != nil {
		return fmt.Errorf("获取帧数据失败: %w", err)
	}

	spriteInfo := albumInfo.Sprites[index]
	oldWidth := spriteInfo.Width
	oldHeight := spriteInfo.Height
	oldX := spriteInfo.X
	oldY := spriteInfo.Y

	// 创建新画布（全透明）
	newBgraData := make([]byte, targetWidth*targetHeight*4)

	// 将原图绘制到新画布上
	// 原图在新画布中的位置: (oldX - targetX, oldY - targetY)
	destX := oldX - targetX
	destY := oldY - targetY

	for y := 0; y < oldHeight; y++ {
		for x := 0; x < oldWidth; x++ {
			srcIdx := (y * oldWidth + x) * 4
			dstX := destX + x
			dstY := destY + y
			if dstX >= 0 && dstX < targetWidth && dstY >= 0 && dstY < targetHeight {
				dstIdx := (dstY * targetWidth + dstX) * 4
				newBgraData[dstIdx+0] = bgraData[srcIdx+0]
				newBgraData[dstIdx+1] = bgraData[srcIdx+1]
				newBgraData[dstIdx+2] = bgraData[srcIdx+2]
				newBgraData[dstIdx+3] = bgraData[srcIdx+3]
			}
		}
	}

	// 更新帧数据
	npkDoc, docExists := s.documents[npkName]
	if docExists {
		for _, albumDoc := range npkDoc.Albums {
			if albumDoc.Path == albumPath {
				if index < len(albumDoc.Sprites) {
					sd := albumDoc.Sprites[index]
					sd.BGRAData = newBgraData
					sd.Width = targetWidth
					sd.Height = targetHeight
					sd.X = targetX
					sd.Y = targetY
					sd.IsModified = true
				}
				break
			}
		}
	}

	// 更新编辑缓存
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	if err := s.setEditedSprite(editKey, newBgraData); err != nil {
		return fmt.Errorf("更新编辑缓存失败: %w", err)
	}

	// 清除图片缓存
	cacheKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.cache.Delete(cacheKey)
	s.thumbs.Delete(npkName, albumPath, index)

	return nil
}

// getSpriteBGRAData 获取帧的 BGRA 数据（内部使用，调用者需持有锁）
func (s *NpkService) getSpriteBGRAData(npkName, albumPath string, index int) ([]byte, error) {
	// 优先从编辑缓存获取
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	if data, ok := s.editedSprites[editKey]; ok {
		return data, nil
	}

	// 从 documents 获取
	npkDoc, docExists := s.documents[npkName]
	if !docExists {
		return nil, fmt.Errorf("NPK 文档不存在: %s", npkName)
	}

	for _, albumDoc := range npkDoc.Albums {
		if albumDoc.Path == albumPath {
			if index >= len(albumDoc.Sprites) {
				return nil, fmt.Errorf("帧索引超出范围: %d", index)
			}
			sd := albumDoc.Sprites[index]
			if sd.BGRAData != nil {
				return sd.BGRAData, nil
			}
			// 从 RawData 解码
			if len(sd.RawData) > 0 {
				// 需要解码 RawData 到 BGRA
				// 这里简化处理，返回空数据
				return nil, fmt.Errorf("帧数据未加载到内存，请先编辑或替换")
			}
			return nil, fmt.Errorf("帧没有数据")
		}
	}

	return nil, fmt.Errorf("Album 不存在: %s", albumPath)
}

// scanNonTransparentRegion 扫描 BGRA 数据中的非透明区域边界
// 返回 (left, top, right, bottom)
func scanNonTransparentRegion(bgraData []byte, width, height int) (left, top, right, bottom int) {
	left = width
	top = height
	right = 0
	bottom = 0

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			idx := (y*width + x) * 4
			alpha := bgraData[idx+3]
			if alpha > 0 { // 非透明像素
				if x < left {
					left = x
				}
				if x >= right {
					right = x + 1
				}
				if y < top {
					top = y
				}
				if y >= bottom {
					bottom = y + 1
				}
			}
		}
	}

	return left, top, right, bottom
}

// AddSprite 添加新帧
func (s *NpkService) AddSprite(npkName, albumPath string, file *multipart.FileHeader) error {
	// 打开上传的文件
	src, err := file.Open()
	if err != nil {
		return fmt.Errorf("打开上传文件失败: %w", err)
	}
	defer src.Close()

	// 解码图片
	img, _, err := image.Decode(src)
	if err != nil {
		return fmt.Errorf("解码图片失败: %w", err)
	}

	// 将 image 转换为 BGRA 字节
	bgraData := npk.ImageToBGRA(img)

	// 从内存中找到对应的 NPK → Album
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	// 创建新的 Sprite 信息
	bounds := img.Bounds()
	newIndex := len(albumInfo.Sprites)

	// Bug3 修复：根据 Album 版本确定颜色格式
	// Ver4/Ver6 强制 ARGB_1555，Ver5 使用 DXT_5，Ver2 默认 ARGB_1555
	spriteType := npk.ARGB_1555
	compressMode := npk.ZLIB
	switch albumInfo.Version {
	case npk.Ver4, npk.Ver6:
		spriteType = npk.ARGB_1555
		compressMode = npk.ZLIB
	case npk.Ver5:
		spriteType = npk.DXT_5
		compressMode = npk.DDS_ZLIB
	case npk.Ver2:
		// Ver2: 参考同 Album 中现有帧的颜色格式
		if len(albumInfo.Sprites) > 0 {
			for _, s := range albumInfo.Sprites {
				if s.Type != npk.LINK && s.Type != npk.UNKNOWN {
					spriteType = s.Type
					compressMode = s.CompressMode
					break
				}
			}
		}
	}

	// 智能颜色格式选择：如果 PNG 包含大量颜色或需要高精度，使用 ARGB_8888
	// 检测是否需要 8888：检查颜色数量或渐变区域
	if spriteType == npk.ARGB_1555 && needsHighColorDepth(bgraData) {
		spriteType = npk.ARGB_8888
	}

	newSprite := &SpriteInfo{
		Index:         newIndex,
		OriginalIndex: -1, // 新增的帧没有原始索引
		Type:          spriteType,
		CompressMode:  compressMode,
		X:             0,
		Y:             0,
		Width:         bounds.Dx(),
		Height:        bounds.Dy(),
		FrameWidth:    bounds.Dx(),
		FrameHeight:   bounds.Dy(),
	}

	// 添加到 Album
	albumInfo.Sprites = append(albumInfo.Sprites, newSprite)
	albumInfo.SpriteCount = len(albumInfo.Sprites)

	// 将 BGRA 数据存储到编辑缓存（带大小限制）
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, newIndex)
	if err := s.setEditedSprite(editKey, bgraData); err != nil {
		return err
	}

	// 同步更新 documents
	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == albumPath && album.IsLoaded {
				docSprite := &SpriteDocument{
					Index:        newIndex,
					Type:         newSprite.Type,
					CompressMode: newSprite.CompressMode,
					Width:        newSprite.Width,
					Height:       newSprite.Height,
					X:            newSprite.X,
					Y:            newSprite.Y,
					FrameWidth:   newSprite.FrameWidth,
					FrameHeight:  newSprite.FrameHeight,
					BGRAData:     bgraData,
					IsModified:   true,
				}
				album.Sprites = append(album.Sprites, docSprite)
				break
			}
		}
	}

	// 标记 NPK 信息为已加载，避免从磁盘重新加载覆盖修改
	info.IsLoaded = true

	// 更新缓存
	s.setNpkDetailCache(npkName, info)

	return nil
}

// AddLinkSprite 添加引用帧
// position: "before" | "after" | "end"
func (s *NpkService) AddLinkSprite(npkName, albumPath string, targetIndex int, position string) error {
	// 从内存中找到对应的 NPK → Album
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	if targetIndex < 0 || targetIndex >= len(albumInfo.Sprites) {
		return fmt.Errorf("目标帧索引无效: %d", targetIndex)
	}

	// 获取目标帧的尺寸信息（LINK 帧从目标帧复制尺寸）
	targetSprite := albumInfo.Sprites[targetIndex]

	newSprite := &SpriteInfo{
		OriginalIndex: -1, // 新增的帧没有原始索引
		Type:          npk.LINK,
		CompressMode:  npk.ZLIB,
		TargetIndex:   targetIndex,
		IsLink:        true,
		Width:         targetSprite.Width,
		Height:        targetSprite.Height,
		X:             targetSprite.X,
		Y:             targetSprite.Y,
		FrameWidth:    targetSprite.FrameWidth,
		FrameHeight:   targetSprite.FrameHeight,
	}

	// 根据插入位置确定新帧的索引
	var insertIndex int
	switch position {
	case "before":
		insertIndex = targetIndex
	case "after":
		insertIndex = targetIndex + 1
	default: // "end"
		insertIndex = len(albumInfo.Sprites)
	}

	// 在修改任何索引前先保存所有原始索引映射
	oldIndexMap := make(map[*SpriteInfo]int)
	for i, sp := range albumInfo.Sprites {
		oldIndexMap[sp] = i
	}

	// 保存 documents 中原有的 SpriteDocument 原始数据（按旧索引）
	var spriteDocs []*SpriteDocument
	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == albumPath && album.IsLoaded {
				spriteDocs = make([]*SpriteDocument, len(album.Sprites))
				copy(spriteDocs, album.Sprites)
				break
			}
		}
	}

	// 在指定位置插入 Sprite
	albumInfo.Sprites = append(albumInfo.Sprites[:insertIndex], append([]*SpriteInfo{newSprite}, albumInfo.Sprites[insertIndex:]...)...)

	// 重新编号所有 Sprite（保持 TargetIndex 不变，引用目标固定）
	for i, sprite := range albumInfo.Sprites {
		sprite.Index = i
	}

	albumInfo.SpriteCount = len(albumInfo.Sprites)

	// 同步更新 documents（始终同步）
	if doc, ok := s.documents[npkName]; ok {
		for ai := range doc.Albums {
			album := doc.Albums[ai]
			if album.Path == albumPath {
				album.Sprites = make([]*SpriteDocument, 0, len(albumInfo.Sprites))
				for _, sp := range albumInfo.Sprites {
					docSprite := &SpriteDocument{
						Index:         sp.Index,
						Type:          sp.Type,
						CompressMode:  sp.CompressMode,
						Width:         sp.Width,
						Height:        sp.Height,
						X:             sp.X,
						Y:             sp.Y,
						FrameWidth:    sp.FrameWidth,
						FrameHeight:   sp.FrameHeight,
						IsLink:        sp.IsLink,
						TargetIndex:   sp.TargetIndex,
					}
					oldIdx, isOriginal := oldIndexMap[sp]
					if isOriginal && oldIdx >= 0 && oldIdx < len(spriteDocs) {
						docSprite.RawData = spriteDocs[oldIdx].RawData
						docSprite.BGRAData = spriteDocs[oldIdx].BGRAData
						docSprite.IsModified = spriteDocs[oldIdx].IsModified
					}
					album.Sprites = append(album.Sprites, docSprite)
				}
				album.IsLoaded = true
				break
			}
		}
	}

	// 标记 NPK 信息为已加载，避免从磁盘重新加载覆盖修改
	info.IsLoaded = true

	// 更新缓存
	s.setNpkDetailCache(npkName, info)

	return nil
}

// ModifyLinkTarget 修改引用帧的目标索引
func (s *NpkService) ModifyLinkTarget(npkName, albumPath string, spriteIndex, newTargetIndex int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	if spriteIndex < 0 || spriteIndex >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", spriteIndex)
	}

	spriteInfo := albumInfo.Sprites[spriteIndex]
	if spriteInfo.Type != npk.LINK {
		return fmt.Errorf("指定的帧不是引用帧，无法修改引用目标")
	}

	if newTargetIndex < 0 || newTargetIndex >= len(albumInfo.Sprites) {
		return fmt.Errorf("目标帧索引无效: %d", newTargetIndex)
	}

	// 获取目标帧的尺寸信息（LINK 帧从目标帧复制尺寸）
	targetSprite := albumInfo.Sprites[newTargetIndex]

	// 更新 LINK 帧属性
	spriteInfo.TargetIndex = newTargetIndex
	spriteInfo.Target = targetSprite
	spriteInfo.Width = targetSprite.Width
	spriteInfo.Height = targetSprite.Height
	spriteInfo.X = targetSprite.X
	spriteInfo.Y = targetSprite.Y
	spriteInfo.FrameWidth = targetSprite.FrameWidth
	spriteInfo.FrameHeight = targetSprite.FrameHeight

	// 同步更新 documents
	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == albumPath && album.IsLoaded {
				if spriteIndex < len(album.Sprites) {
					docSprite := album.Sprites[spriteIndex]
					docSprite.TargetIndex = newTargetIndex
					docSprite.Width = targetSprite.Width
					docSprite.Height = targetSprite.Height
					docSprite.X = targetSprite.X
					docSprite.Y = targetSprite.Y
					docSprite.FrameWidth = targetSprite.FrameWidth
					docSprite.FrameHeight = targetSprite.FrameHeight
					docSprite.IsModified = true
				}
				break
			}
		}
	}

	return nil
}

// UpdateFrame 修改帧属性
func (s *NpkService) UpdateFrame(npkName, albumPath string, index int, x, y, width, height, frameWidth, frameHeight int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	// 确保 sprites 已加载
	if len(albumInfo.Sprites) == 0 {
		s.ensureSpritesLoaded(npkName, albumPath, albumInfo)
	}

	if index < 0 || index >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	// 直接修改 slice 中的元素，避免值拷贝
	albumInfo.Sprites[index].X = x
	albumInfo.Sprites[index].Y = y
	if width > 0 {
		albumInfo.Sprites[index].Width = width
	}
	if height > 0 {
		albumInfo.Sprites[index].Height = height
	}
	albumInfo.Sprites[index].FrameWidth = frameWidth
	albumInfo.Sprites[index].FrameHeight = frameHeight
	albumInfo.Sprites[index].IsModified = true

	// 同步更新 documents
	if doc, ok := s.documents[npkName]; ok {
		for ai, albumDoc := range doc.Albums {
			if albumDoc.Path == albumPath {
				if !albumDoc.IsLoaded {
					loadedAlbum, loadErr := s.loadAlbumToMemoryLocked(npkName, albumPath)
					if loadErr != nil {
						return fmt.Errorf("加载 Album 失败: %w", loadErr)
					}
					doc.Albums[ai] = loadedAlbum
				}
				if index < len(doc.Albums[ai].Sprites) {
					doc.Albums[ai].Sprites[index].X = x
					doc.Albums[ai].Sprites[index].Y = y
					if width > 0 {
						doc.Albums[ai].Sprites[index].Width = width
					}
					if height > 0 {
						doc.Albums[ai].Sprites[index].Height = height
					}
					doc.Albums[ai].Sprites[index].FrameWidth = frameWidth
					doc.Albums[ai].Sprites[index].FrameHeight = frameHeight
					doc.Albums[ai].Sprites[index].IsModified = true
				}
				break
			}
		}
	}

	return nil
}

// ClearSpriteImage 清空帧图像（变为全透明）
func (s *NpkService) ClearSpriteImage(npkName, albumPath string, index int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	if index < 0 || index >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	spriteInfo := albumInfo.Sprites[index]

	// 创建全透明的 BGRA 数据
	transparentData := make([]byte, spriteInfo.Width*spriteInfo.Height*4)
	// BGRA 格式：B=0, G=0, R=0, A=0 (全透明)
	for i := 3; i < len(transparentData); i += 4 {
		transparentData[i] = 0 // Alpha = 0
	}

	// 存储到编辑缓存
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	if err := s.setEditedSprite(editKey, transparentData); err != nil {
		return err
	}

	// 同步更新 documents
	if doc, ok := s.documents[npkName]; ok {
		for _, albumDoc := range doc.Albums {
			if albumDoc.Path == albumPath {
				if !albumDoc.IsLoaded {
					loadedAlbum, loadErr := s.loadAlbumToMemoryLocked(npkName, albumPath)
					if loadErr != nil {
						return fmt.Errorf("加载 Album 失败: %w", loadErr)
					}
					albumDoc = loadedAlbum
				}
				if index < len(albumDoc.Sprites) {
					albumDoc.Sprites[index].BGRAData = transparentData
					albumDoc.Sprites[index].IsModified = true
				}
				break
			}
		}
	}

	// 清除图片缓存
	cacheKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.cache.Delete(cacheKey)
	s.thumbs.Delete(npkName, albumPath, index)

	return nil
}

// ResetSprite 重置帧属性（撤回未保存修改）
func (s *NpkService) ResetSprite(npkName, albumPath string, index int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	if index < 0 || index >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	// 从磁盘重新读取该 Album 获取原始数据
	npkDoc, docExists := s.documents[npkName]
	if !docExists {
		return fmt.Errorf("NPK 文档不存在: %s", npkName)
	}

	var albumDoc *AlbumDocument
	for _, ad := range npkDoc.Albums {
		if ad.Path == albumPath {
			albumDoc = ad
			break
		}
	}
	if albumDoc == nil {
		return fmt.Errorf("Album 文档不存在: %s", albumPath)
	}

	// 重新从磁盘加载该 Album
	file, err := os.Open(info.Path)
	if err != nil {
		return fmt.Errorf("打开 NPK 文件失败: %w", err)
	}
	defer file.Close()

	// 根据加密类型读取 NPK
	npkFile, err := npk.ReadNpkWithFormat(file, info.FormatType)
	if err != nil {
		return fmt.Errorf("读取 NPK 失败: %w", err)
	}

	var diskAlbum *npk.Album
	for _, idx := range npkFile.Indexes {
		if idx.Path == albumPath {
			diskAlbum, err = npk.ReadAlbum(file, idx)
			if err != nil {
				return fmt.Errorf("读取 Album 失败: %w", err)
			}
			break
		}
	}
	if diskAlbum == nil {
		return fmt.Errorf("Album 在磁盘上不存在: %s", albumPath)
	}

	if index >= len(diskAlbum.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	diskSprite := diskAlbum.Sprites[index]
	spriteInfo := albumInfo.Sprites[index]

	// 恢复原始属性
	spriteInfo.X = diskSprite.X
	spriteInfo.Y = diskSprite.Y
	spriteInfo.FrameWidth = diskSprite.FrameWidth
	spriteInfo.FrameHeight = diskSprite.FrameHeight
	spriteInfo.Width = diskSprite.Width
	spriteInfo.Height = diskSprite.Height

	// 清除编辑缓存
	editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.deleteEditedSprite(editKey)

	// 同步更新 documents
	if albumDoc.IsLoaded {
		if index < len(albumDoc.Sprites) && index < len(diskAlbum.Sprites) {
			rawData := make([]byte, len(diskSprite.Data))
			copy(rawData, diskSprite.Data)
			albumDoc.Sprites[index].BGRAData = nil
			albumDoc.Sprites[index].RawData = rawData
			albumDoc.Sprites[index].IsModified = false
			albumDoc.Sprites[index].X = diskSprite.X
			albumDoc.Sprites[index].Y = diskSprite.Y
			albumDoc.Sprites[index].FrameWidth = diskSprite.FrameWidth
			albumDoc.Sprites[index].FrameHeight = diskSprite.FrameHeight
			albumDoc.Sprites[index].Width = diskSprite.Width
			albumDoc.Sprites[index].Height = diskSprite.Height
		}
	}

	// 清除图片缓存
	cacheKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.cache.Delete(cacheKey)
	s.thumbs.Delete(npkName, albumPath, index)

	return nil
}

// DeleteFrame 删除帧
func (s *NpkService) DeleteFrame(npkName, albumPath string, index int) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	if index < 0 || index >= len(albumInfo.Sprites) {
		return fmt.Errorf("Sprite 索引超出范围: %d", index)
	}

	// 删除指定 index 的 Sprite
	albumInfo.Sprites = append(albumInfo.Sprites[:index], albumInfo.Sprites[index+1:]...)

	// 重新编号前保存原始索引（如果还没保存过）
	for _, sp := range albumInfo.Sprites {
		// OriginalIndex == 0 可能是默认值，需要检查是否真的是索引 0
		// 通过判断 OriginalIndex 是否等于当前 Index 来确定是否已经设置过
		// 如果 OriginalIndex 未设置（等于 Index），则保存当前 Index
		if sp.OriginalIndex == sp.Index {
			sp.OriginalIndex = sp.Index
		}
	}

	// 重新编号剩余 Sprite 的 Index
	for i, sp := range albumInfo.Sprites {
		sp.Index = i
	}

	// 清理编辑缓存中受影响的条目
	// 删除被删除的 sprite 的编辑数据
	deletedKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
	s.deleteEditedSprite(deletedKey)

	// 重新编号编辑缓存中 index > 被删除 index 的条目
	for i := index + 1; i <= len(albumInfo.Sprites); i++ {
		oldKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, i)
		if data, ok := s.editedSprites[oldKey]; ok {
			newKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, i-1)
			s.editedSprites[newKey] = data
			s.editedSpritesSize += int64(len(data))
			s.deleteEditedSprite(oldKey)
		}
	}

	albumInfo.SpriteCount = len(albumInfo.Sprites)

	// 同步更新 documents
	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == albumPath && album.IsLoaded {
				if index < len(album.Sprites) {
					// 直接按位置删除，与 albumInfo.Sprites 保持一致
					album.Sprites = append(album.Sprites[:index], album.Sprites[index+1:]...)
					// 重新编号
					for j, sd := range album.Sprites {
						sd.Index = j
					}
				}
				break
			}
		}
	}

	return nil
}

// resizeImage 缩放图片
func (s *NpkService) resizeImage(img *npk.ImageData, width, height int) *npk.ImageData {
	srcImg := img.ToImage()
	var dstImg image.Image

	if width > 0 && height > 0 {
		dstImg = resize.Resize(uint(width), uint(height), srcImg, resize.Lanczos3)
	} else if width > 0 {
		dstImg = resize.Resize(uint(width), 0, srcImg, resize.Lanczos3)
	} else if height > 0 {
		dstImg = resize.Resize(0, uint(height), srcImg, resize.Lanczos3)
	} else {
		return img
	}

	// 转换回 ImageData
	bounds := dstImg.Bounds()
	result := &npk.ImageData{
		Width:  bounds.Dx(),
		Height: bounds.Dy(),
		Pixels: make([]byte, bounds.Dx()*bounds.Dy()*4),
	}

	for y := 0; y < bounds.Dy(); y++ {
		for x := 0; x < bounds.Dx(); x++ {
			r, g, b, a := dstImg.At(x, y).RGBA()
			idx := (y*bounds.Dx() + x) * 4
			result.Pixels[idx+0] = uint8(b >> 8)
			result.Pixels[idx+1] = uint8(g >> 8)
			result.Pixels[idx+2] = uint8(r >> 8)
			result.Pixels[idx+3] = uint8(a >> 8)
		}
	}

	return result
}

// RemoveBlackBgFromPNG 对 PNG 数据进行去黑底处理（Screen 滤色模式）
// 将黑色背景去除，根据亮度设置透明度
func (s *NpkService) RemoveBlackBgFromPNG(pngData []byte) ([]byte, error) {
	img, err := png.Decode(bytes.NewReader(pngData))
	if err != nil {
		return nil, fmt.Errorf("PNG 解码失败: %w", err)
	}

	bounds := img.Bounds()
	rgba, ok := img.(*image.NRGBA)
	if !ok {
		// 转换为 NRGBA
		rgba = image.NewNRGBA(bounds)
		for y := 0; y < bounds.Dy(); y++ {
			for x := 0; x < bounds.Dx(); x++ {
				rgba.Set(x, y, img.At(x, y))
			}
		}
	}

	// Screen 滤色模式：根据 RGB 最大值设置透明度
	for i := 0; i < len(rgba.Pix); i += 4 {
		r := rgba.Pix[i]
		g := rgba.Pix[i+1]
		b := rgba.Pix[i+2]

		brightness := r
		if g > brightness {
			brightness = g
		}
		if b > brightness {
			brightness = b
		}

		if brightness == 0 {
			rgba.Pix[i+3] = 0 // 纯黑完全透明
		} else {
			rgba.Pix[i+3] = brightness // 根据亮度设置透明度
		}
	}

	var buf bytes.Buffer
	if err := png.Encode(&buf, rgba); err != nil {
		return nil, fmt.Errorf("PNG 编码失败: %w", err)
	}

	return buf.Bytes(), nil
}

// ensureSpritesLoaded 确保 albumInfo.Sprites 已填充（从文档缓存或磁盘加载）
func (s *NpkService) ensureSpritesLoaded(npkName, albumPath string, albumInfo *AlbumInfo) {
	// 1. 尝试从文档缓存获取
	if doc, ok := s.documents[npkName]; ok {
		for _, albumDoc := range doc.Albums {
			if albumDoc.Path == albumPath && albumDoc.IsLoaded {
				albumInfo.Sprites = make([]*SpriteInfo, len(albumDoc.Sprites))
				for i, sd := range albumDoc.Sprites {
					albumInfo.Sprites[i] = &SpriteInfo{
						Index: i, X: sd.X, Y: sd.Y,
						Width: sd.Width, Height: sd.Height,
						FrameWidth: sd.FrameWidth, FrameHeight: sd.FrameHeight,
						Type: sd.Type, CompressMode: sd.CompressMode,
						IsLink: sd.IsLink, TargetIndex: sd.TargetIndex,
					}
				}
				return
			}
		}
	}
	// 2. 从磁盘加载
	loaded, err := s.loadAlbumToMemoryLocked(npkName, albumPath)
	if err != nil {
		return
	}
	albumInfo.Sprites = make([]*SpriteInfo, len(loaded.Sprites))
	for i, sd := range loaded.Sprites {
		albumInfo.Sprites[i] = &SpriteInfo{
			Index: i, X: sd.X, Y: sd.Y,
			Width: sd.Width, Height: sd.Height,
			FrameWidth: sd.FrameWidth, FrameHeight: sd.FrameHeight,
			Type: sd.Type, CompressMode: sd.CompressMode,
			IsLink: sd.IsLink, TargetIndex: sd.TargetIndex,
		}
	}
}
