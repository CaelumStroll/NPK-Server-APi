package service

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"npk-server/internal/database"
	"npk-server/internal/npk"
)

// LoadFromDatabase 从数据库加载 NPK 文件信息到内存
func (s *NpkService) LoadFromDatabase() error {
	npkFiles, err := s.db.ListNpkFiles()
	if err != nil {
		return fmt.Errorf("加载 NPK 列表失败: %w", err)
	}

	if len(npkFiles) == 0 {
		return nil
	}

	// 收集所有 NPK ID
	var allIDs []int64
	for _, f := range npkFiles {
		allIDs = append(allIDs, f.ID)
	}

	// 批量加载所有 albums（单个 IN 查询，避免 N+1）
	batchSize := 500
	albumMap := make(map[int64][]*database.AlbumRecord)
	for i := 0; i < len(allIDs); i += batchSize {
		end := i + batchSize
		if end > len(allIDs) {
			end = len(allIDs)
		}
		batch, err := s.db.GetAlbumsByNpkIDs(allIDs[i:end])
		if err != nil {
			log.Printf("批量加载 albums 失败 (batch %d-%d): %v", i, end, err)
			continue
		}
		for id, albums := range batch {
			albumMap[id] = albums
		}
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	for _, dbNpk := range npkFiles {
		// 跳过不存在的文件（减少 stat 调用—仅在需要时检查）
		info := &NpkFileInfo{
			Name:      dbNpk.Name,
			Path:      dbNpk.Path,
			Size:      dbNpk.Size,
			Modified:  dbNpk.ModifiedAt,
			Scanned:   dbNpk.ScannedAt,
			Albums:    []*AlbumInfo{},
			ImgCount:           dbNpk.ImgCount,
			SHA256Hash:         dbNpk.SHA256Hash,
			FormatType:         dbNpk.FormatType,
			EncryptionVerified: dbNpk.EncryptionVerified,
		}

		// 从批量结果中获取 albums
		if albums, ok := albumMap[dbNpk.ID]; ok {
			for _, album := range albums {
				info.Albums = append(info.Albums, &AlbumInfo{
					Path:        album.Path,
					Name:        album.Name,
					FileType:    album.FileType,
					Version:     npk.ImgVersion(album.Version),
					SpriteCount: album.SpriteCount,
					Offset:      album.Offset,
					Size:        album.Size,
					PaletteJSON: album.PaletteJSON,
					DDSInfoJSON: album.DDSInfoJSON,
				})
			}
		}

		s.files[dbNpk.Name] = info
	}

	log.Printf("从数据库加载了 %d 个 NPK 文件到内存 (%d 个 albums)", len(s.files), len(albumMap))
	return nil
}

// ScanProgress 扫描进度
type ScanProgress struct {
	Total     int    `json:"total"`
	Current   int    `json:"current"`
	FileName  string `json:"file_name"`
	Status    string `json:"status"` // scanning, completed, error
	Message   string `json:"message"`
}

// ScanDirectory 扫描目录（并发版本）
func (s *NpkService) ScanDirectory(dir string, progressChan chan<- ScanProgress) error {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return fmt.Errorf("读取目录失败: %w", err)
	}

	// 收集所有 NPK 文件
	var npkFiles []string
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		name := entry.Name()
		if !strings.HasSuffix(strings.ToLower(name), ".npk") {
			continue
		}
		npkFiles = append(npkFiles, filepath.Join(dir, name))
	}

	total := len(npkFiles)
	if total == 0 {
		return nil
	}

	// 发送总进度
	if progressChan != nil {
		progressChan <- ScanProgress{Total: total, Current: 0, Status: "started"}
	}

	// 使用工作池并发扫描（限制为1，避免SQLite并发写入冲突）
	const workerCount = 1 // 串行扫描，避免数据库锁定
	var wg sync.WaitGroup
	fileChan := make(chan string, total)
	var current int32 = 0

	// 启动工作协程
	for i := 0; i < workerCount; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for path := range fileChan {
				name := filepath.Base(path)
				
				// 发送开始扫描进度
				if progressChan != nil {
					progressChan <- ScanProgress{
						Total:    total,
						Current:  int(atomic.AddInt32(&current, 1)),
						FileName: name,
						Status:   "scanning",
					}
				}

				// 检查是否需要重新扫描（增量更新）
				if !s.needRescan(path) {
					log.Printf("跳过未变更文件: %s", name)
					if progressChan != nil {
						progressChan <- ScanProgress{
							Total:    total,
							Current:  int(current),
							FileName: name,
							Status:   "skipped",
							Message:  "未变更",
						}
					}
					continue
				}

				// 扫描文件
				if err := s.ScanFile(path); err != nil {
					log.Printf("扫描文件失败 %s: %v", path, err)
					if progressChan != nil {
						progressChan <- ScanProgress{
							Total:    total,
							Current:  int(current),
							FileName: name,
							Status:   "error",
							Message:  err.Error(),
						}
					}
				} else {
					if progressChan != nil {
						progressChan <- ScanProgress{
							Total:    total,
							Current:  int(current),
							FileName: name,
							Status:   "completed",
						}
					}
				}
			}
		}()
	}

	// 发送文件到工作池
	for _, path := range npkFiles {
		fileChan <- path
	}
	close(fileChan)

	// 等待完成
	wg.Wait()

	if progressChan != nil {
		progressChan <- ScanProgress{Total: total, Current: total, Status: "finished"}
	}

	return nil
}

// IncrementalResult 增量扫描结果
type IncrementalResult struct {
	TotalNpks       int `json:"total_npks"`
	ScannedNpks     int `json:"scanned_npks"`
	SkippedNpks     int `json:"skipped_npks"`
	NpkChanged      int `json:"npk_changed"`
	AlbumsChanged   int `json:"albums_changed"`
	NewNpks         int `json:"new_npks"`
	DeletedNpks     int `json:"deleted_npks"`
}

// ScanDirectoryIncremental 增量扫描目录
// 对比磁盘文件与内存/数据库，只处理变更的文件（并发版本）
func (s *NpkService) ScanDirectoryIncremental(dir string) (*IncrementalResult, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("读取目录失败: %w", err)
	}

	// 收集磁盘上的 NPK 文件
	diskFiles := make(map[string]string) // name -> path
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		name := entry.Name()
		if !strings.HasSuffix(strings.ToLower(name), ".npk") {
			continue
		}
		diskFiles[name] = filepath.Join(dir, name)
	}

	result := &IncrementalResult{
		TotalNpks: len(diskFiles),
	}

	// 获取内存中已有的 NPK 名称
	s.mu.RLock()
	memNames := make(map[string]bool)
	for name := range s.files {
		memNames[name] = true
	}
	s.mu.RUnlock()

	// 1. 处理磁盘上的文件（并发增量扫描）
	if len(diskFiles) > 0 {
		// 使用 Worker 池并发处理 NPK 文件
		type scanJob struct {
			name string
			path string
		}

		jobs := make(chan scanJob, len(diskFiles))
		type scanResult struct {
			name           string
			npkChanged     bool
			albumsChanged  bool
			err            error
		}
		results := make(chan scanResult, len(diskFiles))

		// 并发数：使用 CPU 核心数，但最少 1，最多 8
		workerCount := runtime.NumCPU()
		if workerCount < 1 {
			workerCount = 1
		}
		if workerCount > 8 {
			workerCount = 8
		}

		// 启动 Worker
		var wg sync.WaitGroup
		for i := 0; i < workerCount; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for job := range jobs {
					npkChanged, albumsChanged, err := s.ScanFileIncremental(job.path)
					results <- scanResult{
						name:          job.name,
						npkChanged:    npkChanged,
						albumsChanged: albumsChanged,
						err:           err,
					}
				}
			}()
		}

		// 发送任务
		for name, path := range diskFiles {
			jobs <- scanJob{name: name, path: path}
		}
		close(jobs)

		// 等待所有 Worker 完成并关闭 results 通道
		go func() {
			wg.Wait()
			close(results)
		}()

		// 收集结果
		for res := range results {
			result.ScannedNpks++
			if res.err != nil {
				log.Printf("增量扫描失败 %s: %v", res.name, res.err)
				continue
			}
			if !res.npkChanged && !res.albumsChanged {
				result.SkippedNpks++
			}
			if res.npkChanged {
				result.NpkChanged++
				if !memNames[res.name] {
					result.NewNpks++
				}
			}
			if res.albumsChanged {
				result.AlbumsChanged++
			}
		}
	}

	// 2. 检测已删除的 NPK 文件
	for name := range memNames {
		if _, exists := diskFiles[name]; !exists {
			// 检查是否在其他目录中（多目录场景）
			found := false
			for _, otherDir := range s.cfg.NpkDirs {
				if otherDir == dir {
					continue
				}
				if _, err := os.Stat(filepath.Join(otherDir, name)); err == nil {
					found = true
					break
				}
			}
			if !found {
				s.RemoveFromCache(name)
				result.DeletedNpks++
			}
		}
	}

	return result, nil
}

// needRescan 检查文件是否需要重新扫描
func (s *NpkService) needRescan(path string) bool {
	stat, err := os.Stat(path)
	if err != nil {
		return true // 无法获取信息，重新扫描
	}

	name := filepath.Base(path)
	
	s.mu.RLock()
	info, exists := s.files[name]
	s.mu.RUnlock()

	if !exists {
		return true // 未扫描过
	}

	// 检查修改时间和大小
	if stat.ModTime().After(info.Modified) || stat.Size() != info.Size {
		return true // 文件已变更
	}

	// 检查内存中 size 是否为 0（可能是旧数据），强制重新扫描
	if info.Size == 0 && stat.Size() > 0 {
		return true
	}

	return false // 未变更，跳过
}

// ScanFile 扫描文件
func (s *NpkService) ScanFile(path string) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()

	stat, err := file.Stat()
	if err != nil {
		return err
	}

	// 检测加密类型
	formatType, err := npk.DetectNpkEncryptionType(file)
	if err != nil {
		formatType = 0 // 默认标准加密
	}

	// 根据加密类型读取 NPK
	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return err
	}

	name := filepath.Base(path)
	info := &NpkFileInfo{
		Name:       name,
		Path:       path,
		Size:       stat.Size(),
		Modified:   stat.ModTime(),
		Albums:     make([]*AlbumInfo, 0),
		Scanned:    time.Now(),
		// v4 增强：从 NPK 读取元数据
		ImgCount:   len(npkFile.Indexes),
		FormatType: formatType,
	}

	// 读取每个 Album 的基本信息
	for _, idx := range npkFile.Indexes {
		albumInfo := &AlbumInfo{
			Path:   idx.Path,
			Name:   extractName(idx.Path),
			Offset: int64(idx.Offset), // v5 增强：记录偏移量
			Size:   int64(idx.Length), // v5 增强：记录大小
		}
		// 检测文件类型
		lowerName := strings.ToLower(idx.Path)
		if strings.HasSuffix(lowerName, ".ogg") {
			albumInfo.FileType = 1 // OGG
		} else if !strings.HasSuffix(lowerName, ".img") {
			albumInfo.FileType = 2 // 其他
		} else {
			// 快速读取 IMG header 信息获取 Version 和 SpriteCount
			if header, err := npk.ReadAlbumHeader(file, idx); err == nil {
				albumInfo.Version = header.Version
				albumInfo.SpriteCount = header.SpriteCount
			}
		}
		info.Albums = append(info.Albums, albumInfo)
	}

	s.mu.Lock()
	s.files[name] = info
	s.mu.Unlock()

	// 保存到数据库（包含加密类型）
	npkID, err := s.db.InsertNpkFile(name, path, stat.Size(), len(npkFile.Indexes), "", formatType, true, stat.ModTime())
	if err != nil {
		log.Printf("保存到数据库失败: %v", err)
	} else if npkID > 0 {
		// 同步 albums 到数据库（使用预读取的 Version 和 SpriteCount）
		for _, album := range info.Albums {
			s.db.InsertAlbum(npkID, album.Path, album.Name, album.FileType, int(album.Version), album.SpriteCount, album.Offset, album.Size, "", "")
		}
	}

	log.Printf("扫描文件: %s, Albums: %d", name, len(info.Albums))

	return nil
}

// ScanFileIncremental 增量扫描文件（两级对比：NPK文件 -> Albums路径）
// 不读取 Sprites 详情，只同步 Albums 索引
// 返回：是否更新了NPK文件、是否更新了Albums、错误
func (s *NpkService) ScanFileIncremental(path string) (bool, bool, error) {
	file, err := os.Open(path)
	if err != nil {
		return false, false, err
	}
	defer file.Close()

	stat, err := file.Stat()
	if err != nil {
		return false, false, err
	}

	name := filepath.Base(path)

	s.mu.RLock()
	existingInfo, exists := s.files[name]
	s.mu.RUnlock()

	// 第一级：检查NPK文件是否变更
	npkFileChanged := true
	if exists {
		if !stat.ModTime().After(existingInfo.Modified) && stat.Size() == existingInfo.Size {
			npkFileChanged = false
		}
	}

	// 检测加密类型
	formatType, err := npk.DetectNpkEncryptionType(file)
	if err != nil {
		formatType = 0 // 默认标准加密
	}

	// 根据加密类型读取 NPK
	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return false, false, err
	}

	// 构建新的Albums列表
	newAlbums := make([]*AlbumInfo, 0, len(npkFile.Indexes))
	for _, idx := range npkFile.Indexes {
		albumInfo := &AlbumInfo{
			Path:   idx.Path,
			Name:   extractName(idx.Path),
			Offset: int64(idx.Offset), // v5 增强：记录偏移量
			Size:   int64(idx.Length), // v5 增强：记录大小
		}
		// 检测文件类型
		lowerName := strings.ToLower(idx.Path)
		if strings.HasSuffix(lowerName, ".ogg") {
			albumInfo.FileType = 1 // OGG
		} else if !strings.HasSuffix(lowerName, ".img") {
			albumInfo.FileType = 2 // 其他
		} else {
			// 快速读取 IMG header 信息获取 Version 和 SpriteCount
			if header, err := npk.ReadAlbumHeader(file, idx); err == nil {
				albumInfo.Version = header.Version
				albumInfo.SpriteCount = header.SpriteCount
			}
		}
		newAlbums = append(newAlbums, albumInfo)
	}

	// 第二级：对比Albums全路径
	albumsChanged := true
	if !npkFileChanged && exists {
		// NPK文件未变更，检查Albums路径是否一致
		if len(newAlbums) == len(existingInfo.Albums) {
			albumsChanged = false
			existingPaths := make(map[string]bool)
			for _, album := range existingInfo.Albums {
				existingPaths[album.Path] = true
			}
			for _, album := range newAlbums {
				if !existingPaths[album.Path] {
					albumsChanged = true
					break
				}
			}
		}
	}

	// 如果都没有变更，直接返回
	if !npkFileChanged && !albumsChanged {
		log.Printf("增量扫描跳过: %s (NPK和Albums均未变更)", name)
		return false, false, nil
	}

	// 更新内存
	info := &NpkFileInfo{
		Name:       name,
		Path:       path,
		Size:       stat.Size(),
		Modified:   stat.ModTime(),
		Albums:     newAlbums,
		Scanned:    time.Now(),
		FormatType: formatType,
	}

	s.mu.Lock()
	s.files[name] = info
	s.mu.Unlock()

	// 同步到数据库（包含加密类型）
	npkID, err := s.db.InsertNpkFile(name, path, stat.Size(), len(npkFile.Indexes), "", formatType, true, stat.ModTime())
	if err != nil {
		log.Printf("保存NPK到数据库失败: %v", err)
		return npkFileChanged, albumsChanged, nil
	}

	if npkID > 0 {
		// 获取数据库中现有的Albums
		existingDbAlbums, _ := s.db.GetAlbumsByNpkID(npkID)
		existingDbPaths := make(map[string]int64) // path -> albumID
		for _, album := range existingDbAlbums {
			existingDbPaths[album.Path] = album.ID
		}

		// 同步Albums：新增或保留
		currentPaths := make(map[string]bool)
		for _, album := range newAlbums {
			currentPaths[album.Path] = true
			if albumID, exists := existingDbPaths[album.Path]; !exists {
				// 新增Album，使用预读取的 Version 和 SpriteCount
				s.db.InsertAlbum(npkID, album.Path, album.Name, album.FileType, int(album.Version), album.SpriteCount, album.Offset, album.Size, "", "")
			} else {
				// 已存在的Album，检查是否需要更新 Version 和 SpriteCount
				var dbAlbum *database.AlbumRecord
				for _, a := range existingDbAlbums {
					if a.ID == albumID {
						dbAlbum = a
						break
					}
				}
				if dbAlbum != nil && (dbAlbum.Version != int(album.Version) || dbAlbum.SpriteCount != album.SpriteCount) {
					s.db.UpdateAlbumSpriteInfo(npkID, album.Path, int(album.Version), album.SpriteCount)
				}
			}
		}

		// 删除数据库中不存在的Albums（及其关联数据）
		for path, albumID := range existingDbPaths {
			if !currentPaths[path] {
				s.db.DeleteAlbumWithRelations(albumID)
			}
		}
	}

	log.Printf("增量扫描更新: %s (NPK变更:%v, Albums变更:%v)", name, npkFileChanged, albumsChanged)
	return npkFileChanged, albumsChanged, nil
}

// ListNpkFiles 列出 NPK 文件
func (s *NpkService) ListNpkFiles() []*NpkFileInfo {
	s.mu.RLock()
	defer s.mu.RUnlock()

	result := make([]*NpkFileInfo, 0, len(s.files))
	for _, info := range s.files {
		result = append(result, info)
	}

	sort.Slice(result, func(i, j int) bool {
		return result[i].Name < result[j].Name
	})

	return result
}

// GetFileCount 获取内存中的 NPK 文件数量
func (s *NpkService) GetFileCount() int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return len(s.files)
}

// GetNpkInfo 获取 NPK 详细信息
// 优化版本：使用 LRU 缓存，最多缓存 50 个 NPK 详情
func (s *NpkService) GetNpkInfo(name string) (*NpkFileInfo, error) {
	s.mu.RLock()
	info, exists := s.files[name]
	s.mu.RUnlock()

	if !exists {
		return nil, fmt.Errorf("NPK 文件不存在: %s", name)
	}

	// 如果已经加载了详细信息，直接返回
	if info.IsLoaded {
		return info, nil
	}

	// 尝试从缓存获取
	s.mu.Lock()
	defer s.mu.Unlock()

	if cachedInfo, found := s.getNpkDetailFromCache(name); found {
		// 更新 files 中的引用
		s.files[name] = cachedInfo
		return cachedInfo, nil
	}

	// 从磁盘加载详细信息
	err := s.loadNpkDetail(info)
	if err != nil {
		return nil, err
	}

	// 存入缓存
	s.setNpkDetailCache(name, info)

	return info, nil
}

// loadNpkDetail 加载 NPK 详细信息（只读取 Album 头部，不解析 Sprites）
func (s *NpkService) loadNpkDetail(info *NpkFileInfo) error {
	file, err := os.Open(info.Path)
	if err != nil {
		return err
	}
	defer file.Close()

	// 根据 format_type 选择读取方式
	npkFile, err := npk.ReadNpkWithFormat(file, info.FormatType)
	if err != nil {
		return err
	}

	// 创建 Albums 列表（只读头部，不解析 Sprites）
	albums := make([]*AlbumInfo, 0, len(npkFile.Indexes))

	for _, idx := range npkFile.Indexes {
		// 使用 ReadAlbumHeader 快速读取（跳过 Sprite 解析）
		header, err := npk.ReadAlbumHeader(file, idx)
		if err != nil {
			albums = append(albums, &AlbumInfo{
				Path:        idx.Path,
				Name:        extractName(idx.Path),
				Version:     0,
				SpriteCount: 0,
				Sprites:     make([]*SpriteInfo, 0),
			})
			continue
		}

		albumInfo := &AlbumInfo{
			Path:        idx.Path,
			Name:        extractName(idx.Path),
			Version:     header.Version,
			SpriteCount: header.SpriteCount,
			Sprites:     make([]*SpriteInfo, 0, header.SpriteCount),
			Textures:    make([]*TextureInfo, 0),
			Offset:      int64(idx.Offset),
			Size:        int64(idx.Length),
		}

		albums = append(albums, albumInfo)
	}

	// 检测 NPK 原有的引用关系
	s.detectExistingReferences(albums)

	info.Albums = albums
	info.IsLoaded = true

	// 初始化 documents（不含像素数据）
	doc := &NpkDocument{
		Name:       info.Name,
		Path:       info.Path,
		Size:       info.Size,
		Modified:   info.Modified,
		Albums:     make([]*AlbumDocument, len(info.Albums)),
		IsLoaded:   false,
		LastAccess: time.Now(),
	}
	for i, ai := range info.Albums {
		doc.Albums[i] = &AlbumDocument{
			Path:         ai.Path,
			OriginalPath: ai.Path,
			Name:         ai.Name,
			Version:      ai.Version,
			Sprites:      nil,
			IsLoaded:     false,
			LastAccess:   time.Now(),
			TargetPath:   ai.TargetPath,
		}
	}
	s.documents[info.Name] = doc

	// 注意：扫描时不保存 sprites 到数据库，sprites 在使用时按需加载
	// 只更新 albums 的元数据（version, sprite_count, palette_json, dds_info_json）
	s.updateAlbumsMetadata(info)

	return nil
}

// detectExistingReferences 检测 NPK 原有的引用关系
// 通过相同的 offset + length 来识别引用关系
func (s *NpkService) detectExistingReferences(albums []*AlbumInfo) {
	if len(albums) < 2 {
		return
	}

	// 使用 map 记录 offset+length -> 第一个出现的 Album
	offsetLengthMap := make(map[string]*AlbumInfo)

	for _, album := range albums {
		key := fmt.Sprintf("%d:%d", album.Offset, album.Size)

		if existingAlbum, exists := offsetLengthMap[key]; exists {
			// 找到引用关系：当前 album 引用 existingAlbum
			// 设置引用关系
			album.Target = existingAlbum
			album.TargetPath = existingAlbum.Path

			// 引用不存储 Sprite，只存储目标路径
			album.Sprites = nil
			album.SpriteCount = existingAlbum.SpriteCount
			album.Version = existingAlbum.Version
			album.PaletteJSON = existingAlbum.PaletteJSON
			album.DDSInfoJSON = existingAlbum.DDSInfoJSON

			log.Printf("检测到原有引用关系: %s → %s", album.Path, existingAlbum.Path)
		} else {
			// 记录第一个出现的 album
			offsetLengthMap[key] = album
		}
	}
}

// updateAlbumsMetadata 只更新 albums 表的元数据，不保存 sprites
func (s *NpkService) updateAlbumsMetadata(info *NpkFileInfo) {
	if s.db == nil {
		return
	}

	// 获取 NPK 记录
	npkRecord, err := s.db.GetNpkFileByName(info.Name)
	if err != nil {
		log.Printf("updateAlbumsMetadata: 获取 NPK 记录失败 %s: %v", info.Name, err)
		return
	}

	// 更新每个 album 的元数据
	for _, album := range info.Albums {
		// 查找数据库中的 album 记录
		dbAlbum, err := s.db.GetAlbumByPath(npkRecord.ID, album.Path)
		if err != nil || dbAlbum == nil {
			// 如果不存在，插入新记录（只保存元数据，不保存 sprites）
			_, err = s.db.InsertAlbum(npkRecord.ID, album.Path, album.Name, album.FileType,
				int(album.Version), album.SpriteCount, album.Offset, album.Size,
				album.PaletteJSON, album.DDSInfoJSON)
			if err != nil {
				log.Printf("updateAlbumsMetadata: 插入 album 失败 %s: %v", album.Path, err)
			}
		} else {
			// 更新现有记录
			err = s.db.UpdateAlbum(dbAlbum.ID, album.FileType, int(album.Version),
				album.SpriteCount, album.Offset, album.Size,
				album.PaletteJSON, album.DDSInfoJSON)
			if err != nil {
				log.Printf("updateAlbumsMetadata: 更新 album 失败 %s: %v", album.Path, err)
			}
		}
	}
}

// syncToDatabase 将 NPK 详细信息同步到数据库（包括 sprites，用于完整导出）
// 优化版本：使用批量插入 sprites，速度提升 10~50 倍
func (s *NpkService) syncToDatabase(info *NpkFileInfo) {
	if s.db == nil {
		return
	}

	// 获取 NPK 文件的数据库 ID
	npkRecord, err := s.db.GetNpkFileByName(info.Name)
	if err != nil {
		return
	}

	// 使用事务删除旧记录
	tx, err := s.db.Begin()
	if err != nil {
		log.Printf("syncToDatabase: 开始事务失败: %v", err)
		return
	}
	defer tx.Rollback()

	// 删除旧的 albums 和 sprites 记录
	if _, err := tx.Exec(`DELETE FROM sprites WHERE album_id IN (SELECT id FROM albums WHERE npk_id = ?)`, npkRecord.ID); err != nil {
		log.Printf("syncToDatabase: 删除旧 sprites 失败: %v", err)
		return
	}
	if _, err := tx.Exec(`DELETE FROM albums WHERE npk_id = ?`, npkRecord.ID); err != nil {
		log.Printf("syncToDatabase: 删除旧 albums 失败: %v", err)
		return
	}

	// 提交删除操作
	if err := tx.Commit(); err != nil {
		log.Printf("syncToDatabase: 提交删除失败: %v", err)
		return
	}

	// 写入新的 albums 和 sprites（批量插入）
	for _, album := range info.Albums {
		albumID, err := s.db.InsertAlbum(npkRecord.ID, album.Path, album.Name, album.FileType, int(album.Version), album.SpriteCount, album.Offset, album.Size, album.PaletteJSON, album.DDSInfoJSON)
		if err != nil {
			log.Printf("syncToDatabase: 插入 album 失败 %s: %v", album.Path, err)
			continue
		}

		// 准备批量插入的 sprites 数据
		spritesBatch := make([]*database.SpriteBatchItem, 0, len(album.Sprites))
		for _, sprite := range album.Sprites {
			spritesBatch = append(spritesBatch, &database.SpriteBatchItem{
				Index:        sprite.Index,
				Type:         int(sprite.Type),
				CompressMode: int(sprite.CompressMode),
				Width:        sprite.Width,
				Height:       sprite.Height,
				X:            sprite.X,
				Y:            sprite.Y,
				FrameWidth:   sprite.FrameWidth,
				FrameHeight:  sprite.FrameHeight,
				IsLink:       sprite.IsLink,
				TargetIndex:  sprite.TargetIndex,
				DataSize:     sprite.DataSize, // v6 增强
			})
		}

		// 批量插入 sprites
		if err := s.db.InsertSpritesBatch(albumID, spritesBatch); err != nil {
			log.Printf("syncToDatabase: 批量插入 sprites 失败 %s: %v", album.Path, err)
		}
	}
}

// ClearCache 清空所有缓存
func (s *NpkService) ClearCache() {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 关闭所有打开的文件
	for _, f := range s.openFile {
		f.Close()
	}
	s.openFile = make(map[string]*os.File)
	s.files = make(map[string]*NpkFileInfo)
	s.documents = make(map[string]*NpkDocument)
	s.editedSprites = make(map[string][]byte)
	s.editedSpritesSize = 0
	s.cache.Clear()
	s.thumbs.Clear()
}

// GetCacheStats 获取缓存统计信息
func (s *NpkService) GetCacheStats() map[string]interface{} {
	// 获取原有图片缓存统计
	stats := s.cache.Stats()

	// 获取 IMG 缓存池统计
	imgCacheStatus := s.imgCache.GetStatus()

	// 合并统计信息
	result := map[string]interface{}{
		"size":          stats["size"],
		"count":         stats["count"],
		"max_size":      stats["max_size"],
		"hits":          stats["hits"],
		"misses":        stats["misses"],
		"hit_rate":      stats["hit_rate"],
		"img_cache":     imgCacheStatus,
	}

	return result
}

// RemoveFromCache 从缓存中移除指定 NPK
func (s *NpkService) RemoveFromCache(name string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 关闭打开的文件
	if info, exists := s.files[name]; exists {
		if f, open := s.openFile[info.Path]; open {
			f.Close()
			delete(s.openFile, info.Path)
		}
		delete(s.files, name)
	}
	delete(s.documents, name)
}

// DeleteNpk 删除 NPK 文件（磁盘文件 + 数据库记录 + 内存缓存）
func (s *NpkService) DeleteNpk(name string) error {
	s.mu.RLock()
	info, exists := s.files[name]
	s.mu.RUnlock()

	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", name)
	}

	// 1. 删除磁盘文件
	if err := os.Remove(info.Path); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("删除文件失败: %w", err)
	}

	// 2. 删除数据库记录（通过文件名查找）
	if s.db != nil {
		record, err := s.db.GetNpkFileByName(name)
		if err == nil {
			_ = s.db.DeleteNpkFile(record.ID)
		}
	}

	// 3. 清除内存缓存
	s.RemoveFromCache(name)
	s.cache.DeleteByNpk(name)
	s.thumbs.DeleteByNpk(name)

	// 4. 清除编辑缓存
	s.mu.Lock()
	for key := range s.editedSprites {
		if strings.HasPrefix(key, name+":") {
			s.deleteEditedSprite(key)
		}
	}
	// 清除详情缓存
	if _, ok := s.npkDetailCache[name]; ok {
		delete(s.npkDetailCache, name)
		s.removeFromNpkDetailOrder(name)
	}
	s.mu.Unlock()

	return nil
}

// backupNpkFile 备份 NPK 文件
func (s *NpkService) backupNpkFile(npkPath string) error {
	// 获取文件信息
	stat, err := os.Stat(npkPath)
	if err != nil {
		return fmt.Errorf("获取文件信息失败: %w", err)
	}

	// 获取目录和文件名
	dir := filepath.Dir(npkPath)
	baseName := filepath.Base(npkPath)

	// 创建备份目录 Backup_yymmdd
	now := time.Now()
	backupDirName := fmt.Sprintf("Backup_%02d%02d%02d", now.Year()%100, now.Month(), now.Day())
	backupDir := filepath.Join(dir, backupDirName)

	if err := os.MkdirAll(backupDir, 0755); err != nil {
		return fmt.Errorf("创建备份目录失败: %w", err)
	}

	// 生成备份文件名: 原文件名（不含扩展名）_HH_MM_SS@原扩展名.img
	// 例如: sprite_map_anton_14_30_25@.npk.img
	ext := filepath.Ext(baseName)
	nameWithoutExt := strings.TrimSuffix(baseName, ext)
	backupName := fmt.Sprintf("%s_%02d_%02d_%02d@%s.img",
		nameWithoutExt,
		now.Hour(),
		now.Minute(),
		now.Second(),
		ext,
	)
	backupPath := filepath.Join(backupDir, backupName)

	// 复制文件
	srcFile, err := os.Open(npkPath)
	if err != nil {
		return fmt.Errorf("打开源文件失败: %w", err)
	}
	defer srcFile.Close()

	dstFile, err := os.Create(backupPath)
	if err != nil {
		return fmt.Errorf("创建备份文件失败: %w", err)
	}
	defer dstFile.Close()

	if _, err := io.Copy(dstFile, srcFile); err != nil {
		return fmt.Errorf("复制文件失败: %w", err)
	}

	// 保留原文件的修改时间
	if err := os.Chtimes(backupPath, stat.ModTime(), stat.ModTime()); err != nil {
		log.Printf("设置备份文件时间失败: %v", err)
	}

	log.Printf("已备份 NPK 文件: %s -> %s", npkPath, backupPath)
	return nil
}

// SaveNpk 保存 NPK 文件 - 直接从内存序列化，不回读磁盘
// 对于未加载的 Album，从磁盘按需加载后写入
func (s *NpkService) SaveNpk(npkName string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	doc, exists := s.documents[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}
	npkPath := doc.Path

	// 获取 NPK 文件信息（用于加密格式）
	var formatType int
	if info, ok := s.files[npkName]; ok {
		formatType = info.FormatType
	}

	// 1. 备份原文件
	backupPath := npkPath + ".backup." + time.Now().Format("20060102_150405")
	if err := s.copyFile(npkPath, backupPath); err != nil {
		log.Printf("[SaveNpk] 备份失败: %v", err)
	}

	// 2. 确保所有 Album 都已加载（未加载的从磁盘按需加载）
	// 同时读取非 IMG 文件（Version == Other）的原始数据
	rawAlbumData := make([][]byte, len(doc.Albums))

	// 打开原始 NPK 文件获取索引信息（用于处理重命名后的路径映射）
	file, err := os.Open(npkPath)
	if err != nil {
		return fmt.Errorf("打开 NPK 文件失败: %w", err)
	}
	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	file.Close()
	if err != nil {
		return fmt.Errorf("读取 NPK 索引失败: %w", err)
	}

	// 构建路径映射：内存中的新路径 -> 磁盘上的实际路径
	pathMapping := make(map[string]string)
	for _, albumDoc := range doc.Albums {
		// 优先使用 OriginalPath（重命名前的路径）
		if albumDoc.OriginalPath != "" && albumDoc.OriginalPath != albumDoc.Path {
			// 有原始路径且与当前路径不同，说明发生了重命名
			pathMapping[albumDoc.Path] = albumDoc.OriginalPath
			log.Printf("[SaveNpk] 路径映射(重命名): 内存=%s -> 磁盘=%s", albumDoc.Path, albumDoc.OriginalPath)
			continue
		}
		// 尝试在 NPK 索引中查找匹配的 Album
		found := false
		for _, idx := range npkFile.Indexes {
			// 路径完全匹配
			if idx.Path == albumDoc.Path {
				pathMapping[albumDoc.Path] = idx.Path
				found = true
				break
			}
		}
		// 如果没找到映射，使用内存中的路径（可能是新建的 Album）
		if !found {
			pathMapping[albumDoc.Path] = albumDoc.Path
			log.Printf("[SaveNpk] 路径映射(新建): %s", albumDoc.Path)
		}
	}

	for i, albumDoc := range doc.Albums {
		// 只有真正的非 IMG 文件（Version == Other）才使用原始数据
		if albumDoc.Version == npk.Other {
			diskPath := pathMapping[albumDoc.Path]
			rawData, err := s.readRawAlbumData(npkPath, diskPath, formatType)
			if err != nil {
				log.Printf("[SaveNpk] 警告: 读取原始数据失败 %s (disk: %s): %v", albumDoc.Path, diskPath, err)
			} else {
				rawAlbumData[i] = rawData
			}
			continue
		}

		// 检查是否需要加载
		needsLoad := false
		if albumDoc.TargetPath != "" && len(albumDoc.Sprites) == 0 {
			// 引用 album 且没有 Sprites，需要从目标加载
			needsLoad = true
			log.Printf("[SaveNpk] 引用 Album 没有 Sprites，需要加载目标: %s", albumDoc.Path)
		} else if albumDoc.TargetPath != "" && !albumDoc.IsLoaded {
			// 引用 album 未加载，需要从目标加载
			needsLoad = true
			log.Printf("[SaveNpk] 引用 Album 未加载，需要加载目标: %s", albumDoc.Path)
		} else if !albumDoc.IsLoaded {
			// 普通 album 未加载
			needsLoad = true
		}

		if needsLoad {
			if albumDoc.TargetPath != "" {
				// 引用 album：从目标 album 获取数据
				log.Printf("[SaveNpk] 处理引用 Album: %s -> %s", albumDoc.Path, albumDoc.TargetPath)
				var targetAlbumDoc *AlbumDocument
				for _, album := range doc.Albums {
					if album.Path == albumDoc.TargetPath {
						targetAlbumDoc = album
						break
					}
				}
				if targetAlbumDoc == nil {
					return fmt.Errorf("引用目标 Album 不存在: %s", albumDoc.TargetPath)
				}
				// 如果目标 album 未加载，先加载它
				if !targetAlbumDoc.IsLoaded || len(targetAlbumDoc.Sprites) == 0 {
					diskPath := pathMapping[targetAlbumDoc.Path]
					log.Printf("[SaveNpk] 加载引用目标 Album: %s", targetAlbumDoc.Path)
					loadedTarget, err := s.loadAlbumToMemoryLockedWithPath(npkName, targetAlbumDoc.Path, diskPath, formatType)
					if err != nil {
						return fmt.Errorf("加载引用目标 Album %s 失败: %w", targetAlbumDoc.Path, err)
					}
					targetAlbumDoc = loadedTarget
				}
				// 将引用 album 的数据设置为目标 album 的数据
				albumDoc.Sprites = targetAlbumDoc.Sprites
				albumDoc.Textures = targetAlbumDoc.Textures
				albumDoc.Tables = targetAlbumDoc.Tables
				albumDoc.TextureInfos = targetAlbumDoc.TextureInfos
				albumDoc.IsLoaded = true
				log.Printf("[SaveNpk] 引用 Album 数据已同步: %s, Sprites=%d", albumDoc.Path, len(albumDoc.Sprites))
			} else {
				// 普通 album：从磁盘加载
				diskPath := pathMapping[albumDoc.Path]
				log.Printf("[SaveNpk] 加载 Album: 内存路径=%s, 磁盘路径=%s", albumDoc.Path, diskPath)
				loadedAlbum, err := s.loadAlbumToMemoryLockedWithPath(npkName, albumDoc.Path, diskPath, formatType)
				if err != nil {
					return fmt.Errorf("加载 Album %s 失败: %w", albumDoc.Path, err)
				}
				log.Printf("[SaveNpk] 加载完成: Path=%s, Sprites=%d, IsLoaded=%v", loadedAlbum.Path, len(loadedAlbum.Sprites), loadedAlbum.IsLoaded)
			}
		} else {
			log.Printf("[SaveNpk] Album 已加载: Path=%s, Sprites=%d", albumDoc.Path, len(albumDoc.Sprites))
			for j, sp := range albumDoc.Sprites {
				if sp.RawData != nil {
					log.Printf("[SaveNpk]   帧 %d: Type=%d, CompressMode=%d, W=%d, H=%d, RawDataLen=%d, IsModified=%v", j, sp.Type, sp.CompressMode, sp.Width, sp.Height, len(sp.RawData), sp.IsModified)
				}
			}
		}
	}

	// 3. 从内存构建 Album 和 WriteData
	albums := make([]*npk.Album, len(doc.Albums))
	allWriteDatas := make([][]npk.SpriteWriteData, len(doc.Albums))

	for i, albumDoc := range doc.Albums {
		// 如果是引用 album，不需要构建 Sprites 数据
		// WriteNpk 会跳过引用 album 的数据序列化，共享目标的数据块
		album := &npk.Album{
			Path:         albumDoc.Path,
			Name:         albumDoc.Name,
			Version:      albumDoc.Version,
			Count:        len(albumDoc.Sprites),
			Sprites:      make([]*npk.Sprite, len(albumDoc.Sprites)),
			Textures:     albumDoc.Textures,
			Tables:       albumDoc.Tables,
			TextureInfos: albumDoc.TextureInfos,
			TargetPath:   albumDoc.TargetPath, // 添加引用目标路径
		}

		// 引用 album：跳过 Sprite 数据构建，WriteNpk 会共享目标的数据块
		if albumDoc.TargetPath != "" {
			log.Printf("[SaveNpk] 跳过引用 album 的 Sprite 构建: %s -> %s", albumDoc.Path, albumDoc.TargetPath)
			albums[i] = album
			allWriteDatas[i] = nil
			continue
		}

		writeDatas := make([]npk.SpriteWriteData, 0)

		for j, sd := range albumDoc.Sprites {
			sprite := &npk.Sprite{
				Index:        j,
				Type:         sd.Type,
				CompressMode: sd.CompressMode,
				Width:        sd.Width,
				Height:       sd.Height,
				X:            sd.X,
				Y:            sd.Y,
				FrameWidth:   sd.FrameWidth,
				FrameHeight:  sd.FrameHeight,
				TargetIndex:  sd.TargetIndex,
				Parent:       album,
			}

			if sd.BGRAData != nil {
				// 有编辑数据，使用 BGRA 重新编码
				// Length 将在编码后设置（WriteAlbumV2 中）
				log.Printf("[SaveNpk] %s 帧 %d: 使用 BGRAData (编辑过)", albumDoc.Path, j)
				writeDatas = append(writeDatas, npk.SpriteWriteData{
					Sprite:   sprite,
					BGRAData: sd.BGRAData,
				})
			} else if sd.RawData != nil {
				// 未编辑，使用原始压缩数据
				log.Printf("[SaveNpk] %s 帧 %d: 使用 RawData (未编辑), RawDataLen=%d", albumDoc.Path, j, len(sd.RawData))
				sprite.Data = make([]byte, len(sd.RawData))
				copy(sprite.Data, sd.RawData)
				sprite.Length = len(sd.RawData) // 设置 Length 为原始数据长度
				// 未编辑的帧也要加入 writeDatas，以便 WriteAlbumV2 能找到对应的 sprite
				writeDatas = append(writeDatas, npk.SpriteWriteData{
					Sprite: sprite,
					// BGRAData 为 nil，表示使用 sprite.Data
				})
			} else {
				// 新增的帧但没有数据，创建占位图
				log.Printf("[SaveNpk] 警告: %s 帧 %d 没有数据，创建占位图", albumDoc.Path, j)
				sprite.Width = 1
				sprite.Height = 1
				sprite.FrameWidth = 1
				sprite.FrameHeight = 1
				sprite.Length = 0
				writeDatas = append(writeDatas, npk.SpriteWriteData{
					Sprite:   sprite,
					BGRAData: []byte{0, 0, 0, 0},
				})
			}

			album.Sprites[j] = sprite
		}

		// 设置 LINK 帧的 Target 指针
		for _, sprite := range album.Sprites {
			if sprite.Type == npk.LINK && sprite.TargetIndex >= 0 && sprite.TargetIndex < len(album.Sprites) {
				sprite.Target = album.Sprites[sprite.TargetIndex]
			}
		}

		albums[i] = album
		allWriteDatas[i] = writeDatas
	}

	// 4. 关闭已打开的文件句柄
	if f, open := s.openFile[npkPath]; open {
		f.Close()
		delete(s.openFile, npkPath)
	}

	// 5. 写入临时文件
	tempPath := npkPath + ".tmp." + strconv.FormatInt(time.Now().UnixNano(), 10)
	log.Printf("[SaveNpk] 开始写入临时文件: %s (formatType=%d)", tempPath, formatType)
	if err := npk.WriteNpk(tempPath, albums, allWriteDatas, rawAlbumData, formatType, npkName); err != nil {
		os.Remove(tempPath)
		log.Printf("[SaveNpk] 写入临时文件失败: %v", err)
		return fmt.Errorf("写入临时文件失败: %w", err)
	}
	log.Printf("[SaveNpk] 临时文件写入完成")

	// 6. 验证临时文件
	log.Printf("[SaveNpk] 开始验证临时文件")
	if err := s.verifyNpk(tempPath); err != nil {
		os.Remove(tempPath)
		log.Printf("[SaveNpk] 验证临时文件失败: %v", err)
		return fmt.Errorf("验证临时文件失败: %w", err)
	}
	log.Printf("[SaveNpk] 临时文件验证通过")

	// 7. 原子替换
	if err := os.Rename(tempPath, npkPath); err != nil {
		os.Remove(tempPath)
		if _, statErr := os.Stat(backupPath); statErr == nil {
			if restoreErr := s.copyFile(backupPath, npkPath); restoreErr != nil {
				log.Printf("[SaveNpk] 从备份恢复失败: %v", restoreErr)
			}
		}
		return fmt.Errorf("替换文件失败: %w", err)
	}

	// 8. 保存成功后：重置内存中的修改标记，更新 RawData，重置 OriginalPath
	for _, albumDoc := range doc.Albums {
		// 重置 OriginalPath：保存后，当前路径就是原始路径
		if albumDoc.OriginalPath != albumDoc.Path {
			log.Printf("[SaveNpk] 重置 OriginalPath: %s -> %s", albumDoc.OriginalPath, albumDoc.Path)
			albumDoc.OriginalPath = albumDoc.Path
		}

		for _, sd := range albumDoc.Sprites {
			if sd.IsModified && sd.BGRAData != nil {
				// 将 BGRAData 作为新的 RawData（下次保存直接用）
				sd.RawData = nil // 释放原始数据
				// 注意：BGRAData 保留，下次保存时仍然作为编辑数据
				// 如果想减少内存，可以在这里重新编码为 RawData
				// 但为了支持撤销，保留 BGRAData
			}
		}
	}

	// 9. 清理缓存
	s.cache.DeleteByNpk(npkName)
	s.thumbs.DeleteByNpk(npkName)

	// 清理全局 IMG 缓存池（防止旧 Album/Sprites 引用导致数据不一致）
	s.imgCache.ReleaseAll()

	// 清理该 NPK 的编辑缓存（已写入 documents，editedSprites 不再需要）
	for key := range s.editedSprites {
		if strings.HasPrefix(key, npkName+":") {
			s.deleteEditedSprite(key)
		}
	}

	// 10. 重置修改标记
	for _, albumDoc := range doc.Albums {
		for _, sd := range albumDoc.Sprites {
			sd.IsModified = false
		}
	}

	// 11. 清除 documents 内存文档，让下次 GetAlbum 从磁盘重新加载
	delete(s.documents, npkName)

	// 12. 重置 files 中的 IsLoaded，让下次访问从磁盘重新加载
	if info, ok := s.files[npkName]; ok {
		info.IsLoaded = false
	}

	// 13. 清除 npkDetailCache 中的旧数据
	delete(s.npkDetailCache, npkName)
	s.updateNpkDetailLRU(npkName)

	// 14. 更新文件信息
	stat, err := os.Stat(npkPath)
	if err == nil {
		doc.Size = stat.Size()
		doc.Modified = stat.ModTime()
		if info, ok := s.files[npkName]; ok {
			info.Size = stat.Size()
			info.Modified = stat.ModTime()
		}
	}

	log.Printf("[SaveNpk] NPK 文件保存成功: %s", npkPath)

	// 15. 同步到数据库（保存修改后的帧属性等元数据）
	if info, ok := s.files[npkName]; ok {
		s.syncToDatabase(info)
	}

	return nil
}

// readRawAlbumData 从 NPK 文件中读取指定 Album 的原始字节（用于非 IMG 文件如 OGG）
func (s *NpkService) readRawAlbumData(npkPath, albumPath string, formatType int) ([]byte, error) {
	file, err := os.Open(npkPath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return nil, err
	}

	for _, idx := range npkFile.Indexes {
		if idx.Path == albumPath {
			data := make([]byte, idx.Length)
			if _, err := file.ReadAt(data, int64(idx.Offset)); err != nil {
				return nil, err
			}
			return data, nil
		}
	}

	return nil, fmt.Errorf("Album 不存在: %s", albumPath)
}

// GetAlbumRawData 获取 Album 的原始数据（用于导出 IMG 格式）
func (s *NpkService) GetAlbumRawData(npkName, albumPath string) ([]byte, error) {
	// 大小写不敏感查找 NPK
	actualName, info, exists := s.findNpkByNameCaseInsensitive(npkName)
	if !exists {
		return nil, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}
	npkName = actualName

	// 尝试各种格式类型读取
	for _, formatType := range []int{0, 1, 2} {
		data, err := s.readRawAlbumData(info.Path, albumPath, formatType)
		if err == nil {
			return data, nil
		}
	}

	return nil, fmt.Errorf("无法读取 Album: %s/%s", npkName, albumPath)
}

// findNpkByNameCaseInsensitive 大小写不敏感查找 NPK
func (s *NpkService) findNpkByNameCaseInsensitive(name string) (string, *NpkFileInfo, bool) {
	// 先尝试精确匹配
	if info, exists := s.files[name]; exists {
		return name, info, true
	}
	// 大小写不敏感匹配
	lowerName := strings.ToLower(name)
	for k, v := range s.files {
		if strings.ToLower(k) == lowerName {
			return k, v, true
		}
	}
	return "", nil, false
}
