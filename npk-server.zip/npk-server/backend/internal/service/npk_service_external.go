package service

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"npk-server/internal/npk"
)

// GetExternalNpkAlbums 获取外部 NPK 文件的 Album 列表（含 sprite 元数据）
func (s *NpkService) GetExternalNpkAlbums(npkPath string) ([]*AlbumInfo, error) {
	file, err := os.Open(npkPath)
	if err != nil {
		return nil, fmt.Errorf("打开外部 NPK 文件失败: %w", err)
	}
	defer file.Close()

	formatType, err := npk.DetectNpkEncryptionType(file)
	if err != nil {
		formatType = 0
	}

	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return nil, fmt.Errorf("读取 NPK 失败: %w", err)
	}

	albums := make([]*AlbumInfo, 0, len(npkFile.Indexes))
	for _, idx := range npkFile.Indexes {
		album, err := npk.ReadAlbum(file, idx)
		if err != nil {
			continue
		}
		ai := &AlbumInfo{
			Path:        idx.Path,
			Name:        extractName(idx.Path),
			Version:     album.Version,
			SpriteCount: album.Count,
			Sprites:     make([]*SpriteInfo, 0, len(album.Sprites)),
		}
		for _, sp := range album.Sprites {
			ai.Sprites = append(ai.Sprites, &SpriteInfo{
				Index:        sp.Index,
				Type:         sp.Type,
				CompressMode: sp.CompressMode,
				Width:        sp.Width,
				Height:       sp.Height,
				X:            sp.X,
				Y:            sp.Y,
				FrameWidth:   sp.FrameWidth,
				FrameHeight:  sp.FrameHeight,
				IsLink:       sp.Type == npk.LINK,
				TargetIndex:  sp.TargetIndex,
				DataSize:     sp.Length,
			})
		}
		albums = append(albums, ai)
	}

	return albums, nil
}

// GetExternalNpkFrame 获取外部 NPK 文件的指定帧图像
func (s *NpkService) GetExternalNpkFrame(npkPath, albumPath string, frameIndex int, width, height int, format string, quality int) ([]byte, error) {
	file, err := os.Open(npkPath)
	if err != nil {
		return nil, fmt.Errorf("打开外部 NPK 文件失败: %w", err)
	}
	defer file.Close()

	// 检测加密类型
	formatType, err := npk.DetectNpkEncryptionType(file)
	if err != nil {
		formatType = 0 // 默认标准加密
	}

	// 根据加密类型读取 NPK
	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return nil, fmt.Errorf("读取 NPK 失败: %w", err)
	}

	var targetIdx *npk.NpkIndex
	for _, idx := range npkFile.Indexes {
		if idx.Path == albumPath {
			targetIdx = idx
			break
		}
	}
	if targetIdx == nil {
		return nil, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	album, err := npk.ReadAlbum(file, targetIdx)
	if err != nil {
		return nil, fmt.Errorf("读取 Album 失败: %w", err)
	}

	if frameIndex < 0 || frameIndex >= len(album.Sprites) {
		return nil, fmt.Errorf("帧索引超出范围: %d", frameIndex)
	}

	sprite := album.Sprites[frameIndex]

	// 解码 Sprite
	img, err := npk.DecodeSpriteToImage(sprite, album)
	if err != nil {
		return nil, fmt.Errorf("解码 Sprite 失败: %w", err)
	}

	// 缩放
	if width > 0 && height > 0 {
		img = s.resizeImage(img, width, height)
	}

	return img.Encode(format, quality)
}

// UploadExternalImg 上传并缓存外部 IMG 文件
func (s *NpkService) UploadExternalImg(fileName string, data []byte) (string, *AlbumInfo, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 生成缓存 key
	key := fileName + ":" + strconv.FormatInt(time.Now().UnixNano(), 10)

	// 从字节数据读取 Album
	album, err := npk.ReadAlbumFromData(data)
	if err != nil {
		return "", nil, fmt.Errorf("解析 IMG 文件失败: %w", err)
	}

	// 设置 Album 路径和名称
	album.Path = fileName
	album.Name = fileName

	// 转换为 AlbumInfo
	albumInfo := &AlbumInfo{
		Path:        album.Path,
		Name:        album.Name,
		Version:     album.Version,
		SpriteCount: album.Count,
		TargetPath:  album.TargetPath,
	}

	// 转换 Sprites 为 SpriteInfo
	albumInfo.Sprites = make([]*SpriteInfo, 0, len(album.Sprites))
	for _, sp := range album.Sprites {
		si := &SpriteInfo{
			Index:         sp.Index,
			OriginalIndex: sp.Index,
			Type:          sp.Type,
			CompressMode:  sp.CompressMode,
			Width:         sp.Width,
			Height:        sp.Height,
			X:             sp.X,
			Y:             sp.Y,
			FrameWidth:    sp.FrameWidth,
			FrameHeight:   sp.FrameHeight,
			IsLink:        sp.Type == npk.LINK,
			TargetIndex:   sp.TargetIndex,
			DataSize:      sp.Length,
		}

		// 如果是 Link 帧，使用目标帧的坐标信息
		if sp.Type == npk.LINK && sp.TargetIndex >= 0 && sp.TargetIndex < len(album.Sprites) {
			targetSp := album.Sprites[sp.TargetIndex]
			si.X = targetSp.X
			si.Y = targetSp.Y
			si.FrameWidth = targetSp.FrameWidth
			si.FrameHeight = targetSp.FrameHeight
		}

		albumInfo.Sprites = append(albumInfo.Sprites, si)
	}

	// 保存到缓存
	s.setExternalImgCache(key, data, album, albumInfo)

	log.Printf("上传外部 IMG 成功: %s, 缓存 key: %s", fileName, key)
	return key, albumInfo, nil
}

// LoadExternalImgAlbum 加载单个外部 IMG 文件的信息（从缓存或路径）
func (s *NpkService) LoadExternalImgAlbum(imgPathOrKey string) (*AlbumInfo, error) {
	s.mu.RLock()
	// 先尝试从缓存获取
	if entry, exists := s.externalImgCache[imgPathOrKey]; exists {
		s.mu.RUnlock()
		s.updateExternalImgLRU(imgPathOrKey)
		return entry.info, nil
	}
	s.mu.RUnlock()

	// 缓存中没有，尝试从文件路径读取
	file, err := os.Open(imgPathOrKey)
	if err != nil {
		return nil, fmt.Errorf("打开外部 IMG 文件失败: %w", err)
	}
	defer file.Close()

	// 读取文件内容
	data, err := os.ReadFile(imgPathOrKey)
	if err != nil {
		return nil, fmt.Errorf("读取 IMG 文件失败: %w", err)
	}

	// 从字节数据读取 Album
	album, err := npk.ReadAlbumFromData(data)
	if err != nil {
		return nil, fmt.Errorf("解析 IMG 文件失败: %w", err)
	}

	// 设置 Album 路径和名称
	fileName := filepath.Base(imgPathOrKey)
	album.Path = fileName
	album.Name = fileName

	// 转换为 AlbumInfo
	albumInfo := &AlbumInfo{
		Path:        album.Path,
		Name:        album.Name,
		Version:     album.Version,
		SpriteCount: album.Count,
		TargetPath:  album.TargetPath,
	}

	// 转换 Sprites 为 SpriteInfo
	albumInfo.Sprites = make([]*SpriteInfo, 0, len(album.Sprites))
	for _, sp := range album.Sprites {
		si := &SpriteInfo{
			Index:         sp.Index,
			OriginalIndex: sp.Index,
			Type:          sp.Type,
			CompressMode:  sp.CompressMode,
			Width:         sp.Width,
			Height:        sp.Height,
			X:             sp.X,
			Y:             sp.Y,
			FrameWidth:    sp.FrameWidth,
			FrameHeight:   sp.FrameHeight,
			IsLink:        sp.Type == npk.LINK,
			TargetIndex:   sp.TargetIndex,
			DataSize:      sp.Length,
		}

		// 如果是 Link 帧，使用目标帧的坐标信息
		if sp.Type == npk.LINK && sp.TargetIndex >= 0 && sp.TargetIndex < len(album.Sprites) {
			targetSp := album.Sprites[sp.TargetIndex]
			si.X = targetSp.X
			si.Y = targetSp.Y
			si.FrameWidth = targetSp.FrameWidth
			si.FrameHeight = targetSp.FrameHeight
		}

		albumInfo.Sprites = append(albumInfo.Sprites, si)
	}

	// 保存到缓存（使用路径作为 key）
	s.mu.Lock()
	s.setExternalImgCache(imgPathOrKey, data, album, albumInfo)
	s.mu.Unlock()

	return albumInfo, nil
}

// GetExternalImgFrame 获取单个外部 IMG 文件的指定帧图像
func (s *NpkService) GetExternalImgFrame(imgPathOrKey string, frameIndex int, width, height int, format string, quality int) ([]byte, error) {
	var album *npk.Album

	s.mu.RLock()
	imgInfo, cached := s.externalImgCache[imgPathOrKey]
	s.mu.RUnlock()

	if cached {
		album = imgInfo.album
	} else {
		data, err := os.ReadFile(imgPathOrKey)
		if err != nil {
			return nil, fmt.Errorf("读取文件失败: %w", err)
		}
		album, err = npk.ReadAlbumFromData(data)
		if err != nil {
			return nil, fmt.Errorf("解析 IMG 失败: %w", err)
		}
	}

	if frameIndex < 0 || frameIndex >= len(album.Sprites) {
		return nil, fmt.Errorf("帧索引超出范围: %d", frameIndex)
	}

	img, err := npk.DecodeSpriteToImage(album.Sprites[frameIndex], album)
	if err != nil {
		return nil, err
	}
	if width > 0 && height > 0 {
		img = s.resizeImage(img, width, height)
	}
	return img.Encode(format, quality)
}

// UploadExternalNpk 上传外部 NPK 文件，返回 Album 列表和缓存 key
func (s *NpkService) UploadExternalNpk(fileName string, data []byte) ([]*AlbumInfo, string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	reader := bytes.NewReader(data)
	npkReader, err := npk.ReadNpk(reader)
	if err != nil {
		return nil, "", fmt.Errorf("解析 NPK 失败: %w", err)
	}

	albums := make([]*AlbumInfo, 0, len(npkReader.Indexes))
	for _, idx := range npkReader.Indexes {
		reader.Seek(0, io.SeekStart)
		album, err := npk.ReadAlbum(reader, idx)
		if err != nil {
			continue
		}
		ai := &AlbumInfo{
			Path:        idx.Path,
			Name:        extractName(idx.Path),
			Version:     album.Version,
			SpriteCount: album.Count,
			Sprites:     make([]*SpriteInfo, 0, len(album.Sprites)),
		}
		for _, sp := range album.Sprites {
			ai.Sprites = append(ai.Sprites, &SpriteInfo{
				Index: sp.Index, Type: sp.Type, CompressMode: sp.CompressMode,
				Width: sp.Width, Height: sp.Height,
				X: sp.X, Y: sp.Y, FrameWidth: sp.FrameWidth, FrameHeight: sp.FrameHeight,
				IsLink: sp.Type == npk.LINK, TargetIndex: sp.TargetIndex, DataSize: sp.Length,
			})
		}
		albums = append(albums, ai)
	}

	key := "npk:" + fileName + ":" + strconv.FormatInt(time.Now().UnixNano(), 10)
	s.externalNpkCache[key] = data

	return albums, key, nil
}

// GetExternalNpkFrameByCache 从缓存获取 NPK 帧图像
func (s *NpkService) GetExternalNpkFrameByCache(key, albumPath string, frameIndex int, width, height int, format string, quality int) ([]byte, error) {
	s.mu.Lock()
	data, ok := s.externalNpkCache[key]
	s.mu.Unlock()
	if !ok {
		return nil, fmt.Errorf("缓存已过期")
	}

	reader := bytes.NewReader(data)
	npkReader, err := npk.ReadNpk(reader)
	if err != nil {
		return nil, err
	}
	for _, idx := range npkReader.Indexes {
		if idx.Path == albumPath {
			reader.Seek(0, io.SeekStart)
			album, err := npk.ReadAlbum(reader, idx)
			if err != nil {
				return nil, err
			}
			if frameIndex < 0 || frameIndex >= len(album.Sprites) {
				return nil, fmt.Errorf("帧索引超出范围")
			}
			img, err := npk.DecodeSpriteToImage(album.Sprites[frameIndex], album)
			if err != nil {
				return nil, err
			}
			if width > 0 && height > 0 {
				img = s.resizeImage(img, width, height)
			}
			return img.Encode(format, quality)
		}
	}
	return nil, fmt.Errorf("Album 不存在")
}

// SaveExternalNpk 从缓存重建外部 NPK 并返回字节数据
func (s *NpkService) SaveExternalNpk(key string, allAlbums []*npk.Album) ([]byte, string, error) {
	s.mu.RLock()
	_, ok := s.externalNpkCache[key]
	s.mu.RUnlock()
	if !ok {
		return nil, "", fmt.Errorf("缓存已过期，请重新上传")
	}

	name := strings.TrimPrefix(key, "npk:")
	if idx := strings.Index(name, ":"); idx > 0 {
		name = name[:idx]
	}
	name = strings.TrimSuffix(name, filepath.Ext(name)) + "_modified.npk"

	data, err := npk.WriteNpkToData(allAlbums, 0, name)
	if err != nil {
		return nil, "", err
	}
	return data, name, nil
}
