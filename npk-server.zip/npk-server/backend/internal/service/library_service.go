package service

import (
	"fmt"
	"npk-server/internal/database"
	"strings"
)

// LibraryStats 资源库统计
type LibraryStats struct {
	NpkCount         int                    `json:"npk_count"`
	AlbumCount       int                    `json:"album_count"`
	SpriteCount      int                    `json:"sprite_count"`
	TotalSize        int64                  `json:"total_size"`
	SpritesTotalSize int64                  `json:"sprites_total_size"`
	CacheStats       map[string]interface{} `json:"cache_stats"`
}

// SearchResult 搜索结果
type SearchResult struct {
	NpkID       int64  `json:"npk_id"`
	NpkName     string `json:"npk_name"`
	AlbumID     int64  `json:"album_id"`
	AlbumPath   string `json:"album_path"`
	AlbumName   string `json:"album_name"`
	SpriteCount int    `json:"sprite_count"`
	Version     string `json:"version"`
}

// TreeNode 树形节点
type TreeNode struct {
	Name     string               `json:"name"`
	Path     string               `json:"path"`
	Type     string               `json:"type"` // folder, npk, album
	Children map[string]*TreeNode `json:"children"`
	NpkID    int64                `json:"npk_id,omitempty"`
	AlbumID  int64                `json:"album_id,omitempty"`
}

// LibraryService 资源库服务
type LibraryService struct {
	db    *database.Database
	cache CacheProvider
}

// CacheProvider 缓存统计接口
type CacheProvider interface {
	Stats() map[string]interface{}
}

// NewLibraryService 创建资源库服务
func NewLibraryService(db *database.Database, cache CacheProvider) *LibraryService {
	return &LibraryService{db: db, cache: cache}
}

// GetStats 获取统计信息（使用 SQL COUNT，避免全量加载）
func (s *LibraryService) GetStats() (*LibraryStats, error) {
	stats := &LibraryStats{}

	// 使用数据库层的 COUNT 查询
	dbStats, err := s.db.GetStats()
	if err != nil {
		return nil, err
	}

	stats.NpkCount = dbStats.NpkCount
	stats.AlbumCount = dbStats.AlbumCount
	stats.SpriteCount = dbStats.SpriteCount
	stats.TotalSize = dbStats.TotalSize
	stats.SpritesTotalSize = dbStats.SpritesTotalSize

	// 缓存统计
	if s.cache != nil {
		stats.CacheStats = s.cache.Stats()
	} else {
		stats.CacheStats = map[string]interface{}{"count": 0, "size": 0}
	}

	return stats, nil
}

// SearchAssets 搜索资源（使用 SQL LIKE + 分页，避免 N+1 和全量加载）
func (s *LibraryService) SearchAssets(query string, assetType string, page, pageSize int) ([]*SearchResult, int, error) {
	// 限制 pageSize 防止过大
	if pageSize <= 0 || pageSize > 200 {
		pageSize = 50
	}
	if page <= 0 {
		page = 1
	}

	results, total, err := s.db.SearchAlbums(query, assetType, page, pageSize)
	if err != nil {
		return nil, 0, err
	}

	// 转换为 SearchResult 格式
	searchResults := make([]*SearchResult, 0, len(results))
	for _, r := range results {
		version := ""
		if r.Version > 0 {
			version = fmt.Sprintf("%d", r.Version)
		}
		searchResults = append(searchResults, &SearchResult{
			NpkID:       r.NpkID,
			NpkName:     r.NpkName,
			AlbumID:     r.AlbumID,
			AlbumPath:   r.AlbumPath,
			AlbumName:   r.AlbumName,
			SpriteCount: r.SpriteCount,
			Version:     version,
		})
	}

	return searchResults, total, nil
}

// GetTree 获取树形结构
// 优化版本：使用单条 JOIN 查询获取所有 Albums，避免 N+1 问题
func (s *LibraryService) GetTree() (*TreeNode, error) {
	// 使用批量查询获取所有 NPK 和 Album 信息（单条 SQL）
	albums, err := s.db.GetAllAlbumsWithNpkName()
	if err != nil {
		return nil, err
	}

	root := &TreeNode{
		Name:     "root",
		Type:     "folder",
		Children: make(map[string]*TreeNode),
	}

	// 按 NPK 名称分组组织 Albums
	npkNodes := make(map[string]*TreeNode)

	for _, album := range albums {
		// 获取或创建 NPK 节点
		npkNode, exists := npkNodes[album.NpkName]
		if !exists {
			npkNode = &TreeNode{
				Name:     album.NpkName,
				Path:     album.NpkName,
				Type:     "npk",
				NpkID:    album.NpkID,
				Children: make(map[string]*TreeNode),
			}
			npkNodes[album.NpkName] = npkNode
			root.Children[album.NpkName] = npkNode
		}

		// 构建路径树
		parts := splitPath(album.AlbumPath)
		current := npkNode

		for i, part := range parts {
			if part == "" {
				continue
			}

			if _, exists := current.Children[part]; !exists {
				nodeType := "folder"
				if i == len(parts)-1 {
					nodeType = "album"
				}
				current.Children[part] = &TreeNode{
					Name:     part,
					Path:     joinPath(parts[:i+1]),
					Type:     nodeType,
					Children: make(map[string]*TreeNode),
				}
			}
			current = current.Children[part]
		}

		// 设置 album 的 ID
		if current.Type == "album" {
			current.AlbumID = album.AlbumID
		}
	}

	return root, nil
}

// splitPath 分割路径
func splitPath(path string) []string {
	return strings.Split(path, "/")
}

// joinPath 连接路径
func joinPath(parts []string) string {
	return strings.Join(parts, "/")
}
