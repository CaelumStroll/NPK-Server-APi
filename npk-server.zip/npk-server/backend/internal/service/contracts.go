package service

import (
	"mime/multipart"

	"npk-server/internal/database"
	"npk-server/internal/npk"
)

type NpkManager interface {
	ListNpkFiles() []*NpkFileInfo
	GetFileCount() int
	GetNpkInfo(name string) (*NpkFileInfo, error)
	ScanDirectory(dir string, progressChan chan<- ScanProgress) error
	ScanFile(path string) error
	DeleteNpk(name string) error
	SaveNpk(npkName string) error
	LoadFromDatabase() error
	ScanDirectoryIncremental(dir string) (*IncrementalResult, error)
	ScanFileIncremental(path string) (bool, bool, error)
}

type SpriteManager interface {
	GetSprite(npkName, albumPath string, index int) (*npk.Sprite, *npk.Album, error)
	GetSpriteImage(npkName, albumPath string, index int, width, height int, noCompress bool) ([]byte, error)
	GetSpriteImageFormat(npkName, albumPath string, index int, width, height int, format string, quality int, noCompress bool) ([]byte, error)
	GetThumbnail(npkName, albumPath string, index int) ([]byte, error)
	ReplaceSprite(npkName, albumPath string, index int, file *multipart.FileHeader, colorFormat string, autoResize bool) error
	AddSprite(npkName, albumPath string, file *multipart.FileHeader) error
	AddLinkSprite(npkName, albumPath string, targetIndex int, position string) error
	ModifyLinkTarget(npkName, albumPath string, spriteIndex, newTargetIndex int) error
	UpdateFrame(npkName, albumPath string, index int, x, y, width, height, frameWidth, frameHeight int) error
	DeleteFrame(npkName, albumPath string, index int) error
	ClearSpriteImage(npkName, albumPath string, index int) error
	ResetSprite(npkName, albumPath string, index int) error
	TrimImage(npkName, albumPath string, index int) (dx, dy int, err error)
	CanvasImage(npkName, albumPath string, index, targetX, targetY, targetWidth, targetHeight int) error
	RemoveBlackBgFromPNG(pngData []byte) ([]byte, error)
}

type AlbumManager interface {
	GetAlbum(npkName, albumPath string) (*npk.Album, error)
	GetAlbumRawData(npkName, albumPath string) ([]byte, error)
	RenameAlbum(npkName, oldPath, newPath string) error
	DeleteAlbum(npkName, albumPath string) error
	SetAlbumTarget(npkName, albumPath, targetPath string) error
	ClearAlbumTarget(npkName, albumPath string) error
	CompareAlbum(npkName string, albumPath1, albumPath2 string) (added, deleted, modified []int, err error)
	ExportAlbumCoords(npkName, albumPath string) ([]Coord, error)
	ImportAlbumCoords(npkName, albumPath string, data []byte) (int, error)
	ImportImg(npkName string, imgData []byte, targetPath string, replace bool) error
	BatchReplaceFromFolder(npkName, albumPath string, files map[string][]byte, colorFormat string, startIndex int, autoResize bool) (replaced int, imported int, err error)
	BatchImportSprites(npkName, albumPath string, position BatchImportPosition, currentIndex int, replaceLinks bool, colorFormat string, files map[string][]byte) (int, error)
	ConvertImgVersionAlbum(album *npk.Album, targetVersion int) (*npk.Album, error)
	ConvertImgVersion(album *npk.Album, targetVersion int) ([]byte, error)
	ParseImgData(data []byte) (*npk.Album, error)
}

type AnimationManager interface {
	GetAnimation(npkName, albumPath string) (*npk.Animation, error)
	GetAnimationFrame(npkName, albumPath string, frameIndex int) (data []byte, err error)
	ExportAlbumGif(npkName, albumPath string, fps int, removeBlack bool) ([]byte, error)
	ExportGIFWithFrames(npkName, albumPath string, fps int, frameIndices []int, removeBlack bool) ([]byte, error)
	GetAlbumPreview(npkName, albumPath, mode string) ([]byte, error)
}

type CacheManager interface {
	LoadImgToCache(npkName, albumPath string) error
	GetImgFromCache(npkName, albumPath string, index int) *npk.ImageData
	CacheImg(npkName, albumPath string, index int, img *npk.ImageData) error
	ReleaseImgCache(npkName, albumPath string)
	ReleaseAllImgCache()
	GetImgCacheStatus() map[string]interface{}
	IsImgCached(npkName, albumPath string) bool
	GetCacheStats() map[string]interface{}
	ClearCache()
	RemoveFromCache(name string)
}

type ExternalManager interface {
	GetExternalNpkAlbums(npkPath string) ([]*AlbumInfo, error)
	GetExternalNpkFrame(npkPath, albumPath string, frameIndex int, width, height int, format string, quality int) ([]byte, error)
	UploadExternalImg(fileName string, data []byte) (string, *AlbumInfo, error)
	LoadExternalImgAlbum(imgPathOrKey string) (*AlbumInfo, error)
	GetExternalImgFrame(imgPathOrKey string, frameIndex int, width, height int, format string, quality int) ([]byte, error)
	UploadExternalNpk(fileName string, data []byte) ([]*AlbumInfo, string, error)
	GetExternalNpkFrameByCache(key, albumPath string, frameIndex int, width, height int, format string, quality int) ([]byte, error)
	SaveExternalNpk(key string, allAlbums []*npk.Album) ([]byte, string, error)
}

type VideoManager interface {
	ScanAll() ([]*database.VideoRecord, error)
	ScanDir(dir string) ([]*database.VideoRecord, error)
	RescanDir(dirPath string) ([]*database.VideoRecord, error)
	ListVideos(query string, page, pageSize int) ([]*database.VideoRecord, int, error)
	SearchVideos(query, format string, encryptedOnly bool, page, pageSize int) ([]*database.VideoRecord, int, error)
	GetVideo(id int64) (*database.VideoRecord, error)
	DecryptVideo(id int64) (string, error)
	EncryptVideo(id int64) (string, error)
	GetVideoStream(path string, decrypted bool) ([]byte, string, error)
	OpenVideoStream(path string, needDecrypt bool) (VideoStreamReader, int64, string, error)
	GetVideoStats() (*database.VideoStats, error)
	DeleteVideo(id int64) error
	GetVideosByIDs(ids []int64) ([]*database.VideoRecord, error)
	DeleteVideosByIDs(ids []int64) (int64, error)
}

type LibraryManager interface {
	GetStats() (*LibraryStats, error)
	SearchAssets(query string, assetType string, page, pageSize int) ([]*SearchResult, int, error)
	GetTree() (*TreeNode, error)
}

type BatchManager interface {
	CreateExportTask(req ExportRequest) string
	GetSubTaskFileName(subTaskID string) string
	GetTask(taskID string) (*BatchTask, bool)
	GetTaskFilePath(taskID string) string
	CleanupOldTasks()
}

type NpkAggregate interface {
	NpkManager
	SpriteManager
	AlbumManager
	AnimationManager
	CacheManager
	ExternalManager
}
