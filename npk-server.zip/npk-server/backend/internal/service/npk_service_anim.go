package service

import (
	"fmt"
	"log"

	"npk-server/internal/npk"
)

// GetAnimation 获取动画
func (s *NpkService) GetAnimation(npkName, albumPath string) (*npk.Animation, error) {
	album, err := s.GetAlbum(npkName, albumPath)
	if err != nil {
		return nil, err
	}

	return npk.DecodeAnimation(album, albumPath)
}

// GetAnimationFrame 获取动画帧
func (s *NpkService) GetAnimationFrame(npkName, albumPath string, frameIndex int) (data []byte, err error) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("[PANIC] GetAnimationFrame: npk=%s, album=%s, frame=%d, panic=%v", npkName, albumPath, frameIndex, r)
			err = fmt.Errorf("内部错误: %v", r)
		}
	}()

	sprite, album, err := s.GetSprite(npkName, albumPath, frameIndex)
	if err != nil {
		return nil, err
	}

	// LINK 帧使用目标帧的全部信息
	frameSprite := sprite
	if sprite.Type == npk.LINK && sprite.Target != nil {
		frameSprite = sprite.Target
	}

	// 使用 sprite 的基准坐标和帧域尺寸
	img, err := npk.DecodeSpriteFrame(frameSprite, album, frameSprite.FrameWidth, frameSprite.FrameHeight, frameSprite.X, frameSprite.Y)
	if err != nil {
		return nil, err
	}

	data, err = img.ToPNG()
	if err != nil {
		return nil, err
	}
	return data, nil
}

// ExportAlbumGif 将 Album 所有帧合并导出为单个 GIF（支持指定帧率）
func (s *NpkService) ExportAlbumGif(npkName, albumPath string, fps int, removeBlack bool) ([]byte, error) {
	return s.ExportGIFWithFrames(npkName, albumPath, fps, nil, removeBlack)
}

// ExportGIFWithFrames 导出 GIF
func (s *NpkService) ExportGIFWithFrames(npkName, albumPath string, fps int, frameIndices []int, removeBlack bool) ([]byte, error) {
	anim, err := s.GetAnimation(npkName, albumPath)
	if err != nil {
		return nil, err
	}

	if removeBlack {
		for _, frame := range anim.Frames {
			if frame.Image != nil {
				npk.ApplyScreenFilter(frame.Image)
			}
		}
	}

	delay := 1000 / fps
	if delay < 1 {
		delay = 1
	}

	if len(frameIndices) > 0 {
		filteredFrames := make([]*npk.AnimationFrame, 0, len(frameIndices))
		for _, idx := range frameIndices {
			if idx >= 0 && idx < len(anim.Frames) {
				frame := anim.Frames[idx]
				frame.Delay = delay
				filteredFrames = append(filteredFrames, frame)
			}
		}
		anim.Frames = filteredFrames
	} else {
		for _, frame := range anim.Frames {
			frame.Delay = delay
		}
	}

	return anim.ExportGIF()
}

// GetAlbumPreview 获取 Album 组合预览图
// mode=combined: 将所有 Sprite 按 (X, Y) 偏移绘制到一张大画布上
// mode=frame: 只绘制帧域区域 (FrameWidth x FrameHeight)
func (s *NpkService) GetAlbumPreview(npkName, albumPath, mode string) ([]byte, error) {
	album, err := s.GetAlbum(npkName, albumPath)
	if err != nil {
		return nil, err
	}

	if len(album.Sprites) == 0 {
		return nil, fmt.Errorf("Album 没有任何 Sprite")
	}

	switch mode {
	case "combined":
		return s.renderCombinedPreview(album)
	case "frame":
		return s.renderFramePreview(album)
	default:
		return s.renderCombinedPreview(album)
	}
}

// renderCombinedPreview 将所有 Sprite 按 (X, Y) 偏移绘制到一张大画布上
func (s *NpkService) renderCombinedPreview(album *npk.Album) ([]byte, error) {
	// 第一步：计算所有 Sprite 的边界框
	minX := int(^uint(0) >> 1) // max int
	minY := int(^uint(0) >> 1)
	maxX := -minX - 1 // min int
	maxY := -minY - 1

	for _, sprite := range album.Sprites {
		if sprite.Type == npk.LINK && sprite.Target != nil {
			sprite = sprite.Target
		}
		if sprite.Width <= 0 || sprite.Height <= 0 {
			continue
		}
		sx := sprite.X
		sy := sprite.Y
		if sx < minX {
			minX = sx
		}
		if sy < minY {
			minY = sy
		}
		right := sx + sprite.Width
		bottom := sy + sprite.Height
		if right > maxX {
			maxX = right
		}
		if bottom > maxY {
			maxY = bottom
		}
	}

	canvasW := maxX - minX
	canvasH := maxY - minY
	if canvasW <= 0 || canvasH <= 0 {
		return nil, fmt.Errorf("无效的画布尺寸: %dx%d", canvasW, canvasH)
	}

	// 限制画布最大尺寸
	if canvasW > 8192 || canvasH > 8192 {
		return nil, fmt.Errorf("画布尺寸过大: %dx%d (最大 8192x8192)", canvasW, canvasH)
	}

	// 第二步：创建画布（BGRA 格式，初始全透明）
	canvas := &npk.ImageData{
		Width:  canvasW,
		Height: canvasH,
		Pixels: make([]byte, canvasW*canvasH*4),
	}

	// 第三步：对每个 Sprite 解码并按偏移绘制（Alpha 混合）
	for _, sprite := range album.Sprites {
		img, err := npk.DecodeSpriteToImage(sprite, album)
		if err != nil {
			continue
		}

		offsetX := sprite.X - minX
		offsetY := sprite.Y - minY

		blendSpriteToCanvas(canvas, img, offsetX, offsetY)
	}

	return canvas.ToPNG()
}

// renderFramePreview 使用最大 FrameWidth x FrameHeight 作为画布
func (s *NpkService) renderFramePreview(album *npk.Album) ([]byte, error) {
	// 计算最大帧域尺寸
	maxFW := 0
	maxFH := 0
	for _, sprite := range album.Sprites {
		if sprite.FrameWidth > maxFW {
			maxFW = sprite.FrameWidth
		}
		if sprite.FrameHeight > maxFH {
			maxFH = sprite.FrameHeight
		}
	}

	if maxFW <= 0 || maxFH <= 0 {
		return nil, fmt.Errorf("无效的帧域尺寸: %dx%d", maxFW, maxFH)
	}

	// 限制画布最大尺寸
	if maxFW > 8192 || maxFH > 8192 {
		return nil, fmt.Errorf("帧域尺寸过大: %dx%d (最大 8192x8192)", maxFW, maxFH)
	}

	// 创建画布（BGRA 格式，初始全透明）
	canvas := &npk.ImageData{
		Width:  maxFW,
		Height: maxFH,
		Pixels: make([]byte, maxFW*maxFH*4),
	}

	// 对每个 Sprite 解码并按 (X, Y) 偏移绘制（Alpha 混合）
	for _, sprite := range album.Sprites {
		img, err := npk.DecodeSpriteToImage(sprite, album)
		if err != nil {
			continue
		}

		blendSpriteToCanvas(canvas, img, sprite.X, sprite.Y)
	}

	return canvas.ToPNG()
}

// blendSpriteToCanvas 将 Sprite 图像 Alpha 混合绘制到画布上
// BGRA 格式 Alpha 混合公式：
//   if srcAlpha > 0:
//       dstAlpha = srcAlpha + dstAlpha * (255 - srcAlpha) / 255
//       dstR = (srcR * srcAlpha + dstR * dstAlpha_orig * (255 - srcAlpha) / 255) / dstAlpha
//       (同理 G, B)
func blendSpriteToCanvas(canvas, sprite *npk.ImageData, offsetX, offsetY int) {
	for y := 0; y < sprite.Height; y++ {
		for x := 0; x < sprite.Width; x++ {
			dstX := offsetX + x
			dstY := offsetY + y

			// 越界检查
			if dstX < 0 || dstX >= canvas.Width || dstY < 0 || dstY >= canvas.Height {
				continue
			}

			srcIdx := (y*sprite.Width + x) * 4
			dstIdx := (dstY*canvas.Width + dstX) * 4

			if srcIdx+3 >= len(sprite.Pixels) || dstIdx+3 >= len(canvas.Pixels) {
				continue
			}

			srcB := sprite.Pixels[srcIdx+0]
			srcG := sprite.Pixels[srcIdx+1]
			srcR := sprite.Pixels[srcIdx+2]
			srcA := uint32(sprite.Pixels[srcIdx+3])

			if srcA == 0 {
				continue
			}

			dstB := uint32(canvas.Pixels[dstIdx+0])
			dstG := uint32(canvas.Pixels[dstIdx+1])
			dstR := uint32(canvas.Pixels[dstIdx+2])
			dstA := uint32(canvas.Pixels[dstIdx+3])

			if srcA == 255 {
				// 完全不透明，直接覆盖
				canvas.Pixels[dstIdx+0] = srcB
				canvas.Pixels[dstIdx+1] = srcG
				canvas.Pixels[dstIdx+2] = srcR
				canvas.Pixels[dstIdx+3] = 255
				continue
			}

			// Alpha 混合
			invSrcA := 255 - srcA
			dstAOrig := dstA

			// dstAlpha = srcAlpha + dstAlpha * (255 - srcAlpha) / 255
			dstA = srcA + dstA*invSrcA/255

			if dstA == 0 {
				continue
			}

			// dstR = (srcR * srcAlpha + dstR * dstAlpha_orig * (255 - srcAlpha) / 255) / dstAlpha
			canvas.Pixels[dstIdx+0] = uint8((uint32(srcB)*srcA + dstB*dstAOrig*invSrcA/255) / dstA)
			canvas.Pixels[dstIdx+1] = uint8((uint32(srcG)*srcA + dstG*dstAOrig*invSrcA/255) / dstA)
			canvas.Pixels[dstIdx+2] = uint8((uint32(srcR)*srcA + dstR*dstAOrig*invSrcA/255) / dstA)
			canvas.Pixels[dstIdx+3] = uint8(dstA)
		}
	}
}
