package service

import (
	"crypto/sha256"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/video"
)

// VideoService 视频服务
type VideoService struct {
	cfg    *config.Config
	db     *database.Database
	crypto *video.NeopleCrypto
	mu     sync.RWMutex
}

// NewVideoService 创建视频服务
func NewVideoService(cfg *config.Config, db *database.Database) *VideoService {
	return &VideoService{
		cfg:    cfg,
		db:     db,
		crypto: video.NewNeopleCrypto(),
	}
}

// ScanAll 扫描所有配置的视频目录，更新数据库
func (s *VideoService) ScanAll() ([]*database.VideoRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	dirs := s.cfg.VideoDirs
	if len(dirs) == 0 {
		return nil, nil
	}

	var allRecords []*database.VideoRecord
	for _, dir := range dirs {
		records, err := s.scanDirUnlocked(dir)
		if err != nil {
			log.Printf("[VideoService] 扫描目录 %s 失败: %v", dir, err)
			continue
		}
		allRecords = append(allRecords, records...)
	}

	return allRecords, nil
}

// ScanDir 扫描单个目录
func (s *VideoService) ScanDir(dir string) ([]*database.VideoRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	return s.scanDirUnlocked(dir)
}

// scanDirUnlocked 扫描单个目录（不加锁，内部方法）
func (s *VideoService) scanDirUnlocked(dir string) ([]*database.VideoRecord, error) {
	// 扫描目录中的视频文件
	videoFiles, err := video.ScanVideoDir(dir)
	if err != nil {
		return nil, fmt.Errorf("扫描目录失败: %w", err)
	}

	var records []*database.VideoRecord
	for _, vf := range videoFiles {
		record := s.videoFileToRecord(&vf, dir)

		// 检查数据库中是否已存在该路径的记录
		existing, err := s.db.GetVideoByPath(record.Path)
		if err != nil {
			log.Printf("[VideoService] 查询视频记录失败 %s: %v", record.Path, err)
			continue
		}

		if existing != nil {
			// 更新已有记录
			record.ID = existing.ID
			if err := s.db.UpdateVideo(record); err != nil {
				log.Printf("[VideoService] 更新视频记录失败 %s: %v", record.Path, err)
				continue
			}
			records = append(records, record)
		} else {
			// 插入新记录
			id, err := s.db.InsertVideo(record)
			if err != nil {
				log.Printf("[VideoService] 插入视频记录失败 %s: %v", record.Path, err)
				continue
			}
			record.ID = id
			records = append(records, record)
		}
	}

	return records, nil
}

// videoFileToRecord 将 video.VideoFile 转换为 database.VideoRecord
// baseDir: 扫描的根目录，用于计算相对路径
func (s *VideoService) videoFileToRecord(vf *video.VideoFile, baseDir string) *database.VideoRecord {
	// 计算相对于 baseDir 的路径
	relPath, err := filepath.Rel(baseDir, vf.Path)
	if err != nil {
		relPath = vf.Path
	}
	// 统一使用正斜杠
	relPath = filepath.ToSlash(relPath)
	// 获取目录部分（相对于 baseDir）
	relDir := filepath.ToSlash(filepath.Dir(relPath))
	// 处理根目录情况
	if relDir == "." || relDir == "/" || relDir == "./" {
		relDir = ""
	}
	// 移除开头的 ./
	relDir = strings.TrimPrefix(relDir, "./")

	record := &database.VideoRecord{
		Name:        vf.Name,
		Path:        vf.Path,
		DirPath:     relDir,
		Size:        vf.Size,
		Format:      vf.Format,
		IsEncrypted: vf.IsEncrypted,
	}

	// 填充视频元信息
	if vf.Info != nil {
		record.Width = vf.Info.Width
		record.Height = vf.Info.Height
		record.FrameCount = vf.Info.FrameCount
		record.AudioCount = vf.Info.AudioCount
		record.FPS = vf.Info.FPS
		record.Duration = vf.Info.Duration
	}

	return record
}

// ListVideos 分页列出视频记录
func (s *VideoService) ListVideos(query string, page, pageSize int) ([]*database.VideoRecord, int, error) {
	return s.db.ListVideos(query, page, pageSize)
}

// SearchVideos 搜索视频（支持按名称、格式、是否加密筛选，支持分页）
func (s *VideoService) SearchVideos(query, format string, encryptedOnly bool, page, pageSize int) ([]*database.VideoRecord, int, error) {
	return s.db.SearchVideos(query, format, encryptedOnly, page, pageSize)
}

// GetVideo 获取单个视频信息
func (s *VideoService) GetVideo(id int64) (*database.VideoRecord, error) {
	return s.db.GetVideoByID(id)
}

// DecryptVideo 解密视频，返回新文件路径
// 文件命名规则: 原文件名_decoded.avi（去掉原扩展名）
func (s *VideoService) DecryptVideo(id int64) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 获取视频记录
	record, err := s.db.GetVideoByID(id)
	if err != nil {
		return "", fmt.Errorf("获取视频记录失败: %w", err)
	}
	if record == nil {
		return "", fmt.Errorf("视频记录不存在")
	}

	// 检查是否为加密视频
	if !record.IsEncrypted {
		return "", fmt.Errorf("该视频不是加密视频，无需解密")
	}

	// 构建目标文件路径: 原文件名_decoded.avi
	baseName := removeExtension(record.Name)
	targetName := baseName + "_decoded.avi"
	// 使用原文件的目录（完整路径），而不是相对路径 DirPath
	sourceDir := filepath.Dir(record.Path)
	targetPath := filepath.Join(sourceDir, targetName)

	// 冲突检测: 检查目标文件是否已存在
	if _, err := os.Stat(targetPath); err == nil {
		return "", fmt.Errorf("文件已存在: %s", targetPath)
	}

	// 冲突检测: 检查数据库中是否已有相同路径的记录
	existing, err := s.db.GetVideoByPath(targetPath)
	if err != nil {
		return "", fmt.Errorf("查询数据库失败: %w", err)
	}
	if existing != nil {
		return "", fmt.Errorf("文件已存在: %s", targetPath)
	}

	// 读取源文件
	data, err := os.ReadFile(record.Path)
	if err != nil {
		return "", fmt.Errorf("读取文件失败: %w", err)
	}

	// 解密数据
	decryptedData, err := s.crypto.Decrypt(data)
	if err != nil {
		return "", fmt.Errorf("解密失败: %w", err)
	}

	// 写入新文件
	if err := os.WriteFile(targetPath, decryptedData, 0644); err != nil {
		return "", fmt.Errorf("写入文件失败: %w", err)
	}

	// 计算解密后文件的 SHA256
	hash := sha256.Sum256(decryptedData)
	hashStr := fmt.Sprintf("%x", hash)

	// 分析解密后的视频信息
	videoInfo := video.AnalyzeVideo(decryptedData, false)

	// 创建新的数据库记录
	newRecord := &database.VideoRecord{
		Name:        targetName,
		Path:        targetPath,
		DirPath:     record.DirPath,
		Size:        int64(len(decryptedData)),
		Format:      "AVI",
		IsEncrypted: false,
		SHA256Hash:  hashStr,
	}

	if videoInfo != nil {
		newRecord.Width = videoInfo.Width
		newRecord.Height = videoInfo.Height
		newRecord.FrameCount = videoInfo.FrameCount
		newRecord.AudioCount = videoInfo.AudioCount
		newRecord.FPS = videoInfo.FPS
		newRecord.Duration = videoInfo.Duration
	}

	// 插入新记录
	newID, err := s.db.InsertVideo(newRecord)
	if err != nil {
		// 回滚: 删除已写入的文件
		os.Remove(targetPath)
		return "", fmt.Errorf("插入数据库记录失败: %w", err)
	}
	newRecord.ID = newID

	log.Printf("[VideoService] 视频解密完成: %s -> %s", record.Path, targetPath)
	return targetPath, nil
}

// EncryptVideo 加密视频，返回新文件路径
// 文件命名规则: 原文件名_encrypted.bk2（去掉原扩展名）
func (s *VideoService) EncryptVideo(id int64) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 获取视频记录
	record, err := s.db.GetVideoByID(id)
	if err != nil {
		return "", fmt.Errorf("获取视频记录失败: %w", err)
	}
	if record == nil {
		return "", fmt.Errorf("视频记录不存在")
	}

	// 检查是否为非加密视频
	if record.IsEncrypted {
		return "", fmt.Errorf("该视频已是加密视频，无需加密")
	}

	// 构建目标文件路径: 原文件名_encrypted.bk2
	baseName := removeExtension(record.Name)
	targetName := baseName + "_encrypted.bk2"
	targetPath := filepath.Join(record.DirPath, targetName)

	// 冲突检测: 检查目标文件是否已存在
	if _, err := os.Stat(targetPath); err == nil {
		return "", fmt.Errorf("文件已存在: %s", targetPath)
	}

	// 冲突检测: 检查数据库中是否已有相同路径的记录
	existing, err := s.db.GetVideoByPath(targetPath)
	if err != nil {
		return "", fmt.Errorf("查询数据库失败: %w", err)
	}
	if existing != nil {
		return "", fmt.Errorf("文件已存在: %s", targetPath)
	}

	// 读取源文件
	data, err := os.ReadFile(record.Path)
	if err != nil {
		return "", fmt.Errorf("读取文件失败: %w", err)
	}

	// 加密数据
	encryptedData, err := s.crypto.Encrypt(data)
	if err != nil {
		return "", fmt.Errorf("加密失败: %w", err)
	}

	// 写入新文件
	if err := os.WriteFile(targetPath, encryptedData, 0644); err != nil {
		return "", fmt.Errorf("写入文件失败: %w", err)
	}

	// 计算加密后文件的 SHA256
	hash := sha256.Sum256(encryptedData)
	hashStr := fmt.Sprintf("%x", hash)

	// 分析加密前的视频信息（使用原始数据）
	videoInfo := video.AnalyzeVideo(data, false)

	// 创建新的数据库记录
	newRecord := &database.VideoRecord{
		Name:        targetName,
		Path:        targetPath,
		DirPath:     record.DirPath,
		Size:        int64(len(encryptedData)),
		Format:      "BK2",
		IsEncrypted: true,
		SHA256Hash:  hashStr,
	}

	if videoInfo != nil {
		newRecord.Width = videoInfo.Width
		newRecord.Height = videoInfo.Height
		newRecord.FrameCount = videoInfo.FrameCount
		newRecord.AudioCount = videoInfo.AudioCount
		newRecord.FPS = videoInfo.FPS
		newRecord.Duration = videoInfo.Duration
	}

	// 插入新记录
	newID, err := s.db.InsertVideo(newRecord)
	if err != nil {
		// 回滚: 删除已写入的文件
		os.Remove(targetPath)
		return "", fmt.Errorf("插入数据库记录失败: %w", err)
	}
	newRecord.ID = newID

	log.Printf("[VideoService] 视频加密完成: %s -> %s", record.Path, targetPath)
	return targetPath, nil
}

// GetVideoStream 获取视频流数据（旧接口，保持兼容）
// 已废弃，请使用 OpenVideoStream
func (s *VideoService) GetVideoStream(path string, decrypted bool) ([]byte, string, error) {
	reader, size, contentType, err := s.OpenVideoStream(path, decrypted)
	if err != nil {
		return nil, "", err
	}
	defer reader.Close()

	// 读取所有数据（仅用于小文件兼容）
	data := make([]byte, size)
	_, err = io.ReadFull(reader, data)
	if err != nil {
		return nil, "", fmt.Errorf("读取数据失败: %w", err)
	}
	return data, contentType, nil
}

// VideoStreamReader 视频流读取器接口
type VideoStreamReader interface {
	io.ReadSeeker
	io.Closer
	Size() int64
}

// 小文件阈值：300MB
const smallFileThreshold = 300 * 1024 * 1024

// OpenVideoStream 打开视频流（支持大文件流式传输）
// 对于小于 300MB 的文件，直接读取到内存缓冲播放
// 对于大于 300MB 的文件，使用流式传输
// 返回: ReadSeeker、解密后大小、content-type、错误
func (s *VideoService) OpenVideoStream(path string, needDecrypt bool) (VideoStreamReader, int64, string, error) {
	// 根据文件扩展名返回 content-type
	ext := strings.ToLower(filepath.Ext(path))
	contentType := getVideoContentType(ext)

	// 检查文件是否存在
	stat, err := os.Stat(path)
	if err != nil {
		return nil, 0, "", fmt.Errorf("文件不存在: %w", err)
	}
	fileSize := stat.Size()

	// 读取文件头部检查是否加密（只读 32 字节）
	file, err := os.Open(path)
	if err != nil {
		return nil, 0, "", fmt.Errorf("打开文件失败: %w", err)
	}
	header := make([]byte, 32)
	n, err := file.Read(header)
	file.Close()
	if err != nil || n < 16 {
		return nil, 0, "", fmt.Errorf("读取文件头部失败")
	}
	isEncrypted := video.IsEncrypted(header)

	// 如果文件加密且需要解密
	if isEncrypted && needDecrypt {
		// 对于小文件，直接解密到内存
		if fileSize < smallFileThreshold {
			data, err := os.ReadFile(path)
			if err != nil {
				return nil, 0, "", fmt.Errorf("读取文件失败: %w", err)
			}
			crypto := video.NewNeopleCrypto()
			decryptedData, err := crypto.Decrypt(data)
			if err != nil {
				return nil, 0, "", fmt.Errorf("解密失败: %w", err)
			}
			return &bufferStreamReader{data: decryptedData, size: int64(len(decryptedData))}, int64(len(decryptedData)), "video/x-msvideo", nil
		}
		// 大文件使用流式解密
		decryptReader, origSize, err := video.NewDecryptReader(path)
		if err != nil {
			return nil, 0, "", fmt.Errorf("创建解密 reader 失败: %w", err)
		}
		return decryptReader, origSize, "video/x-msvideo", nil
	}

	// 文件未加密或不需要解密，返回普通文件 reader
	file, err = os.Open(path)
	if err != nil {
		return nil, 0, "", fmt.Errorf("打开文件失败: %w", err)
	}
	return &fileStreamReader{file: file, size: fileSize}, fileSize, contentType, nil
}

// fileStreamReader 包装 os.File 实现 VideoStreamReader
type fileStreamReader struct {
	file *os.File
	size int64
}

func (r *fileStreamReader) Read(p []byte) (n int, err error) {
	return r.file.Read(p)
}

func (r *fileStreamReader) Seek(offset int64, whence int) (int64, error) {
	return r.file.Seek(offset, whence)
}

func (r *fileStreamReader) Close() error {
	return r.file.Close()
}

func (r *fileStreamReader) Size() int64 {
	return r.size
}

// bufferStreamReader 内存缓冲流读取器（用于小文件）
type bufferStreamReader struct {
	data   []byte
	size   int64
	offset int64
}

func (r *bufferStreamReader) Read(p []byte) (n int, err error) {
	if r.offset >= r.size {
		return 0, io.EOF
	}
	n = copy(p, r.data[r.offset:])
	r.offset += int64(n)
	return n, nil
}

func (r *bufferStreamReader) Seek(offset int64, whence int) (int64, error) {
	var newPos int64
	switch whence {
	case io.SeekStart:
		newPos = offset
	case io.SeekCurrent:
		newPos = r.offset + offset
	case io.SeekEnd:
		newPos = r.size + offset
	default:
		return 0, fmt.Errorf("无效的 whence 值: %d", whence)
	}
	if newPos < 0 {
		return 0, fmt.Errorf("无效的位置: %d", newPos)
	}
	if newPos > r.size {
		newPos = r.size
	}
	r.offset = newPos
	return r.offset, nil
}

func (r *bufferStreamReader) Close() error {
	// 内存缓冲不需要关闭，但清空数据以便 GC
	r.data = nil
	return nil
}

func (r *bufferStreamReader) Size() int64 {
	return r.size
}

// GetVideoStats 获取统计信息
func (s *VideoService) GetVideoStats() (*database.VideoStats, error) {
	return s.db.GetVideoStats()
}

// DeleteVideo 删除数据库记录
func (s *VideoService) DeleteVideo(id int64) error {
	return s.db.DeleteVideo(id)
}

// GetVideosByIDs 根据 ID 列表获取视频记录
func (s *VideoService) GetVideosByIDs(ids []int64) ([]*database.VideoRecord, error) {
	return s.db.GetVideosByIDs(ids)
}

// DeleteVideosByIDs 根据 ID 列表删除视频记录，返回删除的行数
func (s *VideoService) DeleteVideosByIDs(ids []int64) (int64, error) {
	return s.db.DeleteVideosByIDs(ids)
}

// RescanDir 重新扫描目录（先删除旧记录再扫描）
func (s *VideoService) RescanDir(dirPath string) ([]*database.VideoRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	// 先删除该目录下的所有旧记录
	deleted, err := s.db.DeleteVideosByDir(dirPath)
	if err != nil {
		return nil, fmt.Errorf("删除旧记录失败: %w", err)
	}
	log.Printf("[VideoService] 已删除目录 %s 下的 %d 条旧记录", dirPath, deleted)

	// 重新扫描目录
	return s.scanDirUnlocked(dirPath)
}

// removeExtension 去掉文件扩展名
func removeExtension(filename string) string {
	if idx := strings.LastIndex(filename, "."); idx != -1 {
		return filename[:idx]
	}
	return filename
}

// getVideoContentType 根据文件扩展名获取 Content-Type
func getVideoContentType(ext string) string {
	switch ext {
	case ".avi":
		return "video/x-msvideo"
	case ".bk2":
		return "application/octet-stream"
	case ".mp4":
		return "video/mp4"
	case ".webm":
		return "video/webm"
	case ".mkv":
		return "video/x-matroska"
	default:
		return "application/octet-stream"
	}
}
