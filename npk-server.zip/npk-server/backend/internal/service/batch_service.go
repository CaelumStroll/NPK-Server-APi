package service

import (
	"archive/zip"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"npk-server/internal/npk"
)

// generateTaskID 生成任务 ID（使用 crypto/rand 生成 16 字节随机数）
func generateTaskID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		// 如果随机数生成失败，使用时间戳作为备选
		return fmt.Sprintf("%d", time.Now().UnixNano())
	}
	return hex.EncodeToString(b)
}

// BatchTaskStatus 任务状态
type BatchTaskStatus string

const (
	TaskStatusPending   BatchTaskStatus = "pending"
	TaskStatusRunning   BatchTaskStatus = "running"
	TaskStatusCompleted BatchTaskStatus = "completed"
	TaskStatusFailed    BatchTaskStatus = "failed"
)

// BatchTask 批量任务
type BatchTask struct {
	ID        string          `json:"id"`
	Type      string          `json:"type"`
	Status    BatchTaskStatus `json:"status"`
	Progress  int             `json:"progress"`  // 0-100
	Total     int             `json:"total"`
	Completed int             `json:"completed"`
	Error     string          `json:"error,omitempty"`
	Result    *TaskResult     `json:"result,omitempty"`
	CreatedAt time.Time       `json:"created_at"`
	UpdatedAt time.Time       `json:"updated_at"`
}

// TaskResult 任务结果
type TaskResult struct {
	FileURLs []string `json:"file_urls,omitempty"` // 多个压缩包的 URL
	FileSizes []int64 `json:"file_sizes,omitempty"` // 对应的文件大小
}

// ExportItem 导出项
type ExportItem struct {
	NpkName   string `json:"npkName"`
	AlbumPath string `json:"albumPath"`
	Indices   []int  `json:"indices"` // 空数组表示全部导出
}

// ExportRequest 导出请求
type ExportRequest struct {
	Items        []ExportItem `json:"items"`
	Format       string       `json:"format"`        // png, jpg, webp, gif
	Quality      int          `json:"quality"`       // 图片质量 1-100
	Width        int          `json:"width"`
	Height       int          `json:"height"`
	RemoveBlack  bool         `json:"removeBlack"`   // 去黑底
}

// BatchService 批量任务服务
type BatchService struct {
	npkSvc  batchNpkProvider
	tasks   map[string]*BatchTask
	mu      sync.RWMutex
	tempDir string
}

type batchNpkProvider interface {
	GetAlbum(npkName, albumPath string) (*npk.Album, error)
	GetAlbumRawData(npkName, albumPath string) ([]byte, error)
	ExportAlbumGif(npkName, albumPath string, fps int, removeBlack bool) ([]byte, error)
	GetSpriteImageFormat(npkName, albumPath string, index int, width, height int, format string, quality int, noCompress bool) ([]byte, error)
	RemoveBlackBgFromPNG(pngData []byte) ([]byte, error)
}

// NewBatchService 创建批量任务服务
func NewBatchService(npkSvc *NpkService) *BatchService {
	tempDir := filepath.Join(os.TempDir(), "npk-server", "exports")
	os.MkdirAll(tempDir, 0755)

	return &BatchService{
		npkSvc:  npkSvc,
		tasks:   make(map[string]*BatchTask),
		tempDir: tempDir,
	}
}

// CreateExportTask 创建导出任务
func (s *BatchService) CreateExportTask(req ExportRequest) string {
	taskID := generateTaskID()
	task := &BatchTask{
		ID:        taskID,
		Type:      "export",
		Status:    TaskStatusPending,
		Progress:  0,
		Total:     s.calculateTotalFrames(req),
		Completed: 0,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	s.mu.Lock()
	s.tasks[taskID] = task
	s.mu.Unlock()

	// 异步处理
	go s.processExport(taskID, req)

	return taskID
}

// calculateTotalFrames 计算总帧数
func (s *BatchService) calculateTotalFrames(req ExportRequest) int {
	total := 0
	for _, item := range req.Items {
		if len(item.Indices) == 0 {
			// 获取 Album 帧数
			album, err := s.npkSvc.GetAlbum(item.NpkName, item.AlbumPath)
			if err != nil {
				continue
			}
			total += len(album.Sprites)
		} else {
			total += len(item.Indices)
		}
	}
	return total
}

// processExport 处理导出任务
func (s *BatchService) processExport(taskID string, req ExportRequest) {
	s.updateTaskStatus(taskID, TaskStatusRunning, 0, "")

	// 确定导出格式
	exportFormat := strings.ToLower(req.Format)
	ext := ".png"
	switch exportFormat {
	case "jpg", "jpeg":
		ext = ".jpg"
	case "webp":
		ext = ".webp"
	case "gif":
		ext = ".gif"
	case "img":
		ext = ".img"
	}
	if req.Quality <= 0 || req.Quality > 100 {
		req.Quality = 90
	}

	// 按 NPK 分组导出项
	npkItems := make(map[string][]ExportItem)
	for _, item := range req.Items {
		npkItems[item.NpkName] = append(npkItems[item.NpkName], item)
	}

	completed := 0
	total := s.calculateTotalFrames(req)
	resultFileURLs := []string{}
	resultFileSizes := []int64{}
	zipIndex := 0

	// 为每个 NPK 创建一个压缩包
	for npkName, items := range npkItems {
		zipIndex++
		// 生成压缩包文件名：NPK名称_时间.zip
		now := time.Now()
		npkNameWithoutExt := strings.TrimSuffix(npkName, ".npk")
		zipFileName := fmt.Sprintf("%s_%s.zip", npkNameWithoutExt, now.Format("20060102_150405"))
		
		// 生成任务 ID 前缀
		subTaskID := fmt.Sprintf("%s_%d", taskID, zipIndex)
		zipPath := filepath.Join(s.tempDir, subTaskID+".zip")
		
		file, err := os.Create(zipPath)
		if err != nil {
			log.Printf("创建 ZIP 文件失败: %v", err)
			continue
		}

		zipWriter := zip.NewWriter(file)

		// 遍历当前 NPK 的每个 Album
		for _, item := range items {
			// IMG 格式：导出原始 IMG 文件
			if exportFormat == "img" {
				imgData, err := s.npkSvc.GetAlbumRawData(item.NpkName, item.AlbumPath)
				if err != nil {
					log.Printf("导出 IMG 失败: %s/%s - %v", item.NpkName, item.AlbumPath, err)
					continue
				}

				// 使用用户指定的文件名格式：目录_路径@文件名.img
				fileName := createImgExportFileName(item.AlbumPath)

				// 创建 ZIP 文件头，确保 UTF-8 编码支持中文和特殊符号
				header := &zip.FileHeader{
					Name:     fileName,
					Method:   zip.Deflate,
					Modified: time.Now(),
				}
				// 设置 UTF-8 标志
				header.Flags |= 0x800

				f, err := zipWriter.CreateHeader(header)
				if err != nil {
					log.Printf("创建 ZIP 文件失败: %v", err)
					continue
				}
				if _, err := f.Write(imgData); err != nil {
					log.Printf("写入 ZIP 数据失败: %v", err)
					continue
				}
				completed++
				s.updateTaskProgress(taskID, completed, total)
				continue
			}

			// GIF 格式：将 Album 所有帧合并为单个 GIF
			if exportFormat == "gif" {
				gifData, err := s.npkSvc.ExportAlbumGif(item.NpkName, item.AlbumPath, 12, req.RemoveBlack)
				if err != nil {
					log.Printf("导出 GIF 失败: %s/%s - %v", item.NpkName, item.AlbumPath, err)
					continue
				}

				folderName := createExportFolderName(item.AlbumPath)
				fileName := fmt.Sprintf("%s/%s.gif", folderName, folderName)

				// 创建 ZIP 文件头，确保 UTF-8 编码支持中文和特殊符号
				header := &zip.FileHeader{
					Name:     fileName,
					Method:   zip.Deflate,
					Modified: time.Now(),
				}
				// 设置 UTF-8 标志
				header.Flags |= 0x800

				f, err := zipWriter.CreateHeader(header)
				if err != nil {
					log.Printf("创建 ZIP 文件失败: %v", err)
					continue
				}
				if _, err := f.Write(gifData); err != nil {
					log.Printf("写入 ZIP 数据失败: %v", err)
					continue
				}
				completed++
				s.updateTaskProgress(taskID, completed, total)
				continue
			}

			// 其他格式：逐帧导出
			album, err := s.npkSvc.GetAlbum(item.NpkName, item.AlbumPath)
			if err != nil {
				log.Printf("获取 Album 失败: %s/%s - %v", item.NpkName, item.AlbumPath, err)
				continue
			}

			// 确定要导出的帧索引
			var indices []int
			if len(item.Indices) == 0 {
				for i := 0; i < len(album.Sprites); i++ {
					indices = append(indices, i)
				}
			} else {
				indices = item.Indices
			}

			folderName := createExportFolderName(item.AlbumPath)

			// 导出每一帧
			for _, idx := range indices {
				if idx < 0 || idx >= len(album.Sprites) {
					continue
				}

				data, err := s.npkSvc.GetSpriteImageFormat(item.NpkName, item.AlbumPath, idx, req.Width, req.Height, exportFormat, req.Quality, false)
				if err != nil {
					log.Printf("获取帧图片失败: %s/%s[%d] - %v", item.NpkName, item.AlbumPath, idx, err)
					continue
				}

				// 去黑底处理
				if req.RemoveBlack && exportFormat == "png" {
					data, err = s.npkSvc.RemoveBlackBgFromPNG(data)
					if err != nil {
						log.Printf("去黑底失败: %s/%s[%d] - %v", item.NpkName, item.AlbumPath, idx, err)
						// 使用原始数据继续
					}
				}

				fileName := fmt.Sprintf("%s/%04d%s", folderName, idx, ext)

				// 创建 ZIP 文件头，确保 UTF-8 编码支持中文和特殊符号
				header := &zip.FileHeader{
					Name:     fileName,
					Method:   zip.Deflate,
					Modified: time.Now(),
				}
				// 设置 UTF-8 标志
				header.Flags |= 0x800

				f, err := zipWriter.CreateHeader(header)
				if err != nil {
					log.Printf("创建 ZIP 文件失败: %v", err)
					continue
				}

				if _, err := f.Write(data); err != nil {
					log.Printf("写入 ZIP 数据失败: %v", err)
					continue
				}

				completed++
				s.updateTaskProgress(taskID, completed, total)
			}
		}

		// 关闭 ZIP 写入器
		if err := zipWriter.Close(); err != nil {
			log.Printf("关闭 ZIP 文件失败: %v", err)
			file.Close()
			continue
		}
		file.Close()

		// 获取文件大小
		fileInfo, err := os.Stat(zipPath)
		if err != nil {
			log.Printf("获取文件信息失败: %v", err)
			continue
		}

		// 保存子任务 ID 和文件名映射
		s.saveSubTaskMapping(subTaskID, zipFileName)

		// 添加到结果
		resultFileURLs = append(resultFileURLs, "/api/batch/download/"+subTaskID)
		resultFileSizes = append(resultFileSizes, fileInfo.Size())
	}

	// 更新任务状态为完成
	s.mu.Lock()
	if task, exists := s.tasks[taskID]; exists {
		task.Status = TaskStatusCompleted
		task.Progress = 100
		task.Completed = completed
		task.Result = &TaskResult{
			FileURLs:  resultFileURLs,
			FileSizes: resultFileSizes,
		}
		task.UpdatedAt = time.Now()
	}
	s.mu.Unlock()

	log.Printf("批量导出任务完成: %s, 共 %d 帧, %d 个压缩包", taskID, completed, len(resultFileURLs))
}

// 子任务 ID 到文件名的映射存储
var subTaskFileNameMap = make(map[string]string)
var subTaskMapMutex = &sync.Mutex{}

// saveSubTaskMapping 保存子任务 ID 到文件名的映射
func (s *BatchService) saveSubTaskMapping(subTaskID, fileName string) {
	subTaskMapMutex.Lock()
	defer subTaskMapMutex.Unlock()
	subTaskFileNameMap[subTaskID] = fileName
}

// getSubTaskFileName 获取子任务的文件名
func (s *BatchService) getSubTaskFileName(subTaskID string) string {
	subTaskMapMutex.Lock()
	defer subTaskMapMutex.Unlock()
	return subTaskFileNameMap[subTaskID]
}

// GetSubTaskFileName 获取子任务的文件名（导出方法）
func (s *BatchService) GetSubTaskFileName(subTaskID string) string {
	return s.getSubTaskFileName(subTaskID)
}

// updateTaskStatus 更新任务状态
func (s *BatchService) updateTaskStatus(taskID string, status BatchTaskStatus, progress int, errMsg string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if task, exists := s.tasks[taskID]; exists {
		task.Status = status
		task.Progress = progress
		if errMsg != "" {
			task.Error = errMsg
		}
		task.UpdatedAt = time.Now()
	}
}

// updateTaskProgress 更新任务进度
func (s *BatchService) updateTaskProgress(taskID string, completed, total int) {
	if total == 0 {
		return
	}
	progress := (completed * 100) / total
	if progress > 100 {
		progress = 100
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	if task, exists := s.tasks[taskID]; exists {
		task.Progress = progress
		task.Completed = completed
		task.UpdatedAt = time.Now()
	}
}

// GetTask 获取任务信息
func (s *BatchService) GetTask(taskID string) (*BatchTask, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	task, exists := s.tasks[taskID]
	return task, exists
}

// GetTaskFilePath 获取任务结果文件路径
func (s *BatchService) GetTaskFilePath(taskID string) string {
	return filepath.Join(s.tempDir, taskID+".zip")
}

// CleanupOldTasks 清理过期任务（24小时前）
func (s *BatchService) CleanupOldTasks() {
	s.mu.Lock()
	defer s.mu.Unlock()

	now := time.Now()
	for id, task := range s.tasks {
		if now.Sub(task.CreatedAt) > 24*time.Hour {
			// 删除主任务临时文件
			zipPath := filepath.Join(s.tempDir, id+".zip")
			os.Remove(zipPath)
			
			// 删除子任务临时文件和映射
			s.cleanupSubTasks(id)
			
			delete(s.tasks, id)
		}
	}
}

// cleanupSubTasks 清理指定主任务的所有子任务
func (s *BatchService) cleanupSubTasks(mainTaskID string) {
	subTaskMapMutex.Lock()
	defer subTaskMapMutex.Unlock()
	
	// 查找并删除所有属于该主任务的子任务映射和临时文件
	prefix := mainTaskID + "_"
	for subTaskID := range subTaskFileNameMap {
		if strings.HasPrefix(subTaskID, prefix) {
			// 删除子任务临时文件
			zipPath := filepath.Join(s.tempDir, subTaskID+".zip")
			os.Remove(zipPath)
			// 删除映射
			delete(subTaskFileNameMap, subTaskID)
		}
	}
}

// createExportFolderName 创建导出文件夹名
func createExportFolderName(albumPath string) string {
	// 提取文件名（不含扩展名）
	base := filepath.Base(albumPath)
	name := strings.TrimSuffix(base, ".img")
	return name
}

// createImgExportFileName 创建 IMG 导出文件名
// 格式：目录_路径@文件名.img
// 例如：
// sprite/map/cutscene/black_market_800.img → sprite_map_cutscene@black_market_800.img
// priest/equipment/totem/skin@pr_body(Town_0)0000.img → priest_equipment_totem_skin@pr_body(Town_0)0000.img
func createImgExportFileName(albumPath string) string {
	// 检查路径中是否包含 @
	if atIndex := strings.LastIndex(albumPath, "@"); atIndex != -1 {
		// 有 @ 符号
		// 获取 @ 符号之前的部分（目录）
		dirPart := albumPath[:atIndex]
		// 获取 @ 符号之后的部分（文件名）
		filePart := albumPath[atIndex:]
		
		// 将目录部分的 / 替换为 _
		dirPart = strings.ReplaceAll(dirPart, "/", "_")
		
		return dirPart + filePart
	}
	
	// 没有 @ 符号，正常处理
	// 去除 .img 扩展名
	pathWithoutExt := strings.TrimSuffix(albumPath, ".img")
	
	// 按 "/" 分割路径
	parts := strings.Split(pathWithoutExt, "/")
	
	// 如果没有目录，直接返回
	if len(parts) == 1 {
		return parts[0] + ".img"
	}

	// 最后一个部分是文件名部分
	lastPart := parts[len(parts)-1]
	
	// 目录部分是前面的所有部分
	dirParts := parts[:len(parts)-1]
	
	// 将目录部分用下划线连接
	dirPart := strings.Join(dirParts, "_")
	
	// 添加 @ 和文件名
	return dirPart + "@" + lastPart + ".img"
}
