package service

import (
	"bytes"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"

	"npk-server/internal/npk"
)

type Coord struct {
	X int
	Y int
}

type BatchImportPosition string

const (
	BatchImportPositionBefore BatchImportPosition = "before"
	BatchImportPositionAfter                       = "after"
	BatchImportPositionEnd                         = "end"
)

// ==================== Album Info ====================

func extractName(path string) string {
	path = filepath.Base(path)
	if ext := filepath.Ext(path); ext != "" {
		path = strings.TrimSuffix(path, ext)
	}
	return path
}

// ==================== Rename Album ====================

func (s *NpkService) RenameAlbum(npkName, oldPath, newPath string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var targetAlbum *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == oldPath {
			targetAlbum = a
			break
		}
	}
	if targetAlbum == nil {
		return fmt.Errorf("Album 不存在: %s", oldPath)
	}

	for _, a := range info.Albums {
		if a.Path == newPath {
			return fmt.Errorf("目标路径已存在: %s", newPath)
		}
	}

	targetAlbum.Path = newPath
	targetAlbum.Name = extractName(newPath)

	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == oldPath {
				album.Path = newPath
				album.Name = extractName(newPath)
				break
			}
		}
	}

	if s.db != nil {
		npkFile, err := s.db.GetNpkFileByName(npkName)
		if err == nil && npkFile != nil {
			if err := s.db.UpdateAlbumPath(npkFile.ID, oldPath, newPath, extractName(newPath)); err != nil {
				log.Printf("[RenameAlbum] DB 更新失败: %v", err)
			}
		}
	}

	return nil
}

// ==================== Album Target ====================

func (s *NpkService) SetAlbumTarget(npkName, albumPath, targetPath string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	var targetInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == targetPath {
			targetInfo = a
			break
		}
	}
	if targetInfo == nil {
		return fmt.Errorf("目标 Album 不存在: %s", targetPath)
	}

	if albumPath == targetPath {
		return fmt.Errorf("不能引用自身")
	}

	// 检查循环引用
	tmp := targetInfo
	for tmp.TargetPath != "" {
		if tmp.TargetPath == albumPath {
			return fmt.Errorf("循环引用")
		}
		found := false
		for _, a := range info.Albums {
			if a.Path == tmp.TargetPath {
				tmp = a
				found = true
				break
			}
		}
		if !found { break }
	}

	albumInfo.TargetPath = targetPath
	albumInfo.Target = targetInfo
	albumInfo.Sprites = targetInfo.Sprites

	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == albumPath {
				album.TargetPath = targetPath
				break
			}
		}
	}

	return nil
}

func (s *NpkService) ClearAlbumTarget(npkName, albumPath string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return fmt.Errorf("Album 不存在: %s", albumPath)
	}

	if albumInfo.TargetPath == "" {
		return fmt.Errorf("该 Album 没有引用目标")
	}

	albumInfo.TargetPath = ""
	albumInfo.Target = nil
	albumInfo.Sprites = make([]*SpriteInfo, 0)

	if doc, ok := s.documents[npkName]; ok {
		for i, album := range doc.Albums {
			if album.Path == albumPath {
				file, err := os.Open(info.Path)
				if err == nil {
					defer file.Close()
					formatType := info.FormatType
					loadedAlbum, err := s.loadAlbumToMemoryLockedWithPath(npkName, albumPath, info.Path, formatType)
					if err == nil {
						doc.Albums[i] = loadedAlbum
						loadedAlbum.TargetPath = ""
					}
				}
				break
			}
		}
	}

	return nil
}

// ==================== Delete Album ====================

func (s *NpkService) DeleteAlbum(npkName, albumPath string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	for i, a := range info.Albums {
		if a.Path == albumPath {
			info.Albums = append(info.Albums[:i], info.Albums[i+1:]...)
			break
		}
	}

	if doc, ok := s.documents[npkName]; ok {
		for i, album := range doc.Albums {
			if album.Path == albumPath {
				doc.Albums = append(doc.Albums[:i], doc.Albums[i+1:]...)
				break
			}
		}
	}

	return nil
}

// ==================== Compare Album ====================

func (s *NpkService) CompareAlbum(npkName string, albumPath1, albumPath2 string) (added, deleted, modified []int, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	album1, err := s.GetAlbum(npkName, albumPath1)
	if err != nil {
		return nil, nil, nil, err
	}
	album2, err := s.GetAlbum(npkName, albumPath2)
	if err != nil {
		return nil, nil, nil, err
	}

	sprites1 := make(map[int]*npk.Sprite)
	for _, sp := range album1.Sprites {
		sprites1[sp.Index] = sp
	}
	sprites2 := make(map[int]*npk.Sprite)
	for _, sp := range album2.Sprites {
		sprites2[sp.Index] = sp
	}

	for idx := range sprites2 {
		if _, ok := sprites1[idx]; !ok {
			added = append(added, idx)
		}
	}
	for idx := range sprites1 {
		if _, ok := sprites2[idx]; !ok {
			deleted = append(deleted, idx)
		}
	}
	for idx, sp1 := range sprites1 {
		if sp2, ok := sprites2[idx]; ok {
			if sp1.Width != sp2.Width || sp1.Height != sp2.Height || sp1.X != sp2.X || sp1.Y != sp2.Y {
				modified = append(modified, idx)
			}
		}
	}

	return added, deleted, modified, nil
}

// ==================== Export/Import Coords ====================

func (s *NpkService) ExportAlbumCoords(npkName, albumPath string) ([]Coord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return nil, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return nil, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	coords := make([]Coord, 0, len(albumInfo.Sprites))
	for _, sprite := range albumInfo.Sprites {
		coords = append(coords, Coord{X: sprite.X, Y: sprite.Y})
	}

	return coords, nil
}

func (s *NpkService) ImportAlbumCoords(npkName, albumPath string, data []byte) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return 0, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return 0, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	lines := strings.Split(string(data), "\n")
	updated := 0
	spriteIdx := 0

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			continue
		}

		parts := strings.Split(line, ",")
		if len(parts) < 2 {
			continue
		}

		x, err1 := strconv.Atoi(strings.TrimSpace(parts[0]))
		y, err2 := strconv.Atoi(strings.TrimSpace(parts[1]))
		if err1 != nil || err2 != nil {
			continue
		}

		if spriteIdx >= len(albumInfo.Sprites) {
			break
		}

		albumInfo.Sprites[spriteIdx].X = x
		albumInfo.Sprites[spriteIdx].Y = y
		albumInfo.Sprites[spriteIdx].IsModified = true

		if doc, ok := s.documents[npkName]; ok {
			for _, album := range doc.Albums {
				if album.Path == albumPath && album.IsLoaded && spriteIdx < len(album.Sprites) {
					album.Sprites[spriteIdx].X = x
					album.Sprites[spriteIdx].Y = y
					album.Sprites[spriteIdx].IsModified = true
					break
				}
			}
		}

		spriteIdx++
		updated++
	}

	return updated, nil
}

// ==================== Batch Replace ====================

func (s *NpkService) BatchReplaceFromFolder(npkName, albumPath string, files map[string][]byte, colorFormat string, startIndex int, autoResize bool) (replaced int, imported int, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return 0, 0, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return 0, 0, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	type FileWithIndex struct {
		Filename string
		Data     []byte
		Index    int
	}
	var fileList []FileWithIndex
	for filename, data_ := range files {
		var index int
		_, parseErr := fmt.Sscanf(filename, "%d", &index)
		if parseErr != nil {
			ext := filepath.Ext(filename)
			baseName := strings.TrimSuffix(filename, ext)
			_, parseErr = fmt.Sscanf(baseName, "%d", &index)
			if parseErr != nil {
				index = len(fileList)
			}
		}
		actualIndex := startIndex + index
		fileList = append(fileList, FileWithIndex{
			Filename: filename,
			Data:     data_,
			Index:    actualIndex,
		})
	}
	sort.Slice(fileList, func(i, j int) bool {
		return fileList[i].Index < fileList[j].Index
	})

	type SpriteWithData struct {
		Sprite *SpriteInfo
		Data   []byte
	}
	var newSprites []SpriteWithData
	oldSpriteCount := len(albumInfo.Sprites)

	for _, f := range fileList {
		index := f.Index

		img, _, decodeErr := image.Decode(bytes.NewReader(f.Data))
		if decodeErr != nil {
			continue
		}

		bounds := img.Bounds()
		newWidth := bounds.Dx()
		newHeight := bounds.Dy()
		bgraData := npk.ImageToBGRA(img)

		if index >= 0 && index < oldSpriteCount {
			spriteInfo := albumInfo.Sprites[index]
			if spriteInfo.Type == npk.LINK {
				continue
			}

			replaceType := spriteInfo.Type
			replaceCompressMode := spriteInfo.CompressMode
			if colorFormat != "" {
				switch colorFormat {
				case "ARGB_1555": replaceType = npk.ARGB_1555; replaceCompressMode = npk.ZLIB
				case "ARGB_4444": replaceType = npk.ARGB_4444; replaceCompressMode = npk.ZLIB
				case "ARGB_8888": replaceType = npk.ARGB_8888; replaceCompressMode = npk.ZLIB
				case "DXT_5":     replaceType = npk.DXT_5;     replaceCompressMode = npk.DDS_ZLIB
				}
			}

			spriteInfo.Type = replaceType
			spriteInfo.CompressMode = replaceCompressMode
			spriteInfo.Width = newWidth
			spriteInfo.Height = newHeight
			spriteInfo.FrameWidth = newWidth
			spriteInfo.FrameHeight = newHeight

			editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
			s.setEditedSprite(editKey, bgraData)

			cacheKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, index)
			s.cache.Delete(cacheKey)
			s.thumbs.Delete(npkName, albumPath, index)

			if doc, ok := s.documents[npkName]; ok {
				for _, album := range doc.Albums {
					if album.Path == albumPath && album.IsLoaded {
						if index < len(album.Sprites) {
							album.Sprites[index].BGRAData = bgraData
							album.Sprites[index].IsModified = true
							album.Sprites[index].Type = replaceType
							album.Sprites[index].CompressMode = replaceCompressMode
							album.Sprites[index].Width = newWidth
							album.Sprites[index].Height = newHeight
							album.Sprites[index].FrameWidth = newWidth
							album.Sprites[index].FrameHeight = newHeight
						}
						break
					}
				}
			}
			replaced++
		} else {
			spriteType := npk.ARGB_8888
			compressMode := npk.ZLIB
			if colorFormat != "" {
				switch colorFormat {
				case "ARGB_1555": spriteType = npk.ARGB_1555; compressMode = npk.ZLIB
				case "ARGB_4444": spriteType = npk.ARGB_4444; compressMode = npk.ZLIB
				case "ARGB_8888": spriteType = npk.ARGB_8888; compressMode = npk.ZLIB
				case "DXT_5":     spriteType = npk.DXT_5;     compressMode = npk.DDS_ZLIB
				}
			} else {
				if len(albumInfo.Sprites) > 0 {
					for _, sp := range albumInfo.Sprites {
						if sp.Type != npk.LINK && sp.Type != npk.UNKNOWN {
							spriteType = sp.Type
							compressMode = sp.CompressMode
							break
						}
					}
				}
			}

			newSprite := &SpriteInfo{
				Index:         -1,
				OriginalIndex: -1,
				Type:          spriteType,
				CompressMode:  compressMode,
				X:             0,
				Y:             0,
				Width:         newWidth,
				Height:        newHeight,
				FrameWidth:    newWidth,
				FrameHeight:   newHeight,
				IsLink:        false,
				DataSize:      0,
				TargetIndex:   -1,
				IsModified:    true,
			}

			newSprites = append(newSprites, SpriteWithData{
				Sprite: newSprite,
				Data:   bgraData,
			})
			imported++
		}
	}

	if len(newSprites) > 0 {
		oldIndexMap := make(map[*SpriteInfo]int)
		for i, sp := range albumInfo.Sprites {
			oldIndexMap[sp] = i
		}
		var spriteDocs []*SpriteDocument
		if doc, ok := s.documents[npkName]; ok {
			for _, album := range doc.Albums {
				if album.Path == albumPath && album.IsLoaded {
					spriteDocs = make([]*SpriteDocument, len(album.Sprites))
					copy(spriteDocs, album.Sprites)
					break
				}
			}
		}
		var updatedSprites []*SpriteInfo
		updatedSprites = append(updatedSprites, albumInfo.Sprites...)
		for _, sw := range newSprites {
			updatedSprites = append(updatedSprites, sw.Sprite)
			editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, len(updatedSprites)-1)
			s.setEditedSprite(editKey, sw.Data)
		}
		oldToNewIndex := make(map[int]int)
		for newIdx, sp := range updatedSprites {
			if oldIdx, ok := oldIndexMap[sp]; ok {
				oldToNewIndex[oldIdx] = newIdx
			}
		}
		for i, sp := range updatedSprites {
			sp.Index = i
		}
		for _, sp := range updatedSprites {
			if sp.Type == npk.LINK && sp.TargetIndex >= 0 {
				if newTargetIdx, ok := oldToNewIndex[sp.TargetIndex]; ok {
					sp.TargetIndex = newTargetIdx
				}
			}
		}
		albumInfo.Sprites = updatedSprites
		albumInfo.SpriteCount = len(updatedSprites)

		if doc, ok := s.documents[npkName]; ok {
			for ai := range doc.Albums {
				album := doc.Albums[ai]
				if album.Path == albumPath {
					album.Sprites = make([]*SpriteDocument, 0, len(updatedSprites))
					for _, sp := range albumInfo.Sprites {
						docSprite := &SpriteDocument{
							Index: sp.Index, Type: sp.Type, CompressMode: sp.CompressMode,
							Width: sp.Width, Height: sp.Height,
							X: sp.X, Y: sp.Y, FrameWidth: sp.FrameWidth, FrameHeight: sp.FrameHeight,
							IsLink: sp.Type == npk.LINK, TargetIndex: sp.TargetIndex,
						}
						oldIdx, isOriginal := oldIndexMap[sp]
						if isOriginal && oldIdx >= 0 && oldIdx < len(spriteDocs) {
							docSprite.RawData = spriteDocs[oldIdx].RawData
							docSprite.BGRAData = spriteDocs[oldIdx].BGRAData
						}
						editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, sp.Index)
						if data, ok := s.editedSprites[editKey]; ok {
							docSprite.BGRAData = data
						}
						album.Sprites = append(album.Sprites, docSprite)
					}
					album.IsLoaded = true
					break
				}
			}
		}
		info.IsLoaded = true
		s.setNpkDetailCache(npkName, info)
	}

	return replaced, imported, nil
}

// ==================== Batch Import ====================

func (s *NpkService) BatchImportSprites(npkName, albumPath string, position BatchImportPosition, currentIndex int, replaceLinks bool, colorFormat string, files map[string][]byte) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return 0, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	var albumInfo *AlbumInfo
	for _, a := range info.Albums {
		if a.Path == albumPath {
			albumInfo = a
			break
		}
	}
	if albumInfo == nil {
		return 0, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	s.ensureSpritesLoaded(npkName, albumPath, albumInfo)

	type FileWithIndex struct {
		Filename string
		Data     []byte
		Index    int
	}
	var fileList []FileWithIndex
	for filename, data_ := range files {
		var index int
		_, err := fmt.Sscanf(filename, "%d", &index)
		if err != nil {
			ext := filepath.Ext(filename)
			baseName := strings.TrimSuffix(filename, ext)
			_, err = fmt.Sscanf(baseName, "%d", &index)
			if err != nil {
				index = len(fileList)
			}
		}
		fileList = append(fileList, FileWithIndex{Filename: filename, Data: data_, Index: index})
	}
	sort.Slice(fileList, func(i, j int) bool { return fileList[i].Index < fileList[j].Index })

	var insertPos int
	switch position {
	case BatchImportPositionBefore: insertPos = currentIndex
	case BatchImportPositionAfter:  insertPos = currentIndex + 1
	default: insertPos = len(albumInfo.Sprites)
	}

	type SpriteWithData struct {
		Sprite *SpriteInfo
		Data   []byte
	}
	var newSprites []SpriteWithData

	for _, f := range fileList {
		img, _, decodeErr := image.Decode(bytes.NewReader(f.Data))
		if decodeErr != nil { continue }
		bgraData := npk.ImageToBGRA(img)
		spriteType := npk.ARGB_1555
		compressMode := npk.ZLIB
		if colorFormat != "" {
			switch colorFormat {
			case "ARGB_1555": spriteType = npk.ARGB_1555; compressMode = npk.ZLIB
			case "ARGB_4444": spriteType = npk.ARGB_4444; compressMode = npk.ZLIB
			case "ARGB_8888": spriteType = npk.ARGB_8888; compressMode = npk.ZLIB
			case "DXT_5":     spriteType = npk.DXT_5;     compressMode = npk.DDS_ZLIB
			}
		} else {
			if len(albumInfo.Sprites) > 0 {
				for _, s := range albumInfo.Sprites {
					if s.Type != npk.LINK && s.Type != npk.UNKNOWN {
						spriteType = s.Type; compressMode = s.CompressMode; break
					}
				}
			}
		}
		bounds := img.Bounds()
		newSprites = append(newSprites, SpriteWithData{
			Sprite: &SpriteInfo{
				Index: -1, OriginalIndex: -1,
				Type: spriteType, CompressMode: compressMode,
				X: 0, Y: 0, Width: bounds.Dx(), Height: bounds.Dy(),
				FrameWidth: bounds.Dx(), FrameHeight: bounds.Dy(),
			},
			Data: bgraData,
		})
	}

	if len(newSprites) == 0 {
		return 0, fmt.Errorf("没有成功解析任何图片")
	}

	oldIndexMap := make(map[*SpriteInfo]int)
	for i, sp := range albumInfo.Sprites { oldIndexMap[sp] = i }
	var spriteDocs []*SpriteDocument
	if doc, ok := s.documents[npkName]; ok {
		for _, album := range doc.Albums {
			if album.Path == albumPath && album.IsLoaded {
				spriteDocs = make([]*SpriteDocument, len(album.Sprites))
				copy(spriteDocs, album.Sprites)
				break
			}
		}
	}

	var updatedSprites []*SpriteInfo
	updatedSprites = append(updatedSprites, albumInfo.Sprites[:insertPos]...)
	for _, sw := range newSprites { updatedSprites = append(updatedSprites, sw.Sprite) }
	updatedSprites = append(updatedSprites, albumInfo.Sprites[insertPos:]...)

	oldToNewIndex := make(map[int]int)
	for newIdx, sp := range updatedSprites {
		if oldIdx, ok := oldIndexMap[sp]; ok { oldToNewIndex[oldIdx] = newIdx }
	}
	for i, sp := range updatedSprites { sp.Index = i }
	for _, sp := range updatedSprites {
		if sp.Type == npk.LINK && sp.TargetIndex >= 0 {
			if newTargetIdx, ok := oldToNewIndex[sp.TargetIndex]; ok {
				sp.TargetIndex = newTargetIdx
			}
		}
	}

	for i, sw := range newSprites {
		editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, insertPos+i)
		s.setEditedSprite(editKey, sw.Data)
	}

	albumInfo.Sprites = updatedSprites
	albumInfo.SpriteCount = len(updatedSprites)
	importedCount := len(newSprites)

	if doc, ok := s.documents[npkName]; ok {
		for ai := range doc.Albums {
			album := doc.Albums[ai]
			if album.Path == albumPath {
				album.Sprites = make([]*SpriteDocument, 0, len(updatedSprites))
				for _, sp := range albumInfo.Sprites {
					docSprite := &SpriteDocument{
						Index: sp.Index, Type: sp.Type, CompressMode: sp.CompressMode,
						Width: sp.Width, Height: sp.Height,
						X: sp.X, Y: sp.Y, FrameWidth: sp.FrameWidth, FrameHeight: sp.FrameHeight,
						IsLink: sp.Type == npk.LINK, TargetIndex: sp.TargetIndex,
					}
					oldIdx, isOriginal := oldIndexMap[sp]
					if isOriginal && oldIdx >= 0 && oldIdx < len(spriteDocs) {
						docSprite.RawData = spriteDocs[oldIdx].RawData
						docSprite.BGRAData = spriteDocs[oldIdx].BGRAData
					}
					editKey := fmt.Sprintf("%s:%s:%d", npkName, albumPath, sp.Index)
					if data, ok := s.editedSprites[editKey]; ok {
						docSprite.BGRAData = data
					}
					album.Sprites = append(album.Sprites, docSprite)
				}
				album.IsLoaded = true
				break
			}
		}
	}

	info.IsLoaded = true
	s.setNpkDetailCache(npkName, info)

	return importedCount, nil
}

// ==================== Import IMG ====================

func (s *NpkService) ImportImg(npkName string, imgData []byte, targetPath string, replace bool) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	info, exists := s.files[npkName]
	if !exists {
		return fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	reader := bytes.NewReader(imgData)
	idx := &npk.NpkIndex{Offset: 0, Length: int32(len(imgData)), Path: targetPath}
	imgFile, err := npk.ReadAlbum(reader, idx)
	if err != nil {
		return fmt.Errorf("解析 IMG 文件失败: %w", err)
	}

	existingIndex := -1
	for i, a := range info.Albums {
		if a.Path == targetPath {
			existingIndex = i
			break
		}
	}

	if existingIndex >= 0 && !replace {
		return fmt.Errorf("目标路径已存在: %s", targetPath)
	}

	newAlbum := &AlbumInfo{
		Path:        targetPath,
		SpriteCount: len(imgFile.Sprites),
		Version:     imgFile.Version,
		Sprites:     make([]*SpriteInfo, len(imgFile.Sprites)),
	}

	for i, sp := range imgFile.Sprites {
		newAlbum.Sprites[i] = &SpriteInfo{
			Index: sp.Index, OriginalIndex: -1,
			Type: sp.Type, CompressMode: sp.CompressMode,
			Width: sp.Width, Height: sp.Height,
			X: sp.X, Y: sp.Y, FrameWidth: sp.FrameWidth, FrameHeight: sp.FrameHeight,
			IsLink: sp.Type == npk.LINK, TargetIndex: sp.TargetIndex, DataSize: sp.Length,
		}
	}

	if existingIndex >= 0 {
		info.Albums[existingIndex] = newAlbum
	} else {
		info.Albums = append(info.Albums, newAlbum)
	}

	return nil
}

// ==================== Convert Version ====================

func (s *NpkService) ConvertImgVersionAlbum(album *npk.Album, targetVersion int) (*npk.Album, error) {
	if album == nil {
		return nil, fmt.Errorf("album 为空")
	}

	srcVersion := int(album.Version)
	if srcVersion == 2 {
		return album, nil
	}

	// 统一转换为 V2
	return s.convertToV2(album)
}

// convertToV2 将任意版本转换为 V2 格式（ARGB_8888 + ZLIB）
func (s *NpkService) convertToV2(album *npk.Album) (*npk.Album, error) {

	newAlbum := &npk.Album{
		Path: album.Path, Name: album.Name, Version: npk.Ver2,
		Sprites: make([]*npk.Sprite, len(album.Sprites)),
	}

	for i, sprite := range album.Sprites {
		if sprite == nil { continue }
		newSprite := &npk.Sprite{
			Index: sprite.Index, Width: sprite.Width, Height: sprite.Height,
			X: sprite.X, Y: sprite.Y, FrameWidth: sprite.FrameWidth, FrameHeight: sprite.FrameHeight,
			Parent: newAlbum,
		}
		if sprite.Type == npk.LINK {
			newSprite.Type = npk.LINK
			newSprite.CompressMode = npk.NONE
			newSprite.TargetIndex = sprite.TargetIndex
			newAlbum.Sprites[i] = newSprite
			continue
		}
		imgData, err := npk.DecodeSpriteToImage(sprite, album)
		if err != nil {
			log.Printf("[Convert] 解码失败 %d: %v", sprite.Index, err)
			// 创建透明占位帧
			placeholder := make([]byte, sprite.Width*sprite.Height*4)
			encoded, _ := npk.EncodePixels(placeholder, int32(npk.ARGB_8888))
			newSprite.Type = npk.ARGB_8888
			newSprite.CompressMode = npk.ZLIB
			if compressed, e := npk.ZlibCompress(encoded); e == nil {
				newSprite.Data = compressed
				newSprite.Length = len(compressed)
			} else {
				newSprite.Data = encoded
				newSprite.Length = len(encoded)
			}
			newAlbum.Sprites[i] = newSprite
			continue
		}
		pixels := imgData.Pixels
		if album.Version == npk.Ver5 { pixels = swapRedBlue(pixels) }
		encoded, err := npk.EncodePixels(pixels, int32(npk.ARGB_8888))
		if err != nil { log.Printf("[Convert] 编码失败 %d: %v", sprite.Index, err); continue }
		var finalData []byte
		var compressMode npk.CompressMode
		if sprite.Width*sprite.Height > 1 && len(encoded) > 0 {
			compressed, err := npk.ZlibCompress(encoded)
			if err != nil { log.Printf("[Convert] 压缩失败 %d: %v", sprite.Index, err); continue }
			finalData = compressed; compressMode = npk.ZLIB
		} else { finalData = encoded; compressMode = npk.NONE }
		newSprite.Type = npk.ARGB_8888
		newSprite.CompressMode = compressMode
		newSprite.Data = finalData
		newSprite.Length = len(finalData)
		newAlbum.Sprites[i] = newSprite
	}

	for i, sprite := range newAlbum.Sprites {
		if sprite != nil && sprite.Type == npk.LINK && album.Sprites[i] != nil && album.Sprites[i].Target != nil {
			targetIdx := album.Sprites[i].Target.Index
			if targetIdx >= 0 && targetIdx < len(newAlbum.Sprites) {
				sprite.Target = newAlbum.Sprites[targetIdx]
			}
		}
	}
	return newAlbum, nil
}

func swapRedBlue(pixels []byte) []byte {
	result := make([]byte, len(pixels))
	for i := 0; i < len(pixels); i += 4 {
		result[i] = pixels[i+2]
		result[i+1] = pixels[i+1]
		result[i+2] = pixels[i]
		result[i+3] = pixels[i+3]
	}
	return result
}

// ==================== Parse IMG Data ====================

func (s *NpkService) ParseImgData(data []byte) (*npk.Album, error) {
	if len(data) < 4 { return nil, fmt.Errorf("数据太短") }
	magic := string(data[:4])
	if magic != "Neopl" { return nil, fmt.Errorf("无效的 IMG 文件头") }
	album, err := npk.ReadAlbumFromData(data)
	if err != nil { return nil, fmt.Errorf("解析 IMG 失败: %w", err) }
	return album, nil
}

func (s *NpkService) ConvertImgVersion(album *npk.Album, targetVersion int) ([]byte, error) {
	converted, err := s.ConvertImgVersionAlbum(album, 2)
	if err != nil { return nil, err }
	return npk.WriteAlbumToData(converted)
}

// needsHighColorDepth checks if BGRA data benefits from full 8-bit color
func needsHighColorDepth(bgra []byte) bool {
	count := len(bgra) / 4
	if count > 1024 { count = 1024 }
	unique := make(map[uint32]struct{}, count)
	for i := 0; i < len(bgra) && i < count*4; i += 4 {
		r := uint32(bgra[i+2]) >> 3
		g := uint32(bgra[i+1]) >> 2
		b := uint32(bgra[i]) >> 3
		unique[(r<<10)|(g<<5)|b] = struct{}{}
	}
	return len(unique) > 256
}

