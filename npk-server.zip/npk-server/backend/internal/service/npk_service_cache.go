package service

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"time"

	"npk-server/internal/npk"
)

// updateNpkDetailLRU 更新 LRU 顺序
func (s *NpkService) updateNpkDetailLRU(name string) {
	for i, n := range s.npkDetailOrder {
		if n == name {
			// 移到末尾（最近使用）
			s.npkDetailOrder = append(s.npkDetailOrder[:i], s.npkDetailOrder[i+1:]...)
			s.npkDetailOrder = append(s.npkDetailOrder, name)
			break
		}
	}
}

// removeFromNpkDetailOrder 从顺序列表中移除
func (s *NpkService) removeFromNpkDetailOrder(name string) {
	for i, n := range s.npkDetailOrder {
		if n == name {
			s.npkDetailOrder = append(s.npkDetailOrder[:i], s.npkDetailOrder[i+1:]...)
			break
		}
	}
}

// evictNpkDetailCache 淘汰最久未使用的缓存
func (s *NpkService) evictNpkDetailCache() {
	if len(s.npkDetailOrder) == 0 {
		return
	}
	// 移除最前面的（最久未使用）
	oldest := s.npkDetailOrder[0]
	delete(s.npkDetailCache, oldest)
	s.npkDetailOrder = s.npkDetailOrder[1:]
}

// loadAlbumToMemoryLocked 内部版本（不加锁，由调用方加锁）
func (s *NpkService) loadAlbumToMemoryLocked(npkName, albumPath string) (*AlbumDocument, error) {
	// 大小写不敏感查找 NPK
	actualName, _, exists := s.findNpkByNameCaseInsensitive(npkName)
	if !exists {
		return nil, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}
	npkName = actualName

	doc, exists := s.documents[npkName]
	if !exists {
		// documents 尚未初始化（用户未查看过该 NPK 详情），自动加载
		_, info, infoExists := s.findNpkByNameCaseInsensitive(npkName)
		if !infoExists {
			return nil, fmt.Errorf("NPK 文件不存在: %s", npkName)
		}
		if err := s.loadNpkDetail(info); err != nil {
			return nil, fmt.Errorf("加载 NPK 失败: %s, %v", npkName, err)
		}
		doc = s.documents[npkName]
	}

	// 查找是否已加载
	for _, album := range doc.Albums {
		if album.Path == albumPath && album.IsLoaded {
			album.LastAccess = time.Now()
			doc.LastAccess = time.Now()
			return album, nil
		}
	}

	// 检查是否是引用 Album（TargetPath 不为空）
	var isReference bool
	var targetPath string
	for _, album := range doc.Albums {
		if album.Path == albumPath && album.TargetPath != "" {
			isReference = true
			targetPath = album.TargetPath
			break
		}
	}

	// 如果是引用，直接加载目标 Album 并返回引用包装
	if isReference {
		targetAlbum, err := s.loadAlbumToMemoryLocked(npkName, targetPath)
		if err != nil {
			return nil, fmt.Errorf("加载引用目标失败: %w", err)
		}

		// 创建引用包装
		refAlbum := &AlbumDocument{
			Path:         albumPath,
			OriginalPath: albumPath,
			Name:         filepath.Base(albumPath),
			Version:      targetAlbum.Version,
			Sprites:      targetAlbum.Sprites,
			Textures:     targetAlbum.Textures,
			Tables:       targetAlbum.Tables,
			TextureInfos: targetAlbum.TextureInfos,
			IsLoaded:     true,
			LastAccess:   time.Now(),
			Target:       targetAlbum,
			TargetPath:   targetPath,
		}

		// 更新 documents
		for i, album := range doc.Albums {
			if album.Path == albumPath {
				doc.Albums[i] = refAlbum
				break
			}
		}

		return refAlbum, nil
	}

	// 从磁盘加载（使用已解析的 actualName）
	_, info, exists := s.findNpkByNameCaseInsensitive(npkName)
	if !exists {
		return nil, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}

	file, err := os.Open(info.Path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// 根据加密类型读取 NPK
	npkFile, err := npk.ReadNpkWithFormat(file, info.FormatType)
	if err != nil {
		return nil, err
	}

	var diskAlbum *npk.Album
	for _, idx := range npkFile.Indexes {
		if idx.Path == albumPath {
			diskAlbum, err = npk.ReadAlbum(file, idx)
			if err != nil {
				return nil, err
			}
			break
		}
	}
	if diskAlbum == nil {
		return nil, fmt.Errorf("Album 不存在: %s", albumPath)
	}

	// 转换为 AlbumDocument
	albumDoc := &AlbumDocument{
		Path:         albumPath,
		OriginalPath: albumPath, // 加载时 OriginalPath = Path
		Name:         diskAlbum.Name,
		Version:      diskAlbum.Version,
		Sprites:      make([]*SpriteDocument, len(diskAlbum.Sprites)),
		Textures:     diskAlbum.Textures,
		Tables:       diskAlbum.Tables,
		TextureInfos: diskAlbum.TextureInfos,
		IsLoaded:     true,
		LastAccess:   time.Now(),
	}

	for i, sp := range diskAlbum.Sprites {
		rawData := make([]byte, len(sp.Data))
		copy(rawData, sp.Data)
		albumDoc.Sprites[i] = &SpriteDocument{
			Index:        sp.Index,
			Type:         sp.Type,
			CompressMode: sp.CompressMode,
			Width:        sp.Width,
			Height:       sp.Height,
			X:            sp.X,
			Y:            sp.Y,
			FrameWidth:   sp.FrameWidth,
			FrameHeight:  sp.FrameHeight,
			RawData:      rawData,
			IsModified:   false,
			IsLink:       sp.Type == npk.LINK,
			TargetIndex:  sp.TargetIndex,
		}
		// 设置 LINK 帧的目标指针
		if sp.Type == npk.LINK && sp.TargetIndex >= 0 && sp.TargetIndex < len(diskAlbum.Sprites) {
			targetSp := diskAlbum.Sprites[sp.TargetIndex]
			targetRawData := make([]byte, len(targetSp.Data))
			copy(targetRawData, targetSp.Data)
			albumDoc.Sprites[i].Target = &SpriteDocument{
				Index:        targetSp.Index,
				Type:         targetSp.Type,
				CompressMode: targetSp.CompressMode,
				Width:        targetSp.Width,
				Height:       targetSp.Height,
				X:            targetSp.X,
				Y:            targetSp.Y,
				FrameWidth:   targetSp.FrameWidth,
				FrameHeight:  targetSp.FrameHeight,
				RawData:      targetRawData,
				IsModified:   false,
				IsLink:       targetSp.Type == npk.LINK,
				TargetIndex:  targetSp.TargetIndex,
			}
		}
	}

	// 存入 documents（替换原有的空壳 AlbumInfo）
	for i, album := range doc.Albums {
		if album.Path == albumPath {
			doc.Albums[i] = albumDoc
			break
		}
	}

	doc.LastAccess = time.Now()

	// 更新 albums 表的 sprite_count 和 version
	go s.updateAlbumSpriteInfoAsync(npkName, albumPath, int(diskAlbum.Version), len(diskAlbum.Sprites))

	return albumDoc, nil
}

// updateAlbumSpriteInfoAsync 异步更新 albums 表的 sprite_count 和 version
func (s *NpkService) updateAlbumSpriteInfoAsync(npkName, albumPath string, version, spriteCount int) {
	if s.db == nil {
		return
	}
	npkRecord, err := s.db.GetNpkFileByName(npkName)
	if err != nil || npkRecord == nil {
		return
	}
	if err := s.db.UpdateAlbumSpriteInfo(npkRecord.ID, albumPath, version, spriteCount); err != nil {
		log.Printf("updateAlbumSpriteInfoAsync: 更新失败 %s/%s: %v", npkName, albumPath, err)
	}
}

// loadAlbumToMemoryLockedWithPath 加载 Album，支持内存路径和磁盘路径不同（用于重命名后的保存）
// memoryPath: 内存中使用的路径（新路径）
// diskPath: 磁盘上实际的路径（旧路径，从 NPK 索引中读取）
func (s *NpkService) loadAlbumToMemoryLockedWithPath(npkName, memoryPath, diskPath string, formatType int) (*AlbumDocument, error) {
	// 大小写不敏感查找 NPK
	actualName, _, exists := s.findNpkByNameCaseInsensitive(npkName)
	if !exists {
		return nil, fmt.Errorf("NPK 文件不存在: %s", npkName)
	}
	npkName = actualName

	doc, exists := s.documents[npkName]
	if !exists {
		return nil, fmt.Errorf("NPK 文档未加载: %s", npkName)
	}

	// 查找是否已加载（使用内存路径）
	for _, album := range doc.Albums {
		if album.Path == memoryPath && album.IsLoaded {
			album.LastAccess = time.Now()
			doc.LastAccess = time.Now()
			return album, nil
		}
	}

	// 从磁盘加载（使用磁盘路径）
	file, err := os.Open(doc.Path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		return nil, err
	}

	var diskAlbum *npk.Album
	for _, idx := range npkFile.Indexes {
		if idx.Path == diskPath {
			diskAlbum, err = npk.ReadAlbum(file, idx)
			if err != nil {
				return nil, err
			}
			break
		}
	}

	// 如果磁盘上不存在这个 album（新建的引用 album）
	if diskAlbum == nil {
		// 检查是否是引用 album
		for _, album := range doc.Albums {
			if album.Path == memoryPath && album.TargetPath != "" {
				// 引用 album，需要加载目标 album 的数据
				log.Printf("[loadAlbumToMemoryLockedWithPath] 引用 Album %s 加载目标 %s", memoryPath, album.TargetPath)
				// 使用目标路径递归调用（memoryPath = diskPath = targetPath）
				return s.loadAlbumToMemoryLockedWithPath(npkName, album.TargetPath, album.TargetPath, formatType)
			}
		}
		return nil, fmt.Errorf("Album 不存在于磁盘: %s", diskPath)
	}

	// 检查是否是引用 album，如果是需要保留 TargetPath 信息
	var refTargetPath string
	var refTarget *AlbumDocument
	for _, album := range doc.Albums {
		if album.Path == memoryPath {
			refTargetPath = album.TargetPath
			refTarget = album.Target
			break
		}
	}

	// 转换为 AlbumDocument，但使用内存路径
	albumDoc := &AlbumDocument{
		Path:         memoryPath,    // 使用新路径
		OriginalPath: diskPath,      // 保留原始磁盘路径
		Name:         diskAlbum.Name,
		Version:      diskAlbum.Version,
		Sprites:      make([]*SpriteDocument, len(diskAlbum.Sprites)),
		Textures:     diskAlbum.Textures,
		Tables:       diskAlbum.Tables,
		TextureInfos: diskAlbum.TextureInfos,
		IsLoaded:     true,
		LastAccess:   time.Now(),
		TargetPath:   refTargetPath, // 保留引用信息
		Target:       refTarget,
	}

	for i, sp := range diskAlbum.Sprites {
		rawData := make([]byte, len(sp.Data))
		copy(rawData, sp.Data)
		albumDoc.Sprites[i] = &SpriteDocument{
			Index:        sp.Index,
			Type:         sp.Type,
			CompressMode: sp.CompressMode,
			Width:        sp.Width,
			Height:       sp.Height,
			X:            sp.X,
			Y:            sp.Y,
			FrameWidth:   sp.FrameWidth,
			FrameHeight:  sp.FrameHeight,
			RawData:      rawData,
			IsModified:   false,
			IsLink:       sp.Type == npk.LINK,
			TargetIndex:  sp.TargetIndex,
		}
		// 设置 LINK 帧的目标指针
		if sp.Type == npk.LINK && sp.TargetIndex >= 0 && sp.TargetIndex < len(diskAlbum.Sprites) {
			targetSp := diskAlbum.Sprites[sp.TargetIndex]
			targetRawData := make([]byte, len(targetSp.Data))
			copy(targetRawData, targetSp.Data)
			albumDoc.Sprites[i].Target = &SpriteDocument{
				Index:        targetSp.Index,
				Type:         targetSp.Type,
				CompressMode: targetSp.CompressMode,
				Width:        targetSp.Width,
				Height:       targetSp.Height,
				X:            targetSp.X,
				Y:            targetSp.Y,
				FrameWidth:   targetSp.FrameWidth,
				FrameHeight:  targetSp.FrameHeight,
				RawData:      targetRawData,
				IsModified:   false,
				IsLink:       targetSp.Type == npk.LINK,
				TargetIndex:  targetSp.TargetIndex,
			}
		}
	}

	// 存入 documents（替换原有的空壳，使用内存路径查找）
	for i, album := range doc.Albums {
		if album.Path == memoryPath {
			doc.Albums[i] = albumDoc
			break
		}
	}

	doc.LastAccess = time.Now()

	// 更新 albums 表的 sprite_count 和 version（使用磁盘路径）
	go s.updateAlbumSpriteInfoAsync(npkName, diskPath, int(diskAlbum.Version), len(diskAlbum.Sprites))

	return albumDoc, nil
}

// loadAlbumToMemory 将 Album 完整数据加载到内存（含像素数据）
func (s *NpkService) loadAlbumToMemory(npkName, albumPath string) (*AlbumDocument, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.loadAlbumToMemoryLocked(npkName, albumPath)
}

// LoadImgToCache 加载 IMG 到全局缓存池，一次性解码所有帧
func (s *NpkService) LoadImgToCache(npkName, albumPath string) error {
	album, err := s.GetAlbum(npkName, albumPath)
	if err != nil {
		return fmt.Errorf("获取 Album 失败: %w", err)
	}

	// 先将 Album 元数据加载到缓存池
	if err := s.imgCache.Load(npkName, albumPath, album, album.Sprites); err != nil {
		return err
	}

	// 一次性解码所有帧并存入缓存
	for i, sprite := range album.Sprites {
		img, err := npk.DecodeSpriteFrame(sprite, album, sprite.FrameWidth, sprite.FrameHeight, sprite.X, sprite.Y)
		if err != nil {
			continue
		}
		if err := s.imgCache.CacheImage(npkName, albumPath, i, img); err != nil {
			continue
		}
	}

	return nil
}

// GetImgFromCache 从缓存获取图片
func (s *NpkService) GetImgFromCache(npkName, albumPath string, index int) *npk.ImageData {
	img, _ := s.imgCache.GetImage(npkName, albumPath, index)
	return img
}

// CacheImg 将解码后的图片存入缓存
func (s *NpkService) CacheImg(npkName, albumPath string, index int, img *npk.ImageData) error {
	return s.imgCache.CacheImage(npkName, albumPath, index, img)
}

// ReleaseImgCache 释放指定 IMG 缓存
func (s *NpkService) ReleaseImgCache(npkName, albumPath string) {
	s.imgCache.Release(npkName, albumPath)
}

// ReleaseAllImgCache 释放所有 IMG 缓存
func (s *NpkService) ReleaseAllImgCache() {
	s.imgCache.ReleaseAll()
	// 同时重置所有 NPK 的 IsLoaded，强制下次从磁盘重新加载
	// 这样放弃修改后，属性变更（如基准坐标）也会被还原
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, info := range s.files {
		info.IsLoaded = false
	}
	// 清除 documents 内存文档
	s.documents = make(map[string]*NpkDocument)
	// 清除详情缓存
	s.npkDetailCache = make(map[string]*NpkFileInfo)
}

// GetImgCacheStatus 获取 IMG 缓存状态
func (s *NpkService) GetImgCacheStatus() map[string]interface{} {
	return s.imgCache.GetStatus()
}

// IsImgCached 检查 IMG 是否已缓存
func (s *NpkService) IsImgCached(npkName, albumPath string) bool {
	return s.imgCache.IsCached(npkName, albumPath)
}

// setExternalImgCache 设置外部 IMG 缓存（LRU）
func (s *NpkService) setExternalImgCache(key string, data []byte, album *npk.Album, info *AlbumInfo) {
	// 如果已存在，先删除旧项
	if _, exists := s.externalImgCache[key]; exists {
		delete(s.externalImgCache, key)
		s.removeFromExternalImgOrder(key)
	}

	// 检查是否需要淘汰
	if len(s.externalImgCache) >= s.externalImgMaxSize {
		s.evictExternalImgCache()
	}

	// 添加新项
	s.externalImgCache[key] = &externalImgEntry{
		data:     data,
		album:    album,
		info:     info,
		loadedAt: time.Now(),
	}
	s.externalImgOrder = append(s.externalImgOrder, key)
}

// updateExternalImgLRU 更新 LRU 顺序
func (s *NpkService) updateExternalImgLRU(key string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	for i, k := range s.externalImgOrder {
		if k == key {
			// 移到末尾（最近使用）
			s.externalImgOrder = append(s.externalImgOrder[:i], s.externalImgOrder[i+1:]...)
			s.externalImgOrder = append(s.externalImgOrder, key)
			return
		}
	}
}

// removeFromExternalImgOrder 从 LRU 顺序中移除
func (s *NpkService) removeFromExternalImgOrder(key string) {
	for i, k := range s.externalImgOrder {
		if k == key {
			s.externalImgOrder = append(s.externalImgOrder[:i], s.externalImgOrder[i+1:]...)
			return
		}
	}
}

// evictExternalImgCache 淘汰最旧的缓存
func (s *NpkService) evictExternalImgCache() {
	if len(s.externalImgOrder) > 0 {
		oldestKey := s.externalImgOrder[0]
		delete(s.externalImgCache, oldestKey)
		s.externalImgOrder = s.externalImgOrder[1:]
	}
}
