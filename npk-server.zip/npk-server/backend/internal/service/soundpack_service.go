package service

import (
	"fmt"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/music"
	"npk-server/internal/npk"
)

type SoundPackService struct {
	cfg *config.Config
	db  *database.Database
	mu  sync.RWMutex
}

func NewSoundPackService(cfg *config.Config, db *database.Database) *SoundPackService {
	return &SoundPackService{cfg: cfg, db: db}
}

func (s *SoundPackService) ScanAll() ([]*database.SoundPackRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	dirs := s.cfg.SoundPackDirs
	if len(dirs) == 0 {
		return nil, nil
	}

	var allRecords []*database.SoundPackRecord
	for _, dir := range dirs {
		log.Printf("[SoundPackService] 开始扫描目录: %s", dir)
		records, err := s.scanDirUnlocked(dir)
		if err != nil {
			log.Printf("[SoundPackService] 扫描目录 %s 失败: %v", dir, err)
			continue
		}
		log.Printf("[SoundPackService] 目录 %s 扫描完成，发现 %d 个 NPK 文件", dir, len(records))
		allRecords = append(allRecords, records...)
	}
	return allRecords, nil
}

func (s *SoundPackService) ScanDir(dir string) ([]*database.SoundPackRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.scanDirUnlocked(dir)
}

func (s *SoundPackService) scanDirUnlocked(dir string) ([]*database.SoundPackRecord, error) {
	var npkFiles []string
	err := filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if !d.IsDir() && strings.ToLower(filepath.Ext(d.Name())) == ".npk" {
			npkFiles = append(npkFiles, path)
		}
		return nil
	})
	if err != nil {
		return nil, fmt.Errorf("扫描目录失败: %w", err)
	}

	var records []*database.SoundPackRecord
	for _, npkPath := range npkFiles {
		record, err := s.indexNpkFile(npkPath, dir)
		if err != nil {
			log.Printf("[SoundPackService] 索引 NPK 文件 %s 失败: %v", npkPath, err)
			continue
		}

		existing, err := s.db.GetSoundPackByPath(record.Path)
		if err != nil {
			log.Printf("[SoundPackService] 查询记录失败 %s: %v", record.Path, err)
			continue
		}

		if existing != nil {
			record.ID = existing.ID
			if err := s.db.UpdateSoundPack(record); err != nil {
				log.Printf("[SoundPackService] 更新记录失败 %s: %v", record.Path, err)
				continue
			}
		} else {
			id, err := s.db.InsertSoundPack(record)
			if err != nil {
				log.Printf("[SoundPackService] 插入记录失败 %s: %v", record.Path, err)
				continue
			}
			record.ID = id
		}

		s.indexNpkEntriesUnlocked(record.ID, npkPath, record.FormatType)

		records = append(records, record)
	}
	return records, nil
}

func (s *SoundPackService) indexNpkFile(npkPath, baseDir string) (*database.SoundPackRecord, error) {
	fileInfo, err := os.Stat(npkPath)
	if err != nil {
		return nil, err
	}

	file, err := os.Open(npkPath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	encType, _ := npk.DetectNpkEncryptionType(file)

	record := &database.SoundPackRecord{
		Name:        fileInfo.Name(),
		Path:        npkPath,
		Size:        fileInfo.Size(),
		IsEncrypted: encType == 0 || encType == 99,
		FormatType:  encType,
	}

	relPath, _ := filepath.Rel(baseDir, npkPath)
	relPath = filepath.ToSlash(relPath)
	relDir := filepath.ToSlash(filepath.Dir(relPath))
	if relDir == "." || relDir == "/" || relDir == "./" {
		relDir = ""
	}
	relDir = strings.TrimPrefix(relDir, "./")
	record.DirPath = relDir

	return record, nil
}

// indexNpkEntriesUnlocked 读取 NPK 索引并自动填充 OGG 条目（不加锁）
func (s *SoundPackService) indexNpkEntriesUnlocked(soundpackID int64, npkPath string, formatType int) {
	file, err := os.Open(npkPath)
	if err != nil {
		log.Printf("[SoundPackService] 打开 NPK 失败 %s: %v", npkPath, err)
		return
	}
	defer file.Close()

	npkFile, err := npk.ReadNpkWithFormat(file, formatType)
	if err != nil {
		log.Printf("[SoundPackService] 读取 NPK 索引失败 %s: %v", npkPath, err)
		return
	}

	s.db.DeleteSoundPackEntriesBySoundPackID(soundpackID)

	var oggCount int
	for _, idx := range npkFile.Indexes {
		lowerPath := strings.ToLower(idx.Path)
		if !strings.HasSuffix(lowerPath, ".ogg") {
			continue
		}

		entry := &database.SoundPackEntry{
			SoundpackID: soundpackID,
			EntryPath:   idx.Path,
			EntryName:   filepath.Base(idx.Path),
			EntrySize:   int64(idx.Length),
			EntryOffset: int64(idx.Offset),
		}

		headerSize := int32(256 * 1024)
		if headerSize > idx.Length {
			headerSize = idx.Length
		}
		data := make([]byte, headerSize)
		if _, err := file.ReadAt(data, int64(idx.Offset)); err == nil {
			info := music.ParseAudioInfo(data, int64(idx.Length), "OGG")
			if info != nil {
				entry.OggDuration = info.Duration
				entry.OggSampleRate = info.SampleRate
				entry.OggChannels = info.Channels
			}
		}

		if _, err := s.db.InsertSoundPackEntry(entry); err != nil {
			log.Printf("[SoundPackService] 插入条目失败 %s: %v", idx.Path, err)
			continue
		}
		oggCount++
	}

	s.db.UpdateOGGCount(soundpackID, oggCount)
}

func (s *SoundPackService) GetSoundPackEntries(soundpackID int64) ([]*database.SoundPackEntry, error) {
	// 如果 DB 中没有条目，尝试自动从 NPK 中索引
	record, err := s.db.GetSoundPackByID(soundpackID)
	if err == nil && record != nil && record.OggCount == 0 {
		s.mu.Lock()
		s.indexNpkEntriesUnlocked(soundpackID, record.Path, record.FormatType)
		s.mu.Unlock()
	}
	return s.db.GetSoundPackEntries(soundpackID)
}

// DecryptSoundPack 强制重新解密/索引（用于重建）
func (s *SoundPackService) DecryptSoundPack(id int64) ([]*database.SoundPackEntry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	record, err := s.db.GetSoundPackByID(id)
	if err != nil || record == nil {
		return nil, fmt.Errorf("音效包不存在")
	}

	s.indexNpkEntriesUnlocked(id, record.Path, record.FormatType)
	return s.db.GetSoundPackEntries(id)
}

// ReadSoundPackEntryData 读取音效包中 OGG 条目的原始数据
func (s *SoundPackService) ReadSoundPackEntryData(entryID int64) ([]byte, *database.SoundPackEntry, *database.SoundPackRecord, error) {
	entry, err := s.db.GetSoundPackEntry(entryID)
	if err != nil || entry == nil {
		return nil, nil, nil, fmt.Errorf("条目不存在")
	}

	record, err := s.db.GetSoundPackByID(entry.SoundpackID)
	if err != nil || record == nil {
		return nil, nil, nil, fmt.Errorf("音效包不存在")
	}

	file, err := os.Open(record.Path)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("打开文件失败: %w", err)
	}
	defer file.Close()

	data := make([]byte, entry.EntrySize)
	if _, err := file.ReadAt(data, entry.EntryOffset); err != nil {
		return nil, nil, nil, fmt.Errorf("读取数据失败: %w", err)
	}

	return data, entry, record, nil
}

// saveSoundPackToFile 保存音效包到 NPK 文件（根据 DB 条目重建）
func (s *SoundPackService) saveSoundPackToFile(soundpackID int64) error {
	record, err := s.db.GetSoundPackByID(soundpackID)
	if err != nil || record == nil {
		return fmt.Errorf("音效包不存在")
	}

	entries, err := s.db.GetSoundPackEntries(soundpackID)
	if err != nil {
		return fmt.Errorf("获取条目失败: %w", err)
	}

	// 收集所有 Album（Version=Other）和原始数据
	var albums []*npk.Album
	var rawData [][]byte

	for _, entry := range entries {
		album := &npk.Album{
			Path:    entry.EntryPath,
			Name:    entry.EntryName,
			Version: npk.Other,
		}

		var data []byte
		if len(entry.Data) > 0 {
			// 导入的条目：使用存储的 OGG 数据
			data = entry.Data
		} else {
			// 原有条目：从 NPK 文件读取
			file, err := os.Open(record.Path)
			if err != nil {
				return fmt.Errorf("打开 NPK 文件失败: %w", err)
			}
			data = make([]byte, entry.EntrySize)
			_, err = file.ReadAt(data, entry.EntryOffset)
			file.Close()
			if err != nil {
				return fmt.Errorf("读取原始数据失败 %s: %w", entry.EntryPath, err)
			}
		}

		albums = append(albums, album)
		rawData = append(rawData, data)
	}

	if len(albums) == 0 {
		return nil
	}

	// 写入 NPK
	backupPath := record.Path + ".bak"
	if err := os.Rename(record.Path, backupPath); err != nil {
		return fmt.Errorf("备份原文件失败: %w", err)
	}

	err = npk.WriteNpk(record.Path, albums, nil, rawData, record.FormatType, record.Name)
	if err != nil {
		os.Rename(backupPath, record.Path)
		return fmt.Errorf("写入 NPK 失败: %w", err)
	}
	os.Remove(backupPath)

	// 更新文件大小
	fileInfo, _ := os.Stat(record.Path)
	if fileInfo != nil {
		record.Size = fileInfo.Size()
		s.db.UpdateSoundPack(record)
	}

	// 重新索引条目（更新 offset 等）
	s.indexNpkEntriesUnlocked(soundpackID, record.Path, record.FormatType)

	return nil
}

func (s *SoundPackService) ImportOGGToSoundPack(soundpackID int64, entryPath string, oggData []byte) (*database.SoundPackEntry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	record, err := s.db.GetSoundPackByID(soundpackID)
	if err != nil || record == nil {
		return nil, fmt.Errorf("音效包不存在")
	}

	entry := &database.SoundPackEntry{
		SoundpackID: soundpackID,
		EntryPath:   entryPath,
		EntryName:   filepath.Base(entryPath),
		EntrySize:   int64(len(oggData)),
		EntryOffset: 0,
		Data:        oggData,
	}

	info := music.ParseAudioInfo(oggData, int64(len(oggData)), "OGG")
	if info != nil {
		entry.OggDuration = info.Duration
		entry.OggSampleRate = info.SampleRate
		entry.OggChannels = info.Channels
	}

	id, err := s.db.InsertSoundPackEntry(entry)
	if err != nil {
		return nil, fmt.Errorf("插入条目失败: %w", err)
	}
	entry.ID = id

	record.OggCount++
	s.db.UpdateSoundPack(record)

	// 保存到 NPK 文件
	if err := s.saveSoundPackToFile(soundpackID); err != nil {
		log.Printf("[SoundPackService] 保存 NPK 文件失败: %v", err)
		return entry, fmt.Errorf("保存 NPK 文件失败: %w", err)
	}

	return entry, nil
}

func (s *SoundPackService) DeleteSoundPackEntryData(entryID int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	entry, err := s.db.GetSoundPackEntry(entryID)
	if err != nil || entry == nil {
		return fmt.Errorf("条目不存在")
	}

	soundpackID := entry.SoundpackID

	if err := s.db.DeleteSoundPackEntry(entryID); err != nil {
		return err
	}

	record, _ := s.db.GetSoundPackByID(soundpackID)
	if record != nil && record.OggCount > 0 {
		record.OggCount--
		s.db.UpdateSoundPack(record)
	}

	return s.saveSoundPackToFile(soundpackID)
}

// BatchDeleteSoundPackEntries 批量删除条目（全删完后只保存一次）
func (s *SoundPackService) BatchDeleteSoundPackEntries(entryIDs []int64) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var soundpackID int64
	deleted := 0

	for _, entryID := range entryIDs {
		entry, err := s.db.GetSoundPackEntry(entryID)
		if err != nil || entry == nil {
			continue
		}

		if soundpackID == 0 {
			soundpackID = entry.SoundpackID
		}

		if err := s.db.DeleteSoundPackEntry(entryID); err != nil {
			continue
		}
		deleted++
	}

	if deleted == 0 || soundpackID == 0 {
		return 0, nil
	}

	record, _ := s.db.GetSoundPackByID(soundpackID)
	if record != nil {
		record.OggCount -= deleted
		if record.OggCount < 0 {
			record.OggCount = 0
		}
		s.db.UpdateSoundPack(record)
	}

	return deleted, s.saveSoundPackToFile(soundpackID)
}

func (s *SoundPackService) ListSoundPacks(query string, page, pageSize int) ([]*database.SoundPackRecord, int, error) {
	return s.db.ListSoundPacks(query, page, pageSize)
}

func (s *SoundPackService) GetSoundPack(id int64) (*database.SoundPackRecord, error) {
	return s.db.GetSoundPackByID(id)
}

func (s *SoundPackService) GetSoundPackStats() (*database.SoundPackStats, error) {
	return s.db.GetSoundPackStats()
}

func (s *SoundPackService) DeleteSoundPack(id int64) error {
	return s.db.DeleteSoundPack(id)
}

func (s *SoundPackService) DeleteSoundPacksByIDs(ids []int64) (int64, error) {
	return s.db.DeleteSoundPacksByIDs(ids)
}

func (s *SoundPackService) GetSoundPacksByIDs(ids []int64) ([]*database.SoundPackRecord, error) {
	return s.db.GetSoundPacksByIDs(ids)
}

func (s *SoundPackService) RescanDir(dirPath string) ([]*database.SoundPackRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	deleted, err := s.db.DeleteSoundPackByDir(dirPath)
	if err != nil {
		return nil, fmt.Errorf("删除旧记录失败: %w", err)
	}
	log.Printf("[SoundPackService] 已删除目录 %s 下的 %d 条旧记录", dirPath, deleted)

	return s.scanDirUnlocked(dirPath)
}

func (s *SoundPackService) UpdateSoundPackEntryPath(entryID int64, newPath string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	entry, err := s.db.GetSoundPackEntry(entryID)
	if err != nil || entry == nil {
		return fmt.Errorf("条目不存在")
	}

	if err := s.db.UpdateSoundPackEntryPath(entryID, newPath); err != nil {
		return err
	}

	return s.saveSoundPackToFile(entry.SoundpackID)
}

func (s *SoundPackService) FindEntryByPath(entryPath string) (*database.SoundPackEntry, error) {
	return s.db.FindSoundPackEntryByPath(entryPath)
}
