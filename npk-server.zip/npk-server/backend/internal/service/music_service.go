package service

import (
	"fmt"
	"log"
	"path/filepath"
	"strings"
	"sync"

	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/music"
)

// MusicService 音乐服务
type MusicService struct {
	cfg *config.Config
	db  *database.Database
	mu  sync.RWMutex
}

// NewMusicService 创建音乐服务
func NewMusicService(cfg *config.Config, db *database.Database) *MusicService {
	return &MusicService{
		cfg: cfg,
		db:  db,
	}
}

// ScanAll 扫描所有配置的音乐目录
func (s *MusicService) ScanAll() ([]*database.MusicRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	dirs := s.cfg.MusicDirs
	if len(dirs) == 0 {
		return nil, nil
	}

	var allRecords []*database.MusicRecord
	for _, dir := range dirs {
		log.Printf("[MusicService] 开始扫描目录: %s", dir)
		records, err := s.scanDirUnlocked(dir)
		if err != nil {
			log.Printf("[MusicService] 扫描目录 %s 失败: %v", dir, err)
			continue
		}
		log.Printf("[MusicService] 目录 %s 扫描完成，发现 %d 个音频文件", dir, len(records))
		allRecords = append(allRecords, records...)
	}

	return allRecords, nil
}

// ScanDir 扫描单个目录
func (s *MusicService) ScanDir(dir string) ([]*database.MusicRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	return s.scanDirUnlocked(dir)
}

func (s *MusicService) scanDirUnlocked(dir string) ([]*database.MusicRecord, error) {
	audioFiles, err := music.ScanMusicDir(dir)
	if err != nil {
		return nil, fmt.Errorf("扫描目录失败: %w", err)
	}

	var records []*database.MusicRecord
	for _, af := range audioFiles {
		record := s.audioFileToRecord(&af, dir)

		existing, err := s.db.GetMusicByPath(record.Path)
		if err != nil {
			log.Printf("[MusicService] 查询音乐记录失败 %s: %v", record.Path, err)
			continue
		}

		if existing != nil {
			record.ID = existing.ID
			if err := s.db.UpdateMusic(record); err != nil {
				log.Printf("[MusicService] 更新音乐记录失败 %s: %v", record.Path, err)
				continue
			}
			records = append(records, record)
		} else {
			id, err := s.db.InsertMusic(record)
			if err != nil {
				log.Printf("[MusicService] 插入音乐记录失败 %s: %v", record.Path, err)
				continue
			}
			record.ID = id
			records = append(records, record)
		}
	}

	return records, nil
}

func (s *MusicService) audioFileToRecord(af *music.AudioFile, baseDir string) *database.MusicRecord {
	relPath, err := filepath.Rel(baseDir, af.Path)
	if err != nil {
		relPath = af.Path
	}
	relPath = filepath.ToSlash(relPath)
	relDir := filepath.ToSlash(filepath.Dir(relPath))
	if relDir == "." || relDir == "/" || relDir == "./" {
		relDir = ""
	}
	relDir = strings.TrimPrefix(relDir, "./")

	record := &database.MusicRecord{
		Name:    af.Name,
		Path:    af.Path,
		DirPath: relDir,
		Size:    af.Size,
		Format:  af.Format,
	}

	if af.Info != nil {
		record.Duration = af.Info.Duration
		record.SampleRate = af.Info.SampleRate
		record.Channels = af.Info.Channels
		record.Bitrate = af.Info.Bitrate
	}

	return record
}

// ListMusic 分页列出音乐记录
func (s *MusicService) ListMusic(query string, page, pageSize int) ([]*database.MusicRecord, int, error) {
	return s.db.ListMusic(query, page, pageSize)
}

// SearchMusic 搜索音乐
func (s *MusicService) SearchMusic(query, format string, page, pageSize int) ([]*database.MusicRecord, int, error) {
	return s.db.SearchMusic(query, format, page, pageSize)
}

// GetMusic 获取单个音乐信息
func (s *MusicService) GetMusic(id int64) (*database.MusicRecord, error) {
	return s.db.GetMusicByID(id)
}

// GetMusicStats 获取统计信息
func (s *MusicService) GetMusicStats() (*database.MusicStats, error) {
	return s.db.GetMusicStats()
}

// DeleteMusic 删除数据库记录
func (s *MusicService) DeleteMusic(id int64) error {
	return s.db.DeleteMusic(id)
}

// GetMusicByIDs 根据ID列表获取记录
func (s *MusicService) GetMusicByIDs(ids []int64) ([]*database.MusicRecord, error) {
	return s.db.GetMusicByIDs(ids)
}

// DeleteMusicByIDs 批量删除
func (s *MusicService) DeleteMusicByIDs(ids []int64) (int64, error) {
	return s.db.DeleteMusicByIDs(ids)
}

// RescanDir 重新扫描目录
func (s *MusicService) RescanDir(dirPath string) ([]*database.MusicRecord, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	deleted, err := s.db.DeleteMusicByDir(dirPath)
	if err != nil {
		return nil, fmt.Errorf("删除旧记录失败: %w", err)
	}
	log.Printf("[MusicService] 已删除目录 %s 下的 %d 条旧记录", dirPath, deleted)

	return s.scanDirUnlocked(dirPath)
}

// FindMusicByPath 按路径查找音乐
func (s *MusicService) FindMusicByPath(path string) (*database.MusicRecord, error) {
	return s.db.GetMusicByPath(path)
}
