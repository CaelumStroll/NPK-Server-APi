package main

import (
	"embed"
	"io/fs"
	"log"
	"os"
	"path/filepath"
)

//go:embed assets/avatars
//go:embed assets/tools/*.json
//go:embed assets/tools/*.html
//go:embed assets/tools/CaelumStroll
//go:embed assets/language
var assetsFS embed.FS

var runtimeDir string

func SetRuntimeDir(dir string) {
	runtimeDir = dir
}

// InitDefaultAssets 初始化默认资源（avatars + tools 始终内嵌）
func InitDefaultAssets() error {
	execDir := runtimeDir
	if execDir == "" {
		exePath, err := os.Executable()
		if err != nil {
			return err
		}
		execDir = filepath.Dir(exePath)
	}

	if err := extractEmbeddedDir(execDir, "avatars", "assets/avatars", assetsFS); err != nil {
		log.Printf("[embed] 初始化 avatars 失败: %v", err)
	}
	if err := extractEmbeddedDir(execDir, "tools", "assets/tools", assetsFS); err != nil {
		log.Printf("[embed] 初始化 tools 失败: %v", err)
	}
	if err := extractEmbeddedDirOverwrite(execDir, "language", "assets/language", assetsFS); err != nil {
		log.Printf("[embed] 初始化 language 失败: %v", err)
	}
	if err := initFFmpeg(execDir); err != nil {
		log.Printf("[embed] 初始化 ffmpeg 失败: %v", err)
	}

	return nil
}

// extractEmbeddedDir 递归提取嵌入目录到目标路径，已有文件跳过不覆盖
func extractEmbeddedDir(execDir, dirName, embedPath string, efs embed.FS) error {
	targetDir := filepath.Join(execDir, dirName)
	log.Printf("[embed] 提取 %s -> %s", embedPath, targetDir)

	count := 0
	if err := walkEmbedDir(embedPath, targetDir, efs, &count); err != nil {
		return err
	}
	log.Printf("[embed] %s 完成: %d 个文件", dirName, count)
	return nil
}

func extractEmbeddedDirOverwrite(execDir, dirName, embedPath string, efs embed.FS) error {
	targetDir := filepath.Join(execDir, dirName)
	log.Printf("[embed] 更新 %s -> %s", embedPath, targetDir)

	count := 0
	entries, err := fs.ReadDir(efs, embedPath)
	if err != nil {
		return err
	}

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		srcPath := embedPath + "/" + entry.Name()
		destPath := filepath.Join(targetDir, entry.Name())

		if err := os.MkdirAll(filepath.Dir(destPath), 0755); err != nil {
			continue
		}

		data, err := efs.ReadFile(srcPath)
		if err != nil {
			continue
		}

		if err := os.WriteFile(destPath, data, 0644); err != nil {
			continue
		}
		count++
	}
	log.Printf("[embed] %s 完成: %d 个文件(覆盖)", dirName, count)
	return nil
}

func walkEmbedDir(embedDir, targetDir string, efs embed.FS, count *int) error {
	entries, err := fs.ReadDir(efs, embedDir)
	if err != nil {
		return err
	}

	for _, entry := range entries {
		srcPath := embedDir + "/" + entry.Name()
		destPath := filepath.Join(targetDir, entry.Name())

		if entry.IsDir() {
			if err := walkEmbedDir(srcPath, destPath, efs, count); err != nil {
				log.Printf("[embed] 遍历 %s 失败: %v", srcPath, err)
			}
			continue
		}

		if _, err := os.Stat(destPath); err == nil {
			continue
		}

		if err := os.MkdirAll(filepath.Dir(destPath), 0755); err != nil {
			log.Printf("[embed] 创建目录失败: %v", err)
			continue
		}

		data, err := efs.ReadFile(srcPath)
		if err != nil {
			log.Printf("[embed] 读取 %s 失败: %v", srcPath, err)
			continue
		}

		if err := os.WriteFile(destPath, data, 0644); err != nil {
			log.Printf("[embed] 写入 %s 失败: %v", destPath, err)
			continue
		}

		*count++
	}

	return nil
}
