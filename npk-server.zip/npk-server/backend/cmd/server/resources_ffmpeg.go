//go:build embedffmpeg

package main

import (
	"embed"
	"log"
	"os"
	"path/filepath"
)

//go:embed assets/tools/ffmpeg/ffmpeg.exe
var ffmpegFS embed.FS

// initFFmpeg 从内嵌资源释放 ffmpeg.exe
func initFFmpeg(execDir string) error {
	ffmpegDir := filepath.Join(execDir, "tools", "ffmpeg")
	ffmpegPath := filepath.Join(ffmpegDir, "ffmpeg.exe")

	if _, err := os.Stat(ffmpegPath); err == nil {
		return nil
	}

	data, err := ffmpegFS.ReadFile("assets/tools/ffmpeg/ffmpeg.exe")
	if err != nil {
		return err
	}

	if err := os.MkdirAll(ffmpegDir, 0755); err != nil {
		return err
	}

	if err := os.WriteFile(ffmpegPath, data, 0755); err != nil {
		return err
	}

	log.Printf("[embed] 释放 ffmpeg: %s", ffmpegPath)
	return nil
}
