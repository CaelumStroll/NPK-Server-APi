//go:build !embedffmpeg

package main

import (
	"log"
	"os"
	"path/filepath"
)

// initFFmpeg 非 ffmpeg 版本：仅创建目录并提示
func initFFmpeg(execDir string) error {
	ffmpegDir := filepath.Join(execDir, "tools", "ffmpeg")
	if err := os.MkdirAll(ffmpegDir, 0755); err != nil {
		return err
	}

	ffmpegPath := filepath.Join(ffmpegDir, "ffmpeg.exe")
	if _, err := os.Stat(ffmpegPath); os.IsNotExist(err) {
		log.Printf("[提示] ffmpeg.exe 未找到，请手动放置到 %s", ffmpegDir)
	}
	return nil
}
