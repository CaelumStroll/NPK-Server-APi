package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"

	"npk-server/internal/api"
	"npk-server/internal/config"
	"npk-server/internal/database"
	"npk-server/internal/service"
)

var (
	configPath = flag.String("config", "config.json", "配置文件路径")
	scanDir    = flag.String("scan", "", "扫描目录")
	port       = flag.Int("port", 0, "服务器端口")
)

func main() {
	flag.Parse()

	// 确定运行目录：使用 exe 所在目录
	runtimeDir := "."
	if exePath, err := os.Executable(); err == nil {
		exeDir := filepath.Dir(exePath)
		// macOS 下 go run 时 exe 在临时目录，使用 CWD
		if strings.Contains(exeDir, "go-build") || strings.Contains(exeDir, "/T/") {
			if cwd, err := os.Getwd(); err == nil {
				runtimeDir = cwd
			}
		} else {
			runtimeDir = exeDir
		}
	} else {
		if cwd, err := os.Getwd(); err == nil {
			runtimeDir = cwd
		}
	}
	os.Chdir(runtimeDir)
	log.Printf("[main] 运行目录: %s", runtimeDir)

	// 将相对路径的 config 解析为相对于运行目录
	configFile := *configPath
	if !filepath.IsAbs(configFile) {
		configFile = filepath.Join(runtimeDir, configFile)
	}

	// 加载配置
	cfg, err := config.Load(configFile)
	if err != nil {
		log.Fatalf("加载配置失败: %v", err)
	}

	// 命令行参数覆盖配置
	if *port > 0 {
		cfg.ServerPort = *port
	}

	// 确保目录存在
	if err := cfg.EnsureDirs(); err != nil {
		log.Fatalf("创建目录失败: %v", err)
	}

	// 初始化默认资源（avatars、tools、language）
	SetRuntimeDir(runtimeDir)
	if err := InitDefaultAssets(); err != nil {
		log.Printf("初始化默认资源失败: %v", err)
	}

	// 设置 exec 目录（供 tools/avatars/language 路由使用）
	api.SetExecDir(runtimeDir)

	// 初始化数据库
	db, err := database.NewDatabase(cfg.DatabasePath)
	if err != nil {
		log.Fatalf("初始化数据库失败: %v", err)
	}
	defer db.Close()

	// 初始化服务
	npkSvc := service.NewNpkService(cfg, db)

	// 优先从数据库加载数据到内存
	if err := npkSvc.LoadFromDatabase(); err != nil {
		log.Printf("从数据库加载数据失败: %v", err)
	}

	// 仅在命令行指定 -scan 时扫描，不自动扫描
	if *scanDir != "" {
		log.Printf("扫描目录: %s", *scanDir)
		if err := npkSvc.ScanDirectory(*scanDir, nil); err != nil {
			log.Printf("扫描目录失败 %s: %v", *scanDir, err)
		}
	}

	// 创建服务器
	videoSvc := service.NewVideoService(cfg, db)
	musicSvc := service.NewMusicService(cfg, db)
	soundpackSvc := service.NewSoundPackService(cfg, db)
	server := api.NewServer(cfg, db, npkSvc, videoSvc, musicSvc, soundpackSvc)
	server.Setup()
	server.InitAudioXml()

	// 打印启动信息
	fmt.Println()
	fmt.Println("╔═══════════════════════════════════════════════════════════╗")
	fmt.Println("║                    NPK Server v3.0.0                      ║")
	fmt.Println("╠═══════════════════════════════════════════════════════════╣")
	fmt.Printf("║  Server:  http://localhost:%-30d ║\n", cfg.ServerPort)
	fmt.Printf("║  Data:    %-46s  ║\n", cfg.DataDir)
	fmt.Printf("║  Cache:   %-46s  ║\n", cfg.CacheDir)
	fmt.Println("╠═══════════════════════════════════════════════════════════╣")
	fmt.Println("║  API Endpoints:                                           ║")
	fmt.Println("║  NPK 管理:                                                ║")
	fmt.Println("║    GET    /api/npk/list              - NPK 文件列表       ║")
	fmt.Println("║    GET    /api/npk/:name/info        - NPK 详细信息       ║")
	fmt.Println("║    GET    /api/npk/:name/assets      - 资源列表           ║")
	fmt.Println("║    POST   /api/npk/:name/reload      - 重新加载 NPK       ║")
	fmt.Println("║  IMG 缓存:                                                ║")
	fmt.Println("║    POST   /api/cache/img/load        - 加载 IMG 到缓存    ║")
	fmt.Println("║    DELETE /api/cache/img/release     - 释放指定缓存       ║")
	fmt.Println("║    DELETE /api/cache/img/release-all - 释放全部缓存       ║")
	fmt.Println("║    GET    /api/cache/img/status      - 缓存状态           ║")
	fmt.Println("╠═══════════════════════════════════════════════════════════╣")
	fmt.Println("║  CaelumStroll - 20260613                                  ║")
	fmt.Println("╚═══════════════════════════════════════════════════════════╝")
	fmt.Println()

	// 优雅关闭
	go func() {
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
		<-sigCh
		log.Println("正在关闭服务器...")
		os.Exit(0)
	}()

	// 启动服务器
	if err := server.Run(); err != nil {
		log.Fatalf("启动服务器失败: %v", err)
	}
}
