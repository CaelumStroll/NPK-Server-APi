import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import 'element-plus/dist/index.css'
import 'element-plus/theme-chalk/dark/css-vars.css'

import App from './App.vue'
import router from './router'
import i18n, { initLanguage } from './language'
import './assets/main.scss'

// 跟随系统主题
function applySystemTheme() {
  const dark = window.matchMedia('(prefers-color-scheme: dark)').matches
  document.documentElement.classList.toggle('dark', dark)
  document.documentElement.classList.toggle('light', !dark)
}

// 初始化主题
applySystemTheme()

// 监听系统主题变化
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
  applySystemTheme()
})

const app = createApp(App)

// 注册所有图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(createPinia())
app.use(router)
app.use(i18n)
app.use(ElementPlus, { size: 'default', zIndex: 3000 })

app.mount('#app')

initLanguage()

// 浏览器 bfcache 恢复时强制刷新，避免显示旧页面
window.addEventListener('pageshow', (event) => {
  if (event.persisted) {
    location.reload()
  }
})
