<script setup lang="ts">
/**
 * 搜索高亮文本组件
 * 将文本中匹配搜索词的部分用 <mark> 标签高亮
 */
withDefaults(defineProps<{
  text: string
  keyword: string
  caseSensitive?: boolean
}>(), {
  caseSensitive: false
})

function highlightText(text: string, keyword: string, caseSensitive: boolean): string {
  if (!keyword || !keyword.trim()) {
    return escapeHtml(text)
  }

  const escaped = escapeHtml(text)
  const escapedKeyword = escapeHtml(keyword.trim())
  const flags = caseSensitive ? 'g' : 'gi'

  try {
    const regex = new RegExp(`(${escapeRegex(escapedKeyword)})`, flags)
    return escaped.replace(regex, '<mark class="search-highlight">$1</mark>')
  } catch {
    return escaped
  }
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}
</script>

<template>
  <span v-html="highlightText(text, keyword, caseSensitive)" />
</template>

<style>
.search-highlight {
  background: rgba(255, 199, 0, 0.45);
  color: inherit;
  border-radius: 2px;
  padding: 0 1px;
}
</style>
