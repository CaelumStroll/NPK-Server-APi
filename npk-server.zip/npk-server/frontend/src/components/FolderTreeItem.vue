<script setup lang="ts">
import { ref } from 'vue'
import { Folder, FolderOpened, ArrowRight, ArrowDown } from '@element-plus/icons-vue'

interface FolderNode {
  path: string
  name: string
  count: number
  children: FolderNode[]
}

const props = defineProps<{
  node: FolderNode
  selectedFolder: string
  level?: number
}>()

const emit = defineEmits<{
  select: [path: string]
}>()

const expanded = ref(false)

const hasChildren = props.node.children.length > 0
const indent = (props.level || 0) * 16

function toggleExpand() {
  if (hasChildren) {
    expanded.value = !expanded.value
  }
}

function select() {
  emit('select', props.node.path)
}

function getTotalCount(node: FolderNode): number {
  let count = node.count
  node.children.forEach(child => {
    count += getTotalCount(child)
  })
  return count
}
</script>

<template>
  <div class="folder-tree-item">
    <div
      class="folder-item"
      :class="{ active: selectedFolder === node.path, expandable: hasChildren }"
      :style="{ paddingLeft: `${16 + indent}px` }"
      @click="select"
    >
      <span class="expand-icon" v-if="hasChildren" @click.stop="toggleExpand">
        <el-icon v-if="expanded"><ArrowDown /></el-icon>
        <el-icon v-else><ArrowRight /></el-icon>
      </span>
      <span class="expand-placeholder" v-else></span>
      <el-icon class="folder-icon">
        <FolderOpened v-if="selectedFolder === node.path || expanded" />
        <Folder v-else />
      </el-icon>
      <span class="folder-name">{{ node.name }}</span>
      <span class="folder-count">({{ getTotalCount(node) }})</span>
    </div>
    <div v-if="expanded && hasChildren" class="folder-children">
      <FolderTreeItem
        v-for="child in node.children"
        :key="child.path"
        :node="child"
        :selected-folder="selectedFolder"
        :level="(level || 0) + 1"
        @select="$emit('select', $event)"
      />
    </div>
  </div>
</template>

<style scoped lang="scss">
.folder-tree-item {
  .folder-item {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    cursor: pointer;
    transition: background-color 0.2s;
    border-radius: 4px;
    margin: 2px 0;

    &:hover {
      background-color: var(--el-fill-color-light);
    }

    &.active {
      background-color: var(--el-color-primary-light-9);
      color: var(--el-color-primary);
    }

    .expand-icon,
    .expand-placeholder {
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 4px;
      cursor: pointer;

      &:hover {
        color: var(--el-color-primary);
      }
    }

    .expand-placeholder {
      cursor: default;
    }

    .folder-icon {
      margin-right: 6px;
      font-size: 16px;
    }

    .folder-name {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: 13px;
    }

    .folder-count {
      font-size: 11px;
      color: var(--el-text-color-secondary);
      margin-left: 4px;
    }
  }

  .folder-children {
    margin-left: 0;
  }
}
</style>
