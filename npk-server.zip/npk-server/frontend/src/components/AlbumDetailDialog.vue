<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { albumApi } from '@/api'
import { ElDialog, ElDescriptions, ElDescriptionsItem, ElTag, ElTable, ElTableColumn, ElButton, ElScrollbar } from 'element-plus'
import { InfoFilled } from '@element-plus/icons-vue'

const { t } = useI18n()

const props = defineProps<{
  visible: boolean
  npkName: string
  albumPath: string
}>()

const emit = defineEmits<{
  (e: 'update:visible', val: boolean): void
}>()

const loading = ref(false)
const albumDetail = ref<any>(null)

const dialogVisible = computed({
  get: () => props.visible,
  set: (val) => emit('update:visible', val)
})

watch(() => props.visible, async (val) => {
  if (val && props.npkName && props.albumPath) {
    await loadAlbumDetail()
  }
})

async function loadAlbumDetail() {
  loading.value = true
  try {
    const res = await albumApi.getFrames(props.npkName, props.albumPath)
    albumDetail.value = res.data
  } catch (e) {
    console.error('加载 Album 详情失败:', e)
    albumDetail.value = null
  } finally {
    loading.value = false
  }
}

function getFileTypeLabel(type: number): string {
  switch (type) {
    case 0: return 'IMG'
    case 1: return 'OGG'
    case 2: return 'Other'
    default: return 'Unknown'
  }
}

type TagType = 'primary' | 'success' | 'warning' | 'info' | 'danger' | undefined
function getFileTypeTagType(type: number): TagType {
  switch (type) {
    case 0: return undefined
    case 1: return 'warning'
    case 2: return 'info'
    default: return 'info'
  }
}

function formatSize(bytes: number | string | undefined): string {
  if (bytes === undefined || bytes === null || bytes === '') return '-'
  const num = typeof bytes === 'string' ? parseInt(bytes, 10) : bytes
  if (isNaN(num) || num === 0) return '-'
  if (num < 1024) return num + ' B'
  if (num < 1024 * 1024) return (num / 1024).toFixed(1) + ' KB'
  return (num / 1024 / 1024).toFixed(2) + ' MB'
}

function formatOffset(offset: number | string | undefined): string {
  if (offset === undefined || offset === null || offset === '') return '-'
  const num = typeof offset === 'string' ? parseInt(offset, 10) : offset
  if (isNaN(num) || num === 0) return '-'
  return '0x' + num.toString(16).toUpperCase() + ' (' + formatSize(num) + ')'
}

type RGBAColor = [number, number, number, number]

const paletteTables = computed((): RGBAColor[][] => {
  if (!albumDetail.value?.palette_json) return []
  try {
    return JSON.parse(albumDetail.value.palette_json)
  } catch {
    return []
  }
})

interface DDSInfo {
  index: number
  type: number
  width: number
  height: number
  x: number
  y: number
  rx: number
  ry: number
  top: number
}

const ddsInfoList = computed((): DDSInfo[] => {
  if (!albumDetail.value?.dds_info_json) return []
  try {
    return JSON.parse(albumDetail.value.dds_info_json)
  } catch {
    return []
  }
})

function getDDSTypeLabel(tex: DDSInfo): string {
  switch (tex.type) {
    case 0x12: return 'DXT1'
    case 0x13: return 'DXT3'
    case 0x14: return 'DXT5'
    default: return `0x${tex.type.toString(16)}`
  }
}

const imgVersion = computed(() => {
  const version = albumDetail.value?.version || ''
  const match = version.match(/V(\d+)/)
  return match ? parseInt(match[1]) : 0
})

const hasPalette = computed(() => {
  return imgVersion.value >= 4 && paletteTables.value.length > 0
})

const hasDDS = computed(() => {
  return imgVersion.value === 5 && ddsInfoList.value.length > 0
})

const versionFeatures = computed(() => {
  const v = imgVersion.value
  if (v === 0) return t('albumDetail.unknownVersion')
  if (v <= 3) return t('albumDetail.versionV1V3')
  if (v === 4) return t('albumDetail.versionV4')
  if (v === 5) return t('albumDetail.versionV5')
  if (v === 6) return t('albumDetail.versionV6')
  return t('albumDetail.versionUnknown', { v })
})


</script>

<template>
  <el-dialog
    v-model="dialogVisible"
    :title="t('albumDetail.dialogTitle')"
    width="700px"
    :close-on-click-modal="true"
  >
    <div v-loading="loading">
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item :label="t('albumDetail.albumName')" :span="2">
          {{ albumDetail?.album_name || '-' }}
        </el-descriptions-item>
        <el-descriptions-item :label="t('albumDetail.fullPath')" :span="2">
          <code style="font-size: 11px">{{ albumDetail?.album_path || '-' }}</code>
        </el-descriptions-item>
        <el-descriptions-item :label="t('albumDetail.imgVersion')">
          <el-tag size="small">{{ albumDetail?.version || '-' }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :label="t('albumDetail.frameCount')">
          {{ albumDetail?.total || 0 }}
        </el-descriptions-item>
        <el-descriptions-item :label="t('albumDetail.fileType')">
          <el-tag
            v-if="albumDetail?.file_type !== undefined"
            size="small"
            :type="getFileTypeTagType(albumDetail.file_type)"
          >
            {{ getFileTypeLabel(albumDetail.file_type) }}
          </el-tag>
          <span v-else>-</span>
        </el-descriptions-item>
        <el-descriptions-item :label="t('albumDetail.offset')">
          {{ formatOffset(albumDetail?.offset) }}
        </el-descriptions-item>
        <el-descriptions-item :label="t('albumDetail.fileSize')">
          {{ formatSize(albumDetail?.size) }}
        </el-descriptions-item>
      </el-descriptions>

      <div class="section version-info">
        <el-alert :title="versionFeatures" :type="imgVersion >= 4 ? 'success' : 'info'" :closable="false" show-icon />
      </div>

      <div v-if="hasPalette" class="section">
        <h4 class="section-title">
          <el-icon><InfoFilled /></el-icon>
          {{ t('albumDetail.paletteInfo', { count: paletteTables.length }) }}
        </h4>
        <el-scrollbar max-height="200px">
          <div v-for="(table, tableIdx) in paletteTables" :key="tableIdx" class="palette-section">
            <span class="palette-label">{{ t('albumDetail.paletteTableLabel', { index: tableIdx, count: table.length }) }}</span>
            <div class="palette-grid">
              <div
                v-for="(color, colorIdx) in table"
                :key="colorIdx"
                class="palette-color"
                :style="{
                  backgroundColor: `rgba(${color[0]}, ${color[1]}, ${color[2]}, ${color[3] / 255})`
                }"
                :title="`#${color[0].toString(16).padStart(2, '0')}${color[1].toString(16).padStart(2, '0')}${color[2].toString(16).padStart(2, '0')} A:${color[3]} Index:${colorIdx}`"
              />
            </div>
          </div>
        </el-scrollbar>
      </div>

      <div v-else-if="imgVersion > 0 && imgVersion < 4" class="section">
        <el-alert :title="t('albumDetail.noPaletteInfo')" type="info" :closable="false" />
      </div>

      <div v-if="hasDDS" class="section">
        <h4 class="section-title">
          <el-icon><InfoFilled /></el-icon>
          {{ t('albumDetail.ddsInfo', { count: ddsInfoList.length }) }}
        </h4>
        <el-table :data="ddsInfoList" size="small" stripe max-height="200">
          <el-table-column prop="index" :label="t('albumDetail.index')" width="60" />
          <el-table-column :label="t('albumDetail.ddsType')" width="80">
            <template #default="{ row }">
              <el-tag size="small" type="warning">{{ getDDSTypeLabel(row) }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="width" :label="t('albumDetail.width')" width="70" />
          <el-table-column prop="height" :label="t('albumDetail.height')" width="70" />
          <el-table-column :label="t('albumDetail.coordRange')" min-width="140">
            <template #default="{ row }">
              ({{ row.x }}, {{ row.y }}) - ({{ row.rx }}, {{ row.ry }})
            </template>
          </el-table-column>
          <el-table-column prop="top" label="Top" width="60" />
        </el-table>
      </div>

      <div v-if="!loading && !albumDetail" class="empty-tip">
        {{ t('albumDetail.noDetailData') }}
      </div>
    </div>

    <template #footer>
      <el-button @click="dialogVisible = false">{{ t('common.close') }}</el-button>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.section {
  margin-top: 16px;
  padding-top: 12px;
  border-top: 1px solid var(--border-color);
}

.section-title {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 0 12px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-primary);
}

.palette-section {
  margin-bottom: 12px;

  .palette-label {
    display: block;
    font-size: 12px;
    color: var(--text-secondary);
    margin-bottom: 6px;
  }
}

.palette-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 2px;
}

.palette-color {
  width: 16px;
  height: 16px;
  border: 1px solid rgba(0, 0, 0, 0.2);
  cursor: pointer;
  transition: transform 0.1s;

  &:hover {
    transform: scale(1.3);
    z-index: 1;
  }
}

.empty-tip {
  text-align: center;
  padding: 30px;
  color: var(--text-muted);
  font-size: 13px;
}
</style>
