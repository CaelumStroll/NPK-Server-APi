import { createI18n } from 'vue-i18n'
import zhCN from './zh-CN.json'
import enUS from './en-US.json'

const STORAGE_KEY = 'npk-language'
const BUNDLED_LOCALES = ['zh-CN', 'en-US']

function getDefaultLocale(): string {
  const saved = localStorage.getItem(STORAGE_KEY)
  if (saved) return saved
  const browserLang = navigator.language
  if (browserLang.startsWith('zh')) return 'zh-CN'
  return 'en-US'
}

const i18n = createI18n({
  legacy: false,
  locale: getDefaultLocale(),
  fallbackLocale: 'zh-CN',
  messages: {
    'zh-CN': zhCN,
    'en-US': enUS
  }
})

export async function loadLanguageFromApi(locale: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/language/${locale}`)
    if (!res.ok) return false
    const messages = await res.json()
    ;(i18n.global as any).setLocaleMessage(locale, messages)
    return true
  } catch {
    return false
  }
}

export async function fetchAvailableLanguages(): Promise<string[]> {
  try {
    const res = await fetch('/api/language/list')
    if (!res.ok) return BUNDLED_LOCALES
    const data = await res.json()
    return data.data || BUNDLED_LOCALES
  } catch {
    return BUNDLED_LOCALES
  }
}

export async function setLanguage(locale: string) {
  if (!BUNDLED_LOCALES.includes(locale)) {
    const loaded = await loadLanguageFromApi(locale)
    if (!loaded) return
  }
  ;(i18n.global.locale as any).value = locale
  localStorage.setItem(STORAGE_KEY, locale)
  document.documentElement.setAttribute('lang', locale.startsWith('zh') ? 'zh-CN' : 'en')
  try {
    await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ language: locale })
    })
  } catch {
    // silent
  }
}

export function getLanguage(): string {
  return (i18n.global.locale as any).value
}

export async function initLanguage() {
  let locale = getDefaultLocale()
  try {
    const res = await fetch('/api/settings')
    if (res.ok) {
      const json = await res.json()
      const data = json.data || json
      if (data.language) {
        locale = data.language
        localStorage.setItem(STORAGE_KEY, locale)
      }
    }
  } catch {
    // use localStorage fallback
  }
  if (!BUNDLED_LOCALES.includes(locale)) {
    const loaded = await loadLanguageFromApi(locale)
    if (!loaded) {
      locale = 'zh-CN'
    }
  }
  ;(i18n.global.locale as any).value = locale
  document.documentElement.setAttribute('lang', locale.startsWith('zh') ? 'zh-CN' : 'en')
}

export default i18n
