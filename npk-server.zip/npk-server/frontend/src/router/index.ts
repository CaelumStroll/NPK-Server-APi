import { createRouter, createWebHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'
import i18n from '@/language'

const routes: RouteRecordRaw[] = [
  { path: '/', name: 'Dashboard', component: () => import('@/views/Dashboard.vue'), meta: { titleKey: 'router.dashboard' } },
  { path: '/npk', name: 'NpkManager', component: () => import('@/views/NpkManager.vue'), meta: { titleKey: 'router.npkManager' } },
  { path: '/browser', name: 'ImgBrowser', component: () => import('@/views/ImgBrowser.vue'), meta: { titleKey: 'router.imgResources' } },
  { path: '/animation', name: 'AnimationPlayer', component: () => import('@/views/AnimationPlayer.vue'), meta: { titleKey: 'router.animationPlayer' } },
  { path: '/preview', name: 'ImgPreview', component: () => import('@/views/ImgPreview.vue'), meta: { titleKey: 'router.imgEdit' } },
  { path: '/library', name: 'ImgDuplicate', component: () => import('@/views/ImgDuplicate.vue'), meta: { titleKey: 'router.imgDuplicate' } },
  { path: '/batch', name: 'BatchExport', component: () => import('@/views/BatchExport.vue'), meta: { titleKey: 'router.batchExport' } },
  { path: '/database', name: 'DatabaseView', component: () => import('@/views/DatabaseView.vue'), meta: { titleKey: 'router.database' } },
  { path: '/videos', name: 'VideoManager', component: () => import('@/views/VideoManager.vue'), meta: { titleKey: 'router.videoManager' } },
  { path: '/soundpacks', name: 'SoundPackManager', component: () => import('@/views/SoundPackManager.vue'), meta: { titleKey: 'router.soundpackManager' } },
  { path: '/music', name: 'MusicManager', component: () => import('@/views/MusicManager.vue'), meta: { titleKey: 'router.musicManager' } },
  { path: '/xml-editor', name: 'XmlAudioEditor', component: () => import('@/views/XmlAudioEditor.vue'), meta: { titleKey: 'router.xmlAudioEditor' } },
  { path: '/api-debug', name: 'ApiDebug', component: () => import('@/views/ApiDebug.vue'), meta: { titleKey: 'router.apiDebug' } },
  { path: '/tools', name: 'Tools', component: () => import('@/views/Tools.vue'), meta: { titleKey: 'router.tools' } },
  { path: '/logs', name: 'LogView', component: () => import('@/views/LogView.vue'), meta: { titleKey: 'router.logs' } },
  { path: '/settings', name: 'Settings', component: () => import('@/views/Settings.vue'), meta: { titleKey: 'router.settings' } },
  { path: '/docs', name: 'DocView', component: () => import('@/views/DocView.vue'), meta: { titleKey: 'router.docCenter' } },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, _from, next) => {
  const t = (i18n.global as any).t
  const titleKey = to.meta.titleKey as string
  const title = titleKey ? t(titleKey) : t('router.defaultTitle')
  document.title = `${title} - NPK Manager`
  next()
})

export default router
