import i18n from '@/language'

const t = (i18n.global as any).t

export interface DocCategory {
  id: string
  name: string
  icon: string
  docs: DocItem[]
}

export interface DocItem {
  id: string
  title: string
  file: string
  description?: string
}

export function getDocCategories(): DocCategory[] {
  return [
    {
      id: 'guide',
      name: t('docs.categories.guide'),
      icon: 'Guide',
      docs: [
        {
          id: 'quick-start',
          title: t('docs.items.quickStart'),
          file: 'README.md',
          description: t('docs.items.quickStartDesc')
        }
      ]
    },
    {
      id: 'architecture',
      name: t('docs.categories.architecture'),
      icon: 'Box',
      docs: [
        {
          id: 'architecture',
          title: t('docs.items.systemArch'),
          file: 'ARCHITECTURE.md',
          description: t('docs.items.systemArchDesc')
        },
        {
          id: 'document-model',
          title: t('docs.items.documentModel'),
          file: 'DOCUMENT_MEMORY_MODEL.md',
          description: t('docs.items.documentModelDesc')
        },
        {
          id: 'img-cache',
          title: t('docs.items.imgCache'),
          file: 'IMG_CACHE.md',
          description: t('docs.items.imgCacheDesc')
        }
      ]
    },
    {
      id: 'development',
      name: t('docs.categories.development'),
      icon: 'Edit',
      docs: [
        {
          id: 'img-editor-dev',
          title: t('docs.items.imgEditorDev'),
          file: 'IMG_EDITOR_DEV_GUIDE.md',
          description: t('docs.items.imgEditorDevDesc')
        },
        {
          id: 'database-design',
          title: t('docs.items.dbDesign'),
          file: 'DATABASE_DESIGN_DISCUSSION.md',
          description: t('docs.items.dbDesignDesc')
        }
      ]
    },
    {
      id: 'research',
      name: t('docs.categories.research'),
      icon: 'Search',
      docs: [
        {
          id: 'npk-encryption',
          title: t('docs.items.npkEncryption'),
          file: 'NPK_ENCRYPTION_RESEARCH.md',
          description: t('docs.items.npkEncryptionDesc')
        },
        {
          id: 'v5-dds-fix',
          title: t('docs.items.v5DdsFix'),
          file: 'V5_DDS_FIX.md',
          description: t('docs.items.v5DdsFixDesc')
        }
      ]
    },
    {
      id: 'changelog',
      name: t('docs.categories.changelog'),
      icon: 'Clock',
      docs: [
        {
          id: 'todo',
          title: t('docs.items.todo'),
          file: 'TODO.md',
          description: t('docs.items.todoDesc')
        }
      ]
    }
  ]
}



export function getDocById(id: string): DocItem | null {
  for (const category of getDocCategories()) {
    const doc = category.docs.find(d => d.id === id)
    if (doc) return doc
  }
  return null
}
