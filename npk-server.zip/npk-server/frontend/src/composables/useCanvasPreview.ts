import { ref, watch } from 'vue'
import { renderImageToCanvas } from '@/utils/canvas'

export function useCanvasPreview() {
  const previewCanvas = ref<HTMLCanvasElement | null>(null)
  const previewUrl = ref('')
  const removeBlackBg = ref(false)
  const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto')
  let currentRenderCancel: (() => void) | null = null

  async function renderToCanvas(url: string, removeBlack: boolean) {
    const canvas = previewCanvas.value
    if (!canvas) return
    if (currentRenderCancel) currentRenderCancel()
    try {
      const { promise, cancel } = renderImageToCanvas(canvas, url, removeBlack)
      currentRenderCancel = cancel
      await promise
      currentRenderCancel = null
    } catch {
      previewUrl.value = ''
      currentRenderCancel = null
    }
  }

  function toggleCanvasBgMode() {
    if (canvasBgMode.value === 'auto') canvasBgMode.value = 'light'
    else if (canvasBgMode.value === 'light') canvasBgMode.value = 'dark'
    else canvasBgMode.value = 'light'
  }

  watch(removeBlackBg, (newVal) => {
    if (previewUrl.value) renderToCanvas(previewUrl.value, newVal)
  })

  return {
    previewCanvas,
    previewUrl,
    removeBlackBg,
    canvasBgMode,
    renderToCanvas,
    toggleCanvasBgMode,
  }
}
