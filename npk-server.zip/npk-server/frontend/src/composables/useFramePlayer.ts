import { ref, type Ref } from 'vue'

export const PLAY_INTERVAL = 200

export function useFramePlayer(
  frameList: Ref<any[]>,
  onFrameSelect: (index: number) => void,
) {
  const isPlaying = ref(false)
  const selectedFrameIndex = ref(0)
  let playTimer: ReturnType<typeof setInterval> | null = null

  function startFramePlay() {
    if (frameList.value.length === 0) return
    isPlaying.value = true
    playTimer = setInterval(() => {
      const next = (selectedFrameIndex.value + 1) % frameList.value.length
      selectedFrameIndex.value = next
      onFrameSelect(next)
    }, PLAY_INTERVAL)
  }

  function stopFramePlay() {
    isPlaying.value = false
    if (playTimer) {
      clearInterval(playTimer)
      playTimer = null
    }
  }

  function toggleFramePlay() {
    if (isPlaying.value) stopFramePlay()
    else startFramePlay()
  }

  return {
    isPlaying,
    selectedFrameIndex,
    startFramePlay,
    stopFramePlay,
    toggleFramePlay,
  }
}
