import { ref, onUnmounted } from 'vue'
import i18n from '@/language'

const t = (i18n.global as any).t

export type WsMessageHandler = (data: any) => void

export interface WsConnection {
  id: string
  url: string
  ws: WebSocket | null
  connected: boolean
  reconnectTimer: ReturnType<typeof setTimeout> | null
  heartbeatTimer: ReturnType<typeof setInterval> | null
  lastHeartbeat: number
  error: string | null
  handlers: Set<WsMessageHandler>
}

export interface WebSocketPoolOptions {
  heartbeatInterval?: number // 心跳间隔（毫秒），默认 30000
  heartbeatTimeout?: number // 心跳超时（毫秒），默认 10000
  maxReconnectAttempts?: number // 最大重连次数，默认 5
  reconnectDelay?: number // 重连延迟（毫秒），默认 3000
  autoReconnect?: boolean // 是否自动重连，默认 true
}

const defaultOptions: Required<WebSocketPoolOptions> = {
  heartbeatInterval: 30000,
  heartbeatTimeout: 10000,
  maxReconnectAttempts: 5,
  reconnectDelay: 3000,
  autoReconnect: true,
}

class WebSocketPool {
  private connections: Map<string, WsConnection> = new Map()
  private options: Required<WebSocketPoolOptions>
  private reconnectAttempts: Map<string, number> = new Map()

  constructor(options: WebSocketPoolOptions = {}) {
    this.options = { ...defaultOptions, ...options }
  }

  getConnection(id: string): WsConnection | undefined {
    return this.connections.get(id)
  }

  getAllConnections(): WsConnection[] {
    return Array.from(this.connections.values())
  }

  getConnectedCount(): number {
    return this.getAllConnections().filter(c => c.connected).length
  }

  connect(id: string, url: string): WsConnection {
    let connection = this.connections.get(id)
    if (connection) {
      if (connection.ws && (connection.ws.readyState === WebSocket.CONNECTING || connection.ws.readyState === WebSocket.OPEN)) {
        return connection
      }
      this.disconnect(id)
    }

    connection = {
      id,
      url,
      ws: null,
      connected: false,
      reconnectTimer: null,
      heartbeatTimer: null,
      lastHeartbeat: 0,
      error: null,
      handlers: new Set(),
    }

    this.connections.set(id, connection)
    this.reconnectAttempts.set(id, 0)
    this.createConnection(connection)

    return connection
  }

  private createConnection(connection: WsConnection) {
    const { id, url } = connection

    console.log(`[WebSocketPool] Connecting ${id} to:`, url)
    const ws = new WebSocket(url)
    connection.ws = ws

    ws.onopen = () => {
      connection.connected = true
      connection.error = null
      connection.lastHeartbeat = Date.now()
      console.log(`[WebSocketPool] ${id} connected`)
      this.startHeartbeat(connection)
    }

    ws.onmessage = (event) => {
      connection.lastHeartbeat = Date.now()
      try {
        const data = JSON.parse(event.data)
        connection.handlers.forEach(handler => {
          try {
            handler(data)
          } catch (e) {
            console.error(`[WebSocketPool] Handler error for ${id}:`, e)
          }
        })
      } catch (e) {
        console.error(`[WebSocketPool] Parse error for ${id}:`, e)
      }
    }

    ws.onclose = (e) => {
      connection.connected = false
      console.log(`[WebSocketPool] ${id} closed:`, e.code, e.reason)
      this.stopHeartbeat(connection)
      this.handleReconnect(connection)
    }

    ws.onerror = (e) => {
      connection.error = t('store.websocket.connectionFailed')
      console.error(`[WebSocketPool] ${id} error:`, e)
    }
  }

  private startHeartbeat(connection: WsConnection) {
    this.stopHeartbeat(connection)

    const { heartbeatInterval } = this.options
    connection.heartbeatTimer = setInterval(() => {
      if (connection.ws && connection.ws.readyState === WebSocket.OPEN) {
        const timeSinceLastHeartbeat = Date.now() - connection.lastHeartbeat
        if (timeSinceLastHeartbeat > this.options.heartbeatTimeout) {
          console.warn(`[WebSocketPool] ${connection.id} heartbeat timeout, reconnecting...`)
          connection.ws.close()
        } else {
          connection.ws.send(JSON.stringify({ type: 'ping' }))
        }
      }
    }, heartbeatInterval)
  }

  private stopHeartbeat(connection: WsConnection) {
    if (connection.heartbeatTimer) {
      clearInterval(connection.heartbeatTimer)
      connection.heartbeatTimer = null
    }
  }

  private handleReconnect(connection: WsConnection) {
    if (!this.options.autoReconnect) return

    const attempts = this.reconnectAttempts.get(connection.id) || 0
    if (attempts >= this.options.maxReconnectAttempts) {
      console.error(`[WebSocketPool] ${connection.id} max reconnect attempts reached`)
      connection.error = t('store.websocket.maxReconnectFailed', { count: attempts })
      return
    }

    this.reconnectAttempts.set(connection.id, attempts + 1)
    console.log(`[WebSocketPool] ${connection.id} reconnecting in ${this.options.reconnectDelay}ms (attempt ${attempts + 1}/${this.options.maxReconnectAttempts})`)

    connection.reconnectTimer = setTimeout(() => {
      if (connection.connected) return
      this.createConnection(connection)
    }, this.options.reconnectDelay)
  }

  disconnect(id: string) {
    const connection = this.connections.get(id)
    if (!connection) return

    if (connection.reconnectTimer) {
      clearTimeout(connection.reconnectTimer)
      connection.reconnectTimer = null
    }

    this.stopHeartbeat(connection)

    if (connection.ws) {
      connection.ws.onclose = null
      connection.ws.close()
      connection.ws = null
    }

    connection.connected = false
    this.connections.delete(id)
    this.reconnectAttempts.delete(id)
  }

  disconnectAll() {
    for (const id of this.connections.keys()) {
      this.disconnect(id)
    }
  }

  onMessage(id: string, handler: WsMessageHandler): () => void {
    const connection = this.connections.get(id)
    if (!connection) {
      console.warn(`[WebSocketPool] Connection ${id} not found`)
      return () => {}
    }

    connection.handlers.add(handler)
    return () => {
      connection.handlers.delete(handler)
    }
  }

  send(id: string, data: any) {
    const connection = this.connections.get(id)
    if (!connection || !connection.ws || connection.ws.readyState !== WebSocket.OPEN) {
      console.warn(`[WebSocketPool] Cannot send to ${id}: not connected`)
      return false
    }

    try {
      connection.ws.send(JSON.stringify(data))
      return true
    } catch (e) {
      console.error(`[WebSocketPool] Send error for ${id}:`, e)
      return false
    }
  }

  reconnect(id: string) {
    const connection = this.connections.get(id)
    if (!connection) return

    this.reconnectAttempts.set(id, 0)
    this.disconnect(id)
    this.connect(id, connection.url)
  }

  reconnectAll() {
    for (const [id, connection] of this.connections.entries()) {
      this.reconnectAttempts.set(id, 0)
      this.disconnect(id)
      this.connect(id, connection.url)
    }
  }
}

const pool = new WebSocketPool()

export function useWebSocketPool() {
  const connections = ref(pool.getAllConnections())
  const connectedCount = ref(pool.getConnectedCount())

  const updateConnections = () => {
    connections.value = pool.getAllConnections()
    connectedCount.value = pool.getConnectedCount()
  }

  return {
    pool,
    connections,
    connectedCount,
    updateConnections,
  }
}

export interface SystemStats {
  cpu_percent: number
  mem_percent: number
  mem_used: number
  mem_total: number
  disk_percent: number
  disk_used: number
  disk_total: number
  goroutines: number
  heap_alloc_mb: number
  heap_sys_mb: number
  uptime_seconds: number
  cache_count?: number
  cache_used_mb?: number
  cache_percent?: number
  cache_hit_rate?: number
  cache_hits?: number
  cache_misses?: number
  cache_max_size?: number
  img_cache?: any
}

export function useSystemWebSocket() {
  const stats = ref<SystemStats>({
    cpu_percent: 0,
    mem_percent: 0,
    mem_used: 0,
    mem_total: 0,
    disk_percent: 0,
    disk_used: 0,
    disk_total: 0,
    goroutines: 0,
    heap_alloc_mb: 0,
    heap_sys_mb: 0,
    uptime_seconds: 0,
  })

  const connected = ref(false)
  const error = ref<string | null>(null)

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const host = window.location.host
  const url = `${protocol}//${host}/ws/system`

  const connection = pool.connect('system-stats', url)

  const handleMessage = (data: any) => {
    if (data.type === 'system_stats' && data.payload) {
      stats.value = { ...stats.value, ...data.payload }
    } else if (data.type === 'pong') {
      connection.lastHeartbeat = Date.now()
    }
  }

  pool.onMessage('system-stats', handleMessage)

  connected.value = connection.connected
  error.value = connection.error

  const updateConnectionStatus = () => {
    const conn = pool.getConnection('system-stats')
    if (conn) {
      connected.value = conn.connected
      error.value = conn.error
    }
  }

  setInterval(updateConnectionStatus, 1000)

  onUnmounted(() => {
    pool.disconnect('system-stats')
  })

  return {
    stats,
    connected,
    error,
    reconnect: () => pool.reconnect('system-stats'),
    disconnect: () => pool.disconnect('system-stats'),
  }
}

export default pool
