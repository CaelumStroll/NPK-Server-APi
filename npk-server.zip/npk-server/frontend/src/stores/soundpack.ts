import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { soundpackApi } from '@/api'
import type { SoundPackFile, SoundPackStats } from '@/types'

export { type SoundPackFile, type SoundPackEntry, type SoundPackStats } from '@/types'

export const useSoundPackStore = defineStore('soundpack', () => {
  const soundpacks = ref<SoundPackFile[]>([])
  const stats = ref<SoundPackStats>({
    total_count: 0,
    total_size: 0,
    total_ogg_count: 0,
  })
  const loading = ref(false)
  const error = ref<string | null>(null)

  const totalCount = computed(() => stats.value.total_count)
  const totalSize = computed(() => stats.value.total_size)
  const totalOggCount = computed(() => stats.value.total_ogg_count)

  async function fetchSoundPacks() {
    loading.value = true
    error.value = null
    try {
      const res = await soundpackApi.list() as any
      soundpacks.value = res.data?.items || res.data || []
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function fetchStats() {
    try {
      const res = await soundpackApi.getStats() as any
      stats.value = res.data || {
        total_count: 0,
        total_size: 0,
        total_ogg_count: 0,
      }
    } catch (e: any) {
      console.warn('[soundpackStore] 获取统计失败:', e)
    }
  }

  async function scanSoundPacks(dir?: string) {
    loading.value = true
    error.value = null
    try {
      await soundpackApi.scan(dir)
      await Promise.all([fetchSoundPacks(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function deleteSoundPack(id: number) {
    try {
      await soundpackApi.delete(id)
      await Promise.all([fetchSoundPacks(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  return {
    soundpacks,
    stats,
    loading,
    error,
    totalCount,
    totalSize,
    totalOggCount,
    fetchSoundPacks,
    fetchStats,
    scanSoundPacks,
    deleteSoundPack,
  }
})
