import { defineStore } from 'pinia'
import { ref, watch, onMounted } from 'vue'

export type ThemeMode = 'system' | 'light' | 'dark'

export const useThemeStore = defineStore('theme', () => {
  // State - 默认跟随系统
  const themeMode = ref<ThemeMode>('system')
  const isDark = ref(false)

  // 检测系统主题
  function detectSystemTheme(): boolean {
    return window.matchMedia('(prefers-color-scheme: dark)').matches
  }

  // 应用主题到 DOM
  function applyTheme(dark: boolean) {
    isDark.value = dark
    const html = document.documentElement
    if (dark) {
      html.classList.add('dark')
      html.classList.remove('light')
    } else {
      html.classList.add('light')
      html.classList.remove('dark')
    }
  }

  // 根据当前模式更新主题
  function updateTheme() {
    if (themeMode.value === 'system') {
      applyTheme(detectSystemTheme())
    } else {
      applyTheme(themeMode.value === 'dark')
    }
  }

  // 设置主题模式
  function setThemeMode(mode: ThemeMode) {
    themeMode.value = mode
    updateTheme()
    // 保存到 localStorage
    localStorage.setItem('theme-mode', mode)
  }

  // 切换手动模式（用于滑动开关）
  function toggleTheme() {
    if (themeMode.value === 'system') {
      // 如果当前是跟随系统，切换到与当前系统相反的手动模式
      setThemeMode(detectSystemTheme() ? 'light' : 'dark')
    } else {
      // 切换 light/dark
      setThemeMode(themeMode.value === 'dark' ? 'light' : 'dark')
    }
  }

  // 初始化
  onMounted(() => {
    // 从 localStorage 读取保存的主题
    const saved = localStorage.getItem('theme-mode') as ThemeMode | null
    if (saved && ['system', 'light', 'dark'].includes(saved)) {
      themeMode.value = saved
    }
    updateTheme()

    // 监听系统主题变化
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    mediaQuery.addEventListener('change', (e) => {
      if (themeMode.value === 'system') {
        applyTheme(e.matches)
      }
    })
  })

  // 监听模式变化
  watch(themeMode, updateTheme)

  return {
    themeMode,
    isDark,
    setThemeMode,
    toggleTheme,
    updateTheme,
    detectSystemTheme
  }
})
