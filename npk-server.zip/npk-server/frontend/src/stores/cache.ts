import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

// 内存条目
export interface MemoryEntry {
  source: string        // 来源：'AnimationPlayer', 'ImgEditor', etc.
  category: string      // 类别：'npk_list', 'album_list', 'frames', etc.
  key: string           // 缓存键
  size: number          // 估算字节数
  timestamp: number     // 最后访问时间
  name: string          // 显示名称
}

// NPK 列表缓存条目（持久化）
export interface NpkListCacheItem {
  name: string
  path: string
  size: number
  modified: string // ISO 时间字符串
  img_count?: number
  format_type?: number
  encryption_verified?: boolean
  _cacheUpdatedAt: number // 本地缓存时间戳
}

export interface NpkListCache {
  version: number
  updatedAt: number
  items: NpkListCacheItem[]
}

// 内存限制
const MEMORY_LIMIT = 500 * 1024 * 1024 // 500MB
const CACHE_VERSION = 1
const STORAGE_KEY_NPK_LIST = 'npk_manager:npk_list_cache'

export const useCacheStore = defineStore('cache', () => {
  // 所有内存条目
  const entries = ref<Map<string, MemoryEntry>>(new Map())

  // NPK 列表缓存数据
  const npkListCacheData = ref<Map<string, any[]>>(new Map())

  // Album 缓存数据
  const albumCacheData = ref<Map<string, any[]>>(new Map())

  // === 持久化工具 ===

  // 从 localStorage 加载 NPK 列表缓存
  function loadNpkListFromStorage(): NpkListCache | null {
    try {
      const data = localStorage.getItem(STORAGE_KEY_NPK_LIST)
      if (!data) return null
      const parsed = JSON.parse(data)
      
      // 检查版本和过期时间（7天过期）
      if (parsed.version !== CACHE_VERSION) return null
      const maxAge = 7 * 24 * 60 * 60 * 1000 // 7天
      if (Date.now() - parsed.updatedAt > maxAge) {
        console.log('[cache] NPK 列表缓存已过期，将重新获取')
        clearNpkListFromStorage()
        return null
      }
      
      return parsed
    } catch {
      return null
    }
  }

  // 保存 NPK 列表缓存到 localStorage
  function saveNpkListToStorage(items: any[]) {
    try {
      const cache: NpkListCache = {
        version: CACHE_VERSION,
        updatedAt: Date.now(),
        items: items.map(item => ({
          ...item,
          _cacheUpdatedAt: Date.now()
        }))
      }
      localStorage.setItem(STORAGE_KEY_NPK_LIST, JSON.stringify(cache))
    } catch (e) {
      console.warn('[缓存] 保存到 localStorage 失败:', e)
    }
  }

  // 清除 localStorage NPK 列表缓存
  function clearNpkListFromStorage() {
    try {
      localStorage.removeItem(STORAGE_KEY_NPK_LIST)
    } catch (e) {
      console.warn('[缓存] 清除 localStorage 失败:', e)
    }
  }

  // 计算两个 NPK 列表的差异
  function diffNpkLists(oldList: NpkListCacheItem[], newList: any[]) {
    const oldMap = new Map(oldList.map(item => [item.name, item]))
    const newMap = new Map(newList.map(item => [item.name, item]))

    const added: any[] = []
    const modified: any[] = []
    const removed: string[] = []

    // 查找新增和修改
    for (const item of newList) {
      const oldItem = oldMap.get(item.name)
      if (!oldItem) {
        added.push(item)
      } else {
        // 判断是否修改：比较 modified 时间和 size
        const oldModified = new Date(oldItem.modified).getTime()
        const newModified = new Date(item.modified).getTime()
        if (oldModified !== newModified || oldItem.size !== item.size) {
          modified.push(item)
        }
      }
    }

    // 查找删除
    for (const oldItem of oldList) {
      if (!newMap.has(oldItem.name)) {
        removed.push(oldItem.name)
      }
    }

    return { added, modified, removed, hasChanges: added.length > 0 || modified.length > 0 || removed.length > 0 }
  }

  // === NPK 列表缓存 ===

  function getNpkListCache(): any[] | null {
    // 优先从内存获取
    const memCache = npkListCacheData.value.get('all')
    if (memCache) return memCache
    
    // 从 localStorage 获取
    const storageCache = loadNpkListFromStorage()
    if (storageCache) {
      npkListCacheData.value.set('all', storageCache.items)
      return storageCache.items
    }
    return null
  }

  function getNpkListCacheMeta(): { updatedAt: number | null } {
    const storageCache = loadNpkListFromStorage()
    return { updatedAt: storageCache?.updatedAt || null }
  }

  function setNpkListCache(list: any[]) {
    const key = 'npk_list_all'
    const size = list.length * 500 // 估算每个 NPK 项约 500 bytes
    track('NpkList', 'npk_list', key, size, `NPK List (${list.length})`)
    npkListCacheData.value.set('all', list)
    // 同时保存到 localStorage
    saveNpkListToStorage(list)
  }

  function updateNpkListCacheIncremental(freshList: any[]) {
    const currentList = getNpkListCache() || []
    const oldList = currentList.map(item => ({
      ...item,
      _cacheUpdatedAt: Date.now()
    }))
    
    const { added, modified, removed, hasChanges } = diffNpkLists(oldList, freshList)
    
    if (hasChanges) {
      // 构建新列表
      const itemMap = new Map()
      
      // 先添加修改的项
      for (const item of modified) {
        itemMap.set(item.name, item)
      }
      
      // 再添加新增的项
      for (const item of added) {
        itemMap.set(item.name, item)
      }
      
      // 保留未删除的旧项
      const newNameSet = new Set(freshList.map(item => item.name))
      for (const item of oldList) {
        if (newNameSet.has(item.name) && !itemMap.has(item.name)) {
          itemMap.set(item.name, item)
        }
      }
      
      const finalList = Array.from(itemMap.values())
      
      // 按名称排序保持一致
      finalList.sort((a, b) => a.name.localeCompare(b.name))
      
      // 更新缓存
      setNpkListCache(finalList)
      
      return { updated: finalList, added, modified, removed }
    }
    
    return { updated: currentList, added: [], modified: [], removed: [] }
  }

  function clearNpkListCache() {
    npkListCacheData.value.clear()
    clearNpkListFromStorage()
    untrack('NpkList', 'npk_list_all')
  }

  // === Album 列表缓存 ===

  function getAlbumListCache(npkName: string): any[] | null {
    const cached = albumCacheData.value.get(npkName)
    if (cached) {
      touch('AlbumList', `album_list_${npkName}`)
    }
    return cached || null
  }

  function setAlbumListCache(npkName: string, list: any[]) {
  // 如果接近内存限制，先清理旧缓存
  if (memoryUsedMB.value > 300) {
    cleanupOldAlbumCaches()
  }
  
  const key = `album_list_${npkName}`
  const size = list.length * 300 // 估算每个 Album 项约 300 bytes
  track('AlbumList', 'album_list', key, size, `${npkName} Albums (${list.length})`)
  albumCacheData.value.set(npkName, list)
}
  
  // 清理旧的 Album 缓存（LRU 策略）
  function cleanupOldAlbumCaches() {
    const entriesArray = Array.from(entries.value.entries())
      .filter(([key]) => key.startsWith('AlbumList:'))
      .sort((a, b) => a[1].timestamp - b[1].timestamp) // 按时间排序，最旧的在前
    
    // 保留最近使用的 10 个，清理其余的
    const toKeep = new Set(entriesArray.slice(-10).map(([key]) => key))
    
    for (const [key, entry] of entriesArray) {
      if (!toKeep.has(key)) {
        const npkName = entry.key.replace('album_list_', '')
        albumCacheData.value.delete(npkName)
        entries.value.delete(key)
        console.log(`[cache] 清理旧 Album 缓存: ${entry.name}`)
      }
    }
  }

  function clearAlbumListCache(npkName?: string) {
    if (npkName) {
      albumCacheData.value.delete(npkName)
      untrack('AlbumList', `album_list_${npkName}`)
    } else {
      albumCacheData.value.clear()
      for (const key of entries.value.keys()) {
        if (key.startsWith('AlbumList:album_list_')) {
          entries.value.delete(key)
        }
      }
    }
  }

  // 计算属性
  const memoryUsedMB = computed(() => {
    let total = 0
    entries.value.forEach(entry => { total += entry.size })
    return total / 1024 / 1024
  })

  const memoryLimitMB = computed(() => MEMORY_LIMIT / 1024 / 1024)

  const memoryUsedPercent = computed(() => {
    return Math.round((memoryUsedMB.value / memoryLimitMB.value) * 100)
  })

  // 按来源分组的内存使用
  const memoryBySource = computed(() => {
    const sources: Record<string, { name: string; size: number; count: number }> = {}
    entries.value.forEach(entry => {
      if (!sources[entry.source]) {
        sources[entry.source] = { name: entry.source, size: 0, count: 0 }
      }
      sources[entry.source].size += entry.size
      sources[entry.source].count++
    })
    return Object.values(sources)
  })

  // 按类别分组的内存使用
  const memoryByCategory = computed(() => {
    const categories: Record<string, { name: string; size: number; count: number }> = {}
    entries.value.forEach(entry => {
      if (!categories[entry.category]) {
        categories[entry.category] = { name: entry.category, size: 0, count: 0 }
      }
      categories[entry.category].size += entry.size
      categories[entry.category].count++
    })
    return Object.values(categories)
  })

  // 生成唯一键
  function makeKey(source: string, key: string): string {
    return `${source}:${key}`
  }

  // 追踪内存
  function track(source: string, category: string, key: string, size: number, name: string) {
    const fullKey = makeKey(source, key)
    entries.value.set(fullKey, {
      source,
      category,
      key,
      size,
      timestamp: Date.now(),
      name
    })
  }

  // 取消追踪
  function untrack(source: string, key?: string) {
    if (key) {
      entries.value.delete(makeKey(source, key))
    } else {
      // 取消该来源的所有追踪
      for (const k of entries.value.keys()) {
        if (k.startsWith(source + ':')) {
          entries.value.delete(k)
        }
      }
    }
  }

  // 更新访问时间
  function touch(source: string, key: string) {
    const fullKey = makeKey(source, key)
    const entry = entries.value.get(fullKey)
    if (entry) {
      entry.timestamp = Date.now()
    }
  }

  // 检查限制并自动释放
  function checkLimit() {
    let total = memoryUsedMB.value * 1024 * 1024
    if (total <= MEMORY_LIMIT) return

    // 按时间排序
    const sorted = Array.from(entries.value.values())
      .sort((a, b) => a.timestamp - b.timestamp)

    while (total > MEMORY_LIMIT && sorted.length > 0) {
      const oldest = sorted.shift()!
      entries.value.delete(makeKey(oldest.source, oldest.key))
      total -= oldest.size
      console.log(`[缓存管理] 释放: ${oldest.source} - ${oldest.name} (节省 ${(oldest.size / 1024 / 1024).toFixed(1)}MB)`)
    }
  }

  // 获取指定来源的条目
  function getEntries(source: string): MemoryEntry[] {
    const result: MemoryEntry[] = []
    entries.value.forEach(entry => {
      if (entry.source === source) {
        result.push(entry)
      }
    })
    return result
  }

  // 清理
  function clear(source?: string) {
    if (source) {
      untrack(source)
    } else {
      entries.value.clear()
    }
  }
  
  // 全局清理（保留 NPK 列表缓存）
  function clearAllExceptNpkList() {
    // 清理内存中的 Album 缓存
    albumCacheData.value.clear()
    
    // 清理 entries 中的非 NpkList 条目
    const npkListKeys = new Set<string>()
    for (const [key] of entries.value) {
      if (key.startsWith('NpkList:')) {
        npkListKeys.add(key)
      }
    }
    
    for (const [key] of entries.value) {
      if (!npkListKeys.has(key)) {
        entries.value.delete(key)
      }
    }
    
    console.log('[cache] 全局缓存清理完成（保留 NPK 列表）')
  }

  return {
    // 状态
    entries,
    
    // 计算属性
    memoryUsedMB,
    memoryLimitMB,
    memoryUsedPercent,
    memoryBySource,
    memoryByCategory,
    
    // 方法
    track,
    untrack,
    touch,
    checkLimit,
    getEntries,
    clear,
    clearAllExceptNpkList,
    cleanupOldAlbumCaches,
    // 缓存辅助方法
    getNpkListCache,
    setNpkListCache,
    updateNpkListCacheIncremental,
    getNpkListCacheMeta,
    clearNpkListCache,
    getAlbumListCache,
    setAlbumListCache,
    clearAlbumListCache
  }
})
