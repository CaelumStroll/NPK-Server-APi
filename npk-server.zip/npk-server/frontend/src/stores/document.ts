// Document Store - 新的 IMG 编辑内存模型
// 基于 ExtractorSharp 设计，支持 Ver1/2/4/5/6 版本

import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { ElMessage } from 'element-plus'
import { npkApi, albumApi, assetApi, imgCacheApi } from '@/api'
import i18n from '@/language'

const t = (i18n.global as any).t

// ========== 类型定义 ==========

export type ImgVersion = 1 | 2 | 4 | 5 | 6

export type ColorBits =
  | 0x0e  // ARGB_1555
  | 0x0f  // ARGB_4444
  | 0x10  // ARGB_8888
  | 0x11  // LINK
  | 0x12  // DXT_1
  | 0x13  // DXT_3
  | 0x14  // DXT_5

export type CompressMode =
  | 0x05  // NONE
  | 0x06  // ZLIB
  | 0x07  // DDS_ZLIB

export interface Point {
  x: number
  y: number
}

export interface TextureRect {
  leftUp: Point
  rightDown: Point
  top: number
}

export interface Sprite {
	// 基础信息
	index: number
	type: ColorBits
	typeName: string

	// 几何信息
	x: number
	y: number
	originalX?: number // 保存原始坐标
	originalY?: number // 保存原始坐标
	width: number
	height: number
	frameWidth: number
	frameHeight: number

	// 压缩与数据
	compressMode: CompressMode
	length: number
	data?: Uint8Array // 压缩数据（可选，懒加载）

	// V5+ 纹理映射
	textureIndex: number // -1 表示无
	textureRect: TextureRect

	// 链接类型
	targetIndex: number // LINK 类型时有效
	isLink?: boolean // 是否为 LINK 类型
	targetValid?: boolean // 目标是否有效
	linkStatus?: 'normal' | 'null' | 'circular' // LINK 状态

	// 修改追踪
	isModified: boolean
	isDeleted: boolean
	isNew: boolean
}

export interface Texture {
  index: number
  type: ColorBits
  typeName: string
  width: number
  height: number
  length: number
  fullLength: number
  data?: Uint8Array
}

export interface Album {
  // 基础信息
  path: string
  name: string
  version: ImgVersion

  // 文件位置
  offset: number
  length: number

  // Sprite 集合
  sprites: Sprite[]
  spriteCount: number  // 总帧数（包括已删除的）

  // V5+ 特有
  tables: number[][]  // 色表
  textures: Texture[]

  // IMG 引用
  targetPath?: string

  // 修改追踪
  isModified: boolean
  isDeleted: boolean
  isNew: boolean
  modifiedSprites: Set<number>
  deletedSprites: Set<number>
  newSprites: Set<number>
}

export interface Document {
  // 基础信息
  name: string
  path: string
  modified: Date

  // Album 集合
  albums: Map<string, Album>
  order: string[]

  // 修改追踪
  modifiedAlbums: Set<string>
  deletedAlbums: Set<string>
  newAlbums: Set<string>
}

// ========== Store ==========

export const useDocumentStore = defineStore('document', () => {
  // ========== State ==========
  const currentDoc = ref<Document | null>(null)
  const selectedAlbumPath = ref('')
  const selectedSpriteIndex = ref(0)
  const loading = ref(false)

  // ========== Getters ==========
  const selectedAlbum = computed<Album | undefined>(() => {
    if (!currentDoc.value || !selectedAlbumPath.value) return undefined
    return currentDoc.value.albums.get(selectedAlbumPath.value)
  })

  const selectedSprite = computed<Sprite | undefined>(() => {
    const album = selectedAlbum.value
    if (!album) return undefined
    return album.sprites.find(s => s.index === selectedSpriteIndex.value)
  })

  const hasUnsavedChanges = computed(() => {
    if (!currentDoc.value) return false
    const doc = currentDoc.value
    return doc.modifiedAlbums.size > 0 ||
           doc.deletedAlbums.size > 0 ||
           doc.newAlbums.size > 0
  })

  const modifiedCount = computed(() => {
    if (!currentDoc.value) return 0
    let count = 0
    const doc = currentDoc.value
    // Album 级修改
    count += doc.modifiedAlbums.size
    count += doc.deletedAlbums.size
    count += doc.newAlbums.size
    // Sprite 级修改
    doc.albums.forEach(album => {
      count += album.modifiedSprites.size
      count += album.deletedSprites.size
      count += album.newSprites.size
    })
    return count
  })

  const albumList = computed(() => {
    if (!currentDoc.value) return []
    return currentDoc.value.order
      .map(path => currentDoc.value!.albums.get(path))
      .filter((a): a is Album => a !== undefined && !a.isDeleted)
  })

  const spriteList = computed(() => {
    return selectedAlbum.value?.sprites.filter(s => !s.isDeleted) || []
  })

  const textureList = computed(() => {
    return selectedAlbum.value?.textures || []
  })

  // ========== Actions ==========

  // 加载 Document
  async function loadDocument(npkName: string) {
    loading.value = true
    try {
      // 获取 NPK 信息
      const res = await npkApi.getInfo(npkName)
      const npkInfo = res.data

      // 创建 Document
      const doc: Document = {
        name: npkName,
        path: npkInfo.path || '',
        modified: new Date(),
        albums: new Map(),
        order: [],
        modifiedAlbums: new Set(),
        deletedAlbums: new Set(),
        newAlbums: new Set(),
      }

      // 加载 Albums（骨架，不加载 Sprite 数据）
      for (const albumInfo of npkInfo.albums || []) {
        const album: Album = {
          path: albumInfo.path,
          name: albumInfo.name,
          version: albumInfo.version as ImgVersion,
          offset: albumInfo.offset || 0,
          length: albumInfo.length || 0,
          sprites: [],
          spriteCount: albumInfo.sprite_count || albumInfo.spriteCount || 0,
          tables: [],
          textures: [],
          targetPath: albumInfo.target_path || albumInfo.targetPath,
          isModified: false,
          isDeleted: false,
          isNew: albumInfo.offset === 0, // offset 为 0 表示新建的 album（还未保存到磁盘）
          modifiedSprites: new Set(),
          deletedSprites: new Set(),
          newSprites: new Set(),
        }
        doc.albums.set(album.path, album)
        doc.order.push(album.path)

        // 如果是新建的 album，添加到 newAlbums
        if (album.isNew) {
          doc.newAlbums.add(album.path)
        }
      }

      // 保存之前选中的路径，重新加载后恢复选中状态
      const oldSelectedPath = selectedAlbumPath.value
      const oldSpriteIndex = selectedSpriteIndex.value
      
      currentDoc.value = doc
      
      // 恢复之前的选中状态（如果该路径还存在）
      if (oldSelectedPath && doc.albums.has(oldSelectedPath)) {
        selectedAlbumPath.value = oldSelectedPath
      } else {
        selectedAlbumPath.value = ''
      }
      
      // 恢复帧索引（不超过新的范围）
      if (oldSelectedPath && doc.albums.has(oldSelectedPath)) {
        const album = doc.albums.get(oldSelectedPath)!
        if (oldSpriteIndex < album.spriteCount) {
          selectedSpriteIndex.value = oldSpriteIndex
        } else {
          selectedSpriteIndex.value = 0
        }
      } else {
        selectedSpriteIndex.value = 0
      }

      return doc
    } finally {
      loading.value = false
    }
  }

  // 加载 Album 详情（Sprite 列表）
  // 缓存策略：选择 IMG 后加载到内存；切换时丢弃旧数据重新加载；保存后释放全部
  async function loadAlbum(albumPath: string, forceReload = false) {
    if (!currentDoc.value) return

    // 如果已经是当前选中的 Album 且有数据，跳过重复加载（除非强制刷新）
    if (!forceReload && selectedAlbumPath.value === albumPath && (currentDoc.value.albums.get(albumPath)?.sprites.length ?? 0) > 0) return

    // 切换时丢弃旧 Album 数据（无论是否修改，不保存就切换 = 放弃修改）
    if (selectedAlbumPath.value && selectedAlbumPath.value !== albumPath) {
      discardAlbum(selectedAlbumPath.value)
    }

    const album = currentDoc.value.albums.get(albumPath)
    if (!album) return

    loading.value = true
    try {
      const res = await albumApi.getFrames(currentDoc.value.name, albumPath)
      const frames = res.data?.frames || []
      const textures = res.data?.textures || []

      // 转换帧数据
      album.sprites = frames.map((f: any, idx: number) => ({
        index: f.index ?? idx,
        type: f.type ?? 0x0e,
        typeName: getColorTypeName(f.type ?? 0x0e),
        x: f.x ?? 0,
        y: f.y ?? 0,
        originalX: f.x ?? 0,  // 保存原始坐标
        originalY: f.y ?? 0,  // 保存原始坐标
        width: f.width ?? 0,
        height: f.height ?? 0,
        frameWidth: f.frame_width ?? f.width ?? 0,
        frameHeight: f.frame_height ?? f.height ?? 0,
        compressMode: f.compress_mode ?? 0x06,
        length: f.length ?? 0,
        textureIndex: f.texture_index ?? -1,
        textureRect: {
          leftUp: { x: f.texture_rect?.lu_x ?? 0, y: f.texture_rect?.lu_y ?? 0 },
          rightDown: { x: f.texture_rect?.rd_x ?? 0, y: f.texture_rect?.rd_y ?? 0 },
          top: f.texture_rect?.top ?? 0,
        },
        targetIndex: f.target_index ?? -1,
        isLink: f.is_link ?? false,
        targetValid: f.target_valid ?? false,
        linkStatus: f.link_status ?? undefined,
        isModified: false,
        isDeleted: false,
        isNew: false,
      }))

      // 转换纹理数据
      album.textures = textures.map((t: any) => ({
        index: t.index ?? 0,
        type: t.type ?? 0x12,
        typeName: getColorTypeName(t.type ?? 0x12),
        width: t.width ?? 0,
        height: t.height ?? 0,
        length: t.length ?? 0,
        fullLength: t.full_length ?? 0,
      }))

      selectedAlbumPath.value = albumPath
      selectedSpriteIndex.value = 0
      // 更新 spriteCount 为实际加载的帧数
      album.spriteCount = frames.length
    } finally {
      loading.value = false
    }
  }

  // 丢弃 Album 数据（切换 IMG 时调用，无论是否修改都清空）
  function discardAlbum(albumPath: string) {
    if (!currentDoc.value) return
    const album = currentDoc.value.albums.get(albumPath)
    if (!album) return
    // 清空 sprites 和 textures
    album.sprites = []
    album.textures = []
    // 清除修改标记
    album.isModified = false
    album.modifiedSprites.clear()
    album.deletedSprites.clear()
    album.newSprites.clear()
    // 从 modifiedAlbums 中移除
    currentDoc.value.modifiedAlbums.delete(albumPath)
  }

  // 还原 Album 状态 (用于用户取消保存时)
  function resetAlbum(albumPath: string) {
    if (!currentDoc.value) return
    const album = currentDoc.value.albums.get(albumPath)
    if (!album) return

    // 还原所有 Sprite 的坐标
    album.sprites.forEach(sprite => {
      if (sprite.originalX !== undefined) {
        sprite.x = sprite.originalX
      }
      if (sprite.originalY !== undefined) {
        sprite.y = sprite.originalY
      }
      sprite.isModified = false
    })

    // 清除修改标记
    album.isModified = false
    album.modifiedSprites.clear()
    album.deletedSprites.clear()
    album.newSprites.clear()
    currentDoc.value.modifiedAlbums.delete(albumPath)
  }

  // 还原单个 Sprite 状态 (用于用户取消保存时)
  function resetSprite(spriteIndex: number) {
    if (!currentDoc.value || !selectedAlbumPath.value) return
    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) return
    
    const sprite = album.sprites.find(s => s.index === spriteIndex)
    if (!sprite) return
    
    // 还原坐标
    if (sprite.originalX !== undefined) {
      sprite.x = sprite.originalX
    }
    if (sprite.originalY !== undefined) {
      sprite.y = sprite.originalY
    }
    sprite.isModified = false
    
    // 清除修改标记
    album.modifiedSprites.delete(spriteIndex)
    
    // 如果没有其他修改的 Sprite，清除 Album 的修改标记
    if (album.modifiedSprites.size === 0) {
      album.isModified = false
      currentDoc.value.modifiedAlbums.delete(selectedAlbumPath.value)
    }
  }

  // 释放未修改的 Album 内存（清空 sprites 和 textures 数组）
  function releaseAlbum(albumPath: string) {
    if (!currentDoc.value) return
    const album = currentDoc.value.albums.get(albumPath)
    if (!album) return
    // 只释放未修改的 Album
    if (!album.isModified) {
      album.sprites = []
      album.textures = []
    }
  }

  // 释放所有未修改的 Album 内存
  function releaseAllUnmodified() {
    if (!currentDoc.value) return
    currentDoc.value.albums.forEach((_album, path) => {
      if (path !== selectedAlbumPath.value) {
        releaseAlbum(path)
      }
    })
  }

  // 选择 Sprite
  function selectSprite(index: number) {
    selectedSpriteIndex.value = index
  }

  // 获取 Sprite 图像 URL
  function getSpriteImageUrl(spriteIndex: number): string {
    if (!currentDoc.value || !selectedAlbumPath.value) return ''
    return assetApi.getImageUrl(
      currentDoc.value.name,
      selectedAlbumPath.value,
      spriteIndex
    )
  }

  // ========== Album 操作 ==========

  // 新建 Album (导入外部 IMG)
  async function newAlbum(targetPath: string, file: File, replace?: boolean) {
    if (!currentDoc.value) throw new Error(t('store.document.noNpkSelected'))

    const npkName = currentDoc.value.name
    loading.value = true
    try {
      await albumApi.importImg(npkName, targetPath, file, replace)

      // 直接调用 API 获取新创建的 Album 信息
      const res = await npkApi.getInfo(npkName)
      const npkInfo = res.data

      // 查找新创建的 Album
      const albumInfo = npkInfo.albums?.find((a: any) => a.path === targetPath)
      if (!albumInfo) {
        throw new Error(t('store.document.imgNotFound'))
      }

      // 创建新的 Album 对象
      // 如果后端没有返回 name，从路径中提取文件名
      const extractName = (path: string): string => {
        const parts = path.split('/')
        return parts[parts.length - 1] || path
      }
      const albumName = albumInfo.name || extractName(albumInfo.path)
      
      const newAlbum: Album = {
        path: albumInfo.path,
        name: albumName,
        version: albumInfo.version as ImgVersion,
        offset: albumInfo.offset || 0,
        length: albumInfo.length || 0,
        sprites: [],
        spriteCount: albumInfo.sprite_count || albumInfo.spriteCount || 0,
        tables: [],
        textures: [],
        isModified: true,
        isDeleted: false,
        isNew: true,
        modifiedSprites: new Set(),
        deletedSprites: new Set(),
        newSprites: new Set(),
      }

      // 添加到当前 Document
      currentDoc.value.albums.set(targetPath, newAlbum)
      currentDoc.value.order.push(targetPath)
      currentDoc.value.newAlbums.add(targetPath)
      currentDoc.value.modifiedAlbums.add(targetPath)

      // 选中新创建的 Album 并加载
      await loadAlbum(targetPath)

      ElMessage.success(t('store.document.newImgCreated', { path: targetPath }))
    } finally {
      loading.value = false
    }
  }

  // 重命名 Album
  async function renameAlbum(newPath: string) {
    if (!currentDoc.value || !selectedAlbumPath.value) throw new Error(t('store.document.noAlbumSelected'))

    const oldPath = selectedAlbumPath.value
    if (newPath === oldPath) return

    loading.value = true
    try {
      await albumApi.rename(currentDoc.value.name, oldPath, newPath)

      // 更新本地 Document
      const album = currentDoc.value.albums.get(oldPath)
      if (album) {
        album.path = newPath
        album.name = newPath.split('/').pop() || newPath
        currentDoc.value.albums.delete(oldPath)
        currentDoc.value.albums.set(newPath, album)

        const orderIdx = currentDoc.value.order.indexOf(oldPath)
        if (orderIdx >= 0) currentDoc.value.order[orderIdx] = newPath

        currentDoc.value.modifiedAlbums.add(newPath)
        album.isModified = true
      }

      selectedAlbumPath.value = newPath
      ElMessage.success(t('store.document.renamed', { oldPath, newPath }))
    } finally {
      loading.value = false
    }
  }

  // 删除 Album（只标记删除，不调用 API，保存时才真正删除）
  async function deleteAlbum(albumPath?: string) {
    if (!currentDoc.value) throw new Error(t('store.document.noDocSelected'))

    const path = albumPath || selectedAlbumPath.value
    if (!path) throw new Error(t('store.document.noAlbumSelected'))

    // 只标记删除（不调用 API）
    const album = currentDoc.value.albums.get(path)
    if (album) {
      album.isDeleted = true
      currentDoc.value.deletedAlbums.add(path)
    }

    // 如果删除的是当前选中的，清空选择
    if (path === selectedAlbumPath.value) {
      selectedAlbumPath.value = ''
      selectedSpriteIndex.value = 0
    }

    ElMessage.success(t('store.document.markedDeleted', { path }))
  }

  // ========== Sprite 操作 ==========

  // 替换 Sprite 图像
  async function replaceSprite(file: File, colorFormat: string = 'ARGB_8888') {
    if (!currentDoc.value || !selectedAlbumPath.value) {
      throw new Error(t('store.document.noAlbumSelected'))
    }

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) throw new Error(t('store.document.albumNotExist'))

    const sprite = album.sprites.find(s => s.index === selectedSpriteIndex.value)
    if (!sprite) throw new Error(t('store.document.spriteNotExist'))

    // 调用 API 替换
    await assetApi.replace(
      currentDoc.value.name,
      selectedAlbumPath.value,
      selectedSpriteIndex.value,
      file,
      colorFormat
    )

    // 重新加载当前帧以获取最新数据
    await loadAlbum(selectedAlbumPath.value)

    // 标记修改
    album.isModified = true
    currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)

    ElMessage.success(t('store.document.replaceSuccess'))
  }

  // 添加 Sprite
  async function addSprite(file: File) {
    if (!currentDoc.value || !selectedAlbumPath.value) {
      throw new Error(t('store.document.noAlbumSelected'))
    }

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) throw new Error(t('store.document.albumNotExist'))

    loading.value = true
    try {
      await assetApi.addFrame(currentDoc.value.name, selectedAlbumPath.value, file)

      // 重新加载 Album 以获取新 Sprite
      album.sprites = []
      await loadAlbum(selectedAlbumPath.value)

      // 选中新添加的 Sprite（最后一个）
      if (album.sprites.length > 0) {
        const newSprite = album.sprites[album.sprites.length - 1]
        newSprite.isNew = true
        album.newSprites.add(newSprite.index)
        album.isModified = true
        currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)
        selectedSpriteIndex.value = newSprite.index
      }

      ElMessage.success(t('store.document.addSuccess'))
    } finally {
      loading.value = false
    }
  }

  // 添加引用 Sprite
  // position: "before" | "after" | "end"
  async function addLinkSprite(targetIndex: number, position: string = 'end') {
    if (!currentDoc.value || !selectedAlbumPath.value) {
      throw new Error(t('store.document.noAlbumSelected'))
    }

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) throw new Error(t('store.document.albumNotExist'))

    loading.value = true
    try {
      await assetApi.addLinkFrame(currentDoc.value.name, selectedAlbumPath.value, targetIndex, position)

      // 重新加载 Album 以获取新 Sprite
      album.sprites = []
      await loadAlbum(selectedAlbumPath.value)

      // 选中新添加的 Sprite（根据插入位置）
      if (album.sprites.length > 0) {
        let newSpriteIndex: number
        if (position === 'end') {
          newSpriteIndex = album.sprites.length - 1
        } else if (position === 'before') {
          newSpriteIndex = targetIndex
        } else {
          newSpriteIndex = targetIndex + 1
        }
        const newSprite = album.sprites[newSpriteIndex]
        if (newSprite) {
          newSprite.isNew = true
          album.newSprites.add(newSprite.index)
          album.isModified = true
          currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)
          selectedSpriteIndex.value = newSprite.index
        }
      }

      ElMessage.success(t('store.document.addSuccess'))
    } finally {
      loading.value = false
    }
  }

  // 修改引用帧目标
  async function modifyLinkSpriteTarget(spriteIndex: number, newTargetIndex: number) {
    if (!currentDoc.value || !selectedAlbumPath.value) {
      throw new Error(t('store.document.noAlbumSelected'))
    }

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) throw new Error(t('store.document.albumNotExist'))

    loading.value = true
    try {
      await assetApi.modifyLinkTarget(currentDoc.value.name, selectedAlbumPath.value, spriteIndex, newTargetIndex)

      // 标记 album 为已修改
      album.isModified = true
      currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)

      // 重新加载 Album 以获取更新后的 Sprite
      album.sprites = []
      await loadAlbum(selectedAlbumPath.value)

      ElMessage.success(t('store.document.modifyLinkSuccess'))
    } finally {
      loading.value = false
    }
  }

  // 删除 Sprite（只标记删除，不调用 API，保存时才真正删除）
  async function deleteSprite() {
    if (!currentDoc.value || !selectedAlbumPath.value) return

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) return

    const sprite = album.sprites.find(s => s.index === selectedSpriteIndex.value)
    if (!sprite) return

    // 只标记删除（不调用 API）
    sprite.isDeleted = true
    album.deletedSprites.add(selectedSpriteIndex.value)
    album.isModified = true
    currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)

    // 自动选择下一个可见 Sprite
    const visible = album.sprites.filter(s => !s.isDeleted)
    if (visible.length > 0) {
      selectedSpriteIndex.value = visible[0].index
    } else {
      selectedSpriteIndex.value = -1
    }

    ElMessage.success(t('store.document.markedDeletedSingle'))
  }

  // 批量删除 Sprite（只标记删除，不调用 API，保存时才真正删除）
  async function deleteSprites(indices: number[]) {
    if (!currentDoc.value || !selectedAlbumPath.value || indices.length === 0) return

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) return

    for (const index of indices) {
      const sprite = album.sprites.find(s => s.index === index)
      if (!sprite || sprite.isDeleted) continue

      // 只标记删除（不调用 API）
      sprite.isDeleted = true
      album.deletedSprites.add(index)
    }

    album.isModified = true
    currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)

    // 自动选择下一个可见 Sprite
    const visible = album.sprites.filter(s => !s.isDeleted)
    if (visible.length > 0) {
      selectedSpriteIndex.value = visible[0].index
    } else {
      selectedSpriteIndex.value = -1
    }

    ElMessage.success(t('store.document.markedDeletedMulti', { count: indices.length }))
  }

  // 修改 Sprite 属性 (坐标/尺寸/帧域)
  async function updateSpriteProps(index: number, props: {
    x?: number
    y?: number
    width?: number
    height?: number
    frameWidth?: number
    frameHeight?: number
  }) {
    if (!currentDoc.value || !selectedAlbumPath.value) throw new Error(t('store.document.noAlbumSelected'))

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) throw new Error(t('store.document.albumNotExist'))

    const sprite = album.sprites.find(s => s.index === index)
    if (!sprite) throw new Error(t('store.document.spriteNotExist'))

    // 保存原始坐标 (只在第一次修改时保存)
    if (!sprite.isModified) {
      if (sprite.originalX === undefined) {
        sprite.originalX = sprite.x
      }
      if (sprite.originalY === undefined) {
        sprite.originalY = sprite.y
      }
    }

    // 调用 API 更新帧属性
    await assetApi.updateFrame(
      currentDoc.value.name,
      selectedAlbumPath.value,
      index,
      0, // frameIndex
      {
        x: props.x ?? sprite.x,
        y: props.y ?? sprite.y,
        width: props.width,
        height: props.height,
        frame_width: props.frameWidth ?? sprite.frameWidth,
        frame_height: props.frameHeight ?? sprite.frameHeight,
      }
    )

    // 更新本地状态
    if (props.x !== undefined) sprite.x = props.x
    if (props.y !== undefined) sprite.y = props.y
    if (props.width !== undefined) sprite.width = props.width
    if (props.height !== undefined) sprite.height = props.height
    if (props.frameWidth !== undefined) sprite.frameWidth = props.frameWidth
    if (props.frameHeight !== undefined) sprite.frameHeight = props.frameHeight

    sprite.isModified = true
    album.modifiedSprites.add(index)
    album.isModified = true
    currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)

    ElMessage.success(t('store.document.propsUpdated'))
  }

  // 移动 Sprite 坐标 (dx, dy 偏移)
  async function moveSprite(dx: number, dy: number) {
    const sprite = selectedSprite.value
    if (!sprite) return

    await updateSpriteProps(sprite.index, {
      x: sprite.x + dx,
      y: sprite.y + dy,
    })
  }

  // 裁剪 Sprite 透明边缘
  async function trimSprite() {
    if (!currentDoc.value || !selectedAlbumPath.value || !selectedSprite.value) return
    // 裁剪需要后端支持 trim API
    ElMessage.info(t('store.document.trimNotSupported'))
  }

  // 画布化 Sprite (调整画布大小)
  async function canvasSprite(newWidth: number, newHeight: number) {
    if (!currentDoc.value || !selectedAlbumPath.value || !selectedSprite.value) return

    const sprite = selectedSprite.value

    // 更新帧域为新的画布大小
    await updateSpriteProps(sprite.index, {
      frameWidth: newWidth,
      frameHeight: newHeight,
    })

    ElMessage.success(t('store.document.canvasized', { width: newWidth, height: newHeight }))
  }

  // 导出坐标
  async function exportCoords() {
    if (!currentDoc.value || !selectedAlbumPath.value) throw new Error(t('store.document.noAlbumSelected'))

    const res = await albumApi.exportCoords(currentDoc.value.name, selectedAlbumPath.value)
    
    // 下载文件
    const blob = new Blob([res.data], { type: 'text/plain' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${currentDoc.value.albums.get(selectedAlbumPath.value)?.name || 'coords'}.txt`
    a.click()
    window.URL.revokeObjectURL(url)
    
    ElMessage.success(t('store.document.exportSuccess'))
  }

  // 导入坐标
  async function importCoords(file: File) {
    if (!currentDoc.value || !selectedAlbumPath.value) throw new Error(t('store.document.noAlbumSelected'))

    await albumApi.importCoords(currentDoc.value.name, selectedAlbumPath.value, file)
    
    // 重新加载 Album
    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (album) {
      album.sprites = []
      await loadAlbum(selectedAlbumPath.value)
      album.isModified = true
      currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)
    }
    
    ElMessage.success(t('store.document.importSuccess'))
  }

  // 批量替换
  async function batchReplace(files: File[], colorFormat: string = 'ARGB_8888', startIndex: number = 0) {
    if (!currentDoc.value || !selectedAlbumPath.value) throw new Error(t('store.document.noAlbumSelected'))

    loading.value = true
    try {
      const result = await albumApi.batchReplaceFromFolder(
        currentDoc.value.name,
        selectedAlbumPath.value,
        files,
        colorFormat,
        startIndex
      )

      // 重新加载 Album
      const album = currentDoc.value.albums.get(selectedAlbumPath.value)
      if (album) {
        album.sprites = []
        await loadAlbum(selectedAlbumPath.value)
        album.sprites.forEach(s => {
          s.isModified = true
          album.modifiedSprites.add(s.index)
        })
        album.isModified = true
        currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)
      }

      return {
        replaced: result.data.replaced || 0,
        imported: result.data.imported || 0,
        total: files.length
      }
    } finally {
      loading.value = false
    }
  }

  // 批量导入
  async function batchImport(files: File[], position: "before" | "after" | "end", replaceLinks: boolean = false, colorFormat: string = "") {
    if (!currentDoc.value || !selectedAlbumPath.value) throw new Error(t('store.document.noAlbumSelected'))

    loading.value = true
    try {
      await albumApi.batchImportSprites(
        currentDoc.value.name,
        selectedAlbumPath.value,
        position,
        selectedSpriteIndex.value,
        replaceLinks,
        colorFormat,
        files
      )

      // 重新加载 Album（清空当前数据后重新加载）
      const album = currentDoc.value.albums.get(selectedAlbumPath.value)
      if (album) {
        album.sprites = []
        await loadAlbum(selectedAlbumPath.value)
        // 只标记 Album 为已修改，不标记所有 Sprite（后端已经处理好）
        album.isModified = true
        currentDoc.value.modifiedAlbums.add(selectedAlbumPath.value)
      }

      ElMessage.success(t('store.document.batchImported', { count: files.length }))
    } finally {
      loading.value = false
    }
  }

  // ========== 保存 ==========

  // 应用当前 Album 的修改（保存整个 NPK，但只清理当前 Album 的标记）
  async function applyAlbumChanges() {
    if (!currentDoc.value || !selectedAlbumPath.value) return

    const album = currentDoc.value.albums.get(selectedAlbumPath.value)
    if (!album) return

    loading.value = true
    try {
      // 先执行删除操作（按索引倒序，避免索引变化问题）
      const deletedIndices = [...album.deletedSprites].sort((a, b) => b - a)
      for (const index of deletedIndices) {
        await assetApi.delete(currentDoc.value.name, selectedAlbumPath.value, index)
      }

      // 调用 API 保存整个 NPK
      await npkApi.save(currentDoc.value.name)

      // 清理当前 Album 的修改标记
      album.isModified = false
      album.isNew = false
      album.modifiedSprites.clear()
      album.deletedSprites.clear()
      album.newSprites.clear()
      album.sprites.forEach(s => {
        s.isModified = false
        s.isNew = false
      })

      // 从 modifiedAlbums 中移除
      currentDoc.value.modifiedAlbums.delete(selectedAlbumPath.value)

      ElMessage.success(t('store.document.applySuccess'))
    } catch (e: any) {
      ElMessage.error(e.message || t('store.document.applyFailed'))
    } finally {
      loading.value = false
    }
  }

  // 保存 Document
  async function saveDocument() {
    if (!currentDoc.value) return

    loading.value = true
    try {
      // 1. 先执行所有 Album 删除操作
      for (const albumPath of currentDoc.value.deletedAlbums) {
        await albumApi.deleteAlbum(currentDoc.value.name, albumPath)
      }

      // 2. 再执行所有 Sprite 删除操作（按 album 遍历，每个 album 内按索引倒序）
      for (const [albumPath, album] of currentDoc.value.albums) {
        if (album.deletedSprites.size > 0) {
          const deletedIndices = [...album.deletedSprites].sort((a, b) => b - a)
          for (const index of deletedIndices) {
            await assetApi.delete(currentDoc.value.name, albumPath, index)
          }
        }
      }

      // 3. 调用保存 API
      await npkApi.save(currentDoc.value.name)

      // 4. 保存后强制重新加载当前 Album（清理缓存后重新获取数据）
      const currentPath = selectedAlbumPath.value
      if (currentPath) {
        const album = currentDoc.value.albums.get(currentPath)
        if (album) {
          album.sprites = []
          album.textures = []
          await loadAlbum(currentPath)
        }
      }

      // 清理修改标记
      currentDoc.value.modifiedAlbums.clear()
      currentDoc.value.deletedAlbums.clear()
      currentDoc.value.newAlbums.clear()

      currentDoc.value.albums.forEach(album => {
        album.isModified = false
        album.isNew = false
        album.modifiedSprites.clear()
        album.deletedSprites.clear()
        album.newSprites.clear()
        album.sprites.forEach(s => {
          s.isModified = false
          s.isNew = false
        })
      })

      // 保存后释放所有未修改的 Album 内存
      releaseAllUnmodified()

      ElMessage.success(t('store.document.saveSuccess'))
    } finally {
      loading.value = false
    }
  }

  // 重置状态
  async function resetState() {
    currentDoc.value = null
    selectedAlbumPath.value = ''
    selectedSpriteIndex.value = 0
    // 清理后端缓存
    await imgCacheApi.releaseAll()
  }

  // ========== 辅助函数 ==========

  function getColorTypeName(type: number): string {
    const names: Record<number, string> = {
      0x0e: 'ARGB1555',
      0x0f: 'ARGB4444',
      0x10: 'ARGB8888',
      0x11: 'LINK',
      0x12: 'DXT1',
      0x13: 'DXT3',
      0x14: 'DXT5',
    }
    return names[type] || 'UNKNOWN'
  }

  return {
    // State
    currentDoc,
    selectedAlbumPath,
    selectedSpriteIndex,
    loading,

    // Getters
    selectedAlbum,
    selectedSprite,
    hasUnsavedChanges,
    modifiedCount,
    albumList,
    spriteList,
    textureList,

    // Actions - Document
    loadDocument,
    saveDocument,
    applyAlbumChanges,
    resetState,

    // Actions - Album
    loadAlbum,
    newAlbum,
    renameAlbum,
    deleteAlbum,
    resetAlbum,

    // Actions - Sprite
    selectSprite,
    getSpriteImageUrl,
    replaceSprite,
    addSprite,
    addLinkSprite,
    modifyLinkSpriteTarget,
    deleteSprite,
    deleteSprites,
    updateSpriteProps,
    moveSprite,
    trimSprite,
    canvasSprite,
    batchReplace,
    batchImport,
    resetSprite,
    exportCoords,
    importCoords,
  }
})
