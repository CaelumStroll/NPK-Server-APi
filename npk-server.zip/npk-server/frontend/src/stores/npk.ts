import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { npkApi, assetApi } from '@/api'
import { useCacheStore } from './cache'

// NPK 文件类型定义
export interface NpkFile {
  name: string
  path: string
  size: number
  modified: string
  // v4 增强：文件级元数据
  img_count?: number
  format_type?: number  // 0=标准加密, 1=明文, 2=混合
  encryption_verified?: boolean
  // 向后兼容
  album_count?: number
}

// Album 类型定义
export interface Album {
  path: string
  name: string
  version: string
  sprite_count: number
  // v5 增强：IMG 级元数据
  file_type?: number  // 0=IMG, 1=OGG, 2=其他
  offset?: number
  size?: number
  // 引用目标路径
  target_path?: string
}

// Sprite 类型定义
export interface Sprite {
  index: number
  type: string
  width: number
  height: number
  x: number
  y: number
  frame_width: number
  frame_height: number
  is_link: boolean
  // LINK 类型特有字段
  target_index?: number
  target_valid?: boolean
  // v6 增强：数据大小
  data_size?: number
}

export const useNpkStore = defineStore('npk', () => {
  // State
  const npkFiles = ref<NpkFile[]>([])
  const currentNpk = ref<NpkFile | null>(null)
  const currentAlbums = ref<Album[]>([])
  const currentAlbum = ref<Album | null>(null)
  const currentSprites = ref<Sprite[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)
  
  // 控制后台刷新请求，防止堆积
  let isRefreshing = false
  let refreshController: AbortController | null = null

  // Getters
  const npkCount = computed(() => npkFiles.value.length)
  const totalAlbums = computed(() => 
    npkFiles.value.reduce((sum, f) => sum + (f.img_count || f.album_count || 0), 0)
  )

  // Actions
  async function fetchNpkList(useCache: boolean = true) {
    loading.value = true
    error.value = null
    const cacheStore = useCacheStore()
    
    try {
      // 先尝试从缓存获取
      if (useCache) {
        const cached = cacheStore.getNpkListCache()
        if (cached && cached.length > 0) {
          npkFiles.value = cached
          // 后台异步刷新
          refreshNpkListInBackground(cacheStore)
          return
        }
      }
      
      // 没有缓存或强制刷新，完整请求
      const res = await npkApi.list() as any
      const freshList = res.data || []
      npkFiles.value = freshList
      // 保存到缓存
      cacheStore.setNpkListCache(freshList)
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }
  
  // 后台刷新 NPK 列表
  async function refreshNpkListInBackground(cacheStore: any) {
    // 防止请求堆积
    if (isRefreshing) return
    isRefreshing = true
    
    try {
      refreshController = new AbortController()
      const res = await npkApi.list() as any
      const freshList = res.data || []
      const result = cacheStore.updateNpkListCacheIncremental(freshList)
      // 如果有变更，更新当前显示的数据
      if (result.added.length > 0 || result.modified.length > 0 || result.removed.length > 0) {
        npkFiles.value = result.updated
      }
    } catch (e: any) {
      if (e.name === 'AbortError') {
        console.log('[npkStore] 后台刷新已取消')
      } else {
        console.warn('[npkStore] 后台刷新失败:', e)
      }
    } finally {
      isRefreshing = false
      refreshController = null
    }
  }
  
  // 取消后台刷新
  function cancelRefresh() {
    if (refreshController) {
      refreshController.abort()
    }
  }

  async function fetchNpkInfo(name: string) {
    loading.value = true
    error.value = null
    // 清除旧数据，避免切换时显示旧的 Albums
    currentNpk.value = null
    currentAlbums.value = []
    try {
      const res = await npkApi.getInfo(name) as any
      currentNpk.value = res.data
      currentAlbums.value = res.data?.albums || []
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function fetchAssets(npkName: string, albumPath: string, page = 1, size = 50) {
    loading.value = true
    error.value = null
    try {
      const res = await assetApi.list(npkName, albumPath, page, size) as any
      currentSprites.value = res.data?.sprites || []
      currentAlbum.value = currentAlbums.value.find(a => a.path === albumPath) || null
      return res.data
    } catch (e: any) {
      error.value = e.message
      return null
    } finally {
      loading.value = false
    }
  }

  async function scanDirectory(path?: string) {
    loading.value = true
    error.value = null
    try {
      await npkApi.scan(path)
      await fetchNpkList()
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  function clearCurrent() {
    currentNpk.value = null
    currentAlbums.value = []
    currentAlbum.value = null
    currentSprites.value = []
  }

  return {
    // State
    npkFiles,
    currentNpk,
    currentAlbums,
    currentAlbum,
    currentSprites,
    loading,
    error,
    // Getters
    npkCount,
    totalAlbums,
    // Actions
    fetchNpkList,
    fetchNpkInfo,
    fetchAssets,
    scanDirectory,
    clearCurrent,
    cancelRefresh
  }
})
