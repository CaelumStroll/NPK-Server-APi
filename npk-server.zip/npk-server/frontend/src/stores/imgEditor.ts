import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { compatApi, assetApi, npkApi, albumApi } from '@/api'
import { ElMessage } from 'element-plus'
import { useCacheStore } from './cache'
import i18n from '@/language'

const t = (i18n.global as any).t

// === 数据类型 ===
export interface NpkItem {
  id: number
  name: string
  path: string
  file_size: number
  // v4 增强
  img_count?: number
  format_type?: number
  encryption_verified?: boolean
}

export interface AlbumItem {
  id: number
  img_path: string
  frame_count: number
  version?: number
  // v5 增强
  file_type?: number
  offset?: number
  size?: number
}

// === Store ===
const CACHE_SOURCE = 'ImgEditor'
const FRAME_SIZE = 200 * 1024 // 每帧约 200KB

export interface FrameItem {
  index: number
  x: number
  y: number
  width: number
  height: number
  frame_width: number
  frame_height: number
  type: number
  type_name: string
  compress: number
  // v6 增强
  data_size?: number
  texture_index?: number
  texture_rect?: {
    lu_x: number
    lu_y: number
    rd_x: number
    rd_y: number
  }
}

export interface TextureItem {
  index: number
  width: number
  height: number
  type: number
  type_name: string
}

// === Store ===
export const useImgEditorStore = defineStore('imgEditor', () => {
  // --- NPK / Album / Frame 数据 ---
  const npkList = ref<NpkItem[]>([])
  const selectedNpkId = ref<number | null>(null)
  const albumList = ref<AlbumItem[]>([])
  const selectedAlbumPath = ref('')
  const frameList = ref<FrameItem[]>([])
  const textureList = ref<TextureItem[]>([])
  const albumVersion = ref(0)
  const selectedFrameIndex = ref(0)

  // --- 加载状态 ---
  const npkLoading = ref(false)
  const albumLoading = ref(false)
  const frameLoading = ref(false)

  // --- 编辑状态 ---
  const editX = ref(0)
  const editY = ref(0)
  const editFrameWidth = ref(0)
  const editFrameHeight = ref(0)
  const editSaving = ref(false)
  const modifiedFrames = ref<Set<string>>(new Set())
  const replaceUploading = ref(false)
  const deleteConfirming = ref(false)
  const savingNpk = ref(false)

  // --- Album 多选状态 ---
  const selectedAlbumPaths = ref<Set<string>>(new Set())
  const selectAllAlbums = ref(false)

  // --- 预览状态 ---
  const zoomLevel = ref(1)
  const fitMode = ref<'contain' | 'original'>('original')
  const showGrid = ref(true)
  const showRuler = ref(true)
  const showCrosshair = ref(true)
  const isPlaying = ref(false)
  const playSpeed = ref(100)

  // --- 拖拽状态 ---
  const enableDrag = ref(false)
  const enablePan = ref(false)
  const isDragging = ref(false)
  const isPanning = ref(false)
  const panOffset = ref({ x: 0, y: 0 })

  // --- 帧图片缓存 ---
  const frameCache = ref<Map<string, string>>(new Map())
  const MAX_CACHE_SIZE = 200
  const PRELOAD_BATCH_SIZE = 10 // 每批预加载数量
  const PRELOAD_DELAY = 50 // 批次间隔 ms

  // --- 内存追踪（使用统一的 cache store） ---
  const cacheStore = useCacheStore()

  // --- 计算属性 ---
  const selectedNpk = computed(() => npkList.value.find(n => n.id === selectedNpkId.value))
  const selectedFrame = computed(() => frameList.value.find(f => f.index === selectedFrameIndex.value))
  const canPreview = computed(() => !!selectedNpk.value && !!selectedAlbumPath.value)
  const totalFrames = computed(() => frameList.value.length)
  const hasUnsavedChanges = computed(() => modifiedFrames.value.size > 0)

  const cacheKey = computed(() => {
    if (!selectedNpk.value || !selectedAlbumPath.value) return ''
    return `${selectedNpk.value.name}:${selectedAlbumPath.value}:${selectedFrameIndex.value}`
  })

  const previewUrl = computed(() => {
    if (!selectedNpk.value || !selectedAlbumPath.value) return ''
    const key = cacheKey.value
    if (frameCache.value.has(key)) {
      return frameCache.value.get(key)!
    }
    const baseUrl = compatApi.getFrameByPathUrl(selectedAlbumPath.value, selectedFrameIndex.value, selectedNpk.value.name)
    // 添加时间戳防止浏览器缓存（修改过的帧需要重新加载）
    const cacheBuster = isFrameModified(selectedFrameIndex.value) ? `&_t=${Date.now()}` : ''
    return baseUrl + cacheBuster
  })

  // 使用统一的 cache store 计算内存
  const memoryUsedMB = computed(() => cacheStore.memoryUsedMB)
  const memoryLimitMB = computed(() => cacheStore.memoryLimitMB)

  // === 内存管理方法 ===

  /** 估算加载一个 Album 的内存占用（帧数 × 平均帧大小） */
  function estimateAlbumMemory(frameCount: number): number {
    return frameCount * FRAME_SIZE
  }

  /** 记录 NPK+Album 加载到内存 */
  function trackMemory(npkName: string, albumPath: string, frameCount: number) {
    const key = `${npkName}:${albumPath}`
    const size = estimateAlbumMemory(frameCount)
    cacheStore.track(CACHE_SOURCE, 'album_frames', key, size, `${albumPath} (${frameCount} frames)`)
    cacheStore.checkLimit()
  }

  /** 释放指定 NPK+Album 的内存 */
  function releaseMemory(npkName: string, albumPath: string) {
    const key = `${npkName}:${albumPath}`
    cacheStore.untrack(CACHE_SOURCE, key)
    // 清除该 Album 相关的帧缓存
    const prefix = `${npkName}:${albumPath}:`
    for (const cacheKey of frameCache.value.keys()) {
      if (cacheKey.startsWith(prefix)) {
        frameCache.value.delete(cacheKey)
      }
    }
  }

  /** 释放所有内存 */
  function releaseAllMemory() {
    frameCache.value.clear()
    cacheStore.clear(CACHE_SOURCE)
  }

  /** 启动定期内存检查（每 30 秒） */
  function startMemoryMonitor() {
    // 使用 cache store 的检查
    setInterval(() => cacheStore.checkLimit(), 30000)
  }

  /** 停止内存监控 */
  function stopMemoryMonitor() {
    // cache store 自动管理
  }

  // === 帧缓存方法 ===

  function setCache(key: string, url: string) {
    frameCache.value.set(key, url)
    if (frameCache.value.size > MAX_CACHE_SIZE) {
      const firstKey = frameCache.value.keys().next().value
      frameCache.value.delete(firstKey)
    }
  }

  function clearFrameCache() {
    frameCache.value.clear()
  }

  // === 播放预加载 ===

  /**
   * 批量预加载帧图片（用于播放前缓存）
   * 分批加载避免阻塞主线程
   */
  async function preloadFramesForPlayback(startIndex: number, count: number): Promise<void> {
    if (!selectedNpk.value || !selectedAlbumPath.value) return

    const npkName = selectedNpk.value.name
    const albumPath = selectedAlbumPath.value
    const total = frameList.value.length

    // 计算需要加载的帧索引
    const indices: number[] = []
    for (let i = 0; i < count; i++) {
      const idx = (startIndex + i) % total
      const key = `${npkName}:${albumPath}:${idx}`
      if (!frameCache.value.has(key)) {
        indices.push(idx)
      }
    }

    if (indices.length === 0) return

    // 分批加载
    for (let i = 0; i < indices.length; i += PRELOAD_BATCH_SIZE) {
      const batch = indices.slice(i, i + PRELOAD_BATCH_SIZE)

      await Promise.all(
        batch.map(idx => {
          const key = `${npkName}:${albumPath}:${idx}`
          const url = compatApi.getFrameByPathUrl(albumPath, idx)

          return new Promise<void>((resolve) => {
            const img = new Image()
            img.onload = () => {
              setCache(key, url)
              resolve()
            }
            img.onerror = () => resolve() // 失败也继续
            img.src = url
          })
        })
      )

      // 批次间延迟，避免阻塞
      if (i + PRELOAD_BATCH_SIZE < indices.length) {
        await new Promise(r => setTimeout(r, PRELOAD_DELAY))
      }
    }
  }

  /**
   * 预加载所有帧（用于短动画）
   */
  async function preloadAllFrames(): Promise<void> {
    if (!selectedNpk.value || !selectedAlbumPath.value) return
    const total = frameList.value.length
    if (total === 0) return

    // 如果帧数太多，只预加载前 50 帧
    const preloadCount = Math.min(total, 50)
    await preloadFramesForPlayback(0, preloadCount)
  }

  // === 数据加载方法 ===

  async function fetchNpkList() {
    npkLoading.value = true
    try {
      const res = await compatApi.listNpks() as any
      npkList.value = res.data?.list || []
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.loadNpkListFailed', { msg: e.message }))
    } finally {
      npkLoading.value = false
    }
  }

  async function fetchAlbums(npkId: number) {
    albumLoading.value = true
    albumList.value = []
    selectedAlbumPath.value = ''
    frameList.value = []
    textureList.value = []
    selectedFrameIndex.value = 0
    try {
      const res = await compatApi.listImgs(npkId) as any
      // 后端返回 { path, name, sprite_count, version, ... }
      // 映射到 AlbumItem 接口 { img_path, frame_count, version, ... }
      const rawList = res.data?.list || []
      albumList.value = rawList.map((item: any) => ({
        id: item.id || 0,
        img_path: item.path || '',
        frame_count: item.sprite_count || 0,
        version: item.version || undefined,
        file_type: item.file_type,
        offset: item.offset,
        size: item.size,
      }))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.loadAlbumListFailed', { msg: e.message }))
    } finally {
      albumLoading.value = false
    }
  }

  async function fetchFrames(npkId: number, imgPath: string) {
    frameLoading.value = true
    // 先清空旧数据
    frameList.value = []
    textureList.value = []
    selectedFrameIndex.value = 0

    try {
      const res = await compatApi.listFramesByQuery(npkId, imgPath) as any
      // 检查是否还是当前选中的 Album（避免异步回调时数据错乱）
      if (selectedAlbumPath.value !== imgPath || selectedNpkId.value !== npkId) {
        return
      }
      const data = res.data
      frameList.value = data?.frames || []
      textureList.value = data?.textures || []
      albumVersion.value = data?.version || 0
      // 确保在 frameList 更新后再设置选中帧
      if (frameList.value.length > 0) {
        selectedFrameIndex.value = frameList.value[0].index
        syncEditFields(frameList.value[0])
      }
      // 记录内存占用
      if (selectedNpk.value) {
        trackMemory(selectedNpk.value.name, imgPath, frameList.value.length)
      }
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.loadFramesFailed', { msg: e.message }))
    } finally {
      frameLoading.value = false
    }
  }

  // === 编辑方法 ===

  function syncEditFields(frame: FrameItem | undefined) {
    if (!frame) return
    editX.value = frame.x
    editY.value = frame.y
    editFrameWidth.value = frame.frame_width
    editFrameHeight.value = frame.frame_height
  }

  function markFrameModified(index: number) {
    if (!selectedNpk.value || !selectedAlbumPath.value) return
    const key = `${selectedNpk.value.name}:${selectedAlbumPath.value}:${index}`
    const next = new Set(modifiedFrames.value)
    next.add(key)
    modifiedFrames.value = next
  }

  function clearFrameModified(index: number) {
    if (!selectedNpk.value || !selectedAlbumPath.value) return
    const key = `${selectedNpk.value.name}:${selectedAlbumPath.value}:${index}`
    const next = new Set(modifiedFrames.value)
    next.delete(key)
    modifiedFrames.value = next
  }

  function isFrameModified(index: number): boolean {
    if (!selectedNpk.value || !selectedAlbumPath.value) return false
    const key = `${selectedNpk.value.name}:${selectedAlbumPath.value}:${index}`
    return modifiedFrames.value.has(key)
  }

  // === 本地更新帧列表（避免重复请求）===

  /**
   * 本地更新帧属性（应用修改后不重新请求）
   */
  function updateFrameLocal(index: number, updates: Partial<FrameItem>) {
    const frameIndex = frameList.value.findIndex(f => f.index === index)
    if (frameIndex === -1) return

    frameList.value[frameIndex] = {
      ...frameList.value[frameIndex],
      ...updates
    }
    markFrameModified(index)
  }

  /**
   * 本地添加帧（添加后不重新请求）
   */
  function addFrameLocal(newFrame: FrameItem) {
    // 找到合适的插入位置（按 index 排序）
    const insertIndex = frameList.value.findIndex(f => f.index > newFrame.index)
    if (insertIndex === -1) {
      frameList.value.push(newFrame)
    } else {
      frameList.value.splice(insertIndex, 0, newFrame)
    }
    markFrameModified(newFrame.index)
  }

  /**
   * 本地删除帧（删除后不重新请求）
   */
  function deleteFrameLocal(index: number) {
    const frameIndex = frameList.value.findIndex(f => f.index === index)
    if (frameIndex === -1) return

    frameList.value.splice(frameIndex, 1)
    clearFrameModified(index)

    // 调整选中帧
    if (selectedFrameIndex.value === index) {
      if (frameList.value.length > 0) {
        const newIndex = Math.min(frameIndex, frameList.value.length - 1)
        selectedFrameIndex.value = frameList.value[newIndex].index
        syncEditFields(frameList.value[newIndex])
      } else {
        selectedFrameIndex.value = 0
      }
    }
  }

  /**
   * 本地替换帧图片（只标记修改，不重新请求）
   */
  function replaceFrameLocal(index: number) {
    markFrameModified(index)
    // 清除该帧的缓存，下次预览会重新加载
    if (selectedNpk.value && selectedAlbumPath.value) {
      const key = `${selectedNpk.value.name}:${selectedAlbumPath.value}:${index}`
      frameCache.value.delete(key)
    }
  }

  // === NPK 切换（智能内存释放：未修改的释放，修改的保持） ===

  async function switchNpk(npkId: number) {
    const oldNpkName = selectedNpk.value?.name || ''

    // 智能释放：只释放没有修改的 Album
    if (oldNpkName) {
      // 找出当前 NPK 下有修改的 Album
      const modifiedAlbums = new Set<string>()
      for (const key of modifiedFrames.value) {
        if (key.startsWith(oldNpkName + ':')) {
          const parts = key.split(':')
          if (parts.length >= 2) {
            modifiedAlbums.add(parts[1])
          }
        }
      }

      // 只释放没有修改的 Album
      for (const entry of cacheStore.getEntries(CACHE_SOURCE)) {
        if (entry.key.startsWith(oldNpkName + ':')) {
          const albumPath = entry.key.substring(oldNpkName.length + 1)
          if (!modifiedAlbums.has(albumPath)) {
            // 没有修改，释放内存
            cacheStore.untrack(CACHE_SOURCE, entry.key)
            // 清除相关帧缓存
            const prefix = entry.key + ':'
            for (const cacheKey of frameCache.value.keys()) {
              if (cacheKey.startsWith(prefix)) {
                frameCache.value.delete(cacheKey)
              }
            }
          }
        }
      }
    }

    selectedNpkId.value = npkId

    // 清除旧 NPK 的修改标记（保存后会清除，这里不需要）
    // 注意：切换 NPK 时不清除修改标记，因为修改的 Album 会保持在内存中

    // 只清除旧 NPK 的帧缓存，保留其他 NPK 的缓存
    if (oldNpkName) {
      const prefix = oldNpkName + ':'
      const next = new Map(frameCache.value)
      for (const key of next.keys()) {
        if (key.startsWith(prefix)) {
          frameCache.value.delete(key)
        }
      }
      frameCache.value = new Map(frameCache.value) // trigger reactivity
    }
    if (npkId) await fetchAlbums(npkId)
  }

  function switchAlbum(path: string) {
    const oldNpkName = selectedNpk.value?.name || ''
    const oldAlbumPath = selectedAlbumPath.value

    // 智能释放：如果旧 Album 没有修改，则释放
    if (oldNpkName && oldAlbumPath) {
      const hasModified = isAlbumModified(oldNpkName, oldAlbumPath)
      if (!hasModified) {
        // 没有修改，释放内存
        releaseMemory(oldNpkName, oldAlbumPath)
      }
      // 有修改的 Album 保持在内存中，不释放
    }

    selectedAlbumPath.value = path
    // 只清除旧 Album 的帧缓存，保留其他 Album 的缓存
    if (oldNpkName && oldAlbumPath) {
      const prefix = `${oldNpkName}:${oldAlbumPath}:`
      const next = new Map(frameCache.value)
      for (const key of next.keys()) {
        if (key.startsWith(prefix)) {
          frameCache.value.delete(key)
        }
      }
      frameCache.value = new Map(frameCache.value) // trigger reactivity
    }
    if (selectedNpkId.value && path) {
      fetchFrames(selectedNpkId.value, path)
    }
  }

  /** 检查指定 Album 是否有修改 */
  function isAlbumModified(npkName: string, albumPath: string): boolean {
    const prefix = `${npkName}:${albumPath}:`
    for (const key of modifiedFrames.value) {
      if (key.startsWith(prefix)) {
        return true
      }
    }
    return false
  }

  // === 帧属性修改 ===

  async function applyFrameEdit() {
    if (!selectedNpk.value || !selectedFrame.value) return
    editSaving.value = true
    try {
      const npkName = selectedNpk.value.name
      const frameIndex = selectedFrameIndex.value
      const albumPath = selectedAlbumPath.value

      // 保存旧值用于回滚
      const oldFrame = { ...selectedFrame.value }

      // 本地先更新（乐观更新）
      updateFrameLocal(frameIndex, {
        x: editX.value,
        y: editY.value,
        frame_width: editFrameWidth.value,
        frame_height: editFrameHeight.value
      })

      try {
        await assetApi.updateFrame(npkName, albumPath, frameIndex, frameIndex, {
          x: editX.value,
          y: editY.value,
          frame_width: editFrameWidth.value,
          frame_height: editFrameHeight.value
        })
        ElMessage.success(t('store.imgEditor.framePropsModified'))
      } catch (e: any) {
        // 失败时回滚
        updateFrameLocal(frameIndex, oldFrame)
        throw e
      }
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.modifyFramePropsFailed', { msg: e.message }))
    } finally {
      editSaving.value = false
    }
  }

  // === 替换帧图片 ===

  async function replaceFrame(file: File) {
    if (!selectedNpk.value) return
    replaceUploading.value = true
    try {
      const npkName = selectedNpk.value.name
      const frameIndex = selectedFrameIndex.value
      const albumPath = selectedAlbumPath.value
      await assetApi.replace(npkName, albumPath, frameIndex, file)
      // 本地标记修改，清除缓存，不重新请求帧列表
      replaceFrameLocal(frameIndex)
      ElMessage.success(t('store.imgEditor.frameImageReplaced'))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.replaceFrameImageFailed', { msg: e.message }))
    } finally {
      replaceUploading.value = false
    }
  }

  // === 添加帧 ===

  async function addFrame(file: File) {
    if (!selectedNpk.value) return
    try {
      const npkName = selectedNpk.value.name
      const albumPath = selectedAlbumPath.value
      await assetApi.addFrame(npkName, albumPath, file)
      ElMessage.success(t('store.imgEditor.frameAdded'))
      if (selectedNpkId.value) {
        await fetchFrames(selectedNpkId.value, albumPath)
      }
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.addFrameFailed', { msg: e.message }))
    }
  }

  // === 删除帧 ===

  async function deleteFrame(overrideIndex?: number) {
    if (!selectedNpk.value) return
    deleteConfirming.value = true
    try {
      const npkName = selectedNpk.value.name
      const frameIndex = overrideIndex ?? selectedFrameIndex.value
      const albumPath = selectedAlbumPath.value
      await assetApi.delete(npkName, albumPath, frameIndex)
      ElMessage.success(t('store.imgEditor.frameDeleted'))
      clearFrameModified(frameIndex)
      if (selectedNpkId.value) {
        await fetchFrames(selectedNpkId.value, albumPath)
        if (frameList.value.length > 0) {
          const nextIndex = Math.min(frameIndex, frameList.value[frameList.value.length - 1].index)
          selectedFrameIndex.value = nextIndex
          const frame = frameList.value.find(f => f.index === nextIndex)
          syncEditFields(frame)
        }
      }
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.deleteFrameFailed', { msg: e.message }))
    } finally {
      deleteConfirming.value = false
    }
  }

  // === 保存 NPK ===

  async function saveNpk() {
    if (!selectedNpk.value) return
    savingNpk.value = true
    try {
      const npkName = selectedNpk.value.name
      await npkApi.save(npkName)
      modifiedFrames.value = new Set()
      clearFrameCache()
      ElMessage.success(t('store.imgEditor.npkSaved'))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.saveNpkFailed', { msg: e.message }))
    } finally {
      savingNpk.value = false
    }
  }

  // === 批量替换 ===

  async function batchReplace(files: File[], mode: 'folder' | 'append' | 'insert', insertIndex: number) {
    if (!selectedNpk.value || files.length === 0) return
    replaceUploading.value = true

    const npkName = selectedNpk.value.name
    const albumPath = selectedAlbumPath.value
    const modifiedIndices: number[] = []

    try {
      // 使用 Promise.all 并行处理，但限制并发数
      const CONCURRENCY = 3
      for (let i = 0; i < files.length; i += CONCURRENCY) {
        const batch = files.slice(i, i + CONCURRENCY)
        await Promise.all(
          batch.map(async (file, batchIdx) => {
            const idx = i + batchIdx

            let targetIndex: number
            if (mode === 'folder') {
              const match = file.name.match(/(\d+)/)
              targetIndex = match ? parseInt(match[1]) : idx
            } else if (mode === 'append') {
              targetIndex = frameList.value.length + idx
            } else {
              targetIndex = insertIndex + idx
            }

            try {
              await assetApi.replace(npkName, albumPath, targetIndex, file)
              modifiedIndices.push(targetIndex)
            } catch (e: any) {
              ElMessage.warning(t('store.imgEditor.replaceFrameIdxFailed', { index: targetIndex, name: file.name }))
            }
          })
        )
      }

      // 本地标记所有修改的帧，不重新请求
      modifiedIndices.forEach(idx => replaceFrameLocal(idx))

      ElMessage.success(t('store.imgEditor.batchReplaceComplete', { success: modifiedIndices.length, total: files.length }))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.batchReplaceFailed', { msg: e.message }))
    } finally {
      replaceUploading.value = false
    }
  }

  // === 批量替换（文件夹模式，按文件名匹配索引）===

  async function batchReplaceFromFolder(files: File[]) {
    if (!selectedNpk.value || files.length === 0) return
    replaceUploading.value = true

    try {
      const npkName = selectedNpk.value.name
      const albumPath = selectedAlbumPath.value

      const res = await albumApi.batchReplaceFromFolder(npkName, albumPath, files) as any
      const replaced = res.data?.replaced || 0
      const total = res.data?.total || files.length

      // 标记所有帧为已修改
      for (let i = 0; i < frameList.value.length; i++) {
        markFrameModified(frameList.value[i].index)
      }

      ElMessage.success(t('store.imgEditor.batchReplaceFromFolderComplete', { replaced, total }))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.batchReplaceFailed', { msg: e.message }))
    } finally {
      replaceUploading.value = false
    }
  }

  // === Album 路径重命名 ===

  async function renameAlbum(newPath: string) {
    if (!selectedNpk.value || !selectedAlbumPath.value) return
    try {
      const npkName = selectedNpk.value.name
      const oldPath = selectedAlbumPath.value

      await albumApi.rename(npkName, oldPath, newPath)

      // 更新本地状态
      selectedAlbumPath.value = newPath

      // 更新 albumList 中的路径
      const album = albumList.value.find(a => a.img_path === oldPath)
      if (album) {
        album.img_path = newPath
      }

      // 更新 modifiedFrames 键：替换旧路径前缀为新路径
      if (selectedNpk.value) {
        const oldPrefix = `${selectedNpk.value.name}:${oldPath}:`
        const newPrefix = `${selectedNpk.value.name}:${newPath}:`
        const next = new Set<string>()
        for (const key of modifiedFrames.value) {
          if (key.startsWith(oldPrefix)) {
            next.add(key.replace(oldPrefix, newPrefix))
          } else {
            next.add(key)
          }
        }
        modifiedFrames.value = next
      }

      ElMessage.success(t('store.imgEditor.renameSuccess'))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.renameFailed', { msg: e.message }))
    }
  }

  // === IMG 对比 ===

  async function compareWithAlbum(targetAlbumPath: string) {
    if (!selectedNpk.value || !selectedAlbumPath.value) return null
    try {
      const npkName = selectedNpk.value.name
      const res = await albumApi.compare(npkName, selectedAlbumPath.value, targetAlbumPath) as any
      return {
        added: res.data?.added || [],
        deleted: res.data?.deleted || [],
        modified: res.data?.modified || []
      }
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.compareFailed', { msg: e.message }))
      return null
    }
  }

  // === 从外部导入 IMG ===

  async function importImgFile(file: File, targetPath: string) {
    if (!selectedNpk.value) return
    try {
      const npkName = selectedNpk.value.name
      await albumApi.importImg(npkName, targetPath, file)
      ElMessage.success(t('store.imgEditor.importSuccess'))
      // 刷新 Album 列表
      if (selectedNpkId.value) {
        await fetchAlbums(selectedNpkId.value)
      }
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.importFailed', { msg: e.message }))
    }
  }

  // === Album 多选操作 ===

  function toggleAlbumSelection(albumPath: string) {
    if (selectedAlbumPaths.value.has(albumPath)) {
      selectedAlbumPaths.value.delete(albumPath)
    } else {
      selectedAlbumPaths.value.add(albumPath)
    }
    updateSelectAllState()
  }

  function selectAlbum(albumPath: string, selected: boolean) {
    if (selected) {
      selectedAlbumPaths.value.add(albumPath)
    } else {
      selectedAlbumPaths.value.delete(albumPath)
    }
    updateSelectAllState()
  }

  function toggleSelectAllAlbums() {
    if (selectAllAlbums.value) {
      selectedAlbumPaths.value.clear()
    } else {
      albumList.value.forEach(album => selectedAlbumPaths.value.add(album.img_path))
    }
    selectAllAlbums.value = !selectAllAlbums.value
  }

  function updateSelectAllState() {
    if (albumList.value.length === 0) {
      selectAllAlbums.value = false
      return
    }
    selectAllAlbums.value = albumList.value.every(album => selectedAlbumPaths.value.has(album.img_path))
  }

  function clearAlbumSelection() {
    selectedAlbumPaths.value.clear()
    selectAllAlbums.value = false
  }

  function isAlbumSelected(albumPath: string) {
    return selectedAlbumPaths.value.has(albumPath)
  }

  async function deleteSelectedAlbums() {
    if (!selectedNpk.value || selectedAlbumPaths.value.size === 0) return
    const npkName = selectedNpk.value.name
    const paths = Array.from(selectedAlbumPaths.value)
    let successCount = 0
    for (const path of paths) {
      try {
        await albumApi.deleteAlbum(npkName, path)
        successCount++
      } catch (e: any) {
        ElMessage.error(t('store.imgEditor.deleteAlbumFailed', { path, msg: e.message }))
      }
    }
    if (successCount > 0) {
      ElMessage.success(t('store.imgEditor.deleteAlbumsSuccess', { count: successCount }))
      clearAlbumSelection()
      await fetchAlbums(selectedNpk.value.id)
    }
  }

  // === 帧操作扩展 ===

  async function clearSpriteImage(frameIndex?: number) {
    if (!selectedNpk.value || !selectedAlbumPath.value) return
    const index = frameIndex ?? selectedFrameIndex.value
    try {
      await albumApi.clearSpriteImage(selectedNpk.value.name, selectedAlbumPath.value, index)
      markFrameModified(index)
      ElMessage.success(t('store.imgEditor.clearSuccess'))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.clearFailed', { msg: e.message }))
    }
  }

  async function resetSprite(frameIndex?: number) {
    if (!selectedNpk.value || !selectedAlbumPath.value) return
    const index = frameIndex ?? selectedFrameIndex.value
    try {
      await albumApi.resetSprite(selectedNpk.value.name, selectedAlbumPath.value, index)
      clearFrameModified(index)
      await fetchFrames(selectedNpkId.value!, selectedAlbumPath.value)
      ElMessage.success(t('store.imgEditor.resetSuccess'))
    } catch (e: any) {
      ElMessage.error(t('store.imgEditor.resetFailed', { msg: e.message }))
    }
  }

  // === 清理 ===

  function resetState() {
    releaseAllMemory()
    npkList.value = []
    selectedNpkId.value = null
    albumList.value = []
    selectedAlbumPath.value = ''
    frameList.value = []
    textureList.value = []
    albumVersion.value = 0
    selectedFrameIndex.value = 0
    modifiedFrames.value = new Set()
    clearAlbumSelection()
    clearFrameCache()
    stopMemoryMonitor()
  }

  return {
    // 数据
    npkList, selectedNpkId, albumList, selectedAlbumPath,
    frameList, textureList, albumVersion, selectedFrameIndex,
    // 加载状态
    npkLoading, albumLoading, frameLoading,
    // 编辑状态
    editX, editY, editFrameWidth, editFrameHeight,
    editSaving, modifiedFrames, replaceUploading, deleteConfirming, savingNpk,
    // Album 多选状态
    selectedAlbumPaths, selectAllAlbums,
    // 预览状态
    zoomLevel, fitMode, showGrid, showRuler, showCrosshair,
    isPlaying, playSpeed,
    // 拖拽状态
    enableDrag, enablePan, isDragging, isPanning, panOffset,
    // 缓存
    frameCache, MAX_CACHE_SIZE,
    // 内存管理
    memoryUsedMB, memoryLimitMB,
    startMemoryMonitor, stopMemoryMonitor, releaseAllMemory,
    // 计算属性
    selectedNpk, selectedFrame, canPreview, totalFrames,
    hasUnsavedChanges, cacheKey, previewUrl,
    // 方法
    setCache, clearFrameCache,
    fetchNpkList, fetchAlbums, fetchFrames,
    syncEditFields, markFrameModified, clearFrameModified, isFrameModified,
    switchNpk, switchAlbum,
    applyFrameEdit, replaceFrame, addFrame, deleteFrame, saveNpk, batchReplace,
    batchReplaceFromFolder, renameAlbum, compareWithAlbum, importImgFile,
    // Album 多选方法
    toggleAlbumSelection, selectAlbum, toggleSelectAllAlbums, clearAlbumSelection,
    isAlbumSelected, deleteSelectedAlbums,
    // 帧操作扩展
    clearSpriteImage, resetSprite,
    resetState,
    // 预加载
    preloadFramesForPlayback, preloadAllFrames,
    // 本地更新
    updateFrameLocal, addFrameLocal, deleteFrameLocal, replaceFrameLocal
  }
})
