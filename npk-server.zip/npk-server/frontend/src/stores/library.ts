import { defineStore } from 'pinia'
import { ref } from 'vue'
import { libraryApi } from '@/api'

export interface Stats {
  npk_count: number
  album_count: number
  sprite_count: number
  total_size: number
  cache_stats: Record<string, any>
}

export interface SearchResult {
  npk_name: string
  album_path: string
  album_name: string
  sprite_count: number
  version: string
  // v5 增强
  file_type?: number
  offset?: number
  size?: number
}

export const useLibraryStore = defineStore('library', () => {
  // State
  const stats = ref<Stats | null>(null)
  const searchResults = ref<SearchResult[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Actions
  async function fetchStats() {
    try {
      const res = await libraryApi.getStats() as any
      stats.value = res.data
    } catch (e: any) {
      error.value = e.message
    }
  }

  async function search(query: string, type?: string, page = 1, size = 20) {
    loading.value = true
    error.value = null
    try {
      const res = await libraryApi.search(query, type, page, size) as any
      searchResults.value = res.data?.results || []
      return res.data
    } catch (e: any) {
      error.value = e.message
      return null
    } finally {
      loading.value = false
    }
  }

  return {
    // State
    stats,
    searchResults,
    loading,
    error,
    // Actions
    fetchStats,
    search
  }
})
