import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { videoApi } from '@/api'

// 视频文件类型定义
export interface VideoFile {
  id: number
  name: string
  path: string
  dir_path: string // 文件夹路径
  format: string
  width: number
  height: number
  fps: number
  duration: number // 秒
  size: number // 字节
  is_encrypted: boolean
  created_at?: string
  modified_at?: string
}

// 视频统计类型
export interface VideoStats {
  total_count: number
  total_size: number
  encrypted_count: number
  total_duration: number // 秒
}

export const useVideoStore = defineStore('video', () => {
  // State
  const videos = ref<VideoFile[]>([])
  const stats = ref<VideoStats>({
    total_count: 0,
    total_size: 0,
    encrypted_count: 0,
    total_duration: 0,
  })
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Getters
  const totalCount = computed(() => stats.value.total_count)
  const totalSize = computed(() => stats.value.total_size)
  const encryptedCount = computed(() => stats.value.encrypted_count)
  const totalDuration = computed(() => stats.value.total_duration)

  // Actions
  // 获取全量视频列表（不分页，用于文件夹浏览）
  async function fetchVideos() {
    loading.value = true
    error.value = null
    try {
      const res = await videoApi.list() as any
      videos.value = res.data?.items || res.data || []
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function fetchStats() {
    try {
      const res = await videoApi.getStats() as any
      stats.value = res.data || {
        total_count: 0,
        total_size: 0,
        encrypted_count: 0,
        total_duration: 0,
      }
    } catch (e: any) {
      console.warn('[videoStore] 获取统计失败:', e)
    }
  }

  async function scanVideos() {
    loading.value = true
    error.value = null
    try {
      await videoApi.scan()
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function encryptVideo(id: number) {
    try {
      await videoApi.encrypt(id)
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  async function decryptVideo(id: number) {
    try {
      await videoApi.decrypt(id)
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  async function deleteVideo(id: number) {
    try {
      await videoApi.deleteVideo(id)
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  async function batchEncrypt(ids: number[]) {
    try {
      await videoApi.batchEncrypt(ids)
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  async function batchDecrypt(ids: number[]) {
    try {
      await videoApi.batchDecrypt(ids)
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  async function batchDelete(ids: number[]) {
    try {
      await videoApi.batchDelete(ids)
      await Promise.all([fetchVideos(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  return {
    // State
    videos,
    stats,
    loading,
    error,
    // Getters
    totalCount,
    totalSize,
    encryptedCount,
    totalDuration,
    // Actions
    fetchVideos,
    fetchStats,
    scanVideos,
    encryptVideo,
    decryptVideo,
    deleteVideo,
    batchEncrypt,
    batchDecrypt,
    batchDelete,
  }
})
