import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

const MAX_LOGS = 500

export const useLogStore = defineStore('log', () => {
  const wsLogs = ref<string[]>([])
  const connected = ref(false)
  const reconnecting = ref(false)

  let ws: WebSocket | null = null
  let reconnectTimer: ReturnType<typeof setTimeout> | null = null

  const filteredLogs = computed(() => wsLogs.value)

  function connect() {
    if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) {
      return
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const host = window.location.host
    ws = new WebSocket(`${protocol}//${host}/ws/logs`)

    ws.onopen = () => {
      connected.value = true
      reconnecting.value = false
      console.log('[LogStore] WebSocket connected')
    }

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data)
        if (msg.type === 'log' && msg.payload && msg.payload.message) {
          wsLogs.value.push(msg.payload.message)
          if (wsLogs.value.length > MAX_LOGS) {
            wsLogs.value = wsLogs.value.slice(-MAX_LOGS)
          }
        }
      } catch {
        // 忽略解析错误
      }
    }

    ws.onclose = () => {
      connected.value = false
      ws = null
      scheduleReconnect()
    }

    ws.onerror = () => {
      connected.value = false
    }
  }

  function scheduleReconnect() {
    if (reconnectTimer) return
    reconnecting.value = true
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null
      reconnecting.value = false
      connect()
    }, 5000)
  }

  function disconnect() {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer)
      reconnectTimer = null
    }
    if (ws) {
      ws.onclose = null
      ws.close()
      ws = null
    }
    connected.value = false
  }

  function clearLogs() {
    wsLogs.value = []
  }

  return {
    wsLogs,
    connected,
    reconnecting,
    filteredLogs,
    connect,
    disconnect,
    clearLogs
  }
})
