import { defineStore } from 'pinia'
import { ref } from 'vue'
import { api } from '@/api'
import i18n from '@/language'

const t = (i18n.global as any).t

export const useUiStore = defineStore('ui', () => {
  const enableSplashScreen = ref(true)
  const splashIntroText = ref(t('ui.defaultSplashText'))
  const splashAvatarImage = ref('/avatars/avatar_01.JPG')
  const autoSplashTimeout = ref(5)

  const builtInAvatars = ref<string[]>([])
  const isLoadingAvatars = ref(false)

  function loadFromStorage() {
    try {
      const saved = localStorage.getItem('npk-ui-settings')
      if (saved) {
        const data = JSON.parse(saved)
        enableSplashScreen.value = data.enableSplashScreen ?? true
        splashIntroText.value = data.splashIntroText ?? splashIntroText.value
        splashAvatarImage.value = data.splashAvatarImage || '/avatars/avatar_01.JPG'
        autoSplashTimeout.value = data.autoSplashTimeout ?? 5
      }
    } catch (e) {
      console.error('Failed to load UI settings:', e)
    }
  }

  function saveToStorage() {
    try {
      localStorage.setItem('npk-ui-settings', JSON.stringify({
        enableSplashScreen: enableSplashScreen.value,
        splashIntroText: splashIntroText.value,
        splashAvatarImage: splashAvatarImage.value,
        autoSplashTimeout: autoSplashTimeout.value
      }))
    } catch (e) {
      console.error('Failed to save UI settings:', e)
    }
    saveToServer()
  }

  async function loadFromServer() {
    try {
      const res = await api.get('/settings') as any
      const data = res.data || res
      if (data.splash_avatar_image) {
        splashAvatarImage.value = data.splash_avatar_image
      }
      if (data.splash_intro_text) {
        splashIntroText.value = data.splash_intro_text
      }
      localStorage.setItem('npk-ui-settings', JSON.stringify({
        enableSplashScreen: enableSplashScreen.value,
        splashIntroText: splashIntroText.value,
        splashAvatarImage: splashAvatarImage.value,
        autoSplashTimeout: autoSplashTimeout.value
      }))
    } catch {
      // fallback to localStorage
    }
  }

  async function saveToServer() {
    try {
      await api.put('/settings', {
        splash_avatar_image: splashAvatarImage.value,
        splash_intro_text: splashIntroText.value
      })
    } catch {
      // silent
    }
  }

  async function loadAvatarsFromAPI() {
    if (isLoadingAvatars.value) return

    isLoadingAvatars.value = true
    try {
      const res = await api.get('/avatars/list') as any
      const data = res.data || res
      if (Array.isArray(data)) {
        builtInAvatars.value = data
      }
    } catch (e) {
      console.error('Failed to load avatars:', e)
    } finally {
      isLoadingAvatars.value = false
    }
  }

  function selectAvatar(avatar: string) {
    splashAvatarImage.value = avatar
    saveToStorage()
  }

  loadFromStorage()
  loadAvatarsFromAPI()
  loadFromServer()

  return {
    enableSplashScreen,
    splashIntroText,
    splashAvatarImage,
    autoSplashTimeout,
    builtInAvatars,
    isLoadingAvatars,
    loadFromStorage,
    saveToStorage,
    loadFromServer,
    saveToServer,
    loadAvatarsFromAPI,
    selectAvatar
  }
})
