import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { musicApi } from '@/api'
import type { MusicFile, MusicStats } from '@/types'

export { type MusicFile, type MusicStats } from '@/types'

export const useMusicStore = defineStore('music', () => {
  const musicFiles = ref<MusicFile[]>([])
  const stats = ref<MusicStats>({
    total_count: 0,
    total_size: 0,
    total_duration: 0,
  })
  const loading = ref(false)
  const error = ref<string | null>(null)

  const totalCount = computed(() => stats.value.total_count)
  const totalSize = computed(() => stats.value.total_size)
  const totalDuration = computed(() => stats.value.total_duration)

  async function fetchMusic() {
    loading.value = true
    error.value = null
    try {
      const res = await musicApi.list() as any
      musicFiles.value = res.data?.items || res.data || []
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function fetchStats() {
    try {
      const res = await musicApi.getStats() as any
      stats.value = res.data || {
        total_count: 0,
        total_size: 0,
        total_duration: 0,
      }
    } catch (e: any) {
      console.warn('[musicStore] 获取统计失败:', e)
    }
  }

  async function scanMusic(dir?: string) {
    loading.value = true
    error.value = null
    try {
      await musicApi.scan(dir)
      await Promise.all([fetchMusic(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  async function deleteMusic(id: number) {
    try {
      await musicApi.deleteMusic(id)
      await Promise.all([fetchMusic(), fetchStats()])
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  async function convertMusic(id: number, targetFormat: string) {
    try {
      return await musicApi.convert(id, targetFormat)
    } catch (e: any) {
      error.value = e.message
      throw e
    }
  }

  return {
    musicFiles,
    stats,
    loading,
    error,
    totalCount,
    totalSize,
    totalDuration,
    fetchMusic,
    fetchStats,
    scanMusic,
    deleteMusic,
    convertMusic,
  }
})
