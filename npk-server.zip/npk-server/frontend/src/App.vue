<script setup lang="ts">
import { RouterView, useRouter } from 'vue-router'
import MainLayout from '@/layouts/MainLayout.vue'
import { onMounted, ref } from 'vue'
import { useNpkStore } from '@/stores/npk'

const router = useRouter()
const npkStore = useNpkStore()

// 缓存的页面列表
const cacheInclude = ['NpkManager', 'AnimationPlayer', 'BatchExport']
const isTransitioning = ref(false)

// 路由切换时取消后台刷新
router.beforeEach((_, __, next) => {
  npkStore.cancelRefresh()
  isTransitioning.value = true
  next()
})

router.afterEach(() => {
  isTransitioning.value = false
})

// 预先加载 NPK 列表缓存
onMounted(() => {
  npkStore.fetchNpkList()
})
</script>

<template>
  <MainLayout>
    <RouterView v-slot="{ Component, route }">
      <!-- 页面切换过渡 -->
      <transition name="fade" mode="out-in">
        <!-- 缓存主要页面，避免频繁重建 -->
        <keep-alive :include="cacheInclude">
          <component 
            :is="Component" 
            :key="route.fullPath"
            v-show="!isTransitioning"
          />
        </keep-alive>
      </transition>
    </RouterView>
  </MainLayout>
</template>

<style>
html, body, #app {
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
}

/* 页面切换过渡 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
