<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Tools as ToolsIcon, FolderOpened, Plus, Delete, Link, Files } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useI18n } from 'vue-i18n'

interface Tool {
  id: string
  name: string
  description: string
  path: string
  icon: string
  type: 'custom' | 'system'
  systemType?: 'html' | 'exe' | 'url' | 'bat' | 'py' | 'cmd' | 'ps1' | 'sh'
  enabled: boolean
  configFile?: string
}

const { t } = useI18n()

const tools = ref<Tool[]>([])
const loading = ref(false)
const scanDirPath = ref('')
const showAddDialog = ref(false)
const showScanDialog = ref(false)

const customToolForm = ref({
  name: '',
  description: '',
  programPath: '',
  type: 'exe' as 'html' | 'exe' | 'url' | 'bat' | 'py' | 'cmd' | 'ps1' | 'sh',
  icon: 'Tools'
})

const systemTools = ref<Tool[]>([])

const toolTypes = [
  { label: t('tools.htmlPage'), value: 'html', desc: t('tools.htmlPageDesc') },
  { label: t('tools.executable'), value: 'exe', desc: t('tools.executableDesc') },
  { label: t('tools.urlLink'), value: 'url', desc: t('tools.urlLinkDesc') },
  { label: t('tools.batch'), value: 'bat', desc: t('tools.batchDesc') },
  { label: t('tools.powershell'), value: 'ps1', desc: t('tools.powershellDesc') },
  { label: t('tools.shellScript'), value: 'sh', desc: t('tools.shellScriptDesc') },
  { label: t('tools.pythonScript'), value: 'py', desc: t('tools.pythonScriptDesc') },
  { label: t('tools.cmdCommand'), value: 'cmd', desc: t('tools.cmdCommandDesc') }
]

const iconOptions = [
  'Tools', 'FolderOpened', 'FileJson', 'Link', 'Download', 'Upload', 'Settings', 'Help', 'Info'
]

onMounted(() => {
  loadSystemTools()
})

async function loadSystemTools() {
  try {
    const res = await fetch('/api/tools/list')
    const data = await res.json()
    if (data.code === 0 && Array.isArray(data.data)) {
      systemTools.value = data.data.map((tool: any, index: number) => ({
        id: `system-tool-${index}-${Date.now()}`,
        name: tool.name || tool.Name || tool.path.split('/').pop() || t('tools.unnamedTool'),
        description: tool.description || tool.Description || '',
        path: tool.path || tool.Path || '',
        icon: tool.icon || tool.Icon || 'Tools',
        type: 'system' as const,
        systemType: (tool.type || tool.Type) as Tool['systemType'],
        enabled: tool.enabled !== false,
        configFile: tool.configFile
      }))
    }
    tools.value = [...systemTools.value]
  } catch (e) {
    console.error('Failed to load system tools:', e)
  }
}

async function scanDirectory() {
  if (!scanDirPath.value) {
    ElMessage.warning(t('tools.fillNameAndPath'))
    return
  }

  loading.value = true
  try {
    const res = await fetch(`/api/tools/scan-config?path=${encodeURIComponent(scanDirPath.value)}`)
    const data = await res.json()

    if (data.code === 0) {
      const scannedTools: Tool[] = (data.data || []).map((tool: any, index: number) => ({
        id: `config-tool-${index}-${Date.now()}`,
        name: tool.name || t('tools.unnamedTool'),
        description: tool.description || '',
        path: tool.path || '',
        icon: tool.icon || 'Tools',
        type: 'custom' as const,
        systemType: (tool.type || 'exe') as Tool['systemType'],
        enabled: true,
        configFile: tool.configFile
      }))

      const existingConfigTools = tools.value.filter(t => t.type === 'custom')
      const newTools = [...existingConfigTools, ...scannedTools]
      
      tools.value = [...systemTools.value, ...newTools]
      showScanDialog.value = false
      scanDirPath.value = ''
      
      ElMessage.success(t('tools.scanComplete'))
    } else {
      ElMessage.error(t('common.scanFailed'))
    }
  } catch (e: any) {
    ElMessage.error(t('common.scanFailed') + ': ' + e.message)
  } finally {
    loading.value = false
  }
}

async function addCustomTool() {
  if (!customToolForm.value.name || !customToolForm.value.programPath) {
    ElMessage.warning(t('tools.fillNameAndPath'))
    return
  }

  loading.value = true
  try {
    const res = await fetch('/api/tools/create-config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: customToolForm.value.name,
        description: customToolForm.value.description,
        path: customToolForm.value.programPath,
        type: customToolForm.value.type,
        icon: customToolForm.value.icon
      })
    })

    const data = await res.json()

    if (data.code === 0) {
      const newTool: Tool = {
        id: `custom-${Date.now()}`,
        name: customToolForm.value.name,
        description: customToolForm.value.description,
        path: customToolForm.value.programPath,
        icon: customToolForm.value.icon,
        type: 'custom',
        systemType: customToolForm.value.type,
        enabled: true,
        configFile: data.data?.configFile
      }

      tools.value = [...tools.value, newTool]
      
      customToolForm.value = {
        name: '',
        description: '',
        programPath: '',
        type: 'exe',
        icon: 'Tools'
      }
      showAddDialog.value = false
      ElMessage.success(t('tools.configCreated'))
    } else {
      ElMessage.error(t('common.operationFailed'))
    }
  } catch (e: any) {
    ElMessage.error(t('common.operationFailed') + ': ' + e.message)
  } finally {
    loading.value = false
  }
}

async function removeTool(tool: Tool) {
  try {
    await ElMessageBox.confirm(`${t('tools.deleteTool')} "${tool.name}"?`, t('tools.deleteTool'), {
      confirmButtonText: t('common.delete'),
      cancelButtonText: t('tools.cancel'),
      type: 'warning'
    })

    if (tool.type === 'custom' && tool.configFile) {
      try {
        const res = await fetch('/api/tools/delete-config', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ configFile: tool.configFile })
        })
        const data = await res.json()
        if (data.code !== 0) {
          console.warn('Failed to delete config file:', data.message)
        }
      } catch (e) {
        console.warn('Failed to delete config file:', e)
      }
    }

    tools.value = tools.value.filter(t => t.id !== tool.id)
    ElMessage.success(t('tools.deleteSuccess'))
  } catch {
    // 取消删除
  }
}

async function openTool(tool: Tool) {
  if (tool.enabled === false) {
    ElMessage.warning(t('common.operationFailed'))
    return
  }

  if (tool.type === 'system' || tool.type === 'custom') {
    switch (tool.systemType) {
      case 'html':
      case 'py':
        window.location.href = tool.path
        break
      case 'exe':
      case 'bat':
      case 'cmd':
      case 'ps1':
      case 'sh':
        try {
          const res = await fetch('/api/tools/open', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: tool.path })
          })
          const data = await res.json()
          if (data.code !== 0) {
            ElMessage.error(t('common.operationFailed'))
          }
        } catch (e: any) {
          ElMessage.error(t('common.operationFailed') + ': ' + e.message)
        }
        break
      case 'url':
        window.open(tool.path, '_blank')
        break
      default:
        ElMessage.warning(t('common.operationFailed'))
    }
  } else {
    ElMessage.warning(t('common.operationFailed'))
  }
}

function getIconClass(tool: Tool): string {
  if (tool.icon === 'town-icon') return 'town-icon'
  if (tool.type === 'custom') return 'custom-icon'
  return 'system-icon'
}

function getToolTypeLabel(type?: string): string {
  const found = toolTypes.find(t => t.value === type)
  return found?.label || type || t('tools.unknown')
}
</script>

<template>
  <div class="tools-page">
    <div class="page-header">
      <h1>{{ t('tools.title') }}</h1>
      <p>{{ t('tools.subtitle') }}</p>
    </div>

    <div class="action-bar">
      <el-button type="primary" :icon="FolderOpened" @click="showScanDialog = true">
        {{ t('tools.scanConfigDir') }}
      </el-button>
      <el-button type="success" :icon="Plus" @click="showAddDialog = true">
        {{ t('tools.addCustomTool') }}
      </el-button>
    </div>

    <div v-if="tools.length > 0" class="tools-section">
      <div class="section-header">
        <h3>{{ t('tools.allTools') }}</h3>
        <el-tag type="info" size="small">{{ tools.length }}</el-tag>
      </div>
      <div class="tools-grid">
        <div
          v-for="tool in tools"
          :key="tool.id"
          class="tool-card"
          :class="{ 'tool-card-disabled': !tool.enabled }"
          @click="openTool(tool)"
        >
          <div class="tool-icon" :class="getIconClass(tool)">
            <component :is="tool.icon === 'Tools' ? ToolsIcon : tool.icon === 'FolderOpened' ? FolderOpened : tool.icon === 'FileJson' ? Files : tool.icon === 'Link' ? Link : ToolsIcon" :size="32" />
          </div>
          <div class="tool-info">
            <div class="tool-name">{{ tool.name }}</div>
            <div class="tool-desc">{{ tool.description || t('tools.noDescription') }}</div>
            <div class="tool-type">
              <el-tag size="small" :type="tool.type === 'system' ? 'info' : 'success'">
                {{ tool.type === 'system' ? t('tools.systemTools') : t('tools.custom') }}
              </el-tag>
              <span class="type-label">{{ getToolTypeLabel(tool.systemType) }}</span>
            </div>
          </div>
          <el-button
            v-if="tool.type === 'custom'"
            type="danger"
            size="small"
            circle
            :icon="Delete"
            class="delete-btn"
            @click.stop="removeTool(tool)"
          />
        </div>
      </div>
    </div>

    <div v-else class="empty-state">
      <div class="empty-icon">
        <el-icon :size="48"><ToolsIcon /></el-icon>
      </div>
      <h3>{{ t('tools.noTools') }}</h3>
      <p>{{ t('tools.scanConfigDir') }}</p>
    </div>

    <el-dialog v-model="showScanDialog" :title="t('tools.scanConfigDir')" width="450px">
      <div class="scan-dialog-content">
        <p class="dialog-desc">
          {{ t('tools.scanDesc') }}
        </p>
        <el-input
          v-model="scanDirPath"
          :placeholder="t('tools.scanDirPlaceholder')"
          clearable
        >
          <template #prefix>
            <el-icon><FolderOpened /></el-icon>
          </template>
        </el-input>
        <div class="config-format">
          <h4>{{ t('tools.configFormatTitle') }}</h4>
          <pre>{
  "name": "{{ t('tools.configFormatName') }}",
  "description": "{{ t('tools.configFormatDesc2') }}",
  "icon": "Tools",
  "type": "html|exe|url|bat|py|cmd|ps1|sh",
  "path": "{{ t('tools.configFormatPath') }}"
}</pre>
        </div>
      </div>
      <template #footer>
        <el-button @click="showScanDialog = false">{{ t('tools.cancel') }}</el-button>
        <el-button type="primary" :loading="loading" @click="scanDirectory">{{ t('common.search') }}</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="showAddDialog" :title="t('tools.addCustomTool')" width="500px">
      <el-form :model="customToolForm" label-width="100px">
        <el-form-item :label="t('tools.toolName')" required>
          <el-input v-model="customToolForm.name" :placeholder="t('tools.toolName')" />
        </el-form-item>
        <el-form-item :label="t('tools.toolType')" required>
          <el-select v-model="customToolForm.type" :placeholder="t('tools.toolType')">
            <el-option
              v-for="t in toolTypes"
              :key="t.value"
              :label="t.label"
              :value="t.value"
            >
              <span style="float: left">{{ t.label }}</span>
              <span style="float: right; color: var(--text-muted); font-size: 12px">{{ t.desc }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="t('tools.programPath')" required>
          <el-input v-model="customToolForm.programPath" :placeholder="t('tools.programPath')" />
        </el-form-item>
        <el-form-item :label="t('tools.toolDescription')">
          <el-input v-model="customToolForm.description" :placeholder="t('tools.toolDescription')" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item :label="t('tools.icon')">
          <el-select v-model="customToolForm.icon" :placeholder="t('tools.icon')">
            <el-option
              v-for="icon in iconOptions"
              :key="icon"
              :label="icon"
              :value="icon"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">{{ t('tools.cancel') }}</el-button>
        <el-button type="primary" :loading="loading" @click="addCustomTool">{{ t('tools.createConfig') }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.tools-page {
  padding: 24px;
  height: 100%;
  overflow-y: auto;
}

.page-header {
  margin-bottom: 24px;

  h1 {
    margin: 0 0 8px 0;
    font-size: 1.5rem;
    color: var(--text-primary);
  }

  p {
    margin: 0;
    color: var(--text-secondary);
    font-size: 0.9rem;
  }
}

.action-bar {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
}

.tools-section {
  margin-bottom: 24px;

  .section-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;

    h3 {
      margin: 0;
      font-size: 1rem;
      color: var(--text-primary);
    }
  }
}

.tools-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 16px;
}

.tool-card {
  position: relative;
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: linear-gradient(
    135deg,
    rgba(255, 255, 255, 0.95) 0%,
    rgba(255, 248, 248, 0.95) 50%,
    rgba(255, 255, 255, 0.95) 100%
  );
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.6);
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      120deg,
      transparent 0%,
      rgba(255, 200, 210, 0.4) 25%,
      rgba(251, 180, 195, 0.6) 50%,
      rgba(255, 200, 210, 0.4) 75%,
      transparent 100%
    );
    transition: left 0.6s cubic-bezier(0.4, 0, 0.2, 1);
  }

  &:hover {
    background: linear-gradient(
      135deg,
      rgba(255, 255, 255, 1) 0%,
      rgba(255, 240, 245, 1) 50%,
      rgba(255, 255, 255, 1) 100%
    );
    border-color: rgba(251, 113, 133, 0.45);
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 12px 40px rgba(251, 113, 133, 0.2),
                0 6px 20px rgba(251, 113, 133, 0.12);

    &::before {
      left: 100%;
    }
  }

  .delete-btn {
    position: absolute;
    top: 8px;
    right: 8px;
    opacity: 0;
    transition: opacity 0.2s;
  }

  &:hover .delete-btn {
    opacity: 1;
  }
}

.tool-icon {
  width: 56px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  flex-shrink: 0;
}

.town-icon {
  background: linear-gradient(135deg, var(--bg-tertiary), var(--bg-tertiary));
  color: var(--accent-color);
}

.custom-icon {
  background: linear-gradient(135deg, #fef3f4, #fee2e6);
  color: var(--accent-color);
}

.system-icon {
  background: linear-gradient(135deg, var(--bg-tertiary), var(--bg-tertiary));
  color: var(--accent-color);
}

.tool-info {
  flex: 1;
  min-width: 0;
}

.tool-name {
  font-size: 1rem;
  font-weight: 500;
  color: var(--text-primary);
  margin-bottom: 4px;
}

.tool-desc {
  font-size: 0.85rem;
  color: var(--text-secondary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-bottom: 8px;
}

.tool-type {
  display: flex;
  align-items: center;
  gap: 6px;

  .type-label {
    font-size: 11px;
    color: var(--text-muted);
  }
}

.tool-card-disabled {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  text-align: center;

  .empty-icon {
    margin-bottom: 16px;
    color: var(--text-muted);
  }

  h3 {
    margin: 0 0 8px 0;
    color: var(--text-primary);
  }

  p {
    margin: 0;
    color: var(--text-secondary);
    font-size: 0.9rem;
  }
}

.scan-dialog-content {
  .dialog-desc {
    margin-bottom: 16px;
    color: var(--text-secondary);
    font-size: 0.9rem;
  }

  .config-format {
    margin-top: 16px;
    padding: 12px;
    background: var(--bg-tertiary);
    border-radius: 8px;

    h4 {
      margin: 0 0 8px 0;
      font-size: 0.85rem;
      color: var(--text-primary);
    }

    pre {
      margin: 0;
      font-size: 11px;
      color: var(--text-secondary);
      overflow-x: auto;
    }
  }
}

html.dark {
  .tool-card {
    background: linear-gradient(
      135deg,
      rgba(30, 18, 18, 0.95) 0%,
      rgba(40, 24, 24, 0.95) 50%,
      rgba(30, 18, 18, 0.95) 100%
    );
    border-color: rgba(255, 255, 255, 0.08);

    &::before {
      background: linear-gradient(
        120deg,
        transparent 0%,
        rgba(251, 113, 133, 0.2) 25%,
        rgba(251, 113, 133, 0.3) 50%,
        rgba(251, 113, 133, 0.2) 75%,
        transparent 100%
      );
    }

    &:hover {
      background: linear-gradient(
        135deg,
        rgba(45, 28, 28, 0.98) 0%,
        rgba(55, 35, 35, 0.98) 50%,
        rgba(45, 28, 28, 0.98) 100%
      );
      border-color: rgba(251, 113, 133, 0.25);
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
    }
  }

  .custom-icon {
    background: linear-gradient(135deg, rgba(251, 113, 133, 0.2), rgba(251, 113, 133, 0.1));
  }

  .config-format {
    background: var(--bg-tertiary);
  }
}
</style>