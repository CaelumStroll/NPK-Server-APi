<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick, onBeforeUnmount } from 'vue'
import { useI18n } from 'vue-i18n'
import { onBeforeRouteLeave, useRoute } from 'vue-router'
import { ElMessageBox, ElMessage } from 'element-plus'
import {
  ZoomIn, ZoomOut, Upload, Delete, Plus, Edit,
  Expand, PictureFilled, Refresh, Picture,
  ArrowLeft, ArrowRight, ArrowUp, ArrowDown,
  FullScreen, Document, Files, Link, Close,
  VideoPlay, Sunny, Moon, Monitor, FolderOpened, Download
} from '@element-plus/icons-vue'
import { useDocumentStore } from '@/stores/document'
import { npkApi, albumApi, assetApi } from '@/api'
import { removeBlackBackground as removeBlackBgUtil } from '@/utils/canvas'

const { t } = useI18n()
const route = useRoute()
const store = useDocumentStore()

// ========== NPK ==========
const npkList = ref<any[]>([])
const selectedNpk = ref('')

// ========== 画布 ==========
const canvasRef = ref<HTMLCanvasElement | null>(null)
const canvasContainerRef = ref<HTMLElement | null>(null)
const rulerHCanvasRef = ref<HTMLCanvasElement | null>(null)
const rulerVCanvasRef = ref<HTMLCanvasElement | null>(null)
const zoomLevel = ref(1)
const panX = ref(0)
const panY = ref(0)
const isDragging = ref(false)
// 拖动模式：'none' | 'canvas' | 'image'（互斥，默认 canvas）
const dragMode = ref<'none' | 'canvas' | 'image'>('canvas')
const dragStartX = ref(0)
const dragStartY = ref(0)
const dragStartPanX = ref(0)
const dragStartPanY = ref(0)
// 拖动图像时的临时坐标（用于实时预览）
const dragImageTempX = ref(0)
const dragImageTempY = ref(0)
const isDraggingImage = ref(false)
// 保存拖动开始前的原始坐标（用于取消时还原）
const dragImageOriginalX = ref(0)
const dragImageOriginalY = ref(0)

const showRuler = ref(true)
const pixelate = ref(false)
// 播放控制
const isPlaying = ref(false)
const playInterval = ref<number | null>(null)
const playIntervalTime = 200 // 播放间隔 0.2s
// 画布样式
const removeBlackBg = ref(false) // 是否去黑底
const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto') // 画布背景模式

// ========== 多选 ==========
const selectedSprites = ref<Set<number>>(new Set())
const selectedAlbums = ref<Set<string>>(new Set())

// ========== 对比 ==========
const compareMode = ref(false)
const compareAlbumPath = ref('')
const compareSourceType = ref<'current' | 'external' | 'external-img'>('current') // 对比来源类型
const compareExternalNpk = ref('') // 外部 NPK 路径
const compareExternalImg = ref('') // 外部 IMG 路径
const compareExternalAlbums = ref<{ path: string; name: string }[]>([])
const showExternalNpkDialog = ref(false)
const externalNpkPath = ref('')
const compareNpkCacheKey = ref('') // 上传后的缓存 key
const externalImgFileInput = ref<HTMLInputElement | null>(null) // 外部 IMG 文件输入
const compareImageOpacity = ref(0.5) // 对比图层透明度

// ========== 外部 NPK 编辑 ==========
const isExternalNpkMode = ref(false)
const externalEditNpkPath = ref('')
const externalEditNpkFileInput = ref<HTMLInputElement | null>(null)

// 对比图像缓存
const compareImageCache = new Map<string, HTMLImageElement>()
// 主图像缓存
const mainImageCache = new Map<string, HTMLImageElement>()
// 图像加载中标记
const imageLoading = new Map<string, boolean>()
// 最后计算的画布尺寸缓存
let lastCanvasSize = { width: 0, height: 0, minX: 0, minY: 0, maxX: 0, maxY: 0, offsetX: 0, offsetY: 0 }
// 上一次对比的 Album 路径
let lastCompareAlbum = ''
// 对比 Album 的 Sprite 信息缓存（含 X, Y 坐标）
let compareSpritesCache: any[] = []

// ========== 对话框 ==========
const showNewAlbumDialog = ref(false)
const showRenameDialog = ref(false)
const showEditPropsDialog = ref(false)
const showBatchAddDialog = ref(false)
const showAddLinkDialog = ref(false)

// 属性修改对话框选项
const editPropsTarget = ref<'current' | 'checked' | 'all'>('current')
const editPropsMode = ref<'move' | 'set' | 'frame'>('move')
const editProps = ref({
  moveX: 0,
  moveY: 0,
  x: 0,
  y: 0,
  frameWidth: 0,
  frameHeight: 0
})
const newAlbumPath = ref('')
const newAlbumFile = ref<File | null>(null)
const newAlbumVersion = ref<number>(2)
const renameNewPath = ref('')
const batchAddFiles = ref<File[]>([])
const showConflictDialog = ref(false)
const conflictFiles = ref<{ file: File; targetPath: string; exists: boolean }[]>([])
const conflictDecisions = ref<Record<string, 'replace' | 'skip'>>({})
const applyToAll = ref<'none' | 'replace' | 'skip'>('none')
const linkTargetIndex = ref(0)
const linkInsertPosition = ref<'before' | 'after' | 'end'>('end')
const showBatchImportDialog = ref(false)
const batchImportFiles = ref<File[]>([])
const batchImportPosition = ref<'before' | 'after' | 'end'>('end')
const batchImportReplaceLinks = ref(false)
const batchImportColorFormat = ref('')
const batchImportInputRef = ref<HTMLInputElement | null>(null)
const batchAddInputRef = ref<HTMLInputElement | null>(null)

// ========== 替换帧 ==========
const showReplaceDialog = ref(false)
const replaceFile = ref<File | null>(null)
const replaceColorFormat = ref('ARGB_8888')
const replaceInputRef = ref<HTMLInputElement | null>(null)

// ========== 批量替换 ==========
const showBatchReplaceDialog = ref(false)
const batchReplaceFiles = ref<File[]>([])
const batchReplaceColorFormat = ref('ARGB_8888')
const batchReplaceStartMode = ref<'selected' | 'fromZero'>('fromZero')
const batchReplaceInputRef = ref<HTMLInputElement | null>(null)

// ========== 导入坐标 ==========
const importCoordsInputRef = ref<HTMLInputElement | null>(null)
const externalNpkFileInput = ref<HTMLInputElement | null>(null)

// ========== IMG 引用 ==========
const showAlbumTargetDialog = ref(false)
const albumTargetMode = ref<'add' | 'edit'>('add') // 模式：添加或修改
const newImgRefName = ref('')
const newImgRefTarget = ref('')
const editingAlbumPath = ref('') // 正在编辑的 album

// ========== 引用帧目标修改 ==========
const showModifyLinkDialog = ref(false)
const modifyLinkSpriteIndex = ref(0)
const modifyLinkNewTargetIndex = ref(0)

// ========== 计算属性 ==========
const currentSprite = computed(() => store.selectedSprite)
const hasTextures = computed(() => store.textureList.length > 0)
const allChecked = computed(() => store.spriteList.length > 0 && store.spriteList.every(s => selectedSprites.value.has(s.index)))
// 可作为引用目标的普通帧列表（排除 LINK 帧）
const linkableSprites = computed(() => store.spriteList.filter(s => !s.isLink))

// 判断当前选中的 Album 是否是引用
const currentAlbumIsRef = computed(() => {
  if (!store.selectedAlbumPath) return false
  const album = store.albumList.find(a => a.path === store.selectedAlbumPath)
  return !!album?.targetPath
})

// 过滤后的目标 Album 列表（排除自身）
const filteredTargetAlbums = computed(() => {
  return store.albumList.filter(a => a.path !== editingAlbumPath.value)
})

const canvasTransform = computed(() => ({
  transform: `translate(${panX.value}px, ${panY.value}px) scale(${zoomLevel.value})`,
  transformOrigin: '0 0'
}))

// ========== NPK ==========
async function loadNpkList() {
  try {
    const res = await npkApi.list() as any
    npkList.value = res.data || []
  } catch (e) {
    console.error('Failed to load NPK list', e)
  }
}

async function onSelectNpk(name: string) {
  // 选择NPK时自动停止播放
  stopPlay()
  
  // 检查当前 Album 是否有未保存修改
  if (store.selectedAlbum?.isModified) {
    try {
      await ElMessageBox.confirm(
        t('imgPreview.unsavedChangesWillLose', { name: store.selectedAlbum.name }),
        t('imgPreview.confirmSwitch'),
        {
          confirmButtonText: t('imgPreview.discardChanges'),
          cancelButtonText: t('common.cancel'),
          type: 'warning'
        }
      )
      // 确认放弃：重置当前 Album 状态
      await store.resetState()
    } catch {
      // 取消切换
      return
    }
  }
  
  selectedNpk.value = name
  isExternalNpkMode.value = false
  externalEditNpkPath.value = ''
  selectedSprites.value.clear()
  compareMode.value = false
  if (name) {
    isExternalNpkMode.value = false
    await store.loadDocument(name)
  } else {
    await store.resetState()
  }
}

// 浏览外部 NPK 文件
function browseExternalNpkFile() {
  externalEditNpkFileInput.value?.click()
}

// 处理外部 NPK 文件选择（上传方式）
async function onExternalNpkFileSelected(e: Event) {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  input.value = ''
  
  try {
    const res = await albumApi.uploadExternalNpk(file) as any
    const data = res.data || {}
    const albums = data.albums || data || []
    if (!albums.length) { ElMessage.warning(t('imgPreview.noImgInNpk')); return }
    
    isExternalNpkMode.value = true
    externalEditNpkPath.value = data.key || file.name
    selectedNpk.value = file.name
    store.resetState()
    
    // 将外部 NPK 的 album 数据注入 store
    const order: string[] = []
    const fakeDoc: any = {
      name: file.name, path: file.name,
      modified: new Date(),
      albums: new Map(), order,
      modifiedAlbums: new Set(), deletedAlbums: new Set(), newAlbums: new Set(),
    }
    for (const a of albums) {
      const albumPath = a.Path || a.path || ''
      const sprites = (a.Sprites || a.sprites || []).map((s: any, idx: number) => ({
        index: s.Index ?? s.index ?? idx,
        type: s.Type ?? s.type ?? 0x0e, typeName: '',
        x: s.X ?? s.x ?? 0, y: s.Y ?? s.y ?? 0,
        width: s.Width ?? s.width ?? 0, height: s.Height ?? s.height ?? 0,
        frameWidth: s.FrameWidth ?? s.frameWidth ?? 0, frameHeight: s.FrameHeight ?? s.frameHeight ?? 0,
        compressMode: s.CompressMode ?? 0x06, length: s.DataSize ?? 0,
        textureIndex: -1, textureRect: { leftUp: { x: 0, y: 0 }, rightDown: { x: 0, y: 0 }, top: 0 },
        targetIndex: s.TargetIndex ?? s.targetIndex ?? -1, isLink: s.IsLink ?? s.isLink ?? false,
        isModified: false, isDeleted: false, isNew: false,
      }))
      order.push(albumPath)
      fakeDoc.albums.set(albumPath, {
        path: albumPath, name: a.Name || a.name || albumPath,
        version: (Number(a.Version) || 4) as any,
        offset: 0, length: 0,
        sprites, spriteCount: sprites.length,
        tables: [], textures: [],
        isLoaded: true, isModified: false, isDeleted: false, isNew: false,
        modifiedSprites: new Set(), deletedSprites: new Set(), newSprites: new Set(),
        targetPath: '',
      })
    }
    store.currentDoc = fakeDoc
    ElMessage.success(t('imgPreview.loadedImgCount', { count: albums.length }))
  } catch (err: any) {
    ElMessage.error(t('imgPreview.loadExternalNpkFailed') + ': ' + (err.message || t('imgPreview.unknownError')))
  }
}

// 关闭外部 NPK 模式
function closeExternalNpk() {
  isExternalNpkMode.value = false
  externalEditNpkPath.value = ''
  selectedNpk.value = ''
  store.resetState()
}

function downloadExternalNpk() {
  if (!externalEditNpkPath.value) return
  const url = albumApi.downloadExternalNpkUrl(externalEditNpkPath.value)
  const a = document.createElement('a')
  a.href = url
  a.download = ''
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

// ========== Album 操作 ==========
async function onSelectAlbum(path: string) {
  // 选择Album时自动停止播放
  stopPlay()
  
  // 检查当前 Album 是否有未保存修改
  if (store.selectedAlbum?.isModified && store.selectedAlbumPath !== path) {
    try {
      await ElMessageBox.confirm(
        t('imgPreview.unsavedChangesWillLose', { name: store.selectedAlbum.name }),
        t('imgPreview.confirmSwitch'),
        {
          confirmButtonText: t('imgPreview.discardChanges'),
          cancelButtonText: t('common.cancel'),
          type: 'warning'
        }
      )
      // 确认放弃：还原状态并继续
      store.resetAlbum(store.selectedAlbumPath)
    } catch {
      // 取消切换
      return
    }
  }
  
  selectedSprites.value.clear()
  
  if (isExternalNpkMode.value) {
    // 外部 NPK：sprites 已随上传加载，直接选中
    store.selectedAlbumPath = path
    store.selectedSpriteIndex = 0
  } else {
    await store.loadAlbum(path)
  }
  nextTick(renderSprite)
}

function openNewAlbum() {
  newAlbumPath.value = ''
  newAlbumFile.value = null
  newAlbumVersion.value = 2
  showNewAlbumDialog.value = true
}

// ========== IMG 引用 ==========
// 处理 Album 引用下拉菜单命令
function handleAlbumRefCommand(command: 'add' | 'modify') {
  if (command === 'add') {
    albumTargetMode.value = 'add'
    newImgRefName.value = ''
    newImgRefTarget.value = ''
    editingAlbumPath.value = ''
  } else {
    // 修改模式
    if (!store.selectedAlbumPath) {
      ElMessage.warning(t('imgPreview.selectImgFirst'))
      return
    }
    albumTargetMode.value = 'edit'
    editingAlbumPath.value = store.selectedAlbumPath
    const currentAlbum = store.albumList.find(a => a.path === store.selectedAlbumPath)
    newImgRefName.value = store.selectedAlbumPath
    newImgRefTarget.value = currentAlbum?.targetPath || ''
  }
  showAlbumTargetDialog.value = true
}

async function confirmAlbumTarget() {
  if (!selectedNpk.value) {
    ElMessage.warning(t('imgPreview.selectNpkFirst'))
    return
  }

  if (albumTargetMode.value === 'add') {
    // 添加模式
    const newImgPath = newImgRefName.value.trim()
    const targetPath = newImgRefTarget.value
    
    if (!newImgPath) {
      ElMessage.warning(t('imgPreview.enterNewImgRefName'))
      return
    }
    
    // 检查名称是否已存在
    const exists = store.albumList.some(a => a.path === newImgPath)
    if (exists) {
      ElMessage.warning(t('imgPreview.imgNameExists'))
      return
    }
    
    if (!targetPath) {
      ElMessage.warning(t('imgPreview.selectRefTargetImg'))
      return
    }
    
    try {
      await npkApi.setAlbumTarget(selectedNpk.value, newImgPath, targetPath)
      ElMessage.success(t('imgPreview.imgRefCreated'))
      await store.loadDocument(selectedNpk.value)
      // 将新添加的 IMG 标记为待保存状态，激活保存按钮
      if (store.currentDoc) {
        store.currentDoc.newAlbums.add(newImgPath)
        store.currentDoc.modifiedAlbums.add(newImgPath)
      }
      showAlbumTargetDialog.value = false
    } catch (e: any) {
      ElMessage.error(t('imgPreview.imgRefCreateFailed') + '：' + e.message)
    }
  } else {
    // 修改模式
    const targetPath = newImgRefTarget.value
    
    if (!targetPath) {
      ElMessage.warning(t('imgPreview.selectRefTargetImg'))
      return
    }
    
    try {
      await npkApi.setAlbumTarget(selectedNpk.value, editingAlbumPath.value, targetPath)
      ElMessage.success(t('imgPreview.imgRefModified'))
      await store.loadDocument(selectedNpk.value)
      // 将修改的 IMG 标记为待保存状态，激活保存按钮
      if (store.currentDoc) {
        store.currentDoc.modifiedAlbums.add(editingAlbumPath.value)
      }
      showAlbumTargetDialog.value = false
    } catch (e: any) {
      ElMessage.error(t('imgPreview.imgRefModifyFailed') + '：' + e.message)
    }
  }
}

// 清除 IMG 引用
async function handleClearAlbumTarget() {
  if (!selectedNpk.value || !store.selectedAlbumPath) {
    ElMessage.warning(t('imgPreview.selectImgFirst'))
    return
  }

  try {
    await ElMessageBox.confirm(
      t('imgPreview.confirmClearRef', { path: store.selectedAlbumPath }),
      t('imgPreview.clearRefTitle'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await npkApi.clearAlbumTarget(selectedNpk.value, store.selectedAlbumPath)
    ElMessage.success(t('imgPreview.clearRefSuccess'))
    await store.loadDocument(selectedNpk.value)
  } catch (e: any) {
    if (e !== 'cancel' && e?.message) {
      ElMessage.error(t('imgPreview.clearRefFailed') + '：' + e.message)
    }
  }
}

function onNewAlbumFileChange(e: Event) {
  const input = e.target as HTMLInputElement
  newAlbumFile.value = input.files?.[0] || null
}

async function confirmNewAlbum() {
  const path = newAlbumPath.value.trim()
  if (!path) {
    ElMessage.warning(t('imgPreview.enterPath'))
    return
  }
  
  // 检查路径中是否包含中文括号
  if (path.includes('（') || path.includes('）')) {
    ElMessage.warning(t('imgPreview.noChineseBrackets'))
    return
  }
  
  if (!newAlbumFile.value) {
    ElMessage.warning(t('imgPreview.selectImgFile'))
    return
  }
  try {
    await store.newAlbum(path, newAlbumFile.value)
    showNewAlbumDialog.value = false
  } catch (e: any) {
    ElMessage.error(e.message || t('imgPreview.createFailed'))
  }
}

// ========== 批量导入 Album ==========
function openBatchAddAlbum() {
  batchAddFiles.value = []
  // 清空文件输入元素
  if (batchAddInputRef.value) {
    batchAddInputRef.value.value = ''
  }
  showBatchAddDialog.value = true
}

// 执行批量导入
async function doBatchImport(files: { file: File; targetPath: string }[]) {
  const results: { success: string[], failed: string[] } = { success: [], failed: [] }
  
  try {
    for (const { file, targetPath } of files) {
      const replace = conflictDecisions.value[targetPath] === 'replace'
      const skip = conflictDecisions.value[targetPath] === 'skip'
      
      if (skip) {
        results.failed.push(`${file.name} - ${t('imgPreview.skipped')}`)
        continue
      }
      
      try {
        await store.newAlbum(targetPath, file, replace)
        results.success.push(file.name)
      } catch (e: any) {
        results.failed.push(`${file.name} - ${e.message || t('imgPreview.importFailedSuffix')}`)
      }
    }
    
    // 显示导入结果
    if (results.success.length > 0) {
      ElMessage.success(t('imgPreview.importSuccessCount', { count: results.success.length }))
    }
    if (results.failed.length > 0) {
      const failedMsg = results.failed.slice(0, 5).join('\n')
      const moreMsg = results.failed.length > 5 ? `\n... ${t('imgPreview.moreImportFailed', { count: results.failed.length - 5 })}` : ''
      ElMessage.warning(`${t('imgPreview.importFailedTitle')}：\n${failedMsg}${moreMsg}`)
    }
    
    showBatchAddDialog.value = false
    showConflictDialog.value = false
    batchAddFiles.value = []
    conflictFiles.value = []
    conflictDecisions.value = {}
    // 清空文件输入元素
    if (batchAddInputRef.value) {
      batchAddInputRef.value.value = ''
    }
  } catch (e: any) {
    ElMessage.error(e.message || t('imgPreview.batchImportFailed'))
  }
}

// 确认冲突处理并执行导入
async function confirmConflictAndImport() {
  // 应用全部设置
  for (const cf of conflictFiles.value) {
    if (applyToAll.value !== 'none' && !conflictDecisions.value[cf.targetPath]) {
      conflictDecisions.value[cf.targetPath] = applyToAll.value
    }
  }
  
  // 过滤要导入的文件
  const filesToImport: { file: File; targetPath: string }[] = conflictFiles.value
    .filter(cf => cf.targetPath)
    .map(cf => ({ file: cf.file, targetPath: cf.targetPath }))
  
  await doBatchImport(filesToImport)
}

function onBatchAddFilesChange(e: Event) {
  const input = e.target as HTMLInputElement
  batchAddFiles.value = input.files ? Array.from(input.files) : []
}

async function confirmBatchAddAlbum() {
  if (batchAddFiles.value.length === 0) {
    ElMessage.warning(t('imgPreview.selectAtLeastOneImg'))
    return
  }
  
  if (!store.currentDoc) {
    ElMessage.warning(t('imgPreview.noNpkSelected'))
    return
  }
  
  // 第一步：解析所有文件的目标路径，检查格式错误
  const validFiles: { file: File; targetPath: string }[] = []
  const invalidFiles: string[] = []
  
  for (const file of batchAddFiles.value) {
    const fileName = file.name
    const separatorIndex = fileName.indexOf('@')
    
    if (separatorIndex === -1) {
      invalidFiles.push(`${fileName} - ${t('imgPreview.missingAtSeparator')}`)
      continue
    }
    
    const directoryPath = fileName.substring(0, separatorIndex)
    const imgFileName = fileName.substring(separatorIndex + 1)
    
    if (!directoryPath || !imgFileName) {
      invalidFiles.push(`${fileName} - ${t('imgPreview.emptyDirOrName')}`)
      continue
    }
    
    // 检查中文括号
    if (directoryPath.includes('（') || directoryPath.includes('）') || 
        imgFileName.includes('（') || imgFileName.includes('）')) {
      invalidFiles.push(`${fileName} - ${t('imgPreview.noChineseBracketsInPath')}`)
      continue
    }
    
    // 将目录路径中的下划线转换为斜杠
    const pathWithSlashes = directoryPath.replace(/_/g, '/')
    const targetPath = `${pathWithSlashes}/${imgFileName}`
    validFiles.push({ file, targetPath })
  }
  
  if (invalidFiles.length > 0) {
    const failedMsg = invalidFiles.slice(0, 5).join('\n')
    const moreMsg = invalidFiles.length > 5 ? `\n... ${t('imgPreview.moreFormatErrors', { count: invalidFiles.length - 5 })}` : ''
    ElMessage.warning(`${t('imgPreview.formatErrorTitle')}：\n${failedMsg}${moreMsg}`)
  }
  
  if (validFiles.length === 0) {
    return
  }
  
  // 第二步：检查哪些路径已存在
  conflictFiles.value = []
  conflictDecisions.value = {}
  applyToAll.value = 'none'
  
  const existingPaths = new Set<string>()
  store.albumList.forEach(album => existingPaths.add(album.path))
  
  for (const { file, targetPath } of validFiles) {
    conflictFiles.value.push({ file, targetPath, exists: existingPaths.has(targetPath) })
  }
  
  // 如果没有冲突，直接导入
  const hasConflicts = conflictFiles.value.some(cf => cf.exists)
  
  if (!hasConflicts) {
    await doBatchImport(validFiles)
    return
  }
  
  // 第三步：显示冲突对话框
  showConflictDialog.value = true
}

function openRename() {
  renameNewPath.value = store.selectedAlbumPath
  showRenameDialog.value = true
}

async function confirmRename() {
  const newPath = renameNewPath.value.trim()
  if (!newPath || newPath === store.selectedAlbumPath) {
    showRenameDialog.value = false
    return
  }
  
  // 检查路径中是否包含中文括号
  if (newPath.includes('（') || newPath.includes('）')) {
    ElMessage.warning(t('imgPreview.noChineseBrackets'))
    return
  }
  
  try {
    await store.renameAlbum(newPath)
    showRenameDialog.value = false
  } catch (e: any) {
    ElMessage.error(e.message || t('imgPreview.renameFailed'))
  }
}

// ========== Sprite 操作 ==========
async function selectSprite(index: number) {
  // 检查当前 Sprite 是否有未保存的修改
  if (currentSprite.value?.isModified && index !== currentSprite.value.index) {
    try {
      await ElMessageBox.confirm(
        t('imgPreview.unsavedFrameChanges', { index: currentSprite.value.index }),
        t('imgPreview.confirmSwitch'),
        {
          confirmButtonText: t('imgPreview.discardChanges'),
          cancelButtonText: t('common.cancel'),
          type: 'warning'
        }
      )
      // 确认放弃：还原当前 Sprite 的状态
      store.resetSprite(currentSprite.value.index)
    } catch {
      // 取消切换
      return
    }
  }
  
  store.selectSprite(index)
}

function toggleCheck(index: number, checked: boolean) {
  const next = new Set(selectedSprites.value)
  checked ? next.add(index) : next.delete(index)
  selectedSprites.value = next
}

function toggleAll() {
  selectedSprites.value = allChecked.value ? new Set() : new Set(store.spriteList.map(s => s.index))
}

// ========== Album 多选 ==========
function toggleAlbumCheck(path: string, checked: boolean) {
  const next = new Set(selectedAlbums.value)
  checked ? next.add(path) : next.delete(path)
  selectedAlbums.value = next
}

async function deleteSelectedAlbums() {
  if (selectedAlbums.value.size === 0) return
  try {
    await ElMessageBox.confirm(
      t('imgPreview.confirmDeleteAlbums', { count: selectedAlbums.value.size }),
      t('imgPreview.deleteImgTitle'),
      { type: 'warning' }
    )
    for (const albumPath of selectedAlbums.value) {
      await store.deleteAlbum(albumPath)
    }
    selectedAlbums.value.clear()
  } catch (e: any) {
    if (e !== 'cancel' && e?.message) ElMessage.error(e.message)
  }
}

function openReplace() {
  replaceFile.value = null
  replaceColorFormat.value = 'ARGB_8888'
  showReplaceDialog.value = true
}

function onReplaceFileChange(e: Event) {
  const input = e.target as HTMLInputElement
  replaceFile.value = input.files?.[0] || null
}

async function confirmReplace() {
  if (!replaceFile.value) {
    ElMessage.warning(t('imgPreview.selectImageFile'))
    return
  }
  try {
    await store.replaceSprite(replaceFile.value, replaceColorFormat.value)
    showReplaceDialog.value = false
    renderSprite()
  } catch (err: any) {
    ElMessage.error(err.message || t('imgPreview.replaceFailed'))
  }
}

function openAddSprite() {
  const input = document.createElement('input')
  input.type = 'file'; input.accept = '.png'
  input.onchange = async (e) => {
    const file = (e.target as HTMLInputElement).files?.[0]
    if (file) {
      try { await store.addSprite(file); renderSprite() }
      catch (err: any) { ElMessage.error(err.message || t('imgPreview.addFailed')) }
    }
  }
  input.click()
}

// 处理坐标下拉菜单命令
async function handleCoordsCommand(command: 'export' | 'import') {
  if (command === 'export') {
    try {
      await store.exportCoords()
    } catch (err: any) {
      ElMessage.error(err.message || t('imgPreview.exportFailed'))
    }
  } else {
    // 导入坐标
    importCoordsInputRef.value?.click()
  }
}

// 处理导入坐标文件选择
async function onImportCoordsFileChange(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (file) {
    try {
      await store.importCoords(file)
      renderSprite()
    } catch (err: any) {
      ElMessage.error(err.message || t('imgPreview.importFailed'))
    }
  }
  // 清空 input
  if (importCoordsInputRef.value) {
    importCoordsInputRef.value.value = ''
  }
}

// 处理 Sprite 引用下拉菜单命令
function handleSpriteRefCommand(command: 'add' | 'modify') {
  if (command === 'add') {
    // 添加模式
    if (store.spriteList.length === 0) {
      ElMessage.warning(t('imgPreview.noFrames'))
      return
    }
    // 默认选中当前帧，如果当前帧是 LINK 则选第一个普通帧
    const currentIndex = store.selectedSpriteIndex ?? 0
    if (store.spriteList[currentIndex]?.isLink) {
      const firstNormal = store.spriteList.findIndex(s => !s.isLink)
      linkTargetIndex.value = firstNormal >= 0 ? firstNormal : 0
    } else {
      linkTargetIndex.value = currentIndex
    }
    linkInsertPosition.value = 'end'
    showAddLinkDialog.value = true
  } else {
    // 修改模式：当前帧是引用帧
    const s = currentSprite.value
    if (!s?.isLink) {
      ElMessage.warning(t('imgPreview.onlyModifyLinkTarget'))
      return
    }
    modifyLinkSpriteIndex.value = s.index
    modifyLinkNewTargetIndex.value = s.targetIndex ?? 0
    showModifyLinkDialog.value = true
  }
}

// 处理对比命令
function handleCompareCommand(command: string) {
  if (command === 'select-current') {
    // 开启对比模式后显示选择列表
    if (!compareMode.value) {
      compareMode.value = true
    }
  } else if (command === 'select-external') {
    openExternalNpkDialog()
  } else if (command === 'select-external-img') {
    // 直接打开文件选择
    externalImgFileInput.value?.click()
  } else if (command === 'clear') {
    compareMode.value = false
    compareAlbumPath.value = ''
    compareSourceType.value = 'current'
    compareExternalNpk.value = ''
    compareExternalImg.value = ''
    renderSprite()
  }
}

async function confirmAddLinkSprite() {
  try {
    await store.addLinkSprite(linkTargetIndex.value, linkInsertPosition.value)
    showAddLinkDialog.value = false
    renderSprite()
  } catch (err: any) {
    ElMessage.error(err.message || t('imgPreview.addFailed'))
  }
}

async function confirmModifyLinkSprite() {
  try {
    await store.modifyLinkSpriteTarget(modifyLinkSpriteIndex.value, modifyLinkNewTargetIndex.value)
    showModifyLinkDialog.value = false
    renderSprite()
  } catch (err: any) {
    ElMessage.error(err.message || t('imgPreview.updateFailed'))
  }
}

async function deleteSprite() {
  try {
    await ElMessageBox.confirm(t('imgPreview.confirmDeleteFrame'), t('imgPreview.hint'), { type: 'warning' })
    await store.deleteSprite()
    renderSprite()
  } catch (e: any) {
    if (e !== 'cancel' && e?.message) ElMessage.error(e.message)
  }
}

async function deleteSelectedSprites() {
  if (selectedSprites.value.size === 0) return
  try {
    await ElMessageBox.confirm(t('imgPreview.confirmDeleteFrames', { count: selectedSprites.value.size }), t('imgPreview.hint'), { type: 'warning' })
    await store.deleteSprites([...selectedSprites.value])
    selectedSprites.value.clear()
    renderSprite()
  } catch (e: any) {
    if (e !== 'cancel' && e?.message) ElMessage.error(e.message)
  }
}

function openEditProps() {
  const s = currentSprite.value
  if (!s) return
  editPropsTarget.value = 'current'
  editPropsMode.value = 'move'
  editProps.value = {
    moveX: 0,
    moveY: 0,
    x: s.x || 0,
    y: s.y || 0,
    frameWidth: s.frameWidth || s.width || 0,
    frameHeight: s.frameHeight || s.height || 0
  }
  showEditPropsDialog.value = true
}

async function applyEditProps() {
  if (!store.currentDoc || !store.selectedAlbum) return
  
  const album = store.selectedAlbum
  let indices: number[] = []
  
  // 根据操作目标获取要修改的帧索引
  if (editPropsTarget.value === 'current') {
    // 当前帧
    if (currentSprite.value) {
      indices = [currentSprite.value.index]
    }
  } else if (editPropsTarget.value === 'checked') {
    // 勾选帧
    if (selectedSprites.value.size > 0) {
      indices = [...selectedSprites.value]
    } else {
      ElMessage.warning(t('imgPreview.noCheckedFrames'))
      return
    }
  } else if (editPropsTarget.value === 'all') {
    // 所有帧
    indices = album.sprites.map(s => s.index)
  }
  
  if (indices.length === 0) {
    ElMessage.warning(t('imgPreview.noFramesToModify'))
    return
  }
  
  try {
    for (const index of indices) {
      const sprite = album.sprites.find(s => s.index === index)
      if (!sprite) continue
      
      const props: any = {}
      
      // 根据操作方式处理
      if (editPropsMode.value === 'move') {
        // 移动基准点：相对偏移
        props.x = sprite.x + editProps.value.moveX
        props.y = sprite.y + editProps.value.moveY
      } else if (editPropsMode.value === 'set') {
        // 修改基准点：直接设置
        props.x = editProps.value.x
        props.y = editProps.value.y
      } else if (editPropsMode.value === 'frame') {
        // 修改帧域
        props.frameWidth = editProps.value.frameWidth
        props.frameHeight = editProps.value.frameHeight
      }
      
      await store.updateSpriteProps(index, props)
    }
    
    showEditPropsDialog.value = false
    renderSprite()
    ElMessage.success(t('imgPreview.modifySuccess', { count: indices.length }))
  } catch (e: any) {
    ElMessage.error(e.message || t('imgPreview.updateFailed'))
  }
}

async function moveSpriteByArrow(dx: number, dy: number) {
  try {
    await store.moveSprite(dx, dy)
    renderSprite()
  } catch (e: any) {
    ElMessage.error(e.message || t('imgPreview.moveFailed'))
  }
}

function openBatchReplace() {
  batchReplaceFiles.value = []
  batchReplaceColorFormat.value = 'ARGB_8888'
  if (batchReplaceInputRef.value) {
    batchReplaceInputRef.value.value = ''
  }
  showBatchReplaceDialog.value = true
}

function onBatchReplaceFilesChange(e: Event) {
  const input = e.target as HTMLInputElement
  batchReplaceFiles.value = input.files ? Array.from(input.files) : []
}

async function confirmBatchReplace() {
  if (batchReplaceFiles.value.length === 0) {
    ElMessage.warning(t('imgPreview.selectAtLeastOneImage'))
    return
  }

  const startIndex = batchReplaceStartMode.value === 'selected'
    ? (store.selectedSpriteIndex ?? 0)
    : 0

  try {
    const result = await store.batchReplace(batchReplaceFiles.value, batchReplaceColorFormat.value, startIndex)
    if (result.replaced > 0) {
      ElMessage.success(t('imgPreview.replacedFrames', { count: result.replaced }))
    }
    if (result.imported > 0) {
      ElMessage.warning(t('imgPreview.autoAddedFrames', { count: result.imported }))
    }
    renderSprite()
    batchReplaceFiles.value = []
    batchReplaceColorFormat.value = 'ARGB_8888'
    if (batchReplaceInputRef.value) {
      batchReplaceInputRef.value.value = ''
    }
    showBatchReplaceDialog.value = false
  } catch (err: any) {
    ElMessage.error(err.message || t('imgPreview.batchReplaceFailed'))
  }
}

function openBatchImport() {
  batchImportFiles.value = []
  batchImportPosition.value = 'end'
  batchImportReplaceLinks.value = false
  batchImportColorFormat.value = 'ARGB_8888'
  if (batchImportInputRef.value) {
    batchImportInputRef.value.value = ''
  }
  showBatchImportDialog.value = true
}

function onBatchImportFilesChange(e: Event) {
  const input = e.target as HTMLInputElement
  batchImportFiles.value = input.files ? Array.from(input.files) : []
}

async function confirmBatchImport() {
  if (batchImportFiles.value.length === 0) {
    ElMessage.warning(t('imgPreview.selectAtLeastOneImage'))
    return
  }

  try {
    await store.batchImport(batchImportFiles.value, batchImportPosition.value, batchImportReplaceLinks.value, batchImportColorFormat.value)
    // 成功后重置对话框状态
    batchImportFiles.value = []
    batchImportPosition.value = 'end'
    batchImportReplaceLinks.value = false
    batchImportColorFormat.value = ''
    // 清空文件输入元素
    if (batchImportInputRef.value) {
      batchImportInputRef.value.value = ''
    }
    showBatchImportDialog.value = false
    renderSprite()
  } catch (err: any) {
    ElMessage.error(err.message || t('imgPreview.batchImportFailed'))
  }
}

async function onSave() {
  try {
    await store.saveDocument()
  } catch (e: any) {
    ElMessage.error(e.message || t('imgPreview.saveFailed'))
  }
}

// ========== 播放控制 ==========
// 预加载状态
let preloadState = {
  playList: [] as number[],
  loadedRanges: new Set<string>(),
  pendingRequests: 0,
  maxConcurrent: 5, // 最多同时5个请求
  requestQueue: [] as number[],
}

// 延迟工具函数
function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

// 加载单个帧（带并发控制）
async function preloadFrameWithLimit(spriteIndex: number) {
  // 等待有空闲槽位
  while (preloadState.pendingRequests >= preloadState.maxConcurrent) {
    await delay(100)
  }
  
  preloadState.pendingRequests++
  
  try {
    // 主图
    if (store.currentDoc) {
      const mainUrl = store.getSpriteImageUrl(spriteIndex)
      if (mainUrl && !mainImageCache.has(mainUrl)) {
        const rangeKey = `main_${spriteIndex}`
        preloadState.loadedRanges.add(rangeKey)
        
        const img = new Image()
        img.crossOrigin = 'anonymous'
        await new Promise<void>((resolve) => {
          img.onload = () => {
            mainImageCache.set(mainUrl, img)
            resolve()
          }
          img.onerror = () => resolve()
          img.src = mainUrl
        })
      }
    }
    
    // 对比图
    if (compareMode.value && compareAlbumPath.value) {
      const compareUrl = getCompareImageUrl(spriteIndex)
      if (compareUrl && !compareImageCache.has(compareUrl) && !imageLoading.get(compareUrl)) {
        const compKey = `comp_${spriteIndex}`
        preloadState.loadedRanges.add(compKey)
        imageLoading.set(compareUrl, true)
        
        const img = new Image()
        img.crossOrigin = 'anonymous'
        await new Promise<void>((resolve) => {
          img.onload = () => {
            compareImageCache.set(compareUrl, img)
            imageLoading.delete(compareUrl)
            resolve()
          }
          img.onerror = () => {
            imageLoading.delete(compareUrl)
            resolve()
          }
          img.src = compareUrl
        })
      }
    }
  } finally {
    preloadState.pendingRequests--
  }
}

// 预加载指定范围（使用并发控制）
async function preloadRangeControlled(start: number, count: number) {
  const end = Math.min(start + count, preloadState.playList.length)
  const promises: Promise<void>[] = []
  
  for (let i = start; i < end; i++) {
    const spriteIndex = preloadState.playList[i]
    if (spriteIndex !== undefined) {
      promises.push(preloadFrameWithLimit(spriteIndex))
    }
  }
  
  await Promise.all(promises)
}

// 计算画布最大尺寸
function calculateCanvasSize(playList: number[]) {
  const canvas = canvasRef.value
  if (!canvas || playList.length === 0) return
  
  let maxWidth = 100, maxHeight = 100
  for (const spriteIndex of playList) {
    const sprite = store.spriteList.find(s => s.index === spriteIndex)
    if (sprite) {
      const imgW = sprite.width || 100
      const imgH = sprite.height || 100
      const drawX = sprite.x || 0
      const drawY = sprite.y || 0
      
      // 计算主图像的完整边界
      const mainMinX = drawX
      const mainMinY = drawY
      const mainMaxX = drawX + imgW
      const mainMaxY = drawY + imgH
      
      // 更新最大宽高，确保包含完整的主图像区域和原点
      const mainWidth = mainMaxX - Math.min(mainMinX, 0)
      const mainHeight = mainMaxY - Math.min(mainMinY, 0)
      maxWidth = Math.max(maxWidth, mainWidth)
      maxHeight = Math.max(maxHeight, mainHeight)
      
      if (compareMode.value && compareAlbumPath.value && compareSpritesCache.length > spriteIndex) {
        const compareSprite = compareSpritesCache[spriteIndex]
        const compX = compareSprite?.X ?? compareSprite?.x ?? 0
        const compY = compareSprite?.Y ?? compareSprite?.y ?? 0
        const compareUrl = getCompareImageUrl(spriteIndex)
        const compareImg = compareImageCache.get(compareUrl)
        const compImgW = compareImg?.width || (compareSprite?.Width ?? compareSprite?.width ?? 100)
        const compImgH = compareImg?.height || (compareSprite?.Height ?? compareSprite?.height ?? 100)
        
        // 计算对比图像的完整边界（包含标签预留空间）
        const compMinX = compX
        const compMinY = Math.min(compY, compY - 20)
        const compMaxX = compX + compImgW
        const compMaxY = compY + compImgH
        
        // 更新最大宽高，确保包含完整的对比图像区域
        const compWidth = compMaxX - Math.min(compMinX, 0)
        const compHeight = compMaxY - Math.min(compMinY, 0)
        maxWidth = Math.max(maxWidth, compWidth)
        maxHeight = Math.max(maxHeight, compHeight)
      }
    }
  }
  
  const padding = 10
  canvas.width = maxWidth + padding * 2
  canvas.height = maxHeight + padding * 2
  
  lastCanvasSize = {
    width: canvas.width,
    height: canvas.height,
    minX: 0,
    minY: 0,
    maxX: maxWidth,
    maxY: maxHeight,
    offsetX: padding,
    offsetY: padding
  }
}

function startPlay() {
  let playList: number[]
  if (selectedSprites.value.size >= 2) {
    playList = [...selectedSprites.value]
  } else {
    playList = store.spriteList.map(s => s.index)
  }
  
  if (playList.length <= 0) return
  
  preloadState = {
    playList,
    loadedRanges: new Set<string>(),
    pendingRequests: 0,
    maxConcurrent: 5,
    requestQueue: [],
  }
  
  calculateCanvasSize(playList)
  console.log(`Play pre-calc: canvas size ${canvasRef.value?.width}x${canvasRef.value?.height}`)
  
  // 初始预加载前100帧
  preloadRangeControlled(0, 100)
  
  isPlaying.value = true
  
  if (playInterval.value !== null) {
    clearInterval(playInterval.value)
  }
  
  let currentPlayIndex = 0
  
  playInterval.value = window.setInterval(async () => {
    if (playList.length <= 0) {
      stopPlay()
      return
    }
    
    const currentSpriteIndex = playList[currentPlayIndex]
    store.selectSprite(currentSpriteIndex)
    
    // 提前预加载接下来100帧（异步，不阻塞播放）
    // 只在距离末尾超过50帧时才预加载，避免重复请求最后几帧
    const nextStart = currentPlayIndex + 1
    const framesRemaining = playList.length - nextStart
    if (framesRemaining > 50) {
      // 检查是否已加载该范围，避免重复预加载
      const rangeKey = `${nextStart}-${nextStart + 99}`
      if (!preloadState.loadedRanges.has(rangeKey)) {
        preloadState.loadedRanges.add(rangeKey)
        preloadRangeControlled(nextStart, 100)
      }
    }
    
    currentPlayIndex = (currentPlayIndex + 1) % playList.length
  }, playIntervalTime)
}

// 停止播放
function stopPlay() {
  isPlaying.value = false
  
  if (playInterval.value !== null) {
    clearInterval(playInterval.value)
    playInterval.value = null
  }
}

// 切换播放状态
function togglePlay() {
  if (isPlaying.value) {
    stopPlay()
  } else {
    startPlay()
  }
}

// ========== 对比 ==========
async function onSelectCompareAlbum(path: string) {
  // 清理旧缓存，避免内存泄漏
  compareImageCache.clear()
  mainImageCache.clear()
  imageLoading.clear()
  lastCompareAlbum = ''
  
  compareAlbumPath.value = path
  compareSourceType.value = 'current'
  
  // 缓存对比 Album 的 Sprites 信息
  const album = store.albumList.find(a => a.path === path)
  compareSpritesCache = album?.sprites || []
  
  renderSprite()
}

async function loadExternalNpkAlbums() {
  try {
    console.log('Loading external NPK:', externalNpkPath.value)
    const res = await albumApi.getExternalNpkAlbums(externalNpkPath.value) as any
    console.log('=== Full API Response ===', res)
    console.log('res.data:', res.data)
    console.log('typeof res.data:', typeof res.data)
    console.log('Array.isArray(res.data):', Array.isArray(res.data))
    
    // 尝试多种可能的数据结构
    let albums: any[] = []
    if (Array.isArray(res.data)) {
      albums = res.data
      console.log('Case 1: res.data is array')
    } else if (Array.isArray(res.data?.albums)) {
      albums = res.data.albums
      console.log('Case 2: res.data.albums is array')
    } else if (Array.isArray(res)) {
      albums = res
      console.log('Case 3: res itself is array')
    }
    
    console.log('Final parsed albums:', albums)
    console.log('albums.length:', albums.length)
    
    compareExternalAlbums.value = albums
    console.log('compareExternalAlbums.value after set:', compareExternalAlbums.value)
    
    if (compareExternalAlbums.value.length === 0) {
      ElMessage.warning(t('imgPreview.noImgInNpk'))
    } else {
      ElMessage.success(t('imgPreview.loadedImgCount', { count: albums.length }))
      // 设置对比来源为外部，并关闭对话框
      compareSourceType.value = 'external'
      compareExternalNpk.value = externalNpkPath.value
      compareMode.value = true
      showExternalNpkDialog.value = false
      // 清空之前的选择，让用户重新选择
      compareAlbumPath.value = ''
    }
  } catch (e: any) {
    console.error('Failed to load NPK:', e)
    ElMessage.error(t('imgPreview.loadNpkFailed') + '：' + (e.message || t('imgPreview.unknownError')))
  }
}

async function loadExternalNpkByName(npkName: string) {
  const npk = npkList.value.find(n => n.name === npkName)
  if (npk) {
    externalNpkPath.value = npk.path || npkName
    await loadExternalNpkAlbums()
  }
}

function openExternalNpkDialog() {
  externalNpkPath.value = ''
  compareExternalAlbums.value = []
  showExternalNpkDialog.value = true
}

// 打开外部 NPK 文件选择对话框
function openExternalNpkFileDialog() {
  externalNpkFileInput.value?.click()
}

// 处理对比 NPK 上传
async function handleCompareNpkUpload(e: Event) {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  input.value = ''
  
  try {
    const res = await albumApi.uploadExternalNpk(file) as any
    const data = res.data || {}
    const albums = data.albums || []
    compareExternalAlbums.value = albums.map((a: any) => ({
      path: a.Path || a.path || '',
      name: a.Name || a.name || a.Path || a.path || ''
    }))
    compareNpkCacheKey.value = data.key || ''
    compareSourceType.value = 'external'
    compareMode.value = true
    ElMessage.success(t('imgPreview.loadedImgCount', { count: albums.length }))
  } catch (err: any) {
    ElMessage.error(t('imgPreview.uploadFailed') + ': ' + (err.message || ''))
  }
}

// 选择对比的外部 Album
function selectCompareExternalAlbum(albumPath: string) {
  compareImageCache.clear()
  compareAlbumPath.value = albumPath
  showExternalNpkDialog.value = false
  renderSprite()
}

// 处理外部 IMG 文件选择
async function handleExternalImgFileSelect(event: Event) {
  const target = event.target as HTMLInputElement
  if (target.files && target.files.length > 0) {
    const file = target.files[0]
    await loadExternalImgAlbums(file)
  }
  // 清空 input 以便再次选择同一文件
  target.value = ''
}

// 加载外部 IMG 文件
async function loadExternalImgAlbums(file: File) {
  try {
    console.log('Uploading external IMG:', file.name)
    const res = await albumApi.uploadExternalImg(file) as any
    console.log('External IMG API response:', res)

    let albums: any[] = []
    if (Array.isArray(res.data)) {
      albums = res.data
    } else if (Array.isArray(res.data?.albums)) {
      albums = res.data.albums
    } else if (Array.isArray(res.data?.data)) {
      albums = res.data.data
    }

    // 获取缓存 key
    const key = res.data?.key || res.key

    if (albums.length > 0) {
      // 清理旧缓存，避免内存泄漏
      compareImageCache.clear()
      mainImageCache.clear()
      imageLoading.clear()
      lastCompareAlbum = ''

      compareExternalAlbums.value = albums
      compareExternalImg.value = key || file.name
      compareSourceType.value = 'external-img'

      const albumAny = albums[0] as any
      compareAlbumPath.value = albumAny.Path || file.name

      // 缓存对比 Album 的 Sprites 信息
      compareSpritesCache = albumAny.Sprites || albumAny.sprites || []

      compareMode.value = true

      renderSprite()
      ElMessage.success(t('imgPreview.externalImgLoaded'))
    } else {
      ElMessage.warning(t('imgPreview.noFrameDataInImg'))
    }
  } catch (err: any) {
    console.error('Failed to load external IMG:', err)
    ElMessage.error(err.message || t('imgPreview.loadFailed'))
  }
}

// 从对比区域的列表中选择外部 Album（通过索引）
function selectExternalAlbumFromListByIndex(index: number) {
  const album = compareExternalAlbums.value[index]
  // 清理旧缓存，避免内存泄漏
  compareImageCache.clear()
  mainImageCache.clear()
  imageLoading.clear()
  lastCompareAlbum = ''
  
  // 使用大写的 Path 字段
  const albumAny = album as any
  compareAlbumPath.value = albumAny.Path || ''
  
  // 缓存对比 Album 的 Sprites 信息
  compareSpritesCache = albumAny.Sprites || albumAny.sprites || []
  
  renderSprite()
}

function getCompareImageUrl(frameIndex: number): string {
  if (compareSourceType.value === 'external') {
    if (compareNpkCacheKey.value) {
      return albumApi.getExternalNpkFrameUrlByKey(compareNpkCacheKey.value, compareAlbumPath.value, frameIndex)
    }
    return albumApi.getExternalNpkFrameUrl(compareExternalNpk.value, compareAlbumPath.value, frameIndex)
  } else if (compareSourceType.value === 'external-img') {
    return albumApi.getExternalImgFrameUrl(compareExternalImg.value, frameIndex)
  } else {
    if (!store.currentDoc) return ''
    return assetApi.getImageUrl(store.currentDoc.name, compareAlbumPath.value, frameIndex)
  }
}

// ========== 画布渲染 ==========
watch(() => store.selectedSpriteIndex, () => nextTick(renderSprite))
watch(() => store.spriteList, () => {
  nextTick(() => {
    if (store.spriteList.length > 0) {
      const currentIdx = store.selectedSpriteIndex
      const exists = store.spriteList.some(s => s.index === currentIdx)
      if (!exists) {
        store.selectSprite(store.spriteList[0].index)
      } else {
        renderSprite()
      }
    }
  })
}, { deep: true })
watch(() => [showRuler], () => nextTick(() => {
  renderSprite()
  drawRulers()
}))
watch(removeBlackBg, () => {
  if (currentSprite.value) {
    nextTick(renderSprite)
  }
})
watch(pixelate, () => {
  if (currentSprite.value) {
    nextTick(renderSprite)
  }
})
watch(compareMode, () => {
  if (currentSprite.value) {
    nextTick(renderSprite)
  }
})
watch(compareImageOpacity, () => {
  if (currentSprite.value && compareMode.value && compareAlbumPath.value) {
    nextTick(renderSprite)
  }
})

// 画布背景模式切换
function toggleCanvasBgMode() {
  if (canvasBgMode.value === 'auto') {
    canvasBgMode.value = 'light'
  } else if (canvasBgMode.value === 'light') {
    canvasBgMode.value = 'dark'
  } else {
    canvasBgMode.value = 'light'
  }
}

function renderSprite() {
  if (!canvasRef.value || !currentSprite.value) return
  const canvas = canvasRef.value
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  const sprite = currentSprite.value

  const url = isExternalNpkMode.value
    ? albumApi.getExternalNpkFrameUrlByKey(externalEditNpkPath.value, store.selectedAlbumPath, sprite.index)
    : store.getSpriteImageUrl(sprite.index)
  if (!url) return

  // 检查主图像是否已缓存
  const cachedMainImg = mainImageCache.get(url)
  if (cachedMainImg) {
    // 主图像已缓存，直接使用
    if (compareMode.value && compareAlbumPath.value) {
      // 对比模式：检查对比图像是否已缓存
      const compareUrl = getCompareImageUrl(sprite.index)
      const cachedCompareImg = compareUrl ? compareImageCache.get(compareUrl) : null
      
      if (cachedCompareImg) {
        // 对比图像已缓存，直接渲染
        renderWithComparison(cachedMainImg, cachedCompareImg, sprite)
      } else if (compareUrl) {
        // 对比图像未缓存，异步加载并渲染
        loadCompareAndRender(cachedMainImg, sprite, compareUrl)
      } else {
        renderSingleImage(cachedMainImg, sprite)
      }
    } else {
      // 普通模式：只加载一张图像
      renderSingleImage(cachedMainImg, sprite)
    }
  } else {
    // 主图像未缓存，正常加载
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      // 保存到缓存
      mainImageCache.set(url, img)
      
      if (compareMode.value && compareAlbumPath.value) {
        // 对比模式：检查对比图像是否已缓存
        const compareUrl = getCompareImageUrl(sprite.index)
        const cachedCompareImg = compareUrl ? compareImageCache.get(compareUrl) : null
        
        if (cachedCompareImg) {
          // 对比图像已缓存，直接渲染
          renderWithComparison(img, cachedCompareImg, sprite)
        } else if (compareUrl) {
          // 对比图像未缓存，异步加载并渲染
          loadCompareAndRender(img, sprite, compareUrl)
        } else {
          renderSingleImage(img, sprite)
        }
      } else {
        // 普通模式：只加载一张图像
        renderSingleImage(img, sprite)
      }
    }
    img.onerror = () => {
      const w = sprite.width || 100
      const h = sprite.height || 100
      canvas.width = w
      canvas.height = h
      ctx.clearRect(0, 0, w, h)
    }
    img.src = url
  }
}

// 渲染单张图像（无对比模式）
function renderSingleImage(img: HTMLImageElement, sprite: any, forceResize = false) {
  const canvas = canvasRef.value
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  const imgW = img.width || sprite.width || 100
  const imgH = img.height || sprite.height || 100
  const drawX = sprite.x || 0
  const drawY = sprite.y || 0

  const padding = 10
  const minX = Math.min(0, drawX)
  const minY = Math.min(0, drawY)
  const maxX = Math.max(0, drawX + imgW)  // 图像右边界
  const maxY = Math.max(0, drawY + imgH)  // 图像下边界

  const newWidth = maxX - minX + padding * 2
  const newHeight = maxY - minY + padding * 2

  const shouldResize = forceResize || 
    Math.abs(canvas.width - newWidth) > 10 || 
    Math.abs(canvas.height - newHeight) > 10

  const offsetX = -minX + padding
  const offsetY = -minY + padding

  if (shouldResize) {
    canvas.width = newWidth
    canvas.height = newHeight
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawRulerGrid(ctx, canvas.width, canvas.height, offsetX, offsetY)
  } else {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawRulerGrid(ctx, canvas.width, canvas.height, offsetX, offsetY)
  }

  if (removeBlackBg.value) {
    const tempCanvas = document.createElement('canvas')
    tempCanvas.width = imgW
    tempCanvas.height = imgH
    const tempCtx = tempCanvas.getContext('2d')
    if (tempCtx) {
      tempCtx.drawImage(img, 0, 0)
      removeBlackBgUtil(tempCanvas)
      ctx.drawImage(tempCanvas, offsetX + drawX, offsetY + drawY)
    }
  } else {
    ctx.drawImage(img, offsetX + drawX, offsetY + drawY)
  }

  // 图像尺寸框从图像左上角(offsetX + drawX, offsetY + drawY)开始绘制
  if (imgW > 0 && imgH > 0) {
    ctx.save()
    ctx.strokeStyle = 'rgba(255, 0, 0, 0.6)'
    ctx.lineWidth = 1
    ctx.setLineDash([4, 4])
    ctx.strokeRect(offsetX + drawX, offsetY + drawY, imgW, imgH)
    ctx.restore()
  }
}

// 加载对比图像并渲染（带缓存）
function loadCompareAndRender(mainImg: HTMLImageElement, sprite: any, compareUrl: string) {
  const canvas = canvasRef.value
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  // 检查是否正在加载
  if (imageLoading.get(compareUrl)) {
    // 如果正在加载，先只渲染主图像
    renderSingleImage(mainImg, sprite)
    return
  }

  // 标记正在加载
  imageLoading.set(compareUrl, true)

  const compareImg = new Image()
  compareImg.crossOrigin = 'anonymous'
  compareImg.onload = () => {
    // 缓存对比图像
    compareImageCache.set(compareUrl, compareImg)
    imageLoading.delete(compareUrl)
    // 播放时不清理缓存，保留所有已加载的图像，避免闪烁
    renderWithComparison(mainImg, compareImg, sprite)
  }
  compareImg.onerror = () => {
    imageLoading.delete(compareUrl)
    renderSingleImage(mainImg, sprite)
  }
  compareImg.src = compareUrl
}

// 带对比图层的完整渲染
function renderWithComparison(mainImg: HTMLImageElement, compareImg: HTMLImageElement, sprite: any, forceResize = false) {
  const canvas = canvasRef.value
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  // 主图像信息
  const mainW = mainImg.width || sprite.width || 100
  const mainH = mainImg.height || sprite.height || 100
  const drawX = sprite.x || 0
  const drawY = sprite.y || 0

  // 对比图像信息 - 获取对比图像的基准坐标和尺寸
  const compW = compareImg.width || 100
  const compH = compareImg.height || 100
  let compX = 0
  let compY = 0
  let compareSprite = null as any
  const frameIndex = sprite.index
  if (compareSpritesCache && compareSpritesCache.length > frameIndex) {
    compareSprite = compareSpritesCache[frameIndex]
    compX = compareSprite.X ?? compareSprite.x ?? 0
    compY = compareSprite.Y ?? compareSprite.y ?? 0
  }

  let shouldRecalculate = forceResize
  if (lastCompareAlbum !== compareAlbumPath.value) {
    shouldRecalculate = true
    lastCompareAlbum = compareAlbumPath.value
  }

  const padding = 10
  let minX, minY, maxX, maxY, offsetX, offsetY

  if (shouldRecalculate) {
    // 计算主图像的完整边界 - 确保包含主图像的完整区域
    const mainMinX = drawX  // 主图像左边界
    const mainMinY = drawY  // 主图像上边界
    const mainMaxX = drawX + mainW  // 主图像右边界
    const mainMaxY = drawY + mainH  // 主图像下边界
    
    // 计算对比图像的完整边界 - 确保包含对比图像的完整区域
    const compMinX = compX  // 对比图像左边界
    const compMinY = Math.min(compY, compY - 20)  // 对比图像上边界（包含标签预留空间）
    const compMaxX = compX + compW  // 对比图像右边界
    const compMaxY = compY + compH  // 对比图像下边界
    
    // 合并边界 - 确保两个图像的完整区域都被包含
    minX = Math.min(mainMinX, compMinX, 0)  // 同时包含原点
    minY = Math.min(mainMinY, compMinY, 0)
    maxX = Math.max(mainMaxX, compMaxX, 0)
    maxY = Math.max(mainMaxY, compMaxY, 0)

    canvas.width = maxX - minX + padding * 2
    canvas.height = maxY - minY + padding * 2
    offsetX = -minX + padding
    offsetY = -minY + padding

    lastCanvasSize = { width: canvas.width, height: canvas.height, minX, minY, maxX, maxY, offsetX, offsetY }
    
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawRulerGrid(ctx, canvas.width, canvas.height, offsetX, offsetY)
  } else {
    canvas.width = lastCanvasSize.width
    canvas.height = lastCanvasSize.height
    offsetX = lastCanvasSize.offsetX
    offsetY = lastCanvasSize.offsetY
    
    // 重新计算边界
    const mainMinX = drawX  // 主图像左边界
    const mainMinY = drawY  // 主图像上边界
    const mainMaxX = drawX + mainW  // 主图像右边界
    const mainMaxY = drawY + mainH  // 主图像下边界
    const compMinX = compX  // 对比图像左边界
    const compMinY = Math.min(compY, compY - 20)  // 对比图像上边界（包含标签预留空间）
    const compMaxX = compX + compW  // 对比图像右边界
    const compMaxY = compY + compH  // 对比图像下边界
    const newMinX = Math.min(mainMinX, compMinX, 0)
    const newMinY = Math.min(mainMinY, compMinY, 0)
    const newMaxX = Math.max(mainMaxX, compMaxX, 0)
    const newMaxY = Math.max(mainMaxY, compMaxY, 0)
    
    const newOffsetX = -newMinX + padding
    const newOffsetY = -newMinY + padding
    if (Math.abs(newOffsetX - offsetX) > 50 || Math.abs(newOffsetY - offsetY) > 50) {
      minX = newMinX
      minY = newMinY
      maxX = newMaxX
      maxY = newMaxY
      
      canvas.width = maxX - minX + padding * 2
      canvas.height = maxY - minY + padding * 2
      offsetX = -minX + padding
      offsetY = -minY + padding
      
      lastCanvasSize = { width: canvas.width, height: canvas.height, minX, minY, maxX, maxY, offsetX, offsetY }
      
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      drawRulerGrid(ctx, canvas.width, canvas.height, offsetX, offsetY)
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      drawRulerGrid(ctx, canvas.width, canvas.height, offsetX, offsetY)
    }
  }

  // 绘制主图像
  if (removeBlackBg.value) {
    const tempCanvas = document.createElement('canvas')
    tempCanvas.width = mainW
    tempCanvas.height = mainH
    const tempCtx = tempCanvas.getContext('2d')
    if (tempCtx) {
      tempCtx.drawImage(mainImg, 0, 0)
      removeBlackBgUtil(tempCanvas)
      ctx.drawImage(tempCanvas, offsetX + drawX, offsetY + drawY)
    }
  } else {
    ctx.drawImage(mainImg, offsetX + drawX, offsetY + drawY)
  }

  // 绘制主图像尺寸框 - 从图像左上角开始绘制
  if (mainW > 0 && mainH > 0) {
    ctx.save()
    ctx.strokeStyle = 'rgba(255, 0, 0, 0.6)'
    ctx.lineWidth = 1
    ctx.setLineDash([4, 4])
    ctx.strokeRect(offsetX + drawX, offsetY + drawY, mainW, mainH)
    ctx.restore()
  }

  // 绘制对比图像（半透明） - 使用它自己的基准坐标
  ctx.save()
  ctx.globalAlpha = compareImageOpacity.value
  ctx.drawImage(compareImg, offsetX + compX, offsetY + compY)
  ctx.restore()

  // 绘制对比图像尺寸框
  ctx.save()
  ctx.strokeStyle = 'rgba(0, 200, 255, 0.6)'
  ctx.lineWidth = 2
  ctx.setLineDash([6, 3])
  ctx.strokeRect(offsetX + compX, offsetY + compY, compareSprite.width, compareSprite.height)
  ctx.restore()

  // 显示对比标签
  ctx.save()
  ctx.fillStyle = 'rgba(0, 200, 255, 0.9)'
  ctx.fillRect(offsetX + compX, offsetY + compY - 18, 60, 18)
  ctx.fillStyle = '#fff'
  ctx.font = '10px monospace'
  ctx.fillText(t('imgPreview.compareLabel'), offsetX + compX + 8, offsetY + compY - 5)
  ctx.restore()
}

// 切换拖动模式（互斥）
function toggleDragMode(mode: 'canvas' | 'image') {
  if (dragMode.value === mode) {
    // 再次点击取消选择
    dragMode.value = 'none'
  } else {
    dragMode.value = mode
  }
}

// 绘制0点十字线和像素网格
function drawRulerGrid(ctx: CanvasRenderingContext2D, w: number, h: number, offsetX: number, offsetY: number) {
  ctx.save()
  
  // 根据背景模式使用不同的网格颜色
  if (canvasBgMode.value === 'light') {
    ctx.strokeStyle = 'rgba(0,0,0,0.1)'
  } else {
    ctx.strokeStyle = 'rgba(255,255,255,0.08)'
  }
  ctx.lineWidth = 1
  
  // 10像素网格
  for (let x = 0; x < w; x += 10) {
    const realX = x - offsetX
    if (realX >= 0) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke()
    }
  }
  for (let y = 0; y < h; y += 10) {
    const realY = y - offsetY
    if (realY >= 0) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
    }
  }
  
  // 0点十字线（红色）
  ctx.strokeStyle = 'rgba(255,0,0,0.6)'
  ctx.lineWidth = 2
  
  // 0点水平线
  ctx.beginPath()
  ctx.moveTo(0, offsetY)
  ctx.lineTo(w, offsetY)
  ctx.stroke()
  
  // 0点垂直线
  ctx.beginPath()
  ctx.moveTo(offsetX, 0)
  ctx.lineTo(offsetX, h)
  ctx.stroke()
  
  ctx.restore()
}

// ========== 标尺绘制 ==========
function drawRulers() {
  drawHRuler()
  drawVRuler()
}

function drawHRuler() {
  const canvas = rulerHCanvasRef.value
  if (!canvas || !canvasContainerRef.value) return
  const rect = canvasContainerRef.value.getBoundingClientRect()
  canvas.width = rect.width - 20
  canvas.height = 20
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  // Bug3 修复：从 CSS 变量获取颜色
  const style = getComputedStyle(document.documentElement)
  const bgTertiary = style.getPropertyValue('--bg-tertiary').trim() || '#252542'
  const borderColor = style.getPropertyValue('--border-color').trim() || '#3d3d66'
  const textMuted = style.getPropertyValue('--text-muted').trim() || '#8888aa'

  ctx.fillStyle = bgTertiary
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.strokeStyle = borderColor
  ctx.lineWidth = 1
  ctx.strokeRect(0, 0, canvas.width, canvas.height)

  const scale = zoomLevel.value
  const offset = panX.value
  ctx.fillStyle = textMuted
  ctx.font = '9px monospace'
  ctx.textAlign = 'center'

  // 根据缩放级别决定刻度间距
  let step = 10
  if (scale < 0.5) step = 100
  else if (scale < 1) step = 50
  else if (scale < 2) step = 20
  else if (scale < 4) step = 10
  else step = 5

  const startPx = Math.floor(-offset / scale / step) * step
  const endPx = Math.ceil((canvas.width - offset) / scale / step) * step

  for (let px = startPx; px <= endPx; px += step) {
    const screenX = px * scale + offset
    if (screenX < 0 || screenX > canvas.width) continue

    const isMajor = px % (step * 5) === 0
    ctx.strokeStyle = isMajor ? textMuted : (style.getPropertyValue('--text-secondary').trim() || '#555577')
    ctx.beginPath()
    ctx.moveTo(screenX, isMajor ? 4 : 12)
    ctx.lineTo(screenX, 20)
    ctx.stroke()

    if (isMajor && px >= 0) {
      ctx.fillText(String(px), screenX, 10)
    }
  }

  // 原点标记
  const originX = offset
  if (originX >= 0 && originX <= canvas.width) {
    ctx.strokeStyle = '#ff6666'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(originX, 0)
    ctx.lineTo(originX, 20)
    ctx.stroke()
  }
}

function drawVRuler() {
  const canvas = rulerVCanvasRef.value
  if (!canvas || !canvasContainerRef.value) return
  const rect = canvasContainerRef.value.getBoundingClientRect()
  canvas.width = 20
  canvas.height = rect.height - 20
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  // Bug3 修复：从 CSS 变量获取颜色
  const style = getComputedStyle(document.documentElement)
  const bgTertiary = style.getPropertyValue('--bg-tertiary').trim() || '#252542'
  const borderColor = style.getPropertyValue('--border-color').trim() || '#3d3d66'
  const textMuted = style.getPropertyValue('--text-muted').trim() || '#8888aa'

  ctx.fillStyle = bgTertiary
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.strokeStyle = borderColor
  ctx.lineWidth = 1
  ctx.strokeRect(0, 0, canvas.width, canvas.height)

  const scale = zoomLevel.value
  const offset = panY.value
  ctx.fillStyle = textMuted
  ctx.font = '9px monospace'
  ctx.textAlign = 'center'

  let step = 10
  if (scale < 0.5) step = 100
  else if (scale < 1) step = 50
  else if (scale < 2) step = 20
  else if (scale < 4) step = 10
  else step = 5

  const startPx = Math.floor(-offset / scale / step) * step
  const endPx = Math.ceil((canvas.height - offset) / scale / step) * step

  for (let px = startPx; px <= endPx; px += step) {
    const screenY = px * scale + offset
    if (screenY < 0 || screenY > canvas.height) continue

    const isMajor = px % (step * 5) === 0
    ctx.strokeStyle = isMajor ? textMuted : (style.getPropertyValue('--text-secondary').trim() || '#555577')
    ctx.beginPath()
    ctx.moveTo(isMajor ? 4 : 12, screenY)
    ctx.lineTo(20, screenY)
    ctx.stroke()

    if (isMajor && px >= 0) {
      ctx.save()
      ctx.translate(10, screenY)
      ctx.rotate(-Math.PI / 2)
      ctx.fillText(String(px), 0, 3)
      ctx.restore()
    }
  }

  // 原点标记
  const originY = offset
  if (originY >= 0 && originY <= canvas.height) {
    ctx.strokeStyle = '#ff6666'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(0, originY)
    ctx.lineTo(20, originY)
    ctx.stroke()
  }
}

// ========== 画布操作 ==========
function zoomIn() { zoomLevel.value = Math.min(zoomLevel.value * 1.25, 32); nextTick(drawRulers) }
function zoomOut() { zoomLevel.value = Math.max(zoomLevel.value / 1.25, 0.1); nextTick(drawRulers) }
function zoomReset() { zoomLevel.value = 1; panX.value = 0; panY.value = 0; nextTick(drawRulers) }

function onMouseDown(e: MouseEvent) {
  // 只在画布区域内响应（排除工具栏、标尺等）
  const target = e.target as HTMLElement
  const isCanvasArea = target.closest('.canvas-main') || target.closest('.canvas-area')
  if (!isCanvasArea) return
  // 排除工具栏按钮点击
  if (target.closest('.canvas-tools')) return
  if (dragMode.value === 'none') return
  
  isDragging.value = true
  dragStartX.value = e.clientX
  dragStartY.value = e.clientY
  dragStartPanX.value = panX.value
  dragStartPanY.value = panY.value
  
  // 拖动图像模式：初始化临时坐标并保存原始坐标
  if (dragMode.value === 'image' && currentSprite.value) {
    isDraggingImage.value = true
    dragImageOriginalX.value = currentSprite.value.x
    dragImageOriginalY.value = currentSprite.value.y
    dragImageTempX.value = currentSprite.value.x
    dragImageTempY.value = currentSprite.value.y
  }
}

function onMouseMove(e: MouseEvent) {
  if (!isDragging.value) return
  const dx = e.clientX - dragStartX.value
  const dy = e.clientY - dragStartY.value
  
  if (dragMode.value === 'canvas') {
    // 拖动画布：移动视图
    panX.value = dragStartPanX.value + dx
    panY.value = dragStartPanY.value + dy
    drawRulers()
  } else if (dragMode.value === 'image' && currentSprite.value && isDraggingImage.value) {
    // 拖动图像：改变基准坐标（基于原始坐标计算偏移）
    const scaleX = dx / zoomLevel.value
    const scaleY = dy / zoomLevel.value
    dragImageTempX.value = dragImageOriginalX.value + Math.round(scaleX)
    dragImageTempY.value = dragImageOriginalY.value + Math.round(scaleY)
    // 实时渲染预览
    renderSpriteWithOffset(dragImageTempX.value, dragImageTempY.value)
  }
}

function onMouseUp() {
  if (!isDragging.value) return
  
  // 拖动图像模式结束：只更新本地状态，不自动调用 API
  if (dragMode.value === 'image' && currentSprite.value && isDraggingImage.value) {
    const newX = dragImageTempX.value
    const newY = dragImageTempY.value
    const originalX = dragImageOriginalX.value
    const originalY = dragImageOriginalY.value
    
    // 检查是否有变化
    if (newX !== originalX || newY !== originalY) {
      // 直接更新本地坐标
      const sprite = currentSprite.value
      sprite.x = newX
      sprite.y = newY
      sprite.isModified = true
      // 标记 Album 为已修改
      const album = store.selectedAlbum
      if (album) {
        album.isModified = true
        album.modifiedSprites.add(sprite.index)
        if (store.currentDoc) {
          store.currentDoc.modifiedAlbums.add(store.selectedAlbumPath)
        }
      }
      // 保存原始坐标（用于取消时回滚）
      if (sprite.originalX === undefined) sprite.originalX = originalX
      if (sprite.originalY === undefined) sprite.originalY = originalY
    }
    isDraggingImage.value = false
    // 刷新最终渲染效果
    renderSprite()
  }
  
  isDragging.value = false
}

// 拖动图像时的缓存 Image 对象（避免每帧重新加载）
let dragImageObj: HTMLImageElement | null = null
let dragImageSrc = ''

// 带偏移量的实时渲染（拖动图像预览）
function renderSpriteWithOffset(offsetX: number, offsetY: number) {
  if (!canvasRef.value || !currentSprite.value) return
  const canvas = canvasRef.value
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  const s = currentSprite.value

  const url = store.getSpriteImageUrl(s.index)
  if (!url) return

  // 复用 Image 对象避免闪烁
  if (!dragImageObj || dragImageSrc !== url) {
    dragImageObj = new Image()
    dragImageObj.crossOrigin = 'anonymous'
    dragImageSrc = url
  }

  const render = () => {
    if (!dragImageObj) return
    
    // 获取尺寸
    const imgW = dragImageObj.naturalWidth || s.width || 100
    const imgH = dragImageObj.naturalHeight || s.height || 100
    
    // 获取对比图像信息（如果存在）
    let compX = 0, compY = 0, compW = 0, compH = 0
    if (compareMode.value && compareAlbumPath.value) {
      const compareUrl = getCompareImageUrl(s.index)
      const compareImg = compareImageCache.get(compareUrl)
      if (compareImg && compareSpritesCache.length > s.index) {
        const compareSprite = compareSpritesCache[s.index]
        compX = compareSprite.X ?? compareSprite.x ?? 0
        compY = compareSprite.Y ?? compareSprite.y ?? 0
        compW = compareImg.width || 100
        compH = compareImg.height || 100
      }
    }
    
    // 计算画布尺寸：使用原始基准坐标（非拖动偏移量）来保持画布稳定
    // 这样对比图像的位置就不会随主图像拖动而变化
    const padding = 10
    const originalX = s.x || 0
    const originalY = s.y || 0
    
    // 画布尺寸基于原始坐标和对比图像坐标计算，不受拖动影响
    // 计算主图像的完整边界 - 确保包含主图像的完整区域
    const mainMinX = originalX  // 主图像左边界
    const mainMinY = originalY  // 主图像上边界
    const mainMaxX = originalX + imgW  // 主图像右边界
    const mainMaxY = originalY + imgH  // 主图像下边界
    
    // 计算对比图像的完整边界 - 确保包含对比图像的完整区域
    const compMinX = compX  // 对比图像左边界
    const compMinY = compY  // 对比图像上边界
    const compMaxX = compX + compW  // 对比图像右边界
    const compMaxY = compY + compH  // 对比图像下边界
    
    // 合并边界 - 确保两个图像的完整区域都被包含
    const minX = Math.min(mainMinX, compMinX, 0)  // 同时包含原点
    const minY = Math.min(mainMinY, compMinY, 0)
    const maxX = Math.max(mainMaxX, compMaxX, 0)
    const maxY = Math.max(mainMaxY, compMaxY, 0)
    
    const newWidth = maxX - minX + padding * 2
    const newHeight = maxY - minY + padding * 2
    
    // 更新画布尺寸
    if (canvas.width !== newWidth || canvas.height !== newHeight) {
      canvas.width = newWidth
      canvas.height = newHeight
    }
    
    // 计算固定的偏移量（基于帧域左上角(0,0)，不随拖动变化）
    const offX = -minX + padding
    const offY = -minY + padding
    
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    
    // 绘制0点十字线和网格
    drawRulerGrid(ctx, canvas.width, canvas.height, offX, offY)
    
    // 绘制图像（支持去黑底）- 使用当前拖动的偏移量
    if (removeBlackBg.value) {
      const tempCanvas = document.createElement('canvas')
      tempCanvas.width = imgW
      tempCanvas.height = imgH
      const tempCtx = tempCanvas.getContext('2d')
      if (tempCtx) {
        tempCtx.drawImage(dragImageObj, 0, 0)
        removeBlackBgUtil(tempCanvas)
        ctx.drawImage(tempCanvas, offX + offsetX, offY + offsetY)
      }
    } else {
      ctx.drawImage(dragImageObj, offX + offsetX, offY + offsetY)
    }
    
    // 绘制图像尺寸框 - 从图像左上角开始绘制
    if (imgW > 0 && imgH > 0) {
      ctx.save()
      ctx.strokeStyle = 'rgba(255, 0, 0, 0.6)'
      ctx.lineWidth = 1
      ctx.setLineDash([4, 4])
      ctx.strokeRect(offX + originalX, offY + originalY, imgW, imgH)
      ctx.restore()
    }
    
    // 对比模式：绘制对比图像（按照自身偏移计算位置）
    if (compareMode.value && compareAlbumPath.value && compW > 0 && compH > 0) {
      const compareUrl = getCompareImageUrl(s.index)
      const compareImg = compareImageCache.get(compareUrl)
      if (compareImg) {
        // 对比图像完全按照自身的基准坐标绘制，不受主图像拖动影响
        // 使用统一的图像左上角作为基准，对比图像的位置 = offX + compX
        ctx.save()
        ctx.globalAlpha = compareImageOpacity.value
        ctx.drawImage(compareImg, offX + compX, offY + compY)
        ctx.restore()
        
        // 绘制对比图像尺寸框
        ctx.save()
        ctx.strokeStyle = 'rgba(0, 200, 255, 0.6)'
        ctx.lineWidth = 2
        ctx.setLineDash([6, 3])
        ctx.strokeRect(offX + compX, offY + compY, compW, compH)
        ctx.restore()
      }
    }
    
    // 显示坐标提示
    ctx.fillStyle = 'rgba(255,255,0,0.8)'
    ctx.font = '12px monospace'
    ctx.fillText(`X:${offsetX}, Y:${offsetY}`, 5, 15)
  }

  if (dragImageObj && dragImageObj.complete && dragImageObj.naturalWidth > 0) {
    render()
  } else if (dragImageObj) {
    dragImageObj.onload = () => {
      render()
    }
    if (!dragImageObj.src || dragImageObj.src === '') {
      dragImageObj.src = url
    }
  } else {
    // 创建新的图像对象
    const newImg = new Image()
    newImg.crossOrigin = 'anonymous'
    newImg.onload = () => {
      dragImageObj = newImg
      dragImageSrc = url
      render()
    }
    newImg.src = url
  }
}

function onWheel(e: WheelEvent) {
  e.preventDefault()
  if (e.deltaY < 0) zoomIn()
  else zoomOut()
}

// ========== 生命周期 ==========
onMounted(async () => {
  await loadNpkList()
  
  // 从路由参数自动选择 NPK 和 Album
  const npkFromQuery = route.query.npk as string
  const albumFromQuery = route.query.album as string
  if (npkFromQuery) {
    await onSelectNpk(npkFromQuery)
    if (albumFromQuery) {
      await onSelectAlbum(albumFromQuery)
    }
  }
  
  window.addEventListener('mousemove', onMouseMove)
  window.addEventListener('mouseup', onMouseUp)
})

onBeforeUnmount(() => {
  window.removeEventListener('mousemove', onMouseMove)
  window.removeEventListener('mouseup', onMouseUp)
  // 组件卸载时停止播放
  stopPlay()
})

onBeforeRouteLeave(async () => {
  if (store.hasUnsavedChanges) {
    try {
      await ElMessageBox.confirm(t('imgPreview.unsavedWillLose'), t('imgPreview.hint'), { type: 'warning' })
      await store.resetState()
      return true
    } catch {
      return false
    }
  }
  await store.resetState()
  return true
})
</script>

<template>
  <div class="img-editor">
    <!-- 顶部栏 -->
    <div class="top-bar">
      <div class="top-left">
        <h2>{{ t('imgPreview.title') }}</h2>
      </div>
      <div class="top-center">
      </div>
      <div class="top-right">
        <el-tag v-if="store.modifiedCount > 0" type="warning" size="small" effect="dark">{{ t('imgPreview.unsavedItems', { count: store.modifiedCount }) }}</el-tag>
        <el-button type="primary" size="small" :icon="Upload" :disabled="!store.hasUnsavedChanges" @click="onSave">{{ t('imgPreview.save') }}</el-button>
      </div>
    </div>

    <div class="main-area">
      <!-- 左侧：Album + Sprite 列表 -->
      <div class="left-panel">
        <!-- NPK 选择 -->
        <div class="panel-section">
          <div class="section-header">
            <span>{{ t('imgPreview.npkFile') }}</span>
          </div>
          <div class="npk-select-wrapper">
            <el-select v-model="selectedNpk" :placeholder="t('imgPreview.selectNpk')" filterable size="small" style="width: 100%" @update:model-value="onSelectNpk($event as string)" :disabled="isExternalNpkMode">
              <el-option v-for="n in npkList" :key="n.name" :label="n.name" :value="n.name" />
            </el-select>
            <div v-if="isExternalNpkMode" style="display:flex;gap:4px;margin-top:4px">
              <el-button size="small" style="flex:1;overflow:hidden;text-overflow:ellipsis" :title="externalEditNpkPath">
                {{ externalEditNpkPath.split(/[/\\]/).pop() || t('imgPreview.externalNpk') }}
              </el-button>
              <el-button size="small" @click="downloadExternalNpk" :icon="Download" :title="t('imgPreview.downloadNpk')" />
              <el-button size="small" :icon="Close" @click="closeExternalNpk" :title="t('imgPreview.closeExternalNpk')" />
            </div>
            <el-button v-else size="small" :icon="FolderOpened" style="margin-top:4px;width:100%" @click="browseExternalNpkFile">
              {{ t('imgPreview.browseExternalFile') }}
            </el-button>
            <input ref="externalEditNpkFileInput" type="file" accept=".npk" style="display:none" @change="onExternalNpkFileSelected" />
          </div>
        </div>
        
        <!-- Album 列表 -->
        <div class="panel-section">
          <div class="section-header">
            <span>{{ t('imgPreview.imgFiles') }} ({{ selectedAlbums.size }}/{{ store.albumList.length }})</span>
            <div class="header-btns">
              <el-button size="small" :icon="Delete" @click="deleteSelectedAlbums" :disabled="selectedAlbums.size === 0" :title="t('imgPreview.deleteSelected')"></el-button>
              <el-button size="small" :icon="Plus" @click="openNewAlbum" :disabled="!selectedNpk" :title="t('imgPreview.newImg')"></el-button>
            </div>
          </div>
          <div class="album-list">
            <div v-for="album in store.albumList" :key="album.path" class="album-item" :class="{ active: store.selectedAlbumPath === album.path, modified: album.isModified, 'has-target': album.targetPath }" @click="onSelectAlbum(album.path)">
              <input type="checkbox" class="cb" :checked="selectedAlbums.has(album.path)" @click.stop @change="toggleAlbumCheck(album.path, ($event.target as HTMLInputElement).checked)">
              <span class="name">{{ album.name }}</span>
              <span v-if="album.targetPath" class="target-arrow">→</span>
              <span v-if="album.targetPath" class="target-name">{{ album.targetPath.split('/').pop() }}</span>
              <span class="count">{{ album.spriteCount }}</span>
            </div>
            <div v-if="selectedNpk && store.albumList.length === 0" class="empty">{{ t('imgPreview.noImgFiles') }}</div>
          </div>
        </div>

        <!-- Sprite 列表 -->
        <div class="panel-section flex">
          <div class="section-header">
            <span>{{ t('imgPreview.frameList') }} ({{ selectedSprites.size }}/{{ store.spriteList.length }})</span>
            <div class="header-btns">
              <el-button size="small" :icon="Delete" @click="deleteSelectedSprites" :disabled="selectedSprites.size === 0" :title="t('imgPreview.deleteSelected')"></el-button>
              <el-dropdown trigger="click" @command="(cmd: string) => cmd === 'add' && openAddSprite()">
                <el-button size="small" :icon="Plus" :disabled="!store.selectedAlbumPath">{{ t('imgPreview.addFrame') }} <el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item command="add" :icon="Picture">{{ t('imgPreview.addImage') }}</el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </div>
          </div>
          <!-- 表头 -->
          <div v-if="store.spriteList.length > 0" class="tbl-header">
            <input type="checkbox" class="cb" :checked="allChecked" @change="toggleAll()">
            <span class="c-idx">#</span>
            <span class="c-type">{{ t('imgPreview.format') }}</span>
            <span class="c-pos">{{ t('imgPreview.origin') }}</span>
            <span class="c-size">{{ t('imgPreview.size') }}</span>
            <span class="c-frame">{{ t('imgPreview.frameRect') }}</span>
            <span v-if="hasTextures" class="c-tex">{{ t('imgPreview.textureSet') }}</span>
          </div>
          <div class="sprite-list">
            <div v-for="s in store.spriteList" :key="s.index" class="sprite-item" :class="{ active: store.selectedSpriteIndex === s.index, modified: s.isModified, 'is-new': s.isNew }" @click="selectSprite(s.index)">
              <input type="checkbox" class="cb" :checked="selectedSprites.has(s.index)" @click.stop @change="toggleCheck(s.index, ($event.target as HTMLInputElement).checked)">
              <span class="c-idx">{{ s.index }}</span>
              <template v-if="s.isLink">
                <span class="c-type">LINK</span>
                <span class="c-pos">
                  <template v-if="s.linkStatus === 'normal'">{{ t('imgPreview.refFrame', { index: s.targetIndex }) }}</template>
                  <template v-else-if="s.linkStatus === 'null'">{{ t('imgPreview.nullPointer') }}</template>
                  <template v-else-if="s.linkStatus === 'circular'">{{ t('imgPreview.circularRef') }}</template>
                  <template v-else>{{ t('imgPreview.refFrame', { index: s.targetIndex }) }}</template>
                </span>
                <span class="c-size">-×-</span>
                <span class="c-frame">-×-</span>
              </template>
              <template v-else>
                <span class="c-type">{{ s.typeName }}</span>
                <span class="c-pos">{{ s.x }},{{ s.y }}</span>
                <span class="c-size">{{ s.width }}×{{ s.height }}</span>
                <span class="c-frame">{{ s.frameWidth }}×{{ s.frameHeight }}</span>
              </template>
              <span v-if="hasTextures && s.textureIndex >= 0" class="c-tex">T{{ s.textureIndex }}</span>
              <div class="ops" @click.stop>
                <el-button size="small" text :icon="Upload" @click="openReplace" :title="t('imgPreview.replace')" />
                <el-button size="small" text :icon="Delete" @click="deleteSprite" :title="t('imgPreview.delete')" />
              </div>
            </div>
          </div>
          <div v-if="store.selectedAlbumPath && store.spriteList.length === 0" class="empty">{{ t('imgPreview.noFrameData') }}</div>

          <!-- 纹理集 -->
          <div v-if="store.textureList.length > 0" class="tex-section">
            <div class="section-header"><span>{{ t('imgPreview.textureSet') }} ({{ store.textureList.length }})</span></div>
            <div class="tbl-header">
              <span class="t-idx">{{ t('imgPreview.textureSet') }}</span>
              <span class="t-type">{{ t('imgPreview.format') }}</span>
              <span class="t-size">{{ t('imgPreview.size') }}</span>
            </div>
            <div class="tex-list">
              <div v-for="t in store.textureList" :key="t.index" class="tex-item">
                <span class="t-idx">{{ t.index }}</span>
                <span class="t-type">{{ t.typeName }}</span>
                <span class="t-size">{{ t.width }}×{{ t.height }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 中间：画布 -->
      <div class="canvas-area" ref="canvasContainerRef" @mousedown="onMouseDown" @wheel="onWheel">
        <!-- 左上角原点 -->
        <div v-if="showRuler" class="ruler-corner">
          <svg width="20" height="20" viewBox="0 0 20 20">
            <line x1="0" y1="10" x2="20" y2="10" stroke="#ff6666" stroke-width="1" />
            <line x1="10" y1="0" x2="10" y2="20" stroke="#ff6666" stroke-width="1" />
          </svg>
        </div>
        <!-- 水平标尺 -->
        <div v-if="showRuler" class="ruler-h">
          <canvas ref="rulerHCanvasRef" height="20" />
        </div>
        <!-- 垂直标尺 -->
        <div v-if="showRuler" class="ruler-v">
          <canvas ref="rulerVCanvasRef" width="20" />
        </div>
        <!-- 画布主体 -->
        <div class="canvas-main" :class="canvasBgMode">
          <div v-if="currentSprite" class="canvas-wrapper" :style="canvasTransform">
            <canvas ref="canvasRef" :style="{ imageRendering: pixelate && zoomLevel >= 2 ? 'pixelated' : 'auto' }" />
          </div>
          <div v-else class="placeholder">
            <el-icon :size="48"><PictureFilled /></el-icon>
            <span>{{ t('imgPreview.selectImgToView') }}</span>
          </div>
        </div>
        <!-- 工具栏 -->
        <div class="canvas-tools">
          <!-- 缩放和方向调整 -->
          <el-button-group size="small">
            <el-button :icon="ZoomOut" @click="zoomOut" />
            <el-button @click="zoomReset" style="min-width:56px">{{ Math.round(zoomLevel * 100) }}%</el-button>
            <el-button :icon="ZoomIn" @click="zoomIn" />
          </el-button-group>
          <el-button-group size="small" style="margin-left:8px">
            <el-button :icon="ArrowLeft" @click="moveSpriteByArrow(-1, 0)" :title="t('imgPreview.moveLeft')" />
            <el-button :icon="ArrowRight" @click="moveSpriteByArrow(1, 0)" :title="t('imgPreview.moveRight')" />
            <el-button :icon="ArrowUp" @click="moveSpriteByArrow(0, -1)" :title="t('imgPreview.moveUp')" />
            <el-button :icon="ArrowDown" @click="moveSpriteByArrow(0, 1)" :title="t('imgPreview.moveDown')" />
          </el-button-group>
          
          <el-divider direction="vertical" style="margin-left:8px;margin-right:8px" />
          
          <!-- 拖动模式：互斥开关 -->
          <el-tooltip :content="t('imgPreview.dragCanvas')" placement="top">
            <el-button 
              :type="dragMode === 'canvas' ? 'primary' : 'default'" 
              size="small" 
              @click="toggleDragMode('canvas')"
            >
              <el-icon><FullScreen /></el-icon>
            </el-button>
          </el-tooltip>
          <el-tooltip :content="t('imgPreview.dragImage')" placement="top">
            <el-button 
              :type="dragMode === 'image' ? 'primary' : 'default'" 
              size="small" 
              @click="toggleDragMode('image')"
              :disabled="!currentSprite"
            >
              <el-icon><Expand /></el-icon>
            </el-button>
          </el-tooltip>
          
          <el-divider direction="vertical" />
          
          <!-- 标尺 -->
          <el-tooltip :content="t('imgPreview.ruler')" placement="top">
            <el-button 
              size="small" 
              :type="showRuler ? 'primary' : 'default'" 
              @click="showRuler = !showRuler"
            >
              <el-icon><Edit /></el-icon>
            </el-button>
          </el-tooltip>
          
          <!-- 像素化 -->
          <el-tooltip :content="pixelate ? t('imgPreview.pixelateEnabled') : t('imgPreview.pixelateDisabled')" placement="top">
            <el-button 
              size="small" 
              :type="pixelate ? 'primary' : 'default'" 
              @click="pixelate = !pixelate"
            >
              <el-icon><Document /></el-icon>
            </el-button>
          </el-tooltip>
          
          <el-divider direction="vertical" />
          
          <!-- 去黑底 -->
          <el-tooltip :content="t('imgPreview.removeBlackBg')" placement="top">
            <el-checkbox v-model="removeBlackBg" size="small" />
          </el-tooltip>
          
          <!-- 画布背景模式 -->
          <el-tooltip :content="canvasBgMode === 'auto' ? t('imgPreview.bgAuto') : canvasBgMode === 'light' ? t('imgPreview.bgLight') : t('imgPreview.bgDark')" placement="top">
            <el-button 
              size="small" 
              :type="canvasBgMode !== 'auto' ? 'primary' : 'default'" 
              @click="toggleCanvasBgMode"
            >
              <el-icon>
                <Monitor v-if="canvasBgMode === 'auto'" />
                <Sunny v-else-if="canvasBgMode === 'light'" />
                <Moon v-else />
              </el-icon>
            </el-button>
          </el-tooltip>
          
          <el-divider direction="vertical" />
          
          <!-- 播放控制 -->
          <el-tooltip :content="isPlaying ? t('imgPreview.stopPlay') : t('imgPreview.playFrames')" placement="top">
            <el-button 
              size="small" 
              :type="isPlaying ? 'danger' : 'default'" 
              @click="togglePlay"
              :disabled="!currentSprite || store.spriteList.length <= 0"
            >
              <el-icon v-if="isPlaying"><Close /></el-icon>
              <el-icon v-else><VideoPlay /></el-icon>
            </el-button>
          </el-tooltip>
        </div>
      </div>

      <!-- 右侧：操作面板 -->
      <div class="right-panel">
        <!-- Album 操作 -->
        <div class="panel-section">
          <div class="section-header"><span>{{ t('imgPreview.albumActions') }}</span></div>
          <div class="action-list">
            <el-button size="small" @click="openBatchAddAlbum" :disabled="!selectedNpk">
              <span class="btn-content">
                <span class="btn-icon"><Plus /></span>
                <span class="btn-text">{{ t('imgPreview.batchAddImg') }}</span>
              </span>
            </el-button>
            <el-button size="small" @click="openRename" :disabled="!store.selectedAlbumPath">
              <span class="btn-content">
                <span class="btn-icon"><Edit /></span>
                <span class="btn-text">{{ t('imgPreview.rename') }}</span>
              </span>
            </el-button>
            <el-dropdown size="small" @command="handleCompareCommand" :disabled="!store.selectedAlbumPath" trigger="click">
              <el-button size="small" :type="compareMode ? 'warning' : 'default'">
                <span class="btn-content">
                  <span class="btn-icon"><Refresh /></span>
                  <span class="btn-text">{{ t('imgPreview.compare') }}</span>
                  <span style="margin-left:4px">▼</span>
                </span>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="select-current" :disabled="store.albumList.length <= 1">{{ t('imgPreview.selectCompareTarget') }}</el-dropdown-item>
                  <el-dropdown-item command="select-external">{{ t('imgPreview.fromExternalNpk') }}</el-dropdown-item>
                  <el-dropdown-item command="select-external-img">{{ t('imgPreview.fromExternalImg') }}</el-dropdown-item>
                  <el-dropdown-item command="clear" divided :disabled="!compareMode">{{ t('imgPreview.clearCompare') }}</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
            <el-switch
              v-model="compareMode"
              size="small"
              :disabled="!compareAlbumPath"
              :title="t('imgPreview.compareSwitch')"
              style="margin-left: 4px;"
            />
            <el-dropdown size="small" @command="handleAlbumRefCommand" :disabled="!selectedNpk" trigger="click">
              <el-button size="small">
                <span class="btn-content">
                  <span class="btn-icon"><Link /></span>
                  <span class="btn-text">{{ currentAlbumIsRef ? t('imgPreview.modifyRef') : t('imgPreview.addRef') }}</span>
                  <span style="margin-left:4px">▼</span>
                </span>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="add">{{ t('imgPreview.addRef') }}</el-dropdown-item>
                  <el-dropdown-item command="modify" :disabled="!store.selectedAlbumPath">{{ t('imgPreview.modifyRef') }}</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
            <el-button size="small" @click="handleClearAlbumTarget" v-if="currentAlbumIsRef" type="warning">
              <span class="btn-content">
                <span class="btn-icon"><Close /></span>
                <span class="btn-text">{{ t('imgPreview.clearRef') }}</span>
              </span>
            </el-button>
          </div>
          <!-- 对比 Album 选择 -->
          <div v-if="compareMode" class="compare-section">
            <div class="compare-info">
              <span class="compare-label">{{ t('imgPreview.compareTarget') }}</span>
              <span class="compare-target">
                {{ compareSourceType === 'external' ? t('imgPreview.externalNpkPrefix') : compareSourceType === 'external-img' ? t('imgPreview.externalImgPrefix') : '' }}{{ compareAlbumPath.split('/').pop() || t('imgPreview.notSelected') }}
              </span>
            </div>
            <div class="compare-opacity">
              <span class="compare-label">{{ t('imgPreview.opacity') }}</span>
              <el-slider v-model="compareImageOpacity" :min="0.1" :max="1" :step="0.1" size="small" style="width: 80px;" />
              <span class="opacity-value">{{ Math.round(compareImageOpacity * 100) }}%</span>
            </div>
            <!-- 当前 NPK 的 Album 列表 -->
            <div class="compare-list" v-if="compareSourceType === 'current'">
              <div class="section-header" style="padding: 4px 0; border-bottom: 1px solid var(--border-color); margin-bottom: 4px;">
                <span style="font-size: 11px; color: var(--text-muted);">{{ t('imgPreview.selectCurrentNpkImg') }}</span>
              </div>
              <div v-for="album in store.albumList.filter(a => a.path !== store.selectedAlbumPath)" :key="album.path" class="compare-item" :class="{ active: compareAlbumPath === album.path }" @click="onSelectCompareAlbum(album.path)">
                {{ album.name }}
              </div>
            </div>
            <!-- 外部 NPK 的 Album 列表 -->
            <div class="compare-list" v-if="compareSourceType === 'external' && compareExternalAlbums.length > 0">
              <div class="section-header" style="padding: 4px 0; border-bottom: 1px solid var(--border-color); margin-bottom: 4px;">
                <span style="font-size: 11px; color: var(--text-muted);">{{ t('imgPreview.selectExternalNpkImg', { count: compareExternalAlbums.length }) }}</span>
              </div>
              <div v-for="(album, index) in compareExternalAlbums" :key="index" class="compare-item" :class="{ active: compareAlbumPath === (album as any).Path }" @click="selectExternalAlbumFromListByIndex(index)">
                {{ (album as any).Name }}
              </div>
            </div>
            <!-- 外部 IMG 文件的信息 -->
            <div class="compare-list" v-if="compareSourceType === 'external-img' && compareExternalAlbums.length > 0">
              <div class="section-header" style="padding: 4px 0; border-bottom: 1px solid var(--border-color); margin-bottom: 4px;">
                <span style="font-size: 11px; color: var(--text-muted);">{{ t('imgPreview.externalImgFrames', { count: (compareExternalAlbums[0] as any).SpriteCount || 0 }) }}</span>
              </div>
              <div class="external-img-info" style="padding: 4px 8px; font-size: 11px; color: var(--text-muted);">
                {{ t('imgPreview.filePrefix') }} {{ (compareExternalAlbums[0] as any).Name }}
              </div>
            </div>
            <!-- 提示：还没有选择外部 NPK/IMG -->
            <div v-if="((compareSourceType === 'external' || compareSourceType === 'external-img') && compareExternalAlbums.length === 0)" style="padding: 8px; text-align: center; color: var(--text-muted); font-size: 11px;">
              {{ t('imgPreview.selectExternalFirst', { type: compareSourceType === 'external' ? 'NPK' : 'IMG' }) }}
            </div>
          </div>
        </div>

        <!-- Sprite 操作 -->
        <div class="panel-section">
          <div class="section-header"><span>{{ t('imgPreview.spriteActions') }}</span></div>
          <div class="action-list">
            <el-button size="small" @click="openEditProps" :disabled="!currentSprite">
              <span class="btn-content">
                <span class="btn-icon"><Edit /></span>
                <span class="btn-text">{{ t('imgPreview.modifyProps') }}</span>
              </span>
            </el-button>
            <el-button size="small" @click="openBatchReplace" :disabled="!store.selectedAlbumPath">
              <span class="btn-content">
                <span class="btn-icon"><Files /></span>
                <span class="btn-text">{{ t('imgPreview.batchReplace') }}</span>
              </span>
            </el-button>
            <el-button size="small" @click="openBatchImport" :disabled="!store.selectedAlbumPath">
              <span class="btn-content">
                <span class="btn-icon"><Plus /></span>
                <span class="btn-text">{{ t('imgPreview.batchImport') }}</span>
              </span>
            </el-button>
            <el-dropdown size="small" @command="handleCoordsCommand" :disabled="!store.selectedAlbumPath" trigger="click">
              <el-button size="small">
                <span class="btn-content">
                  <span class="btn-icon"><Files /></span>
                  <span class="btn-text">{{ t('imgPreview.coordsManager') }}</span>
                  <span style="margin-left:4px">▼</span>
                </span>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="export">{{ t('imgPreview.exportCoords') }}</el-dropdown-item>
                  <el-dropdown-item command="import">{{ t('imgPreview.importCoords') }}</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
            <el-dropdown size="small" @command="handleSpriteRefCommand" :disabled="!store.selectedAlbumPath" trigger="click">
              <el-button size="small">
                <span class="btn-content">
                  <span class="btn-icon"><Link /></span>
                  <span class="btn-text">{{ currentSprite?.isLink ? t('imgPreview.modifyRef') : t('imgPreview.addRef') }}</span>
                  <span style="margin-left:4px">▼</span>
                </span>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="add">{{ t('imgPreview.addRef') }}</el-dropdown-item>
                  <el-dropdown-item command="modify" :disabled="!currentSprite?.isLink">{{ t('imgPreview.modifyRef') }}</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>

        <!-- 帧信息 -->
        <div class="panel-section" v-if="currentSprite">
          <div class="section-header"><span>{{ t('imgPreview.frameInfo') }}</span></div>
          <div class="info-grid">
            <span class="label">{{ t('imgPreview.index') }}</span><span class="value">{{ currentSprite.index }}</span>
            <span class="label">{{ t('imgPreview.format') }}</span><span class="value">{{ currentSprite.typeName }}</span>
            <span class="label">{{ t('imgPreview.origin') }}</span><span class="value">{{ currentSprite.x }}, {{ currentSprite.y }}</span>
            <span class="label">{{ t('imgPreview.size') }}</span><span class="value">{{ currentSprite.width }} × {{ currentSprite.height }}</span>
            <span class="label">{{ t('imgPreview.frameRect') }}</span><span class="value">{{ currentSprite.frameWidth }} × {{ currentSprite.frameHeight }}</span>
            <span v-if="currentSprite.textureIndex >= 0" class="label">{{ t('imgPreview.texture') }}</span>
            <span v-if="currentSprite.textureIndex >= 0" class="value">T{{ currentSprite.textureIndex }}</span>
          </div>
        </div>

        <!-- 纹理集 (V5+) -->
        <div class="panel-section" v-if="store.textureList.length > 0">
          <div class="section-header"><span>{{ t('imgPreview.textureSet') }}</span></div>
          <div class="info-grid">
            <template v-for="t in store.textureList" :key="t.index">
              <span class="label">T{{ t.index }}</span>
              <span class="value">{{ t.typeName }} {{ t.width }}×{{ t.height }}</span>
            </template>
          </div>
        </div>
      </div>
    </div>

    <!-- 隐藏的导入坐标文件选择 -->
    <input ref="importCoordsInputRef" type="file" accept=".txt" style="display: none" @change="onImportCoordsFileChange" />

    <!-- 新建 IMG 对话框 -->
    <el-dialog v-model="showNewAlbumDialog" :title="t('imgPreview.newImgTitle')" width="400px">
      <el-form label-width="80px">
        <el-form-item :label="t('imgPreview.path')">
          <el-input v-model="newAlbumPath" :placeholder="t('imgPreview.egPlaceholder')" />
        </el-form-item>
        <el-form-item :label="t('imgPreview.imgFile')">
          <input type="file" accept=".img" @change="onNewAlbumFileChange" class="file-input" />
          <span v-if="newAlbumFile" class="file-name">{{ newAlbumFile.name }}</span>
        </el-form-item>
        <el-form-item :label="t('imgPreview.version')">
          <el-select v-model="newAlbumVersion" style="width:100%">
            <el-option :value="2" label="Ver2" />
            <el-option :value="5" label="Ver5" />
            <el-option :value="6" label="Ver6" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showNewAlbumDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmNewAlbum" :loading="store.loading">{{ t('imgPreview.create') }}</el-button>
      </template>
    </el-dialog>

    <!-- 批量导入 IMG 对话框 -->
    <el-dialog v-model="showBatchAddDialog" :title="t('imgPreview.batchAddImgTitle')" width="500px">
      <div class="batch-add-tip">
        <p><strong>{{ t('imgPreview.batchAddTipFormat') }}</strong>{{ t('imgPreview.batchAddTipFormatDetail') }}</p>
        <p><strong>{{ t('imgPreview.batchAddTipDesc') }}</strong>{{ t('imgPreview.batchAddTipDescDetail') }}</p>
        <p><strong>{{ t('imgPreview.batchAddTipExample') }}</strong></p>
        <ul>
          <li><code>priest_equipment_totem_skin@pr_body0000.img</code></li>
          <li style="margin-left: 20px; color: var(--text-muted);">{{ t('imgPreview.examplePath') }} <code>priest/equipment/totem/skin/pr_body0000.img</code></li>
          <li style="margin-left: 20px; color: var(--text-muted);">{{ t('imgPreview.exampleName') }} <code>pr_body0000.img</code></li>
          <li><code>priest_equipment_totem_skin@pr_body(Town_0)0000.img</code></li>
          <li style="margin-left: 20px; color: var(--text-muted);">{{ t('imgPreview.examplePath') }} <code>priest/equipment/totem/skin/pr_body(Town_0)0000.img</code></li>
          <li style="margin-left: 20px; color: var(--text-muted);">{{ t('imgPreview.exampleName') }} <code>pr_body(Town_0)0000.img</code></li>
        </ul>
        <p>{{ t('imgPreview.batchAddTipMultiple') }}</p>
      </div>
      <el-form label-width="100px">
        <el-form-item :label="t('imgPreview.selectImgFiles')">
          <input ref="batchAddInputRef" type="file" accept=".img" multiple @change="onBatchAddFilesChange" class="file-input" />
          <div v-if="batchAddFiles.length > 0" class="file-list">
            <div v-for="(file, index) in batchAddFiles" :key="index" class="file-item">
              <span class="file-name">{{ file.name }}</span>
            </div>
          </div>
          <div v-else class="file-hint">{{ t('imgPreview.noFileSelected') }}</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showBatchAddDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmBatchAddAlbum" :loading="store.loading" :disabled="batchAddFiles.length === 0">{{ t('imgPreview.import') }}</el-button>
      </template>
    </el-dialog>

    <!-- 替换帧对话框 -->
    <el-dialog v-model="showReplaceDialog" :title="t('imgPreview.replaceFrameTitle')" width="400px">
      <el-form label-width="100px">
        <el-form-item :label="t('imgPreview.selectImage')">
          <input ref="replaceInputRef" type="file" accept=".png,.jpg,.jpeg" @change="onReplaceFileChange" class="file-input" />
          <div v-if="replaceFile" class="file-list">
            <div class="file-item">
              <span class="file-name">{{ replaceFile.name }}</span>
            </div>
          </div>
          <div v-else class="file-hint">{{ t('imgPreview.noFileSelected') }}</div>
        </el-form-item>
        <el-form-item :label="t('imgPreview.colorFormat')">
          <el-select v-model="replaceColorFormat" style="width: 160px;">
            <el-option label="ARGB_1555 (16bit)" value="ARGB_1555" />
            <el-option label="ARGB_4444 (16bit)" value="ARGB_4444" />
            <el-option label="ARGB_8888 (32bit)" value="ARGB_8888" />
            <el-option label="DXT_5 (compressed)" value="DXT_5" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showReplaceDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmReplace" :loading="store.loading" :disabled="!replaceFile">{{ t('imgPreview.replace') }}</el-button>
      </template>
    </el-dialog>

    <!-- 批量替换对话框 -->
    <el-dialog v-model="showBatchReplaceDialog" :title="t('imgPreview.batchReplaceTitle')" width="500px">
      <div class="batch-import-tip">
        <p><strong>{{ t('imgPreview.description') }}</strong>{{ t('imgPreview.batchReplaceTipDesc') }}</p>
        <p><strong>{{ t('imgPreview.supportedFormats') }}</strong>{{ t('imgPreview.batchReplaceTipFormat') }}</p>
        <p><strong>{{ t('imgPreview.specialNote') }}</strong>{{ t('imgPreview.batchReplaceTipExtra') }}</p>
        <p>{{ t('imgPreview.batchAddTipMultiple') }}</p>
      </div>
      <el-form label-width="100px">
        <el-form-item :label="t('imgPreview.selectImage')">
          <input ref="batchReplaceInputRef" type="file" accept=".png,.jpg,.jpeg" multiple @change="onBatchReplaceFilesChange" class="file-input" />
          <div v-if="batchReplaceFiles.length > 0" class="file-list">
            <div v-for="(file, index) in batchReplaceFiles" :key="index" class="file-item">
              <span class="file-name">{{ file.name }}</span>
            </div>
          </div>
          <div v-else class="file-hint">{{ t('imgPreview.noFileSelected') }}</div>
        </el-form-item>
        <el-form-item :label="t('imgPreview.colorFormat')">
          <el-select v-model="batchReplaceColorFormat" style="width: 160px;">
            <el-option label="ARGB_1555 (16bit)" value="ARGB_1555" />
            <el-option label="ARGB_4444 (16bit)" value="ARGB_4444" />
            <el-option label="ARGB_8888 (32bit)" value="ARGB_8888" />
            <el-option label="DXT_5 (compressed)" value="DXT_5" />
          </el-select>
        </el-form-item>
        <el-form-item :label="t('imgPreview.startPosition')">
          <el-radio-group v-model="batchReplaceStartMode">
            <el-radio value="fromZero">{{ t('imgPreview.fromFrame0') }}</el-radio>
            <el-radio value="selected">{{ t('imgPreview.fromSelected') }}</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showBatchReplaceDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmBatchReplace" :loading="store.loading" :disabled="batchReplaceFiles.length === 0">{{ t('imgPreview.replace') }}</el-button>
      </template>
    </el-dialog>

    <!-- 批量导入对话框 -->
    <el-dialog v-model="showBatchImportDialog" :title="t('imgPreview.batchImportTitle')" width="500px">
      <div class="batch-import-tip">
        <p><strong>{{ t('imgPreview.description') }}</strong>{{ t('imgPreview.batchImportTipDesc') }}</p>
        <p><strong>{{ t('imgPreview.supportedFormats') }}</strong>{{ t('imgPreview.batchImportTipFormat') }}</p>
        <p>{{ t('imgPreview.batchImportTipMultiple') }}</p>
      </div>
      <el-form label-width="100px">
        <el-form-item :label="t('imgPreview.selectImage')">
          <input ref="batchImportInputRef" type="file" accept=".png,.jpg,.jpeg" multiple @change="onBatchImportFilesChange" class="file-input" />
          <div v-if="batchImportFiles.length > 0" class="file-list">
            <div v-for="(file, index) in batchImportFiles" :key="index" class="file-item">
              <span class="file-name">{{ file.name }}</span>
            </div>
          </div>
          <div v-else class="file-hint">{{ t('imgPreview.noFileSelected') }}</div>
        </el-form-item>
        <el-form-item :label="t('imgPreview.importPosition')">
          <el-radio-group v-model="batchImportPosition">
            <el-radio value="before">{{ t('imgPreview.beforeCurrent') }}</el-radio>
            <el-radio value="after">{{ t('imgPreview.afterCurrent') }}</el-radio>
            <el-radio value="end">{{ t('imgPreview.afterLast') }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item :label="t('imgPreview.replaceLinks')">
          <el-switch v-model="batchImportReplaceLinks" />
          <span style="margin-left: 10px; color: var(--text-muted); font-size: 12px;">{{ t('imgPreview.notImplemented') }}</span>
        </el-form-item>
        <el-form-item :label="t('imgPreview.colorFormat')">
          <el-select v-model="batchImportColorFormat" :placeholder="t('imgPreview.autoSelectPlaceholder')" style="width: 160px;">
            <el-option :label="t('imgPreview.autoSelect')" value="" />
            <el-option label="ARGB_1555 (16bit)" value="ARGB_1555" />
            <el-option label="ARGB_4444 (16bit)" value="ARGB_4444" />
            <el-option label="ARGB_8888 (32bit)" value="ARGB_8888" />
            <el-option label="DXT_5 (compressed)" value="DXT_5" />
          </el-select>
          <span style="margin-left: 10px; color: var(--text-muted); font-size: 12px;">{{ t('imgPreview.autoSelectHint') }}</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showBatchImportDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmBatchImport" :loading="store.loading" :disabled="batchImportFiles.length === 0">{{ t('imgPreview.import') }}</el-button>
      </template>
    </el-dialog>

    <!-- 重命名对话框 -->
    <el-dialog v-model="showRenameDialog" :title="t('imgPreview.renameImgTitle')" width="400px">
      <el-form label-width="80px">
        <el-form-item :label="t('imgPreview.currentPath')"><el-input :model-value="store.selectedAlbumPath" disabled /></el-form-item>
        <el-form-item :label="t('imgPreview.newPath')"><el-input v-model="renameNewPath" :placeholder="t('imgPreview.inputNewPath')" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showRenameDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmRename" :loading="store.loading">{{ t('imgPreview.confirm') }}</el-button>
      </template>
    </el-dialog>

    <!-- 修改属性对话框 -->
    <el-dialog v-model="showEditPropsDialog" :title="t('imgPreview.editPropsTitle')" width="500px">
      <div v-if="currentSprite" style="margin-bottom: 16px; padding: 12px; background: var(--el-fill-color-light); border-radius: 4px;">
        <div style="font-weight: bold; margin-bottom: 8px;">{{ t('imgPreview.currentFrameInfo') }}</div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <div>
            <span style="color: var(--el-text-color-secondary);">{{ t('imgPreview.originCoord') }}</span>
            <span style="font-weight: bold;">{{ currentSprite.x }}, {{ currentSprite.y }}</span>
          </div>
          <div>
            <span style="color: var(--el-text-color-secondary);">{{ t('imgPreview.frameRectSize') }}</span>
            <span style="font-weight: bold;">{{ currentSprite.frameWidth }} × {{ currentSprite.frameHeight }}</span>
          </div>
          <div>
            <span style="color: var(--el-text-color-secondary);">{{ t('imgPreview.imageSize') }}</span>
            <span style="font-weight: bold;">{{ currentSprite.width }} × {{ currentSprite.height }}</span>
          </div>
        </div>
      </div>
      
      <div style="margin-bottom: 16px;">
        <div style="font-weight: bold; margin-bottom: 8px;">{{ t('imgPreview.operationTarget') }}</div>
        <el-radio-group v-model="editPropsTarget">
          <el-radio value="current">{{ t('imgPreview.currentFrame') }}</el-radio>
          <el-radio value="checked">{{ t('imgPreview.checkedFrames') }}</el-radio>
          <el-radio value="all">{{ t('imgPreview.allFrames') }}</el-radio>
        </el-radio-group>
      </div>
      
      <div style="margin-bottom: 16px;">
        <div style="font-weight: bold; margin-bottom: 8px;">{{ t('imgPreview.operationMode') }}</div>
        <el-radio-group v-model="editPropsMode">
          <el-radio value="move">{{ t('imgPreview.moveOrigin') }}</el-radio>
          <el-radio value="set">{{ t('imgPreview.setOrigin') }}</el-radio>
          <el-radio value="frame">{{ t('imgPreview.modifyFrameRect') }}</el-radio>
        </el-radio-group>
      </div>
      
      <div style="margin-bottom: 16px;">
        <div style="font-weight: bold; margin-bottom: 8px;">{{ t('imgPreview.operationParams') }}</div>
        
        <div v-if="editPropsMode === 'move'" style="padding: 12px; background: var(--el-fill-color-lighter); border-radius: 4px;">
          <div style="font-size: 12px; color: var(--el-text-color-secondary); margin-bottom: 8px;">{{ t('imgPreview.moveHVHint') }}</div>
          <div style="display: flex; gap: 16px;">
            <el-form-item :label="t('imgPreview.moveHorizontal')" style="flex: 1;">
              <el-input-number v-model="editProps.moveX" :step="1" style="width: 100%;" />
            </el-form-item>
            <el-form-item :label="t('imgPreview.moveVertical')" style="flex: 1;">
              <el-input-number v-model="editProps.moveY" :step="1" style="width: 100%;" />
            </el-form-item>
          </div>
        </div>
        
        <div v-if="editPropsMode === 'set'" style="padding: 12px; background: var(--el-fill-color-lighter); border-radius: 4px;">
          <div style="font-size: 12px; color: var(--el-text-color-secondary); margin-bottom: 8px;">{{ t('imgPreview.setXYHint') }}</div>
          <div style="display: flex; gap: 16px;">
            <el-form-item :label="t('imgPreview.xCoord')" style="flex: 1;">
              <el-input-number v-model="editProps.x" :step="1" style="width: 100%;" />
            </el-form-item>
            <el-form-item :label="t('imgPreview.yCoord')" style="flex: 1;">
              <el-input-number v-model="editProps.y" :step="1" style="width: 100%;" />
            </el-form-item>
          </div>
        </div>
        
        <div v-if="editPropsMode === 'frame'" style="padding: 12px; background: var(--el-fill-color-lighter); border-radius: 4px;">
          <div style="font-size: 12px; color: var(--el-text-color-secondary); margin-bottom: 8px;">{{ t('imgPreview.frameWHHint') }}</div>
          <div style="display: flex; gap: 16px;">
            <el-form-item :label="t('imgPreview.frameWidth')" style="flex: 1;">
              <el-input-number v-model="editProps.frameWidth" :min="1" :step="1" style="width: 100%;" />
            </el-form-item>
            <el-form-item :label="t('imgPreview.frameHeight')" style="flex: 1;">
              <el-input-number v-model="editProps.frameHeight" :min="1" :step="1" style="width: 100%;" />
            </el-form-item>
          </div>
        </div>
      </div>
      
      <template #footer>
        <el-button @click="showEditPropsDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="applyEditProps" :loading="store.loading">{{ t('imgPreview.confirm') }}</el-button>
      </template>
    </el-dialog>

    <!-- 冲突处理对话框 -->
    <el-dialog v-model="showConflictDialog" :title="t('imgPreview.conflictTitle')" width="600px">
      <div style="margin-bottom: 16px;">
        <el-radio-group v-model="applyToAll" size="small" style="margin-right: 16px;">
          <el-radio-button value="none">{{ t('imgPreview.selectIndividual') }}</el-radio-button>
          <el-radio-button value="skip">{{ t('imgPreview.skipAll') }}</el-radio-button>
          <el-radio-button value="replace">{{ t('imgPreview.replaceAll') }}</el-radio-button>
        </el-radio-group>
      </div>
      <div style="max-height: 400px; overflow-y: auto;">
        <el-table :data="conflictFiles" border style="width: 100%;" size="small">
          <el-table-column :label="t('imgPreview.fileName')" prop="file.name" width="200" show-overflow-tooltip />
          <el-table-column :label="t('imgPreview.targetPath')" prop="targetPath" show-overflow-tooltip />
          <el-table-column :label="t('imgPreview.status')" width="120">
            <template #default="{ row }">
              <el-tag v-if="row.exists" type="warning">{{ t('imgPreview.exists') }}</el-tag>
              <el-tag v-else type="success">{{ t('imgPreview.newItem') }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column :label="t('imgPreview.operation')" width="150" v-if="applyToAll === 'none'">
            <template #default="{ row }">
              <template v-if="row.exists">
                <el-button-group size="small">
                  <el-button :type="conflictDecisions[row.targetPath] === 'skip' ? 'primary' : 'default'" @click="conflictDecisions[row.targetPath] = 'skip'">{{ t('imgPreview.skip') }}</el-button>
                  <el-button :type="conflictDecisions[row.targetPath] === 'replace' ? 'primary' : 'default'" @click="conflictDecisions[row.targetPath] = 'replace'">{{ t('imgPreview.replace') }}</el-button>
                </el-button-group>
              </template>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <template #footer>
        <el-button @click="showConflictDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmConflictAndImport" :loading="store.loading">{{ t('imgPreview.confirmImport') }}</el-button>
      </template>
    </el-dialog>

    <!-- 添加引用帧对话框 -->
    <el-dialog v-model="showAddLinkDialog" :title="t('imgPreview.addLinkTitle')" width="450px">
      <div style="margin-bottom: 12px; color: var(--text-muted); font-size: 12px;">
        {{ t('imgPreview.linkOnlyNormal') }}
      </div>
      <el-form label-width="80px">
        <el-form-item :label="t('imgPreview.refTarget')">
          <el-select v-model="linkTargetIndex" :placeholder="t('imgPreview.selectRefFrame')" style="width: 100%;">
            <el-option v-for="s in linkableSprites" :key="s.index" :label="t('imgPreview.frame', { index: s.index })" :value="s.index">
              <span style="display: flex; justify-content: space-between; width: 100%;">
                <span>{{ t('imgPreview.frame', { index: s.index }) }}</span>
                <span style="color: var(--text-muted); font-size: 12px;">{{ s.width }}×{{ s.height }}</span>
              </span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="t('imgPreview.insertPosition')">
          <el-radio-group v-model="linkInsertPosition">
            <el-radio value="before">{{ t('imgPreview.beforeRef') }}</el-radio>
            <el-radio value="after">{{ t('imgPreview.afterRef') }}</el-radio>
            <el-radio value="end">{{ t('imgPreview.appendEnd') }}</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddLinkDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmAddLinkSprite" :loading="store.loading" :disabled="linkableSprites.length === 0">{{ t('imgPreview.confirm') }}</el-button>
      </template>
    </el-dialog>

    <!-- 修改引用帧对话框 -->
    <el-dialog v-model="showModifyLinkDialog" :title="t('imgPreview.modifyLinkTitle')" width="450px">
      <div style="margin-bottom: 12px; color: var(--text-muted); font-size: 12px;">
        {{ t('imgPreview.modifyLinkDesc') }}
      </div>
      <el-form label-width="80px">
        <el-form-item :label="t('imgPreview.currentRefFrame')">
          <el-input :model-value="t('imgPreview.frame', { index: modifyLinkSpriteIndex })" disabled />
        </el-form-item>
        <el-form-item :label="t('imgPreview.newTargetFrame')">
          <el-select v-model="modifyLinkNewTargetIndex" :placeholder="t('imgPreview.selectNewTarget')" style="width: 100%;">
            <el-option v-for="s in linkableSprites" :key="s.index" :label="t('imgPreview.frame', { index: s.index })" :value="s.index">
              <span style="display: flex; justify-content: space-between; width: 100%;">
                <span>{{ t('imgPreview.frame', { index: s.index }) }}</span>
                <span style="color: var(--text-muted); font-size: 12px;">{{ s.width }}×{{ s.height }}</span>
              </span>
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showModifyLinkDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmModifyLinkSprite" :loading="store.loading" :disabled="linkableSprites.length === 0">{{ t('imgPreview.confirm') }}</el-button>
      </template>
    </el-dialog>

    <!-- IMG 引用对话框 -->
    <el-dialog v-model="showAlbumTargetDialog" :title="albumTargetMode === 'add' ? t('imgPreview.addImgRefTitle') : t('imgPreview.modifyImgRefTitle')" width="500px">
      <div style="margin-bottom: 12px; color: var(--text-muted); font-size: 12px;" v-if="albumTargetMode === 'add'">
        {{ t('imgPreview.addImgRefDesc') }}
      </div>
      <div style="margin-bottom: 12px; color: var(--text-muted); font-size: 12px;" v-else>
        {{ t('imgPreview.modifyImgRefDesc') }}
      </div>
      <el-form label-width="100px">
        <el-form-item :label="t('imgPreview.imgName')" v-if="albumTargetMode === 'add'">
          <el-input v-model="newImgRefName" :placeholder="t('imgPreview.egRefPlaceholder')" />
        </el-form-item>
        <el-form-item :label="t('imgPreview.imgName')" v-else>
          <el-input :model-value="newImgRefName" disabled />
        </el-form-item>
        <el-form-item :label="t('imgPreview.refTargetImg')">
          <el-select
            v-model="newImgRefTarget"
            :placeholder="t('imgPreview.selectTargetImg')"
            clearable
            filterable
            style="width: 100%;"
          >
            <el-option
              v-for="album in filteredTargetAlbums"
              :key="album.path"
              :label="album.path"
              :value="album.path"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAlbumTargetDialog = false">{{ t('imgPreview.cancel') }}</el-button>
        <el-button type="primary" @click="confirmAlbumTarget" :loading="store.loading">{{ albumTargetMode === 'add' ? t('imgPreview.createRef') : t('imgPreview.saveModify') }}</el-button>
      </template>
    </el-dialog>

    <!-- 外部 NPK 对比选择对话框 -->
    <el-dialog v-model="showExternalNpkDialog" :title="t('imgPreview.selectCompareNpkTitle')" width="550px">
      <div style="margin-bottom: 16px; color: var(--text-muted); font-size: 12px;">
        {{ t('imgPreview.selectCompareNpkDesc') }}
      </div>
      
      <div v-if="npkList.length > 0" style="margin-bottom: 12px;">
        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 8px;">{{ t('imgPreview.fromLoadedNpk') }}</div>
        <el-select v-model="externalNpkPath" :placeholder="t('imgPreview.selectNpk')" filterable style="width: 100%;" @change="(val) => val && loadExternalNpkByName(val)">
          <el-option v-for="npk in npkList" :key="npk.name" :label="npk.name" :value="npk.path || npk.name" />
        </el-select>
      </div>
      
      <el-divider content-position="center" style="margin: 12px 0;">{{ t('imgPreview.orUploadLocal') }}</el-divider>
      
      <input ref="externalNpkFileInput" type="file" accept=".npk" style="display:none" @change="handleCompareNpkUpload" />
      <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px">
        <el-button size="small" @click="openExternalNpkFileDialog">{{ t('imgPreview.uploadNpkFile') }}</el-button>
        <span v-if="compareNpkCacheKey" style="font-size:12px;color:var(--el-color-success)">
          {{ t('imgPreview.uploaded', { count: compareExternalAlbums.length }) }}
        </span>
      </div>
      
      <!-- 已上传的 Album 列表 -->
      <div v-if="compareExternalAlbums.length > 0" style="max-height:200px;overflow-y:auto;margin-bottom:12px">
        <div v-for="a in compareExternalAlbums" :key="a.path" style="padding:4px 8px;cursor:pointer;border-radius:4px"
             @click="selectCompareExternalAlbum(a.path)"
             :style="{ background: compareAlbumPath === a.path ? 'var(--el-color-primary-light-9)' : '' }">
          {{ a.name || a.path }}
        </div>
      </div>
      
      <template #footer>
        <el-button @click="showExternalNpkDialog = false">{{ t('imgPreview.close') }}</el-button>
      </template>
    </el-dialog>
    
    <!-- 外部 IMG 文件输入 -->
    <input 
      ref="externalImgFileInput" 
      type="file" 
      accept=".img" 
      style="display: none;"
      @change="handleExternalImgFileSelect"
    />
  </div>
</template>

<style scoped>
.img-editor { height: 100%; display: flex; flex-direction: column; background: var(--bg-primary); color: var(--text-primary); }

/* 顶部栏 */
.top-bar { flex-shrink: 0; height: 44px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; border-bottom: 1px solid var(--border-color); background: var(--bg-tertiary); gap: 12px; }
.top-bar h2 { margin: 0; font-size: 15px; font-weight: 600; white-space: nowrap; }
.top-left { display: flex; align-items: center; gap: 12px; }
.top-center { display: flex; align-items: center; gap: 8px; }
.top-right { display: flex; align-items: center; gap: 8px; }

/* NPK 选择包装器 */
.npk-select-wrapper { padding: 8px 10px; }

/* 主区域 */
.main-area { flex: 1; min-height: 0; display: flex; gap: 1px; background: var(--border-color); overflow: hidden; }

/* 左侧面板 */
.left-panel { width: 320px; flex-shrink: 0; display: flex; flex-direction: column; background: var(--bg-primary); overflow: hidden; }
.panel-section { display: flex; flex-direction: column; border-bottom: 1px solid var(--border-color); }
.panel-section.flex { flex: 1; min-height: 0; }
.section-header { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; font-size: 12px; font-weight: 600; color: var(--text-secondary); background: var(--bg-tertiary); flex-shrink: 0; }
.header-btns { display: flex; gap: 4px; }

/* Album 列表 */
.album-list { max-height: 200px; overflow-y: auto; flex-shrink: 0; }
.album-item { display: flex; justify-content: space-between; align-items: center; padding: 5px 10px; cursor: pointer; border-bottom: 1px solid var(--border-color); font-size: 12px; transition: background 0.15s; }
.album-item:hover { background: var(--bg-tertiary); }
.album-item.active { background: var(--accent-color); color: #fff; }
.album-item.modified { border-left: 3px solid var(--el-color-warning); }
.album-item.has-target .name { color: var(--el-color-warning); }
.album-item .name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: left; flex: 1; margin-left: 4px; }
.album-item .target-arrow { color: var(--text-muted); font-size: 10px; flex-shrink: 0; margin: 0 2px; }
.album-item .target-name { color: var(--el-color-warning); font-size: 10px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 80px; flex-shrink: 0; }
.album-item .count { font-size: 10px; color: var(--text-muted); flex-shrink: 0; margin-left: 8px; }

/* 表头 */
.tbl-header { display: flex; align-items: center; gap: 4px; padding: 4px 10px; font-size: 10px; color: var(--text-muted); background: var(--bg-secondary); flex-shrink: 0; }
.cb { width: 13px; height: 13px; accent-color: var(--accent-color); flex-shrink: 0; cursor: pointer; }
.c-idx { width: 22px; } .c-type { width: 55px; } .c-pos { width: 48px; } .c-size { width: 55px; } .c-frame { width: 55px; } .c-tex { flex: 1; min-width: 0; }
.t-idx { width: 36px; } .t-type { width: 55px; } .t-size { flex: 1; }

/* Sprite 列表 */
.sprite-list { flex: 1; min-height: 0; overflow-y: auto; }
.sprite-list::-webkit-scrollbar { width: 4px; } .sprite-list::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 2px; }
.sprite-item { display: flex; align-items: center; gap: 4px; padding: 4px 10px; cursor: pointer; border-bottom: 1px solid var(--border-color); font-size: 11px; position: relative; transition: background 0.1s; }
.sprite-item:hover { background: var(--bg-tertiary); }
.sprite-item.active { background: rgba(64,158,255,0.15); border-left: 2px solid var(--accent-color); }
.sprite-item.modified { border-left: 2px solid var(--el-color-warning); }
.sprite-item.is-new { border-left: 2px solid var(--el-color-success); }
.sprite-item .c-type, .sprite-item .c-pos, .sprite-item .c-size, .sprite-item .c-frame { font-family: monospace; color: var(--text-muted); }
.sprite-item .c-idx { color: var(--accent-color); font-weight: 600; }
.sprite-item .c-tex { color: var(--accent-secondary); font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sprite-item .ops { display: none; position: absolute; right: 4px; top: 50%; transform: translateY(-50%); gap: 2px; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 3px; padding: 1px 3px; z-index: 10; }
.sprite-item:hover .ops { display: flex; }

/* 纹理列表 */
.tex-list { max-height: 160px; overflow-y: auto; }
.tex-item { display: flex; align-items: center; gap: 6px; padding: 4px 10px; font-size: 11px; border-bottom: 1px solid var(--border-color); }
.tex-item .t-idx { color: var(--accent-secondary); font-weight: 600; }
.tex-item .t-type { color: var(--text-secondary); }
.tex-item .t-size { color: var(--text-muted); font-family: monospace; }

.empty { padding: 20px 10px; text-align: center; color: var(--text-muted); font-size: 12px; }

/* 画布区域 - Bug3 修复：使用 CSS 变量跟随系统主题 */
.canvas-area { flex: 1; min-width: 0; display: flex; flex-direction: column; background: var(--bg-primary); position: relative; overflow: hidden; }
.ruler-corner { position: absolute; top: 0; left: 0; width: 20px; height: 20px; background: var(--bg-tertiary); z-index: 20; border-right: 1px solid var(--border-color); border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: center; }
.ruler-h { position: absolute; top: 0; left: 20px; right: 0; height: 20px; background: var(--bg-tertiary); z-index: 10; border-bottom: 1px solid var(--border-color); }
.ruler-v { position: absolute; top: 20px; left: 0; bottom: 32px; width: 20px; background: var(--bg-tertiary); z-index: 10; border-right: 1px solid var(--border-color); }
.ruler-h canvas, .ruler-v canvas { display: block; }
.canvas-main { position: absolute; top: 20px; left: 20px; right: 0; bottom: 32px; overflow: hidden; cursor: grab; }
.canvas-main.auto {
  background-image:
    linear-gradient(45deg, var(--bg-secondary) 25%, transparent 25%),
    linear-gradient(-45deg, var(--bg-secondary) 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, var(--bg-secondary) 75%),
    linear-gradient(-45deg, transparent 75%, var(--bg-secondary) 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0;
  background-color: var(--bg-primary);
}
.canvas-main.light {
  background-image:
    linear-gradient(45deg, #e5e5e5 25%, transparent 25%),
    linear-gradient(-45deg, #e5e5e5 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #e5e5e5 75%),
    linear-gradient(-45deg, transparent 75%, #e5e5e5 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0;
  background-color: #ffffff;
}
.canvas-main.dark {
  background-image:
    linear-gradient(45deg, #2d1f1f 25%, transparent 25%),
    linear-gradient(-45deg, #2d1f1f 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #2d1f1f 75%),
    linear-gradient(-45deg, transparent 75%, #2d1f1f 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0;
  background-color: #151010;
}
.canvas-main:active { cursor: grabbing; }
.canvas-wrapper { position: absolute; top: 0; left: 0; }
.canvas-wrapper canvas { display: block; }
.placeholder { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px; color: var(--text-muted); }

.canvas-tools { position: absolute; bottom: 0; left: 20px; right: 0; height: 32px; display: flex; align-items: center; gap: 6px; padding: 0 10px; background: var(--bg-tertiary); border-top: 1px solid var(--border-color); z-index: 10; }

/* 右侧面板 */
.right-panel { width: 200px; flex-shrink: 0; display: flex; flex-direction: column; background: var(--bg-primary); overflow-y: auto; }
.right-panel::-webkit-scrollbar { width: 4px; } .right-panel::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 2px; }
.action-list { display: flex; flex-direction: column; gap: 4px; padding: 8px 10px; }
.action-list .el-button { 
  width: 100% !important; 
  font-size: 11px !important; 
  padding: 5px 8px !important; 
  margin: 0 !important;
}
.action-list .btn-content { 
  display: flex !important;
  align-items: center !important;
  justify-content: flex-start !important;
  width: 100% !important;
}
.action-list .btn-icon { 
  width: 16px !important;
  min-width: 16px !important;
  height: 16px !important;
  display: inline-flex !important;
  justify-content: center !important;
  align-items: center !important;
  margin-right: 6px !important;
  flex-shrink: 0 !important;
}
.action-list .btn-text { 
  text-align: left !important;
  flex: 1 !important;
  display: inline !important;
}

/* 对比区域 */
.compare-section { padding: 8px 10px; border-top: 1px solid var(--border-color); }
.compare-label { font-size: 11px; color: var(--text-muted); display: block; margin-bottom: 4px; }
.compare-list { 
  max-height: 160px; 
  overflow-y: auto; 
  margin-top: 4px;
}
.compare-item { 
  padding: 6px 8px; 
  font-size: 12px; 
  cursor: pointer; 
  border-radius: 4px; 
  margin-bottom: 2px;
  transition: background 0.15s;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.compare-item:hover { background: var(--bg-tertiary); }
.compare-item.active { background: var(--accent-color); color: #fff; }
.compare-info { display: flex; align-items: center; gap: 4px; margin-bottom: 8px; }
.compare-info .compare-label { margin-bottom: 0; }
.compare-target { 
  font-size: 12px; 
  color: var(--text-primary); 
  font-weight: 500; 
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.compare-opacity { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.compare-opacity .compare-label { margin-bottom: 0; }
.opacity-value { font-size: 11px; color: var(--text-muted); min-width: 30px; }
.external-album-list { border: 1px solid var(--border-color); border-radius: 4px; overflow: hidden; }
.dialog-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 10px;
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary);
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border-color);
}
.dialog-album-list {
  max-height: 250px;
  overflow-y: auto;
}
.dialog-album-item {
  padding: 8px 12px;
  font-size: 12px;
  cursor: pointer;
  border-bottom: 1px solid var(--border-color);
  transition: background 0.15s;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.dialog-album-item:last-child {
  border-bottom: none;
}
.dialog-album-item:hover {
  background: var(--bg-tertiary);
}
.dialog-album-name {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.info-grid { display: grid; grid-template-columns: auto 1fr; gap: 2px 8px; padding: 8px 10px; font-size: 11px; }
.info-grid .label { color: var(--text-muted); }
.info-grid .value { color: var(--text-primary); font-family: monospace; text-align: right; }

/* 文件输入 */
.file-input { font-size: 12px; color: var(--text-primary); }
.file-name { font-size: 12px; color: var(--text-secondary); margin-left: 8px; }

/* 批量导入样式 */
.batch-add-tip {
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  padding: 12px;
  margin-bottom: 16px;
  font-size: 12px;
  line-height: 1.6;
}
.batch-add-tip p { margin: 0 0 8px 0; }
.batch-add-tip ul { margin: 4px 0; padding-left: 20px; }
.batch-add-tip li { margin-bottom: 4px; }
.batch-add-tip code {
  background: var(--bg-tertiary);
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 11px;
  color: var(--accent-color);
}
.batch-add-tip strong { color: var(--text-primary); }

.file-list {
  max-height: 200px;
  overflow-y: auto;
  margin-top: 8px;
  border: 1px solid var(--border-color);
  border-radius: 4px;
  background: var(--bg-secondary);
}
.file-item {
  padding: 6px 10px;
  border-bottom: 1px solid var(--border-color);
  font-size: 11px;
}
.file-item:last-child { border-bottom: none; }
.file-item .file-name { 
  color: var(--text-secondary); 
  margin-left: 0; 
  word-break: break-all;
}
.file-hint {
  color: var(--text-muted);
  font-size: 12px;
  margin-top: 8px;
}

:deep(.el-button--small) { padding: 5px 8px; }
:deep(.el-input-number) { width: 100%; }
:deep(.el-dialog__body) { padding-top: 10px; }
</style>
