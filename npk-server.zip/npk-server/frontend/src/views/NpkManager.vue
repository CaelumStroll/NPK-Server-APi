<script setup lang="ts">
import { ref, onMounted, computed, watch, nextTick, onUnmounted, h, onActivated, onDeactivated } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useNpkStore } from '@/stores/npk'
import { useCacheStore } from '@/stores/cache'
import { npkApi, assetApi, albumApi, imgCacheApi } from '@/api'
import { ElMessage, ElMessageBox, ElButton, ElTag, ElIcon } from 'element-plus'
import {
  Refresh,
  Search,
  Picture,
  View,
  Delete,
  DocumentCopy,
  Download,
  InfoFilled,
  VideoPlay,
  VideoPause,
  Sunny,
  Moon,
  Monitor
} from '@element-plus/icons-vue'
import TextHighlight from '@/components/TextHighlight.vue'
import AlbumDetailDialog from '@/components/AlbumDetailDialog.vue'
import { renderImageToCanvas, removeBlackBackground } from '@/utils/canvas'

const { t } = useI18n()
const route = useRoute()
const router = useRouter()
const npkStore = useNpkStore()
const cacheStore = useCacheStore()

// 搜索相关
const npkSearchQuery = ref('')
const albumSearchQuery = ref('')

// NPK 列表
const npkList = ref<any[]>([])
const npkLoading = ref(false)
const npkClicking = ref<string | null>(null) // 防止重复点击
const focusedNpk = ref<string | null>(null) // 当前聚焦的 NPK

// 虚拟表格相关
const npkTableRef = ref()
const tableContainerWidth = ref(800)
const tableContainerHeight = ref(400)

// 虚拟表格列定义
const npkTableColumns: any[] = [
  {
    key: 'checkbox',
    width: 40,
    cellRenderer: ({ rowData }: { rowData: any }) => {
      const checked = selectedNpks.value.includes(rowData.name)
      return h('input', {
        type: 'checkbox',
        class: 'item-checkbox',
        checked,
        onClick: (e: Event) => {
          e.stopPropagation()
          toggleNpkSelection(rowData.name)
        }
      })
    }
  },
  {
    key: 'name',
    dataKey: 'name',
    flexGrow: 1,
    cellRenderer: ({ rowData }: { rowData: any }) => {
      const name = rowData.name || ''
      const query = npkSearchQuery.value
      const tags = []
      
      // 加密状态标签
      if (rowData.format_type === 0) {
        tags.push(h(ElTag, { size: 'small', class: 'encrypt-tag standard' }, () => t('npkManager.standardEncrypt')))
      } else if (rowData.format_type === 1) {
        tags.push(h(ElTag, { size: 'small', class: 'encrypt-tag name-encrypt' }, () => t('npkManager.nameEncrypt')))
      } else if (rowData.format_type === 99) {
        tags.push(h(ElTag, { size: 'small', class: 'encrypt-tag damaged' }, () => t('npkManager.nameDamaged')))
      }
      
      // 文件大小标签
      tags.push(h(ElTag, { size: 'small', class: 'size-tag' }, () => formatSize(rowData.size)))
      
      // IMG 数量标签
      if (rowData.img_count ?? rowData.album_count) {
        tags.push(h(ElTag, { size: 'small', class: 'img-tag' }, () => `IMG ${rowData.img_count ?? rowData.album_count}`))
      }
      
      return h('div', { class: 'npk-cell-info' }, [
        h(TextHighlight, { text: name, keyword: query, class: 'item-name' }),
        h('div', { class: 'item-tags' }, tags)
      ])
    }
  },
  {
    key: 'actions',
    width: 40,
    cellRenderer: ({ rowData }: { rowData: any }) => {
      return h(ElButton, {
        size: 'small',
        type: 'primary',
        link: true,
        class: 'batch-btn',
        onClick: (e: Event) => {
          e.stopPropagation()
          onNpkHover(rowData.name)
        }
      }, () => h(ElIcon, () => h(Download)))
    }
  }
]

function getNpkRowClass({ rowData }: { rowData: any }): string {
  const classes = ['npk-virtual-row']
  if (selectedNpks.value.includes(rowData.name)) classes.push('selected')
  if (npkStore.currentNpk?.name === rowData.name) classes.push('active')
  if (npkClicking.value === rowData.name) classes.push('clicking')
  if (focusedNpk.value === rowData.name) classes.push('focused')
  return classes.join(' ')
}

function handleNpkRowHover({ rowData }: { rowData: any }) {
  onNpkHover(rowData.name)
}

const npkRowEventHandlers = {
  onClick: ({ rowData }: { rowData: any }) => {
    focusedNpk.value = rowData.name
    selectNpk(rowData.name)
  },
  onMouseEnter: ({ rowData }: { rowData: any }) => {
    handleNpkRowHover({ rowData })
  }
}

let resizeDebounceTimer: ReturnType<typeof setTimeout> | null = null

function updateTableSize() {
  // 防抖处理，避免频繁更新导致跳动
  if (resizeDebounceTimer) {
    clearTimeout(resizeDebounceTimer)
  }
  resizeDebounceTimer = setTimeout(() => {
    const container = document.querySelector('.npk-table-container')
    if (container) {
      tableContainerWidth.value = (container as HTMLElement).clientWidth
      tableContainerHeight.value = (container as HTMLElement).clientHeight
    }
  }, 100)
}

// 选择相关
const selectedNpks = ref<string[]>([])
const selectedAlbum = ref('')
const albumClicking = ref<string | null>(null) // 防止重复点击
const selectedFrameIndex = ref(0)

// 数据
const sprites = ref<any[]>([])
const totalSprites = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const loading = ref(false)
const scanning = ref(false)
const deleting = ref(false)

// 画布相关
const previewUrl = ref('')
const frameList = ref<any[]>([])
const frameListLoading = ref(false)
const albumVersion = ref('')
const editableImgPath = ref('')
const previewCanvas = ref<HTMLCanvasElement | null>(null)
const removeBlackBg = ref(false)
const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto')

// Album 详情对话框
const albumDetailVisible = ref(false)
const currentAlbumPath = ref('')

// 帧播放相关
const isPlaying = ref(false)
let playInterval: ReturnType<typeof setInterval> | null = null
const PLAY_INTERVAL = 200 // 0.2s 每帧

// 防抖定时器
let searchDebounceTimer: ReturnType<typeof setTimeout> | null = null
let tableResizeObserver: ResizeObserver | null = null
const cacheStatus = ref<'loading' | 'cached' | 'refreshing' | 'idle'>('idle')

onMounted(async () => {
  // 初始化只执行一次
  // 初始化表格尺寸
  await nextTick()
  updateTableSize()
  
  // 监听容器大小变化
  const container = document.querySelector('.npk-table-container')
  if (container) {
    tableResizeObserver = new ResizeObserver(() => {
      updateTableSize()
    })
    tableResizeObserver.observe(container)
  }
})

// 页面激活时添加键盘事件监听
function addKeyboardListeners() {
  window.addEventListener('keydown', onKeyDown)
  window.addEventListener('keyup', onKeyRelease)
}

// 页面失活时移除键盘事件监听
function removeKeyboardListeners() {
  window.removeEventListener('keydown', onKeyDown)
  window.removeEventListener('keyup', onKeyRelease)
}

// 页面激活时（从缓存恢复或首次进入）
onActivated(async () => {
  // 添加键盘事件监听
  addKeyboardListeners()
  
  // 如果列表为空，先加载数据
  if (npkList.value.length === 0) {
    await fetchNpkList()
  }
  
  // 获取路由参数
  const name = route.query.name as string
  
  // 如果有参数，重新选择 NPK
  if (name && npkList.value.length > 0) {
    const exists = npkList.value.some(n => n.name === name)
    if (exists) {
      await selectNpk(name)
      return // 如果有参数，保持选中状态
    }
  }
  
  // 没有参数时，清除选中状态（返回页面时）
  clearSelection()
  
  // 后台刷新最新数据
  refreshNpkListInBackground()
})

// 清除所有选中状态
function clearSelection() {
  selectedNpks.value = []
  focusedNpk.value = null
  selectedAlbum.value = ''
  albumClicking.value = null
  selectedFrameIndex.value = 0
  sprites.value = []
  totalSprites.value = 0
  currentPage.value = 1
  previewUrl.value = ''
  frameList.value = []
  albumVersion.value = ''
  editableImgPath.value = ''
  npkStore.clearCurrent()
}

// 页面失活时（切换到其他页面）
onDeactivated(() => {
  npkStore.cancelRefresh()
  // 移除键盘事件监听
  removeKeyboardListeners()
})

// 后台刷新 NPK 列表
async function refreshNpkListInBackground() {
  cacheStatus.value = 'refreshing'
  try {
    const res = await npkApi.list() as any
    const freshList = res.data || []
    // 增量更新缓存
    const result = cacheStore.updateNpkListCacheIncremental(freshList)
    // 更新显示（如果有变化）
    const hasChanges = result.added.length > 0 || result.modified.length > 0 || result.removed.length > 0
    if (hasChanges) {
      npkList.value = result.updated
      // 如果有变化，给用户提示
      if (result.added.length > 0 || result.removed.length > 0 || result.modified.length > 0) {
        let message = t('npkManager.dataUpdated')
        const parts: string[] = []
        if (result.added.length > 0) parts.push(t('npkManager.newItems', { count: result.added.length }))
        if (result.modified.length > 0) parts.push(t('npkManager.modifiedItems', { count: result.modified.length }))
        if (result.removed.length > 0) parts.push(t('npkManager.removedItems', { count: result.removed.length }))
        if (parts.length > 0) {
          message += `: ${parts.join(', ')}`
        }
        ElMessage.info(message)
      }
    }
  } catch (e) {
    console.warn('[Cache] Background refresh failed:', e)
  } finally {
    cacheStatus.value = 'idle'
  }
}

onUnmounted(() => {
  // 取消后台刷新
  npkStore.cancelRefresh()
  // 移除键盘事件监听
  window.removeEventListener('keydown', onKeyDown)
  window.removeEventListener('keyup', onKeyRelease)
  stopFramePlay()
  // 释放 IMG 缓存
  if (npkManagerCachedImgKey) {
    const [npk, ...pathParts] = npkManagerCachedImgKey.split(':')
    imgCacheApi.release(npk, pathParts.join(':')).catch(() => {})
    npkManagerCachedImgKey = null
  }
  // 移除表格尺寸监听
  if (tableResizeObserver) {
    tableResizeObserver.disconnect()
    tableResizeObserver = null
  }
  // 清理防抖定时器
  if (resizeDebounceTimer) {
    clearTimeout(resizeDebounceTimer)
    resizeDebounceTimer = null
  }
})

// 监听搜索输入，防抖 300ms
watch(npkSearchQuery, () => {
  if (searchDebounceTimer) {
    clearTimeout(searchDebounceTimer)
  }
  searchDebounceTimer = setTimeout(() => {
    fetchNpkList()
  }, 300)
})

// 获取 NPK 列表（全部）
async function fetchNpkList() {
  npkLoading.value = true
  try {
    const res = await npkApi.list() as any
    let items = res.data || []
    // 更新缓存
    cacheStore.setNpkListCache(items)
    // 客户端过滤搜索
    if (npkSearchQuery.value) {
      const query = npkSearchQuery.value.toLowerCase()
      items = items.filter((item: any) =>
        item.name?.toLowerCase().includes(query)
      )
    }
    npkList.value = items
  } catch (e: any) {
    ElMessage.error(t('npkManager.fetchListFailed') + ': ' + e.message)
  } finally {
    npkLoading.value = false
  }
}

// 过滤后的 Albums 列表（客户端过滤，因为单个 NPK 的 Albums 不会太多）
const filteredAlbums = computed(() => {
  if (!npkStore.currentNpk) return []
  if (!albumSearchQuery.value) return npkStore.currentAlbums
  const query = albumSearchQuery.value.toLowerCase()
  return npkStore.currentAlbums.filter(album =>
    album.name.toLowerCase().includes(query) ||
    album.path.toLowerCase().includes(query)
  )
})

// 点击 NPK 名称加载详情
async function selectNpk(name: string) {
  // 如果已经在加载这个 NPK，不发起新请求
  if (npkClicking.value === name) return
  
  // 如果点击的是当前已选中的 NPK，不发起请求
  if (npkStore.currentNpk?.name === name) return
  
  npkClicking.value = name

  // 清除之前的状态（回到初始状态）
  albumSearchQuery.value = ''
  selectedAlbum.value = ''
  editableImgPath.value = ''
  selectedFrameIndex.value = 0
  currentPage.value = 1
  sprites.value = []
  totalSprites.value = 0
  frameList.value = []
  previewUrl.value = ''
  albumVersion.value = ''
  // 释放旧的 IMG 缓存
  if (npkManagerCachedImgKey) {
    const [oldNpk, ...oldPathParts] = npkManagerCachedImgKey.split(':')
    imgCacheApi.release(oldNpk, oldPathParts.join(':')).catch(() => {})
    npkManagerCachedImgKey = null
  }
  npkStore.clearCurrent()
  
  // 停止帧播放
  stopFramePlay()

  // 只加载 Albums 列表，等待用户手动选择
  try {
    await npkStore.fetchNpkInfo(name)
  } finally {
    npkClicking.value = null
  }
}

// 切换 NPK 勾选
function toggleNpkSelection(name: string) {
  const idx = selectedNpks.value.indexOf(name)
  if (idx >= 0) {
    selectedNpks.value.splice(idx, 1)
  } else {
    selectedNpks.value.push(name)
  }
}

// 选择 Album
async function selectAlbum(path: string) {
  // 如果已经在加载这个 Album，不发起新请求
  if (albumClicking.value === path) return
  
  // 如果点击的是当前已选中的 Album，不发起请求
  if (selectedAlbum.value === path) return
  
  albumClicking.value = path

  selectedAlbum.value = path
  editableImgPath.value = path
  selectedFrameIndex.value = 0
  
  // 停止帧播放
  stopFramePlay()
  
  try {
    await loadSprites()
  } finally {
    albumClicking.value = null
  }
}

// 加载 Sprites
async function loadSprites() {
  if (!npkStore.currentNpk || !selectedAlbum.value) return

  loading.value = true
  frameListLoading.value = true
  try {
    const res = await assetApi.list(
      npkStore.currentNpk.name,
      selectedAlbum.value,
      currentPage.value,
      pageSize.value
    ) as any
    sprites.value = res?.data?.sprites || []
    totalSprites.value = res?.data?.total || 0

    // 先加载帧列表，再加载第一帧预览（确保 frameList 有数据后再调用 loadFramePreview）
    if (sprites.value.length > 0) {
      await loadFrameList()
      if (frameList.value.length > 0) {
        loadFramePreview(0)
      }
    }
  } finally {
    loading.value = false
    frameListLoading.value = false
  }
}

// 当前缓存的 IMG key
let npkManagerCachedImgKey: string | null = null

// 加载帧预览（使用 canvas，支持去黑底）
async function loadFramePreview(index: number) {
  if (!npkStore.currentNpk || !selectedAlbum.value) return
  if (index < 0 || index >= frameList.value.length) return
  selectedFrameIndex.value = index

  // 预加载 IMG 到缓存（如果是新选中的 album）
  const imgKey = `${npkStore.currentNpk.name}:${selectedAlbum.value}`
  if (npkManagerCachedImgKey !== imgKey) {
    // 释放旧的
    if (npkManagerCachedImgKey) {
      const [oldNpk, ...oldPathParts] = npkManagerCachedImgKey.split(':')
      imgCacheApi.release(oldNpk, oldPathParts.join(':')).catch(() => {})
    }
    // 加载新的
    try {
      await imgCacheApi.load(npkStore.currentNpk.name, selectedAlbum.value)
      npkManagerCachedImgKey = imgKey
    } catch (e) {
      console.warn('Preload IMG cache failed:', e)
    }
  }

  const url = `${albumApi.getPreviewUrl(npkStore.currentNpk.name, selectedAlbum.value)}&frame=${index}`
  previewUrl.value = url

  // 渲染到 canvas
  nextTick(async () => {
    if (previewCanvas.value) {
      try {
        await renderImageToCanvas(previewCanvas.value, url, removeBlackBg.value)
      } catch {
        // 如果 canvas 渲染失败，忽略
      }
    }
    // 滚动到选中的帧
    const frameElement = document.querySelector(`.frame-item[data-index="${index}"]`)
    if (frameElement) {
      frameElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    }
  })
}

// 监听去黑底开关变化
watch(removeBlackBg, async (newVal) => {
  if (previewUrl.value && previewCanvas.value) {
    try {
      await renderImageToCanvas(previewCanvas.value, previewUrl.value, newVal)
    } catch {
      // 忽略错误
    }
  }
})

// 选择下一帧
function selectNextFrame() {
  if (frameList.value.length === 0) return
  const nextIndex = selectedFrameIndex.value + 1
  if (nextIndex < frameList.value.length) {
    loadFramePreview(nextIndex)
  }
}

// 选择上一帧
function selectPrevFrame() {
  if (frameList.value.length === 0) return
  const prevIndex = selectedFrameIndex.value - 1
  if (prevIndex >= 0) {
    loadFramePreview(prevIndex)
  }
}

// 长按逐帧切换
let longPressTimer: ReturnType<typeof setTimeout> | null = null
let autoPlayInterval: ReturnType<typeof setInterval> | null = null
const LONG_PRESS_DELAY = 500 // 0.5秒长按触发
let isLongPressActive = false
let currentDirection: 'next' | 'prev' | null = null

function startAutoPlay(direction: 'next' | 'prev') {
  stopLongPressPlay()
  isLongPressActive = true
  autoPlayInterval = setInterval(() => {
    if (direction === 'next') {
      selectNextFrame()
    } else {
      selectPrevFrame()
    }
  }, 100) // 100ms 切换一帧
}

function stopLongPressPlay() {
  isLongPressActive = false
  currentDirection = null
  if (autoPlayInterval) {
    clearInterval(autoPlayInterval)
    autoPlayInterval = null
  }
}

// 帧列表播放功能（0.2s 每帧）
function toggleFramePlay() {
  if (isPlaying.value) {
    stopFramePlay()
  } else {
    startFramePlay()
  }
}

function startFramePlay() {
  if (frameList.value.length === 0) return
  isPlaying.value = true
  playInterval = setInterval(() => {
    const nextIndex = selectedFrameIndex.value + 1
    if (nextIndex < frameList.value.length) {
      loadFramePreview(nextIndex)
    } else {
      // 循环播放：回到第一帧
      loadFramePreview(0)
    }
  }, PLAY_INTERVAL)
}

function stopFramePlay() {
  isPlaying.value = false
  if (playInterval) {
    clearInterval(playInterval)
    playInterval = null
  }
}

function toggleCanvasBgMode() {
  if (canvasBgMode.value === 'auto') {
    canvasBgMode.value = 'light'
  } else if (canvasBgMode.value === 'light') {
    canvasBgMode.value = 'dark'
  } else {
    canvasBgMode.value = 'light'
  }
}

function onKeyDown(e: KeyboardEvent) {
  // 只在帧列表区域有数据时响应
  if (frameList.value.length === 0) return
  
  switch (e.key) {
    case 'ArrowDown':
      e.preventDefault()
      // 如果已经在长按播放，不重复触发
      if (isLongPressActive && currentDirection === 'next') return
      currentDirection = 'next'
      selectNextFrame()
      // 启动长按检测
      if (longPressTimer) clearTimeout(longPressTimer)
      longPressTimer = setTimeout(() => {
        startAutoPlay('next')
      }, LONG_PRESS_DELAY)
      break
    case 'ArrowUp':
      e.preventDefault()
      // 如果已经在长按播放，不重复触发
      if (isLongPressActive && currentDirection === 'prev') return
      currentDirection = 'prev'
      selectPrevFrame()
      // 启动长按检测
      if (longPressTimer) clearTimeout(longPressTimer)
      longPressTimer = setTimeout(() => {
        startAutoPlay('prev')
      }, LONG_PRESS_DELAY)
      break
    case 'PageDown':
      e.preventDefault()
      // 向下翻页，跳过10帧
      const nextPageIndex = Math.min(selectedFrameIndex.value + 10, frameList.value.length - 1)
      loadFramePreview(nextPageIndex)
      break
    case 'PageUp':
      e.preventDefault()
      // 向上翻页，跳过10帧
      const prevPageIndex = Math.max(selectedFrameIndex.value - 10, 0)
      loadFramePreview(prevPageIndex)
      break
    case 'Home':
      e.preventDefault()
      loadFramePreview(0)
      break
    case 'End':
      e.preventDefault()
      loadFramePreview(frameList.value.length - 1)
      break
  }
}

function onKeyRelease() {
  // 清除长按检测定时器
  if (longPressTimer) {
    clearTimeout(longPressTimer)
    longPressTimer = null
  }
  // 停止长按逐帧播放
  stopLongPressPlay()
}

// 加载帧列表详情
async function loadFrameList() {
  if (!npkStore.currentNpk || !selectedAlbum.value) return
  try {
    const res = await albumApi.getFrames(npkStore.currentNpk.name, selectedAlbum.value)
    frameList.value = res.data?.frames || []
    albumVersion.value = res.data?.version || ''
  } catch {
    frameList.value = []
    albumVersion.value = ''
  }
}

// 点击帧列表行
function onFrameClick(row: any) {
  loadFramePreview(row.index)
}

// 悬停 NPK 项时，跳转到批量导出并自动选择
function onNpkHover(npkName: string) {
  router.push({
    path: '/batch',
    query: { npk: npkName }
  })
}

// 获取版本标签样式类
function getVersionClass(version: string): string {
  const versionMap: Record<string, string> = {
    'V1': 'v1',
    'V2': 'v2',
    'V3': 'v3',
    'V4': 'v4',
    'V5': 'v5',
    'V6': 'v6'
  }
  return versionMap[version] || 'other'
}

// 悬停 Album 项时，跳转到批量导出并自动选择
function onAlbumHover(albumPath: string) {
  if (!npkStore.currentNpk) return
  router.push({
    path: '/batch',
    query: { npk: npkStore.currentNpk.name, album: albumPath }
  })
}

// 复制全路径到剪贴板
function copyFullPath() {
  const path = editableImgPath.value || selectedAlbum.value
  if (!path) {
    ElMessage.warning(t('npkManager.noCopyPath'))
    return
  }
  navigator.clipboard.writeText(path).then(() => {
    ElMessage.success(t('common.copySuccess'))
  }).catch(() => {
    ElMessage.error(t('common.copyFailed'))
  })
}

// 打开 Album 详情对话框
function openAlbumDetail() {
  if (!selectedAlbum.value || !npkStore.currentNpk) return
  currentAlbumPath.value = selectedAlbum.value
  albumDetailVisible.value = true
}

// 下载当前选中的帧为 PNG（全质量不压缩）
async function downloadFrame(frame: any) {
  if (!npkStore.currentNpk || !selectedAlbum.value) {
    ElMessage.warning(t('npkManager.selectAlbumFirst'))
    return
  }
  try {
    const url = assetApi.getImageUrl(npkStore.currentNpk.name, selectedAlbum.value, frame.index, 0, 0, true)
    const response = await fetch(url)
    if (!response.ok) throw new Error(t('npkManager.downloadFailed'))
    const blob = await response.blob()

    let finalBlob = blob
    if (removeBlackBg.value) {
      // 去黑底处理
      const bitmap = await createImageBitmap(blob)
      const canvas = document.createElement('canvas')
      canvas.width = bitmap.width
      canvas.height = bitmap.height
      const ctx = canvas.getContext('2d')!
      ctx.drawImage(bitmap, 0, 0)
      bitmap.close()
      removeBlackBackground(canvas)
      finalBlob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((b) => resolve(b!), 'image/png')
      })
    }

    const link = document.createElement('a')
    link.href = URL.createObjectURL(finalBlob)
    const albumName = selectedAlbum.value.split('/').pop()?.replace(/\.img$/i, '') || 'frame'
    const suffix = removeBlackBg.value ? '_nobg' : ''
    link.download = `${albumName}_frame_${frame.index}${suffix}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(link.href)
    ElMessage.success(t('common.downloadSuccess'))
  } catch (e: any) {
    ElMessage.error(t('common.downloadFailed') + ': ' + e.message)
  }
}

// 扫描目录
async function handleScan() {
  scanning.value = true
  try {
    await npkApi.scan()
    ElMessage.success(t('common.scanComplete'))
    await fetchNpkList()
  } catch (e: any) {
    ElMessage.error(e.message || t('common.scanFailed'))
  } finally {
    scanning.value = false
  }
}

// 删除选中的 NPK
async function handleDeleteNpks() {
  if (selectedNpks.value.length === 0) return

  try {
    await ElMessageBox.confirm(
      t('npkManager.confirmDeleteNpks', { count: selectedNpks.value.length }),
      t('common.confirmDelete'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )

    deleting.value = true
    let successCount = 0

    for (const npkName of selectedNpks.value) {
      try {
        await npkApi.delete(npkName)
        successCount++
      } catch (e: any) {
        ElMessage.error(t('npkManager.deleteItemFailed', { name: npkName }))
      }
    }

    ElMessage.success(t('npkManager.deleteSuccess', { count: successCount }))
    selectedNpks.value = []
    // 清除缓存，确保其他页面刷新时能获取最新数据
    cacheStore.clearNpkListCache()
    cacheStore.clearAlbumListCache()
    await fetchNpkList()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('npkManager.deleteFailed'))
    }
  } finally {
    deleting.value = false
  }
}

// 清理缓存
async function handleClearCache() {
  try {
    const { value } = await ElMessageBox.confirm(
      t('npkManager.confirmClearCache'),
      t('npkManager.confirmClearTitle'),
      {
        confirmButtonText: t('npkManager.clearAll'),
        cancelButtonText: t('npkManager.keepNpkList'),
        distinguishCancelAndClose: true,
        type: 'warning'
      }
    )
    
    if (value === 'confirm') {
      cacheStore.clear()
      cacheStore.clearNpkListCache()
      cacheStore.clearAlbumListCache()
      ElMessage.success(t('npkManager.allCacheCleared'))
    } else {
      cacheStore.clearAllExceptNpkList()
      ElMessage.success(t('npkManager.partialCacheCleared'))
    }
    
    // 重新加载数据
    await fetchNpkList()
    clearSelection()
  } catch (e) {
    // 用户取消
  }
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(1) + ' KB'
  }
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

// 格式化路径为数组，用于分隔符高亮显示
function formatPath(path: string): string[] {
  return path.split('/').filter(Boolean)
}

// 从完整路径中提取目标文件名
function getTargetName(path: string): string {
  return path.split('/').pop() || path
}
</script>

<template>
  <div class="npk-manager">
    <div class="page-header">
      <h2 class="page-title">{{ t('npkManager.title') }}</h2>
      <div class="header-actions">
        <el-button :icon="View" :loading="scanning" @click="handleScan">{{ t('npkManager.scanDir') }}</el-button>
        <el-button :icon="Refresh" @click="fetchNpkList">{{ t('common.refresh') }}</el-button>
        <el-button type="warning" @click="handleClearCache">{{ t('npkManager.clearCache') }}</el-button>
      </div>
    </div>

    <el-row :gutter="16" class="main-row">
      <!-- 1. NPK 文件列表 -->
      <el-col :span="8">
        <el-card class="list-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('npkManager.npkFiles') }} ({{ npkList.length }})</span>
              <el-button
                v-if="selectedNpks.length > 0"
                type="danger"
                size="small"
                :icon="Delete"
                :loading="deleting"
                @click="handleDeleteNpks"
              >
                {{ t('npkManager.deleteSelected') }} ({{ selectedNpks.length }})
              </el-button>
            </div>
          </template>

          <div class="search-box">
            <el-input
              v-model="npkSearchQuery"
              :placeholder="t('npkManager.searchNpk')"
              :prefix-icon="Search"
              clearable
            />
          </div>

          <!-- NPK 列表（虚拟滚动表格） -->
          <div ref="npkTableRef" class="npk-table-container">
            <el-table-v2
              v-loading="npkLoading"
              :columns="npkTableColumns"
              :data="npkList"
              :width="tableContainerWidth || 800"
              :height="tableContainerHeight"
              :row-height="52"
              :header-height="0"
              :row-class="getNpkRowClass"
              :row-event-handlers="npkRowEventHandlers"
            />
          </div>
        </el-card>
      </el-col>

      <!-- 2. Albums 列表 -->
      <el-col :span="7">
        <el-card class="list-card">
          <template #header>
            <div class="card-header">
              <span>Albums</span>
              <span v-if="npkStore.currentNpk" class="header-count">
                {{ npkStore.currentAlbums.length }}
              </span>
            </div>
          </template>

          <div class="search-box">
            <el-input
              v-model="albumSearchQuery"
              :placeholder="t('npkManager.searchAlbums')"
              :prefix-icon="Search"
              clearable
            />
          </div>

          <div class="scroll-container">
            <el-scrollbar>
              <div v-if="!npkStore.currentNpk" class="empty-tip">
                <p>{{ t('npkManager.selectNpk') }}</p>
              </div>
              <div v-else-if="filteredAlbums.length === 0" class="empty-tip">
          <p>{{ t('npkManager.noMatchAlbums') }}</p>
        </div>
        <div class="album-list">
          <div
            v-for="album in filteredAlbums"
            :key="album.path"
            class="list-item album-item"
            :class="{
              active: selectedAlbum === album.path,
              clicking: albumClicking === album.path,
              'has-target': album.target_path
            }"
            @click="selectAlbum(album.path)"
          >
            <div class="item-row">
              <div class="item-actions-float" @click.stop>
                <el-button
                  size="small"
                  type="primary"
                  link
                  class="batch-btn"
                  @click="onAlbumHover(album.path)"
                >
                  <el-icon><Download /></el-icon>
                </el-button>
              </div>
              <div class="item-info album-info">
                <el-tag v-if="album.file_type === 1" size="small" class="album-file-tag ogg-tag">OGG</el-tag>
                <el-tag v-else-if="album.file_type === 2" size="small" class="album-file-tag other-tag">Other</el-tag>
                <el-tag
                  v-else
                  size="small"
                  :class="['album-file-tag', 'version-tag', getVersionClass(album.version)]"
                >
                  {{ album.version || 'IMG' }}
                </el-tag>
                <div class="item-name">
                  <TextHighlight :text="album.name" :keyword="albumSearchQuery" />
                  <span v-if="album.target_path" class="target-info">
                    &nbsp;→&nbsp;{{ getTargetName(album.target_path) }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
            </el-scrollbar>
          </div>
        </el-card>
      </el-col>

      <!-- 3. Sprites 区域 -->
      <el-col :span="9">
        <el-card class="preview-card">
          <template #header>
            <div class="card-header">
              <span>Sprites</span>
              <div v-if="selectedAlbum" class="header-actions">
                <div class="album-path-wrapper">
                  <span
                    v-for="(part, index) in formatPath(editableImgPath || selectedAlbum)"
                    :key="index"
                    class="path-part"
                  >
                    <span class="path-separator" v-if="index > 0">/</span>
                    <span class="path-segment">{{ part }}</span>
                  </span>
                </div>
                <el-button
                  :icon="DocumentCopy"
                  size="small"
                  type="primary"
                  link
                  @click="copyFullPath"
                  :title="t('npkManager.copyFullPathTitle')"
                />
                <!-- v5 增强：Album 详情按钮 -->
                <el-button
                  :icon="InfoFilled"
                  size="small"
                  type="primary"
                  link
                  @click="openAlbumDetail"
                  :title="t('npkManager.viewDetailTitle')"
                />
              </div>
            </div>
          </template>

          <div v-if="!selectedAlbum" class="preview-empty">
            <el-icon :size="48"><Picture /></el-icon>
            <span>{{ t('npkManager.selectAlbumPreview') }}</span>
          </div>

          <!-- 画布预览 -->
          <div v-else class="preview-content">
            <!-- 画布 -->
            <div class="canvas-container" :class="canvasBgMode" v-loading="loading">
              <canvas v-if="previewUrl" ref="previewCanvas" class="canvas-image"></canvas>
            </div>

            <!-- 帧列表 -->
            <div class="frame-section">
              <div class="frame-section-header">
                <div class="frame-header-left">
                  <span>{{ t('npkManager.frameList') }}</span>
                  <el-tag size="small" v-if="frameList.length > 0">{{ frameList.length }}</el-tag>
                </div>
                <div class="frame-header-right">
                  <el-checkbox v-model="removeBlackBg" size="small">{{ t('npkManager.removeBlackBg') }}</el-checkbox>
                  <el-button size="small" :icon="canvasBgMode === 'auto' ? Monitor : canvasBgMode === 'light' ? Sunny : Moon" @click="toggleCanvasBgMode" />
                  <el-button
                    v-if="frameList.length > 0"
                    :icon="isPlaying ? VideoPause : VideoPlay"
                    size="small"
                    :type="isPlaying ? 'warning' : 'primary'"
                    @click="toggleFramePlay"
                  >
                    {{ isPlaying ? t('common.stop') : t('common.play') }}
                  </el-button>
                </div>
              </div>
              <el-scrollbar v-if="frameList.length > 0" class="frame-scroll">
                <div class="frame-list">
                  <div
                    v-for="frame in frameList"
                    :key="frame.index"
                    class="frame-item"
                    :class="{ active: selectedFrameIndex === frame.index }"
                    :data-index="frame.index"
                    @click="onFrameClick(frame)"
                  >
                    <span class="frame-number">{{ frame.index }}</span>
                    <template v-if="frame.is_link">
                      <span class="frame-link">
                        LINK
                        <template v-if="frame.link_status === 'normal'"> {{ t('npkManager.refFrameTarget', { index: frame.target_index }) }}</template>
                        <template v-else-if="frame.link_status === 'null'"> {{ t('npkManager.nullPointer') }}</template>
                        <template v-else-if="frame.link_status === 'circular'"> {{ t('npkManager.circularRef') }}</template>
                        <template v-else> {{ t('npkManager.refFrameTarget', { index: frame.target_index }) }}</template>
                      </span>
                      <span v-if="frame.data_size" class="frame-data text-muted">-</span>
                      <el-tag size="small" :type="frame.link_status === 'normal' ? 'warning' : 'danger'" class="frame-tag">
                        <template v-if="frame.link_status === 'normal'">Link</template>
                        <template v-else-if="frame.link_status === 'null'">Error</template>
                        <template v-else-if="frame.link_status === 'circular'">Circular</template>
                        <template v-else>Link</template>
                      </el-tag>
                    </template>
                    <template v-else>
                      <span class="frame-type">{{ frame.type_name || (albumVersion || 'IMG') }}</span>
                      <span class="frame-pos">{{ frame.x }},{{ frame.y }}</span>
                      <span class="frame-size">{{ frame.width }}×{{ frame.height }}</span>
                      <span class="frame-frame">{{ frame.frame_width }}×{{ frame.frame_height }}</span>
                      <!-- v6 增强：显示数据大小 -->
                      <span v-if="frame.data_size" class="frame-data text-muted">{{ formatSize(frame.data_size) }}</span>
                    </template>
                    <el-button
                      :icon="Download"
                      size="small"
                      type="primary"
                      link
                      class="frame-download"
                      @click.stop="downloadFrame(frame)"
                      :title="t('npkManager.downloadPngTitle')"
                    />
                  </div>
                </div>
              </el-scrollbar>
              <div v-else v-loading="frameListLoading" class="empty-tip" style="padding: 20px">
                {{ frameListLoading ? t('common.loading') : t('npkManager.noFrameData') }}
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- v5 增强：Album 详情对话框 -->
    <AlbumDetailDialog
      v-model:visible="albumDetailVisible"
      :npk-name="npkStore.currentNpk?.name || ''"
      :album-path="currentAlbumPath"
    />
  </div>
</template>

<style lang="scss" scoped>
.npk-manager {
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 0;
  box-sizing: border-box;

  .page-header {
    flex-shrink: 0;
    margin-bottom: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .page-title {
      margin: 0;
      color: var(--text-primary);
      font-size: 20px;
      font-weight: 600;
    }

    .header-actions {
      display: flex;
      gap: 10px;
    }
  }

  .main-row {
    flex: 1;
    min-height: 0;
    margin: 0;

    .el-col {
      height: 100%;

      .el-card {
        height: 100%;
        display: flex;
        flex-direction: column;
        border-radius: 8px;

        :deep(.el-card__header) {
          padding: 14px 18px;
          border-bottom: 1px solid var(--border-color);
        }

        :deep(.el-card__body) {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
          padding: 16px;
        }
      }
    }
  }

  .list-card {
    height: 100%;
    display: flex;
    flex-direction: column;

    :deep(.el-card__body) {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      padding-bottom: 0;
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-shrink: 0;
      font-weight: 600;
      font-size: 14px;

      .header-count {
        color: var(--text-muted);
        font-size: 12px;
        background: var(--bg-tertiary);
        padding: 4px 10px;
        border-radius: 12px;
      }
    }

    .search-box {
      margin-bottom: 12px;
      flex-shrink: 0;

      :deep(.el-input__wrapper) {
        border-radius: 8px;
      }
    }

    .pagination-bar {
      margin-top: 16px;
      padding-top: 16px;
      border-top: 1px solid var(--border-color);
      display: flex;
      justify-content: center;
    }
  }

  .npk-table-container {
    flex: 1;
    min-height: 0;
    overflow: hidden;

    :deep(.el-table-v2) {
      --el-table-border-color: var(--border-color);
      --el-table-header-bg-color: var(--bg-secondary);
    }

    :deep(.el-table-v2__header),
    :deep(.el-table-v2__header-wrapper) {
      display: none;
      height: 0;
    }

    :deep(.el-table-v2__row) {
      height: 44px !important;
      box-sizing: border-box;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      margin: 2px 0;
      transition: background 0.2s;
      
      &:hover {
        background: var(--bg-secondary);
      }
      
      &.selected {
        background: rgba(251, 113, 133, 0.1) !important;
        border-color: rgba(251, 113, 133, 0.3);
      }
      
      &.focused:not(.selected) {
        background: var(--bg-secondary);
      }
    }

    :deep(.el-table-v2__cell) {
      height: 48px;
      box-sizing: border-box;
      display: flex;
      align-items: center;
    }

    :deep(.npk-cell-info) {
      display: flex;
      flex-direction: column;
      gap: 4px;
      width: 100%;
    }

    :deep(.item-name) {
      font-size: 13px;
      color: var(--text-primary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      font-weight: 500;
    }

    :deep(.item-tags) {
      display: flex;
      gap: 4px;
      flex-wrap: wrap;
    }
    
    // NPK 标签样式
    :deep(.encrypt-tag) {
      padding: 2px 8px;
      font-size: 11px;
      height: 20px;
      line-height: 16px;
      border-radius: 4px;
      border: none;
      
      &.standard {
        background: rgba(103, 194, 58, 0.15);
        color: rgba(103, 194, 58, 0.9);
      }
      
      &.name-encrypt {
        background: rgba(230, 162, 60, 0.15);
        color: rgba(230, 162, 60, 0.9);
      }
      
      &.damaged {
        background: rgba(245, 108, 108, 0.15);
        color: rgba(245, 108, 108, 0.9);
      }
    }
    
    :deep(.size-tag) {
      padding: 2px 8px;
      font-size: 11px;
      height: 20px;
      line-height: 16px;
      border-radius: 4px;
      border: none;
      background: rgba(144, 147, 153, 0.15);
      color: var(--text-secondary);
    }
    
    :deep(.img-tag) {
      padding: 2px 8px;
      font-size: 11px;
      height: 20px;
      line-height: 16px;
      border-radius: 4px;
      border: none;
      background: rgba(122, 205, 246, 0.15);
      color: rgba(122, 205, 246, 0.9);
    }
  }

  .scroll-container {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }

  .npk-list,
  .album-list {
    display: flex;
    flex-direction: column;
    width: max-content;
    min-width: 100%;
    padding-bottom: 12px;
    gap: 4px;
  }

  // el-scrollbar 样式
  :deep(.el-scrollbar) {
    flex: 1;
    min-height: 0;
    height: 100%;
  }

  :deep(.el-scrollbar__wrap) {
    overflow-x: auto !important;
    overflow-y: auto !important;
    max-height: 100%;
  }

  :deep(.el-scrollbar__view) {
    min-width: 100%;
  }

  :deep(.el-scrollbar__bar.is-horizontal) {
    bottom: 0;
  }

  :deep(.el-scrollbar__thumb) {
    background: var(--accent-color);
    border-radius: 4px;
    opacity: 0.3;
  }

  .list-item {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    cursor: pointer;
    border-radius: 6px;
    transition: background 0.2s;
    width: max-content;
    min-width: 100%;
    margin: 2px 0;
    background: var(--bg-primary);
    border: 1px solid var(--border-color);

    &:hover {
      background: var(--bg-secondary);
    }

    &.active {
      background: rgba(251, 113, 133, 0.1);
      color: var(--accent-color);
      border-color: rgba(251, 113, 133, 0.3);
      font-weight: 500;

      .item-name {
        color: var(--accent-color);
      }
    }

    &.selected {
      background: rgba(251, 113, 133, 0.08);
    }

    &.clicking {
      opacity: 0.6;
      cursor: wait;
    }

    &.has-target {
      background: rgba(251, 113, 133, 0.06);
      border-left: 3px solid var(--accent-color);
      padding-left: 11px;

      &:hover {
        background: rgba(251, 113, 133, 0.1);
      }

      &.active {
        background: rgba(251, 113, 133, 0.12);
        border-left-color: var(--accent-color);

        .item-name {
          color: var(--accent-dark);
          font-weight: 500;
        }
      }

      .item-info {
        .item-name {
          color: var(--accent-color);
          font-weight: 500;
        }
      }
    }

    .item-row {
      display: flex;
      align-items: center;
      gap: 10px;
      flex: 1;
      min-width: max-content;
    }

    .item-checkbox {
      width: 18px;
      height: 18px;
      accent-color: var(--accent-color);
      cursor: pointer;
      flex-shrink: 0;
    }

    .item-name {
      white-space: nowrap;
      font-size: 13px;
      color: var(--text-primary);
      flex: 1;
      min-width: 0;
      font-weight: 500;
    }



    // 操作区：常驻显示
    .item-actions-float {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-shrink: 0;

      .batch-btn {
        padding: 4px;
        font-size: 12px;
        border-radius: 8px;
      }
    }

    // 项目信息区（文件名 + 标签）
    .item-info {
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex: 1;
      min-width: 0;
      align-items: flex-start;

      .item-name {
        font-size: 14px;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-weight: 500;
      }



      // Album 列表横向布局
      &.album-info {
        flex-direction: row;
        align-items: flex-start;
        gap: 6px;

        .item-name {
          font-size: 13px;
          flex: 1;
          word-break: break-all;
          line-height: 1.4;
          display: flex;
          align-items: center;
          flex-wrap: wrap;
        }

        .target-info {
          color: var(--accent-color);
          font-weight: 500;
        }
      }
    }
    
    // Album 文件标签样式
    :deep(.album-file-tag) {
      padding: 2px 8px;
      font-size: 11px;
      height: 20px;
      line-height: 16px;
      border-radius: 4px;
      border: none;
      
      &.ogg-tag {
        background: rgba(230, 162, 60, 0.15);
        color: rgba(230, 162, 60, 0.9);
      }
      
      &.other-tag {
        background: rgba(144, 147, 153, 0.15);
        color: var(--text-secondary);
      }
    }
    
    // Album 版本标签样式
    :deep(.version-tag) {
      padding: 2px 8px;
      font-size: 11px;
      height: 20px;
      line-height: 16px;
      border-radius: 4px;
      border: none;
      
      &.v1 {
        background: rgba(128, 0, 128, 0.15);
        color: rgba(128, 0, 128, 0.9);
      }
      
      &.v2 {
        background: rgba(122, 205, 246, 0.15);
        color: rgba(122, 205, 246, 0.9);
      }
      
      &.v3 {
        background: rgba(0, 128, 128, 0.15);
        color: rgba(0, 128, 128, 0.9);
      }
      
      &.v4 {
        background: rgba(103, 194, 58, 0.15);
        color: rgba(103, 194, 58, 0.9);
      }
      
      &.v5 {
        background: rgba(230, 162, 60, 0.15);
        color: rgba(230, 162, 60, 0.9);
      }
      
      &.v6 {
        background: rgba(245, 108, 108, 0.15);
        color: rgba(245, 108, 108, 0.9);
      }
      
      &.other {
        background: rgba(144, 147, 153, 0.15);
        color: var(--text-secondary);
      }
    }
  }

  // 画布预览（与 BatchExport 一致）
  .preview-card {
    height: calc(100vh - 180px);
    
    :deep(.el-card__body) {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .preview-empty {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 16px;
      color: var(--text-muted);
      font-size: 15px;
    }

    .preview-content {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }

    .preview-toolbar {
      padding: 12px 0;
      border-bottom: 1px solid var(--border-color);
      margin-bottom: 12px;
    }
  }

  .canvas-container {
    display: flex;
    align-items: center;
    justify-content: center;
    background:
      linear-gradient(45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #fef0f0 75%),
      linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
      #fdf7f7;
    background-size: 20px 20px;
    background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    min-height: 200px;
    max-height: 300px;
    overflow: hidden;
    margin-bottom: 16px;
    flex-shrink: 0;

    .canvas-image {
      display: block;
      max-width: 100%;
      max-height: 300px;
      image-rendering: pixelated;
      border-radius: 4px;
    }

    &.light {
      background:
        linear-gradient(45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #fef0f0 75%),
        linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
        #ffffff;
      background-size: 16px 16px;
      background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    }

    &.dark {
      background:
        linear-gradient(45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(-45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #2d1f1f 75%),
        linear-gradient(-45deg, transparent 75%, #2d1f1f 75%),
        #151010;
      background-size: 16px 16px;
      background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    }
  }

  .frame-section {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    .frame-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
      font-size: 14px;
      font-weight: 600;
      color: var(--text-primary);
      flex-shrink: 0;

      .frame-header-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .frame-header-right {
        display: flex;
        align-items: center;
        gap: 16px;
      }
    }

    .frame-scroll {
      flex: 1;
      min-height: 0;
      overflow-y: auto;
    }
  }

  .frame-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding-bottom: 12px;
  }

  .frame-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 12px;
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.2s;
    margin: 2px 0;

    &:hover {
      background: var(--bg-secondary);
    }

    &.active {
      background: rgba(251, 113, 133, 0.1);
      border-color: rgba(251, 113, 133, 0.3);

      .frame-number,
      .frame-type,
      .frame-pos,
      .frame-size,
      .frame-frame,
      .frame-data,
      .frame-link {
        color: var(--accent-color);
      }
    }

    .frame-number {
      font-size: 13px;
      font-weight: 600;
      color: var(--accent-color);
      min-width: 28px;
      font-family: monospace;
    }

    .frame-link {
      font-size: 12px;
      font-family: monospace;
      white-space: nowrap;
      flex: 1;
    }

    .frame-type {
      font-size: 12px;
      width: 60px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-pos {
      font-size: 12px;
      width: 52px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-size {
      font-size: 12px;
      width: 60px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-frame {
      font-size: 12px;
      width: 60px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-data {
      font-size: 12px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-detail {
      font-size: 12px;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-tag {
      margin-left: auto;
      flex-shrink: 0;
      border-radius: 6px !important;
    }

    .text-muted {
      color: var(--text-muted);
      font-size: 12px;
    }

    .frame-download {
      flex-shrink: 0;
      margin-left: 6px;
      opacity: 0;
      transition: opacity 0.15s;
      padding: 4px;
      border-radius: 6px;

      &:hover {
        background: rgba(255, 255, 255, 0.1);
      }
    }

    &:hover .frame-download {
      opacity: 1;
    }
  }

  // v5 增强：Album 路径显示
  .album-path-wrapper {
    width: 100%;
    font-family: monospace;
    font-size: 12px;
    line-height: 1.6;
    padding: 10px 14px;
    background: var(--bg-tertiary);
    border-radius: 12px;
    border: 1px solid var(--border-color);

    .path-part {
      display: inline;

      .path-separator {
        color: var(--accent-color);
        font-weight: bold;
        margin: 0 2px;
      }

      .path-segment {
        color: var(--text-secondary);
        word-break: break-all;

        // 最后一级（文件名）高亮
        &:last-child {
          color: var(--text-primary);
          font-weight: 600;
        }
      }
    }
  }

  .empty-tip {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-muted);
    font-size: 14px;
  }
}

/* 深色模式样式覆盖 */
html.dark {
  .npk-manager {
    // 深色模式不再添加复杂的渐变和动画，保持与浅色模式相同的简洁风格
    // 所有样式继承自上面的基础样式，仅通过 CSS 变量控制颜色
  }
}
</style>
