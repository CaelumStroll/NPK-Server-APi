<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick, computed, watch } from 'vue'
import { Delete, Download, Link, Operation } from '@element-plus/icons-vue'
import { clearApiLogs, useApiLogs } from '@/api'
import { useLogStore } from '@/stores/logStore'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const logStore = useLogStore()
const apiLogs = useApiLogs()

const autoScroll = ref(true)
const paused = ref(false)
const clearNotification = ref<string | null>(null)
const filterText = ref('')

const filterMethod = ref('')
const filterStatus = ref<number | null>(null)

const wsLogContent = ref<HTMLElement | null>(null)

const filteredWsLogs = computed(() => {
  if (!filterText.value) return logStore.wsLogs
  const keyword = filterText.value.toLowerCase()
  return logStore.wsLogs.filter(log => log.toLowerCase().includes(keyword))
})

const filteredApiLogs = computed(() => {
  let logs = apiLogs.value
  
  if (filterText.value) {
    const keyword = filterText.value.toLowerCase()
    logs = logs.filter(log => 
      log.path.toLowerCase().includes(keyword) ||
      String(log.status).includes(keyword) ||
      log.method.toLowerCase().includes(keyword)
    )
  }
  
  if (filterMethod.value) {
    logs = logs.filter(log => log.method === filterMethod.value)
  }
  
  if (filterStatus.value !== null) {
    logs = logs.filter(log => log.status === filterStatus.value)
  }
  
  return logs
})

function updateFilteredLogs() {
  // computed 自动更新
}

function scrollToBottom() {
  if (wsLogContent.value) {
    wsLogContent.value.scrollTop = wsLogContent.value.scrollHeight
  }
}

// 监听 WebSocket 日志变化，自动滚动
watch(() => logStore.wsLogs.length, () => {
  if (autoScroll.value && !paused.value) {
    nextTick(() => {
      scrollToBottom()
    })
  }
})

function clearLogs() {
  logStore.clearLogs()
  clearApiLogs()
  showClearNotification(t('logView.allCleared'))
}

function clearWsLogs() {
  logStore.clearLogs()
  showClearNotification(t('logView.wsCleared'))
}

function clearApiLogsHandler() {
  clearApiLogs()
  showClearNotification(t('logView.apiCleared'))
}

function showClearNotification(message: string) {
  clearNotification.value = message
  setTimeout(() => {
    clearNotification.value = null
  }, 2000)
}

function togglePause() {
  paused.value = !paused.value
}

function downloadLogs() {
  const now = new Date()
  const timestamp = now.toISOString().slice(0, 19).replace(/:/g, '-')
  const dateStr = now.toLocaleString('zh-CN', { timeZoneName: 'short' })
  
  let apiContent = ''
  if (apiLogs.value.length > 0) {
    apiContent = apiLogs.value.map(log => {
      const status = log.error ? 'ERROR' : String(log.status)
      const extra = log.size ? ` (${log.size})` : ''
      return `[${log.time}] ${log.method} ${log.path} ${status} ${log.duration}ms${extra}${log.error ? ` - ${log.error}` : ''}`
    }).join('\n')
  } else {
    apiContent = t('logView.noApiLogs')
  }
  
  let wsContent = ''
  if (logStore.wsLogs.length > 0) {
    wsContent = logStore.wsLogs.join('\n')
  } else {
    wsContent = t('logView.noWsLogs')
  }
  
  const combined = `${t('logView.exportTitle')}\n${t('logView.exportTime')}: ${dateStr}\n========================================\n\n=== ${t('logView.apiRequest')} ===\n${apiContent}\n\n=== ${t('logView.websocketLog')} ===\n${wsContent}`
  
  const blob = new Blob([combined], { type: 'text/plain;charset=utf-8' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `npk-server-logs-${timestamp}.txt`
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(link.href)
}

function getLogClass(log: string): string {
  const lower = log.toLowerCase()
  if (lower.includes('[error]') || lower.includes('error')) return 'log-error'
  if (lower.includes('[warn]') || lower.includes('warning')) return 'log-warn'
  if (lower.includes('[debug]')) return 'log-debug'
  return 'log-info'
}

function getMethodClass(method: string): string {
  const m = method.toUpperCase()
  if (m === 'GET') return 'method-get'
  if (m === 'POST') return 'method-post'
  if (m === 'PUT') return 'method-put'
  if (m === 'DELETE') return 'method-delete'
  if (m === 'PATCH') return 'method-patch'
  return ''
}

function getStatusClass(status: number): string {
  if (status >= 200 && status < 300) return 'status-success'
  if (status >= 400 && status < 500) return 'status-warning'
  if (status >= 500) return 'status-error'
  return ''
}

onMounted(() => {
  logStore.connect()
})

onUnmounted(() => {
  // 不再主动断开连接，保持全局状态
})
</script>

<template>
  <div class="log-view">
    <transition name="fade">
      <div v-if="clearNotification" class="clear-notification">
        <el-icon><Operation /></el-icon>
        {{ clearNotification }}
      </div>
    </transition>
    <div class="page-header">
      <h2 class="page-title">{{ t('logView.title') }}</h2>
      <div class="header-actions">
        <el-input
          v-model="filterText"
          :placeholder="t('logView.searchPlaceholder')"
          clearable
          size="small"
          style="width: 200px"
          @input="updateFilteredLogs"
        />
        <el-switch
          v-model="autoScroll"
          size="small"
          :active-text="t('logView.autoScroll')"
          style="margin-left: 12px"
        />
        <el-button
          :type="paused ? 'warning' : 'default'"
          size="small"
          @click="togglePause"
          style="margin-left: 8px"
        >
          {{ paused ? t('logView.resume') : t('logView.pause') }}
        </el-button>
        <el-button :icon="Delete" size="small" @click="clearLogs">{{ t('logView.clearAll') }}</el-button>
        <el-button :icon="Download" size="small" @click="downloadLogs">{{ t('logView.export') }}</el-button>
      </div>
    </div>

    <!-- API 请求日志 - 上半部分 -->
    <div class="log-section api-section">
      <div class="section-header">
        <div class="section-title">
          <el-icon><Link /></el-icon>
          <span>{{ t('logView.apiRequest') }}</span>
          <el-tag size="small" type="info">{{ filteredApiLogs.length }}</el-tag>
        </div>
        <div class="section-actions">
          <el-select
            v-model="filterMethod"
            :placeholder="t('logView.method')"
            clearable
            size="small"
            style="width: 90px; margin-right: 8px"
          >
            <el-option label="GET" value="GET" />
            <el-option label="POST" value="POST" />
            <el-option label="PUT" value="PUT" />
            <el-option label="DELETE" value="DELETE" />
          </el-select>
          <el-input
            v-model="filterText"
            :placeholder="t('logView.searchPath')"
            clearable
            size="small"
            style="width: 150px; margin-right: 8px"
          />
          <el-button size="small" @click="clearApiLogsHandler">{{ t('logView.clear') }}</el-button>
        </div>
      </div>
      <div class="api-log-container">
        <el-scrollbar>
          <div v-if="filteredApiLogs.length === 0" class="log-empty">
            {{ t('logView.noApiRequests') }}
          </div>
          <table v-else class="api-log-table">
            <thead>
              <tr>
                <th class="col-time">{{ t('logView.time') }}</th>
                <th class="col-method">{{ t('logView.method') }}</th>
                <th class="col-path">{{ t('logView.path') }}</th>
                <th class="col-status">{{ t('logView.status') }}</th>
                <th class="col-duration">{{ t('logView.elapsed') }}</th>
                <th class="col-size">{{ t('videoManager.size') }}</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="log in filteredApiLogs"
                :key="log.id"
                :class="{ 'log-error-row': log.error }"
              >
                <td class="col-time">{{ log.time }}</td>
                <td class="col-method">
                  <el-tag size="small" :class="getMethodClass(log.method)">
                    {{ log.method }}
                  </el-tag>
                </td>
                <td class="col-path" :title="log.path">{{ log.path }}</td>
                <td class="col-status">
                  <el-tag v-if="log.error" size="small" type="danger">Error</el-tag>
                  <el-tag v-else size="small" :class="getStatusClass(log.status)">
                    {{ log.status }}
                  </el-tag>
                </td>
                <td class="col-duration">{{ log.duration }}ms</td>
                <td class="col-size">{{ log.size || '-' }}</td>
              </tr>
            </tbody>
          </table>
        </el-scrollbar>
      </div>
    </div>

    <!-- 分隔线 -->
    <div class="section-divider">
      <el-icon><Operation /></el-icon>
      <span>{{ t('logView.websocketLog') }}</span>
    </div>

    <!-- WebSocket 日志 - 下半部分 -->
    <div class="log-section ws-section">
      <div class="section-header">
        <div class="section-title">
          <el-icon><Operation /></el-icon>
          <span>{{ t('logView.websocketLog') }}</span>
          <el-tag size="small" type="info">{{ filteredWsLogs.length }}</el-tag>
        </div>
        <div class="section-actions">
          <el-button size="small" @click="clearWsLogs">{{ t('logView.clear') }}</el-button>
        </div>
      </div>
      <div class="ws-log-container">
        <div ref="wsLogContent" class="ws-log-content">
          <div
            v-for="(log, index) in filteredWsLogs"
            :key="index"
            class="log-line"
            :class="getLogClass(log)"
          >{{ log }}</div>
          <div v-if="filteredWsLogs.length === 0" class="log-empty">
            {{ paused ? t('logView.logPaused') : t('logView.waitingLog') }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.log-view {
  height: calc(100vh - 120px);
  display: flex;
  flex-direction: column;
  gap: 8px;

  .clear-notification {
    position: fixed;
    top: 80px;
    right: 20px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-color);
    border-radius: 6px;
    padding: 10px 16px;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--text-primary);
    font-size: 13px;
    z-index: 1000;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);

    .el-icon {
      color: #a6e3a1;
    }
  }

  .fade-enter-active,
  .fade-leave-active {
    transition: opacity 0.3s, transform 0.3s;
  }

  .fade-enter-from,
  .fade-leave-to {
    opacity: 0;
    transform: translateY(-10px);
  }

  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }

    .header-actions {
      display: flex;
      align-items: center;
    }
  }

  .log-section {
    display: flex;
    flex-direction: column;
    background: var(--bg-primary);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);

    &:hover {
      border-color: rgba(251, 113, 133, 0.4);
      box-shadow: 0 8px 32px rgba(251, 113, 133, 0.18),
                  0 4px 16px rgba(251, 113, 133, 0.1);
      transform: translateY(-2px);
    }
  }

  .api-section {
    flex: 0 0 40%;
    min-height: 150px;
  }

  .ws-section {
    flex: 1;
    min-height: 200px;
  }

  .section-divider {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    color: var(--text-muted);
    font-size: 12px;
    flex-shrink: 0;
    padding: 4px 0;
  }

  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: var(--bg-primary);
    border-bottom: 1px solid var(--border-color);
    position: relative;
    z-index: 2;

    .section-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      font-weight: 600;
      color: var(--text-primary);
    }
  }

  .api-log-container {
    flex: 1;
    overflow: hidden;

    :deep(.el-scrollbar__view) {
      padding: 0;
    }
  }

  .api-log-table {
    width: 100%;
    border-collapse: collapse;
    font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
    font-size: 12px;

    th, td {
      padding: 6px 8px;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
    }

    th {
      background: var(--bg-tertiary);
      color: var(--text-muted);
      font-weight: 500;
      font-size: 11px;
      text-transform: uppercase;
      position: sticky;
      top: 0;
      z-index: 1;
    }

    td {
      color: var(--text-secondary);
    }

    .col-time {
      width: 80px;
      color: var(--text-muted);
    }

    .col-method {
      width: 70px;
    }

    .col-path {
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .col-status {
      width: 60px;
    }

    .col-duration {
      width: 70px;
      text-align: right;
    }

    .col-size {
      width: 80px;
      text-align: right;
      color: var(--text-muted);
    }

    tr:hover {
      background: var(--bg-tertiary);
    }

    tr.log-error-row {
      background: rgba(243, 139, 168, 0.1);
    }

    :deep(.el-tag) {
      &.method-get {
        background: rgba(166, 227, 161, 0.2);
        color: #a6e3a1;
        border-color: transparent;
      }
      &.method-post {
        background: rgba(137, 180, 250, 0.2);
        color: #89b4fa;
        border-color: transparent;
      }
      &.method-put {
        background: rgba(249, 226, 175, 0.2);
        color: #f9e2af;
        border-color: transparent;
      }
      &.method-delete {
        background: rgba(243, 139, 168, 0.2);
        color: #f38ba8;
        border-color: transparent;
      }
      &.method-patch {
        background: rgba(203, 166, 247, 0.2);
        color: #cba6f7;
        border-color: transparent;
      }
      &.status-success {
        background: rgba(166, 227, 161, 0.2);
        color: #a6e3a1;
        border-color: transparent;
      }
      &.status-warning {
        background: rgba(249, 226, 175, 0.2);
        color: #f9e2af;
        border-color: transparent;
      }
      &.status-error {
        background: rgba(243, 139, 168, 0.2);
        color: #f38ba8;
        border-color: transparent;
      }
    }
  }

  .ws-log-container {
    flex: 1;
    overflow: hidden;
  }

  .ws-log-content {
    height: 100%;
    overflow-y: auto;
    padding: 12px;
    font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
    font-size: 12px;
    line-height: 1.6;

    .log-line {
      padding: 3px 6px;
      margin: 2px 0;
      white-space: pre-wrap;
      word-break: break-all;
      color: var(--text-secondary);
      border-radius: 4px;
      background: rgba(255, 255, 255, 0.5);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      transition: all 0.3s ease;

      &.log-error {
        color: #e11d48;
        background: rgba(254, 226, 226, 0.5);
      }

      &.log-warn {
        color: #d97706;
        background: rgba(254, 243, 199, 0.5);
      }

      &.log-debug {
        color: var(--text-muted);
        background: rgba(255, 255, 255, 0.3);
      }

      &.log-info {
        color: var(--text-secondary);
        background: rgba(255, 255, 255, 0.5);
      }

      &:hover {
        background: rgba(255, 255, 255, 0.8);
        transform: translateX(4px);
        box-shadow: 0 2px 8px rgba(251, 113, 133, 0.1);
      }
    }

    .log-empty {
      text-align: center;
      color: var(--text-muted);
      padding: 20px;
    }
  }
}

html.dark {
  .log-view {
    .log-section {
      background: linear-gradient(
        135deg,
        rgba(30, 18, 18, 0.95) 0%,
        rgba(40, 24, 24, 0.95) 50%,
        rgba(30, 18, 18, 0.95) 100%
      );
      border-color: rgba(255, 255, 255, 0.08);

      &::before {
        background: linear-gradient(
          120deg,
          transparent 0%,
          rgba(251, 113, 133, 0.2) 25%,
          rgba(251, 113, 133, 0.3) 50%,
          rgba(251, 113, 133, 0.2) 75%,
          transparent 100%
        );
      }

      &:hover {
        background: linear-gradient(
          135deg,
          rgba(45, 28, 28, 0.98) 0%,
          rgba(55, 35, 35, 0.98) 50%,
          rgba(45, 28, 28, 0.98) 100%
        );
        border-color: rgba(251, 113, 133, 0.25);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
      }
    }

    .section-header {
      background: linear-gradient(
        135deg,
        rgba(35, 20, 20, 0.98) 0%,
        rgba(45, 28, 28, 0.98) 100%
      );
      border-bottom-color: rgba(255, 255, 255, 0.08);
    }

    .api-log-table {
      th {
        background: rgba(30, 18, 18, 0.95);
      }

      tr:hover {
        background: rgba(40, 24, 24, 0.5);
      }

      tr.log-error-row {
        background: rgba(243, 139, 168, 0.15);
      }
    }

    .ws-log-content {
      .log-line {
        background: rgba(30, 18, 18, 0.5);

        &.log-error {
          color: #f38ba8;
          background: rgba(243, 139, 168, 0.15);
        }

        &.log-warn {
          color: #fab387;
          background: rgba(250, 179, 135, 0.15);
        }

        &.log-debug {
          color: var(--text-muted);
          background: rgba(255, 255, 255, 0.05);
        }

        &.log-info {
          color: var(--text-secondary);
          background: rgba(30, 18, 18, 0.5);
        }

        &:hover {
          background: rgba(45, 28, 28, 0.8);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }
      }
    }

    .clear-notification {
      background: linear-gradient(
        135deg,
        rgba(30, 18, 18, 0.98) 0%,
        rgba(40, 24, 24, 0.98) 100%
      );
      border-color: rgba(251, 113, 133, 0.25);
    }
  }
}
</style>
