<script setup lang="ts">
import { ref, onMounted, onUnmounted, computed, nextTick } from 'vue'
import { useSoundPackStore, type SoundPackFile, type SoundPackEntry } from '@/stores/soundpack'
import { soundpackApi } from '@/api'
import {
  Search, Refresh, VideoPlay, Delete, FolderOpened,
  Download, Lock, Unlock, Upload, Edit, Headset
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const soundpackStore = useSoundPackStore()

const searchQuery = ref('')
let debounceTimer: ReturnType<typeof setTimeout> | null = null

const filteredSoundPacks = computed(() => {
  if (!searchQuery.value) return soundpackStore.soundpacks
  const q = searchQuery.value.toLowerCase()
  return soundpackStore.soundpacks.filter(sp => sp.name.toLowerCase().includes(q))
})

// 选中的音效包和条目
const selectedSoundPack = ref<SoundPackFile | null>(null)
const entries = ref<SoundPackEntry[]>([])
const entriesLoading = ref(false)
const selectedEntries = ref<SoundPackEntry[]>([])

// 解密状态
// const decrypting = ref(false)  // 不再需要，自动在服务端解密

// 播放器
const playDialogVisible = ref(false)
const currentPlayingEntry = ref<SoundPackEntry | null>(null)
const audioUrl = ref('')
const audioRef = ref<HTMLAudioElement | null>(null)
const volume = ref(80)

// 导入
const importDialogVisible = ref(false)
const importFiles = ref<File[]>([])
const importResults = ref<any[]>([])

// 重命名
const renameDialogVisible = ref(false)
const renameEntry = ref<SoundPackEntry | null>(null)
const renameNewPath = ref('')

// 转换格式
const convertDialogVisible = ref(false)
const convertEntry = ref<SoundPackEntry | null>(null)
const targetFormat = ref('mp3')

// 批量导出
const batchExportDialogVisible = ref(false)
const batchExportFormat = ref('ogg')

const operationLoading = ref<string | null>(null)

onMounted(async () => {
  await Promise.all([soundpackStore.fetchSoundPacks(), soundpackStore.fetchStats()])
})

onUnmounted(() => {
  if (debounceTimer) clearTimeout(debounceTimer)
})

// 选择音效包 - 自动加载条目
async function selectSoundPack(sp: SoundPackFile) {
  selectedSoundPack.value = sp
  entries.value = []
  selectedEntries.value = []
  await loadEntries()
}

async function loadEntries() {
  if (!selectedSoundPack.value) return
  entriesLoading.value = true
  try {
    const res = await soundpackApi.getEntries(selectedSoundPack.value.id) as any
    entries.value = res.data?.items || res.data || []
  } catch (e: any) {
    ElMessage.error(t('common.requestFailed') + ': ' + e.message)
  } finally {
    entriesLoading.value = false
  }
}

async function handleScan() {
  try {
    await ElMessageBox.confirm(
      t('soundpackManager.scanDir'),
      t('soundpackManager.scanDir'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = 'scan'
    try {
      await soundpackStore.scanSoundPacks()
      ElMessage.success(t('common.scanComplete'))
      if (selectedSoundPack.value) {
        const updated = soundpackStore.soundpacks.find(sp => sp.id === selectedSoundPack.value!.id)
        if (updated) {
          selectedSoundPack.value = updated
          await loadEntries()
        }
      }
    } catch (e: any) {
      ElMessage.error(t('common.scanFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function handleRefresh() {
  await Promise.all([soundpackStore.fetchSoundPacks(), soundpackStore.fetchStats()])
  if (selectedSoundPack.value) {
    // 更新选中的音效包引用
    const updated = soundpackStore.soundpacks.find(sp => sp.id === selectedSoundPack.value!.id)
    if (updated) selectedSoundPack.value = updated
  }
}

// 操作后刷新
async function refreshAfterOp() {
  await loadEntries()
  await soundpackStore.fetchSoundPacks()
  await soundpackStore.fetchStats()
  if (selectedSoundPack.value) {
    const updated = soundpackStore.soundpacks.find(sp => sp.id === selectedSoundPack.value!.id)
    if (updated) selectedSoundPack.value = updated
  }
}

function handleEntrySelectionChange(selection: SoundPackEntry[]) {
  selectedEntries.value = selection
}

// 播放 OGG 条目
function handlePlay(entry: SoundPackEntry) {
  if (!selectedSoundPack.value) return
  currentPlayingEntry.value = entry
  audioUrl.value = soundpackApi.getEntryStreamUrl(selectedSoundPack.value.id, entry.id)
  playDialogVisible.value = true
  nextTick(() => {
    setTimeout(() => {
      if (audioRef.value) {
        audioRef.value.play().catch(() => {})
      }
    }, 300)
  })
}

function handleDialogClose() {
  if (audioRef.value) {
    audioRef.value.pause()
    audioRef.value.src = ''
  }
  currentPlayingEntry.value = null
}

function handleVolumeChange(val: number | number[]) {
  if (audioRef.value) {
    audioRef.value.volume = (typeof val === 'number' ? val : val[0]) / 100
  }
}

function handleAudioError(e: Event) {
  const audio = e.target as HTMLAudioElement
  if (!audio.src || audio.src === '' || audio.src === window.location.href) return
  const err = audio.error
  // MEDIA_ERR_ABORTED (1) = user aborted, MEDIA_ERR_NETWORK (2) = real network error
  if (!err || err.code === 1) return
  console.error('Audio load error:', err.code, err.message)
  ElMessage.error(t('common.requestFailed'))
}

function handleDownload(entry: SoundPackEntry) {
  if (!selectedSoundPack.value) return
  const url = soundpackApi.getEntryDownloadUrl(selectedSoundPack.value.id, entry.id)
  const a = document.createElement('a')
  a.href = url
  const path = entry.entry_path
  const idx = path.lastIndexOf('/')
  const dir = idx >= 0 ? path.substring(0, idx) : ''
  const name = idx >= 0 ? path.substring(idx + 1) : path
  a.download = dir ? dir.replace(/\//g, '_') + '@' + name : name
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

// 删除音效包
async function handleDeleteSP(sp: SoundPackFile) {
  try {
    const action = await ElMessageBox.confirm(
      t('common.confirmDelete') + ` "${sp.name}"?`,
      t('common.delete'),
      {
        confirmButtonText: t('common.confirm'),
        cancelButtonText: t('common.cancel'),
        type: 'warning',
        distinguishCancelAndClose: true
      }
    ).catch((a) => a)
    if (!action) return

    operationLoading.value = `delete-sp-${sp.id}`
    try {
      if (action === 'confirm') {
        await soundpackApi.deleteWithFile(sp.id)
        ElMessage.success(t('common.operationSuccess'))
      } else {
        await soundpackStore.deleteSoundPack(sp.id)
        ElMessage.success(t('common.operationSuccess'))
      }
      if (selectedSoundPack.value?.id === sp.id) {
        selectedSoundPack.value = null
        entries.value = []
      }
      await handleRefresh()
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

// 删除条目
async function handleDeleteEntry(entry: SoundPackEntry) {
  if (!selectedSoundPack.value) return
  try {
    await ElMessageBox.confirm(
      t('common.confirmDelete') + ` "${entry.entry_name}"?`,
      t('common.delete'),
      { confirmButtonText: t('common.delete'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    operationLoading.value = `delete-entry-${entry.id}`
    try {
      await soundpackApi.deleteEntry(selectedSoundPack.value.id, entry.id)
      ElMessage.success(t('common.operationSuccess'))
      await refreshAfterOp()
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

// 导入 OGG
function openImportDialog() {
  importFiles.value = []
  importResults.value = []
  importDialogVisible.value = true
}

function handleImportFiles(files: any) {
  const raw = (Array.isArray(files) ? files : [files]).map((f: any) => f.raw || f)
  importFiles.value = raw
  // 解析文件名 → 路径预览
  importResults.value = raw.map(f => {
    const name = f.name
    const ext = name.substring(name.lastIndexOf('.'))
    const nameOnly = name.substring(0, name.lastIndexOf('.'))
    let path = ''
    if (nameOnly.includes('@')) {
      const idx = nameOnly.indexOf('@')
      const dirPart = nameOnly.substring(0, idx).replace(/_/g, '/')
      const filePart = nameOnly.substring(idx + 1)
      path = dirPart + '/' + filePart + ext
    } else {
      path = 'imported/' + name
    }
    const exists = entries.value.some(e => e.entry_path === path || e.entry_name === name)
    return { filename: name, path, exists }
  })
}

async function handleImport() {
  if (!selectedSoundPack.value || importFiles.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  const dup = importResults.value.filter(r => r.exists)
  if (dup.length > 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  operationLoading.value = 'import'
  try {
    const res = await soundpackApi.batchImport(selectedSoundPack.value.id, importFiles.value) as any
    const data = res.data || res
    importResults.value = (data.results || []).map((r: any) => ({
      ...r,
      exists: r.status === 'skipped',
    }))
    const imported = data.imported || 0
    if (imported > 0) {
      ElMessage.success(t('common.operationSuccess'))
      await refreshAfterOp()
      importDialogVisible.value = false
    }
  } catch (e: any) {
    ElMessage.error(t('common.operationFailed') + ': ' + e.message)
  } finally {
    operationLoading.value = null
  }
}

// 批量删除
async function handleBatchDelete() {
  if (!selectedSoundPack.value || selectedEntries.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  try {
    await ElMessageBox.confirm(
      t('common.confirmDelete') + ` ${selectedEntries.value.length}?`,
      t('soundpackManager.batchDelete'),
      { confirmButtonText: t('common.delete'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    const ids = selectedEntries.value.map(e => e.id)
    await soundpackApi.batchDeleteEntries(selectedSoundPack.value.id, ids)
    ElMessage.success(t('common.operationSuccess'))
    selectedEntries.value = []
    await refreshAfterOp()
  } catch (e: any) {
    if (e !== 'cancel') ElMessage.error(t('common.operationFailed') + ': ' + e.message)
  }
}

// 批量导出
function openBatchExportDialog() {
  if (selectedEntries.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  batchExportFormat.value = 'ogg'
  batchExportDialogVisible.value = true
}

async function handleBatchExport() {
  if (!selectedSoundPack.value || selectedEntries.value.length === 0) return
  try {
    const entryIds = selectedEntries.value.map(e => e.id)
    const res = await fetch(soundpackApi.getBatchExportUrl(selectedSoundPack.value.id), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entry_ids: entryIds, target_format: batchExportFormat.value }),
    })
    if (!res.ok) throw new Error(t('common.operationFailed'))
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `soundpack_export.${batchExportFormat.value === 'ogg' ? 'zip' : 'zip'}`
    a.click()
    URL.revokeObjectURL(url)
    ElMessage.success(t('common.operationSuccess'))
    batchExportDialogVisible.value = false
  } catch (e: any) {
    ElMessage.error(t('common.operationFailed') + ': ' + e.message)
  }
}

function formatSize(bytes: number): string {
  if (!bytes || isNaN(bytes)) return '0 B'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

function formatDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return '00:00'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
}

function formatSampleRate(rate: number): string {
  if (!rate) return '-'
  return (rate / 1000).toFixed(1) + ' kHz'
}

const convertFormats = [
  { label: 'MP3', value: 'mp3' },
  { label: 'OGG', value: 'ogg' },
  { label: 'WAV', value: 'wav' },
  { label: 'FLAC', value: 'flac' },
]

// 重命名
function openRenameDialog(entry: SoundPackEntry) {
  renameEntry.value = entry
  renameNewPath.value = entry.entry_path
  renameDialogVisible.value = true
}

async function handleRename() {
  if (!selectedSoundPack.value || !renameEntry.value || !renameNewPath.value) return
  const newName = renameNewPath.value.substring(renameNewPath.value.lastIndexOf('/') + 1)
  const dup = entries.value.find(e => 
    e.id !== renameEntry.value!.id && 
    (e.entry_path === renameNewPath.value || e.entry_name === newName)
  )
  if (dup) {
    ElMessage.warning(t('common.warning') + ': ' + renameNewPath.value)
    return
  }
  operationLoading.value = 'rename'
  try {
    await soundpackApi.renameEntry(selectedSoundPack.value.id, renameEntry.value.id, renameNewPath.value)
    ElMessage.success(t('common.operationSuccess'))
    renameDialogVisible.value = false
    await refreshAfterOp()
  } catch (e: any) {
    ElMessage.error(t('common.operationFailed') + ': ' + e.message)
  } finally {
    operationLoading.value = null
  }
}

// 转换格式
function openConvertDialog(entry: SoundPackEntry) {
  convertEntry.value = entry
  targetFormat.value = 'mp3'
  convertDialogVisible.value = true
}

function handleConvert() {
  if (!selectedSoundPack.value || !convertEntry.value) return
  const baseName = convertEntry.value.entry_name.replace(/\.[^.]+$/, '')
  const url = soundpackApi.convertEntry(selectedSoundPack.value.id, convertEntry.value.id, targetFormat.value)
  const a = document.createElement('a')
  a.href = url
  a.download = baseName + '.' + targetFormat.value
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  ElMessage.success(t('common.operationSuccess'))
  convertDialogVisible.value = false
}
</script>

<template>
  <div class="soundpack-manager">
    <div class="page-header">
      <h2 class="page-title">{{ t('soundpackManager.title') }}</h2>
      <div class="header-actions">
        <el-button :icon="Refresh" size="small" :loading="soundpackStore.loading" @click="handleRefresh">
          {{ t('common.refresh') }}
        </el-button>
      </div>
    </div>

    <!-- 工具栏 -->
    <div class="toolbar">
      <el-input
        v-model="searchQuery"
        :placeholder="t('soundpackManager.searchPlaceholder')"
        :prefix-icon="Search"
        clearable
        class="search-input"
      />
      <el-button
        type="primary"
        :icon="FolderOpened"
        :loading="operationLoading === 'scan'"
        @click="handleScan"
      >
        {{ t('soundpackManager.scanDir') }}
      </el-button>
    </div>

    <!-- 统计卡片 -->
    <el-row :gutter="16" class="stats-row">
      <el-col :span="8">
        <el-card class="stat-card stat-card--total" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><FolderOpened /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ soundpackStore.totalCount }}</div>
              <div class="stat-label">{{ t('soundpackManager.totalPacks') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="stat-card stat-card--size" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><Headset /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ formatSize(soundpackStore.totalSize) }}</div>
              <div class="stat-label">{{ t('soundpackManager.totalSize') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="stat-card stat-card--ogg" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><Headset /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ soundpackStore.totalOggCount }}</div>
              <div class="stat-label">{{ t('soundpackManager.totalOggEntries') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主内容 -->
    <div class="main-content">
      <!-- 左侧：音效包列表 -->
      <div class="sp-sidebar">
        <div class="sidebar-header">
          <el-icon><FolderOpened /></el-icon>
          <span>SoundPacks</span>
        </div>
        <div class="sp-list">
          <div
            v-for="sp in filteredSoundPacks"
            :key="sp.id"
            class="sp-item"
            :class="{ active: selectedSoundPack?.id === sp.id }"
            @click="selectSoundPack(sp)"
          >
            <div class="sp-info">
              <div class="sp-name">
                <el-icon v-if="sp.is_encrypted" class="lock-icon"><Lock /></el-icon>
                <el-icon v-else class="unlock-icon"><Unlock /></el-icon>
                {{ sp.name }}
              </div>
              <div class="sp-meta">
                {{ formatSize(sp.size) }}
                <span v-if="sp.ogg_count > 0"> | {{ sp.ogg_count }} OGG</span>
              </div>
            </div>
            <el-button
              type="danger"
              :icon="Delete"
              circle
              size="small"
              :loading="operationLoading === `delete-sp-${sp.id}`"
              @click.stop="handleDeleteSP(sp)"
            />
          </div>
          <el-empty v-if="filteredSoundPacks.length === 0" :description="t('soundpackManager.noPacks')" />
        </div>
      </div>

      <!-- 右侧：条目详情 -->
      <div class="entry-panel">
        <template v-if="selectedSoundPack">
          <div class="entry-panel-header">
            <div class="entry-panel-title">
              <span class="sp-detail-name">{{ selectedSoundPack.name }}</span>
              <el-tag v-if="selectedSoundPack.is_encrypted" type="warning" size="small">{{ t('soundpackManager.encrypted') }}</el-tag>
              <el-tag v-else type="success" size="small">{{ t('soundpackManager.decrypted') }}</el-tag>
              <el-tag size="small">{{ formatSize(selectedSoundPack.size) }}</el-tag>
            </div>
            <div class="entry-panel-actions">
              <el-tag v-if="selectedEntries.length > 0" type="info" size="small" effect="dark" style="margin-right: 8px">
                {{ t('soundpackManager.selectedCount', { count: selectedEntries.length }) }}
              </el-tag>
              <el-button
                v-if="selectedEntries.length > 0"
                type="danger"
                size="small"
                :icon="Delete"
                @click="handleBatchDelete"
              >
                {{ t('soundpackManager.batchDelete') }}
              </el-button>
              <el-button
                v-if="selectedEntries.length > 0"
                type="success"
                size="small"
                :icon="Download"
                @click="openBatchExportDialog"
              >
                {{ t('soundpackManager.batchExport') }}
              </el-button>
              <el-button
                type="primary"
                size="small"
                :icon="Upload"
                @click="openImportDialog"
              >
                {{ t('soundpackManager.importOgg') }}
              </el-button>
            </div>
          </div>

          <el-card class="entry-table-card">
            <el-table
              v-loading="entriesLoading"
              :data="entries"
              stripe
              @selection-change="handleEntrySelectionChange"
              class="entry-table"
            >
              <el-table-column type="selection" width="40" />

              <el-table-column :label="t('soundpackManager.path')" prop="entry_path" min-width="200" show-overflow-tooltip>
                <template #default="{ row }">
                  <span class="entry-path-text">{{ row.entry_path }}</span>
                </template>
              </el-table-column>

              <el-table-column :label="t('soundpackManager.fileName')" prop="entry_name" min-width="150" show-overflow-tooltip />

              <el-table-column :label="t('soundpackManager.duration')" width="80" align="center">
                <template #default="{ row }">
                  <span class="mono-text">{{ formatDuration(row.ogg_duration) }}</span>
                </template>
              </el-table-column>

              <el-table-column :label="t('soundpackManager.sampleRate')" width="100" align="center">
                <template #default="{ row }">
                  <span class="mono-text">{{ formatSampleRate(row.ogg_sample_rate) }}</span>
                </template>
              </el-table-column>

              <el-table-column :label="t('soundpackManager.size')" width="100" align="right">
                <template #default="{ row }">
                  <span class="mono-text">{{ formatSize(row.entry_size) }}</span>
                </template>
              </el-table-column>

              <el-table-column :label="t('soundpackManager.operation')" width="220" align="center" fixed="right">
                <template #default="{ row }">
                  <div class="action-icons">
                    <el-button type="primary" :icon="VideoPlay" circle size="small" :title="t('soundpackManager.playTitle')" @click="handlePlay(row)" />
                    <el-button type="success" :icon="Download" circle size="small" :title="t('soundpackManager.downloadTitle')" @click="handleDownload(row)" />
                    <el-button type="info" :icon="Edit" circle size="small" :title="t('soundpackManager.renameTitle')" @click="openRenameDialog(row)" />
                    <el-button
                      type="warning"
                      circle
                      size="small"
                      :title="t('soundpackManager.convertTitle')"
                      @click="openConvertDialog(row)"
                    >
                      <el-icon><Headset /></el-icon>
                    </el-button>
                    <el-button
                      type="danger"
                      :icon="Delete"
                      circle
                      size="small"
                      :title="t('soundpackManager.deleteTitle')"
                      :loading="operationLoading === `delete-entry-${row.id}`"
                      @click="handleDeleteEntry(row)"
                    />
                  </div>
                </template>
              </el-table-column>
            </el-table>
            <div class="entry-count-info">
              <el-tag type="info" effect="plain">{{ t('soundpackManager.entryCount', { count: entries.length }) }}</el-tag>
            </div>
          </el-card>

          <el-empty v-if="!entriesLoading && entries.length === 0 && !selectedSoundPack.is_encrypted" :description="t('soundpackManager.noOggEntries')" />
        </template>

        <el-empty v-else :description="t('soundpackManager.selectPackHint')" class="no-selection" />
      </div>
    </div>

    <!-- 播放对话框 -->
    <el-dialog
      v-model="playDialogVisible"
      :title="currentPlayingEntry ? `${t('common.play')}: ${currentPlayingEntry.entry_name}` : t('common.play')"
      width="500px"
      destroy-on-close
      align-center
      @close="handleDialogClose"
    >
      <div class="player-container">
        <div v-if="currentPlayingEntry" class="entry-info-box">
          <div class="entry-info-row">
            <span class="info-label">{{ t('soundpackManager.path') }}:</span>
            <span>{{ currentPlayingEntry.entry_path }}</span>
          </div>
          <div class="entry-info-row">
            <span class="info-label">{{ t('soundpackManager.duration') }}:</span>
            <span>{{ formatDuration(currentPlayingEntry.ogg_duration) }}</span>
          </div>
          <div class="entry-info-row">
            <span class="info-label">{{ t('soundpackManager.sampleRate') }}:</span>
            <span>{{ formatSampleRate(currentPlayingEntry.ogg_sample_rate) }}</span>
          </div>
        </div>
        <div class="audio-player-wrapper">
          <audio
            ref="audioRef"
            :src="audioUrl"
            class="audio-player"
            controls
            preload="auto"
            @error="handleAudioError"
          />
        </div>
      </div>
      <div class="player-controls-bar">
        <div class="volume-control">
          <el-icon :size="16"><Headset /></el-icon>
          <el-slider
            v-model="volume"
            :min="0"
            :max="100"
            :show-tooltip="false"
            size="small"
            style="width: 100px"
            @input="handleVolumeChange"
          />
        </div>
      </div>
    </el-dialog>

    <!-- 导入对话框 -->
    <el-dialog v-model="importDialogVisible" :title="t('soundpackManager.importOggFile')" width="550px" align-center>
      <div class="import-body">
        <el-upload
          :auto-upload="false"
          multiple
          :on-change="handleImportFiles"
          accept=".ogg,.mp3,.wav,.flac"
          drag
        >
          <el-icon :size="40"><Upload /></el-icon>
          <div>{{ t('soundpackManager.dragUploadHint') }}</div>
          <template #tip>
            <div style="font-size: 12px; margin-top: 8px; color: var(--text-muted)">
              {{ t('soundpackManager.autoParseHint') }}
            </div>
          </template>
        </el-upload>

        <div v-if="importResults.length > 0" class="import-preview" style="margin-top: 16px">
          <h4>{{ t('soundpackManager.pathPreview') }}</h4>
          <el-table :data="importResults" size="small" max-height="200">
            <el-table-column prop="filename" :label="t('soundpackManager.fileNameLabel')" min-width="180" show-overflow-tooltip />
            <el-table-column prop="path" :label="t('soundpackManager.importPathLabel')" min-width="180" show-overflow-tooltip>
              <template #default="{ row }">
                <span :style="{ color: row.exists ? 'var(--el-color-danger)' : '' }">{{ row.path }}</span>
              </template>
            </el-table-column>
          </el-table>
          <div v-if="importResults.some(r => r.exists)" style="color: var(--el-color-danger); font-size: 12px; margin-top: 8px">
            {{ t('soundpackManager.conflictHint') }}
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="importDialogVisible = false">{{ t('soundpackManager.cancel') }}</el-button>
        <el-button
          type="primary"
          :loading="operationLoading === 'import'"
          :disabled="importFiles.length === 0 || importResults.some(r => r.exists)"
          @click="handleImport"
        >
          {{ t('common.upload') }} {{ importFiles.length }}
        </el-button>
      </template>
    </el-dialog>

    <!-- 重命名对话框 -->
    <el-dialog v-model="renameDialogVisible" :title="t('soundpackManager.renameEntry')" width="450px" align-center>
      <el-form label-width="80px">
        <el-form-item :label="t('soundpackManager.newPath')">
          <el-input v-model="renameNewPath" placeholder="button/click_new.ogg" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="renameDialogVisible = false">{{ t('soundpackManager.cancel') }}</el-button>
        <el-button type="primary" :loading="operationLoading === 'rename'" @click="handleRename">{{ t('soundpackManager.confirm') }}</el-button>
      </template>
    </el-dialog>

    <!-- 转换对话框 -->
    <el-dialog v-model="convertDialogVisible" :title="t('soundpackManager.convertFormat')" width="400px" align-center>
      <el-form label-width="80px">
        <el-form-item :label="t('soundpackManager.convertFormat')">
          <el-select v-model="targetFormat" style="width: 200px">
            <el-option v-for="fmt in convertFormats" :key="fmt.value" :label="fmt.label" :value="fmt.value" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="convertDialogVisible = false">{{ t('soundpackManager.cancel') }}</el-button>
        <el-button type="primary" @click="handleConvert">{{ t('soundpackManager.convertAndDownload') }}</el-button>
      </template>
    </el-dialog>

    <!-- 批量导出对话框 -->
    <el-dialog v-model="batchExportDialogVisible" :title="t('soundpackManager.batchExport')" width="420px" align-center>
      <el-form label-width="80px">
        <el-form-item :label="t('soundpackManager.entryCount', { count: selectedEntries.length })">
          <span>{{ selectedEntries.length }}</span>
        </el-form-item>
        <el-form-item :label="t('soundpackManager.convertFormat')">
          <el-select v-model="batchExportFormat" style="width: 200px">
            <el-option v-for="fmt in convertFormats" :key="fmt.value" :label="fmt.label" :value="fmt.value" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="batchExportDialogVisible = false">{{ t('soundpackManager.cancel') }}</el-button>
        <el-button type="primary" @click="handleBatchExport">{{ t('soundpackManager.exportZip') }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.soundpack-manager {
  height: calc(100vh - 90px - 48px);
  display: flex;
  flex-direction: column;

  .page-header {
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-shrink: 0;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
  }

  .toolbar {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
    flex-shrink: 0;

    .search-input {
      width: 260px;
    }
  }

  .stats-row {
    margin-bottom: 16px;
    flex-shrink: 0;

    .stat-card {
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 16px;
      transition: transform 0.2s ease;
      position: relative;
      overflow: hidden;

      &:hover {
        transform: translateY(-2px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        border-radius: 14px 14px 0 0;
      }

      &--total::before { background: linear-gradient(90deg, #89b4fa, #74c7ec); }
      &--size::before { background: linear-gradient(90deg, #a6e3a1, #94e2d5); }
      &--ogg::before { background: linear-gradient(90deg, #cba6f7, #b4befe); }

      .stat-content {
        display: flex; align-items: center; gap: 14px;

        .stat-icon {
          width: 48px; height: 48px; border-radius: 12px;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }

        .stat-info {
          .stat-value {
            font-size: 20px; font-weight: 600;
            color: var(--text-primary); margin-bottom: 2px;
          }
          .stat-label { font-size: 11px; color: var(--text-secondary); }
        }
      }
    }

    .stat-card--total .stat-icon { background: rgba(137,180,250,0.15); color: #89b4fa; }
    .stat-card--size .stat-icon { background: rgba(166,227,161,0.15); color: #a6e3a1; }
    .stat-card--ogg .stat-icon { background: rgba(203,166,247,0.15); color: #cba6f7; }
  }

  .main-content {
    flex: 1;
    display: flex;
    gap: 16px;
    min-height: 0;
    overflow: hidden;

    .sp-sidebar {
      width: 280px;
      flex-shrink: 0;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      overflow: hidden;

      .sidebar-header {
        display: flex; align-items: center; gap: 8px;
        padding: 12px 16px;
        font-weight: 600; font-size: 14px;
        border-bottom: 1px solid var(--border-color);
        background: var(--el-fill-color-light);
      }

      .sp-list {
        flex: 1; overflow-y: auto; padding: 8px;

        .sp-item {
          display: flex; align-items: center; justify-content: space-between;
          padding: 10px 12px; cursor: pointer;
          border-radius: 6px; margin: 2px 0;
          border: 1px solid transparent;
          transition: all 0.2s;

          &:hover {
            background: var(--el-fill-color-light);
            border-color: var(--el-color-primary-light-5);
          }

          &.active {
            background: rgba(251,113,133,0.08);
            border-color: rgba(251,113,133,0.3);
          }

          .sp-info {
            flex: 1; min-width: 0;

            .sp-name {
              display: flex; align-items: center; gap: 6px;
              font-size: 13px; font-weight: 500;
              overflow: hidden; text-overflow: ellipsis; white-space: nowrap;

              .lock-icon { color: var(--el-color-warning); }
              .unlock-icon { color: var(--el-color-success); }
            }

            .sp-meta {
              font-size: 11px; color: var(--text-muted); margin-top: 2px;
            }
          }
        }
      }
    }

    .entry-panel {
      flex: 1; min-width: 0;
      display: flex; flex-direction: column;

      .entry-panel-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 0 0 12px 0; flex-shrink: 0;

        .entry-panel-title {
          display: flex; align-items: center; gap: 8px;

          .sp-detail-name { font-size: 16px; font-weight: 600; }
        }

        .entry-panel-actions {
          display: flex; align-items: center; gap: 8px;
        }
      }

      .entry-table-card {
        flex: 1; display: flex; flex-direction: column;
        min-height: 0;
        background: var(--bg-primary);
        border: 1px solid var(--border-color);

        :deep(.el-card__body) {
          flex: 1; display: flex; flex-direction: column;
          min-height: 0; padding: 12px;
        }

        .entry-table {
          flex: 1; min-height: 0;
        }

        .entry-path-text { font-size: 12px; color: var(--text-secondary); }
        .mono-text { font-family: monospace; font-size: 12px; }

        .action-icons {
          display: flex; align-items: center; justify-content: center;
          gap: 4px; flex-wrap: wrap;
        }

        .entry-count-info {
          display: flex; justify-content: flex-end;
          padding-top: 12px; flex-shrink: 0;
        }
      }

      .no-selection {
        margin-top: 40px;
      }
    }
  }

  .player-container {
    background: var(--bg-secondary);
    border-radius: 8px; overflow: hidden;

    .entry-info-box {
      padding: 12px 16px; display: flex; flex-direction: column; gap: 6px;

      .entry-info-row {
        display: flex; align-items: center; gap: 8px;
        font-size: 13px;

        .info-label { color: var(--text-muted); min-width: 50px; }
      }
    }

    .audio-player-wrapper {
      padding: 12px; background: #f5f7fa;

      .audio-player { width: 100%; outline: none; }
    }
  }

  .player-controls-bar {
    display: flex; align-items: center; justify-content: center; gap: 16px;
    padding: 12px;
    background: var(--bg-secondary);
    border-top: 1px solid var(--border-color);
    border-radius: 0 0 8px 8px;

    .volume-control {
      display: flex; align-items: center; gap: 8px;
    }
  }

  .batch-import-body {
    .import-results {
      max-height: 200px;
      overflow-y: auto;

      h4 { margin: 0 0 8px 0; font-size: 13px; }

      .result-item {
        display: flex; align-items: center; gap: 8px;
        padding: 6px 0; font-size: 12px;

        .result-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .result-err { color: var(--el-color-danger); font-size: 11px; }
      }
    }
  }
}
</style>
