<script setup lang="ts">
import { onMounted, computed, ref, nextTick, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useLibraryStore } from '@/stores/library'
import { useNpkStore } from '@/stores/npk'
import { useUiStore } from '@/stores/ui'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Document,
  Picture,
  VideoPlay,
  Folder,
  Download,
  ArrowRight,
  Plus,
  Edit,
  Upload,
  Setting,
  Help,
  Link,
  Tools as ToolsIcon,
  Delete
} from '@element-plus/icons-vue'

const { t } = useI18n()
const libraryStore = useLibraryStore()
const npkStore = useNpkStore()
const uiStore = useUiStore()

// 屏保状态
const showSplashScreen = ref(false)
const isSplashExiting = ref(false)

// 自动屏保定时器
let autoSplashTimer: ReturnType<typeof setTimeout> | null = null

// 重置自动屏保定时器
function resetAutoSplashTimer() {
  if (autoSplashTimer) {
    clearTimeout(autoSplashTimer)
    autoSplashTimer = null
  }
  
  // 如果启用了自动屏保且屏保未显示，则设置定时器
  if (uiStore.autoSplashTimeout > 0 && !showSplashScreen.value && uiStore.enableSplashScreen) {
    autoSplashTimer = setTimeout(() => {
      showSplashScreen.value = true
    }, uiStore.autoSplashTimeout * 60 * 1000)
  }
}

// 用户活动监听
function handleUserActivity() {
  resetAutoSplashTimer()
}

onMounted(async () => {
  // 检查是否首次访问（使用 sessionStorage）
  const hasVisited = sessionStorage.getItem('npk-has-visited')
  
  // 先加载数据
  await Promise.all([
    libraryStore.fetchStats(),
    npkStore.fetchNpkList(),
  ])
  
  // 加载卡组
  loadGroups()
  
  // 只有首次访问才显示屏保
  if (!hasVisited && uiStore.enableSplashScreen) {
    showSplashScreen.value = true
    await nextTick()
  }
  
  // 标记已访问
  sessionStorage.setItem('npk-has-visited', 'true')
  
  // 启动自动屏保定时器
  resetAutoSplashTimer()
  
  // 添加用户活动监听
  document.addEventListener('mousemove', handleUserActivity)
  document.addEventListener('keydown', handleUserActivity)
  document.addEventListener('click', handleUserActivity)
})

onUnmounted(() => {
  // 清理定时器和监听器
  if (autoSplashTimer) {
    clearTimeout(autoSplashTimer)
  }
  document.removeEventListener('mousemove', handleUserActivity)
  document.removeEventListener('keydown', handleUserActivity)
  document.removeEventListener('click', handleUserActivity)
})

// 关闭屏保
async function closeSplashScreen() {
  if (!showSplashScreen.value) return
  
  isSplashExiting.value = true
  
  // 等待动画完成
  setTimeout(() => {
    showSplashScreen.value = false
    isSplashExiting.value = false
    // 重置自动屏保定时器
    resetAutoSplashTimer()
  }, 600)
}

const stats = computed(() => libraryStore.stats)

interface QuickAction {
  id: string
  title: string
  description: string
  icon: any
  iconName: string
  path: string
  color: string
}

const defaultActions: QuickAction[] = [
  { id: '1', title: t('dashboard.defaultActions.npkManage'), description: t('dashboard.defaultActions.npkManageDesc'), icon: Folder, iconName: 'Folder', path: '/npk', color: 'var(--accent-color)' },
  { id: '2', title: t('dashboard.defaultActions.imgBrowse'), description: t('dashboard.defaultActions.imgBrowseDesc'), icon: Picture, iconName: 'Picture', path: '/browser', color: 'var(--accent-color)' },
  { id: '3', title: t('dashboard.defaultActions.animation'), description: t('dashboard.defaultActions.animationDesc'), icon: VideoPlay, iconName: 'VideoPlay', path: '/animation', color: 'var(--accent-color)' },
  { id: '4', title: t('dashboard.defaultActions.batchExport'), description: t('dashboard.defaultActions.batchExportDesc'), icon: Download, iconName: 'Download', path: '/batch', color: 'var(--accent-color)' }
]

const quickActions = ref<QuickAction[]>([])
const showActionDialog = ref(false)
const editingAction = ref<QuickAction | null>(null)
const actionForm = ref({
  title: '',
  description: '',
  iconName: 'Folder',
  path: '',
  color: 'var(--accent-color)'
})

const iconOptions = ['Folder', 'Picture', 'VideoPlay', 'Download', 'Upload', 'Setting', 'Help', 'Link', 'Tools']

function getIconByName(name: string) {
  const iconMap: Record<string, any> = {
    Folder, Picture, VideoPlay, Download, Upload, Setting, Help, Link, Tools: ToolsIcon
  }
  return iconMap[name] || Folder
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2)
}

function saveActions() {
  const data = quickActions.value.map(item => ({
    id: item.id,
    title: item.title,
    description: item.description,
    iconName: item.iconName,
    path: item.path,
    color: item.color
  }))
  localStorage.setItem('npk-dashboard-actions', JSON.stringify(data))
}

function openAddActionDialog() {
  editingAction.value = null
  actionForm.value = {
    title: '',
    description: '',
    iconName: 'Folder',
    path: '',
    color: 'var(--accent-color)'
  }
  showActionDialog.value = true
}

function openEditActionDialog(action: QuickAction) {
  editingAction.value = action
  actionForm.value = {
    title: action.title,
    description: action.description,
    iconName: action.iconName,
    path: action.path,
    color: action.color
  }
  showActionDialog.value = true
}

function confirmSaveAction() {
  if (!actionForm.value.title || !actionForm.value.path) {
    ElMessage.warning(t('dashboard.fillTitleAndPath'))
    return
  }

  if (editingAction.value) {
    const index = quickActions.value.findIndex(a => a.id === editingAction.value!.id)
    if (index !== -1) {
      quickActions.value[index] = {
        ...editingAction.value,
        title: actionForm.value.title,
        description: actionForm.value.description,
        iconName: actionForm.value.iconName,
        icon: getIconByName(actionForm.value.iconName),
        path: actionForm.value.path,
        color: actionForm.value.color
      }
    }
  } else {
    quickActions.value.push({
      id: generateId(),
      title: actionForm.value.title,
      description: actionForm.value.description,
      iconName: actionForm.value.iconName,
      icon: getIconByName(actionForm.value.iconName),
      path: actionForm.value.path,
      color: actionForm.value.color
    })
  }

  saveActions()
  showActionDialog.value = false
  ElMessage.success(editingAction.value ? t('dashboard.actionUpdated') : t('dashboard.actionAdded'))
}

async function deleteAction(action: QuickAction) {
  try {
    await ElMessageBox.confirm(t('dashboard.confirmDeleteAction', { title: action.title }), t('common.confirmDelete'), {
      confirmButtonText: t('common.confirm'),
      cancelButtonText: t('common.cancel'),
      type: 'warning'
    })

    quickActions.value = quickActions.value.filter(a => a.id !== action.id)
    saveCurrentGroupActions()
    ElMessage.success(t('dashboard.deleted'))
  } catch {
    // cancelled
  }
}

// 卡组管理
interface ActionGroup {
  id: string
  name: string
  actions: QuickAction[]
}

const defaultGroups: ActionGroup[] = [
  {
    id: 'all',
    name: t('dashboard.defaultGroups.all'),
    actions: JSON.parse(JSON.stringify(defaultActions))
  },
  {
    id: 'favorites',
    name: t('dashboard.defaultGroups.favorites'),
    actions: []
  },
  {
    id: 'recent',
    name: t('dashboard.defaultGroups.recent'),
    actions: []
  },
  {
    id: 'recommend',
    name: t('dashboard.defaultGroups.recommend'),
    actions: []
  }
]

const actionGroups = ref<ActionGroup[]>([])
const activeGroupId = ref<string>('all')
const showGroupDialog = ref(false)
const editingGroup = ref<ActionGroup | null>(null)
const groupForm = ref({
  name: ''
})

function loadGroups() {
  const savedGroups = localStorage.getItem('npk-dashboard-groups')
  const savedActiveId = localStorage.getItem('npk-dashboard-active-group')

  if (savedGroups) {
    try {
      const groups = JSON.parse(savedGroups)
      actionGroups.value = groups.map((g: any) => ({
        ...g,
        actions: g.actions.map((a: any) => ({
          ...a,
          icon: getIconByName(a.iconName)
        }))
      }))
    } catch {
      actionGroups.value = JSON.parse(JSON.stringify(defaultGroups))
    }
  } else {
    actionGroups.value = JSON.parse(JSON.stringify(defaultGroups))
  }

  if (savedActiveId && actionGroups.value.find(g => g.id === savedActiveId)) {
    activeGroupId.value = savedActiveId
  } else if (actionGroups.value.length > 0) {
    activeGroupId.value = actionGroups.value[0].id
  }

  loadGroupActions()
  loadGroupsFromServer()
}

function saveGroups() {
  const data = actionGroups.value.map(g => ({
    id: g.id,
    name: g.name,
    actions: g.actions.map(a => ({
      id: a.id,
      title: a.title,
      description: a.description,
      iconName: a.iconName,
      path: a.path,
      color: a.color
    }))
  }))
  localStorage.setItem('npk-dashboard-groups', JSON.stringify(data))
  localStorage.setItem('npk-dashboard-active-group', activeGroupId.value)
  saveGroupsToServer(data)
}

async function loadGroupsFromServer() {
  try {
    const res = await fetch('/api/settings')
    if (!res.ok) return
    const json = await res.json()
    const data = json.data || json
    if (data.dashboard_groups && Array.isArray(data.dashboard_groups) && data.dashboard_groups.length > 0) {
      actionGroups.value = data.dashboard_groups.map((g: any) => ({
        ...g,
        actions: (g.actions || []).map((a: any) => ({
          ...a,
          icon: getIconByName(a.iconName)
        }))
      }))
      if (data.dashboard_active_group && actionGroups.value.find(g => g.id === data.dashboard_active_group)) {
        activeGroupId.value = data.dashboard_active_group
      }
      loadGroupActions()
      const localData = actionGroups.value.map(g => ({
        id: g.id, name: g.name,
        actions: g.actions.map(a => ({ id: a.id, title: a.title, description: a.description, iconName: a.iconName, path: a.path, color: a.color }))
      }))
      localStorage.setItem('npk-dashboard-groups', JSON.stringify(localData))
      localStorage.setItem('npk-dashboard-active-group', activeGroupId.value)
    }
  } catch {
    // fallback to localStorage
  }
}

async function saveGroupsToServer(data: any[]) {
  try {
    await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dashboard_groups: data,
        dashboard_active_group: activeGroupId.value
      })
    })
  } catch {
    // silent
  }
}

function loadGroupActions() {
  const activeGroup = actionGroups.value.find(g => g.id === activeGroupId.value)
  if (activeGroup) {
    quickActions.value = [...activeGroup.actions]
  }
}

function switchGroup(groupId: string) {
  activeGroupId.value = groupId
  loadGroupActions()
  saveGroups()
}

function openAddGroupDialog() {
  editingGroup.value = null
  groupForm.value.name = ''
  showGroupDialog.value = true
}

function openEditGroupDialog(group: ActionGroup, event: MouseEvent) {
  event.stopPropagation()
  editingGroup.value = group
  groupForm.value.name = group.name
  showGroupDialog.value = true
}

function confirmSaveGroup() {
  if (!groupForm.value.name.trim()) {
    ElMessage.warning(t('dashboard.groupNameRequired'))
    return
  }

  if (editingGroup.value) {
    const index = actionGroups.value.findIndex(g => g.id === editingGroup.value!.id)
    if (index !== -1) {
      actionGroups.value[index].name = groupForm.value.name.trim()
    }
  } else {
    const newGroup: ActionGroup = {
      id: generateId(),
      name: groupForm.value.name.trim(),
      actions: []
    }
    actionGroups.value.push(newGroup)
    activeGroupId.value = newGroup.id
    quickActions.value = []
  }

  saveGroups()
  showGroupDialog.value = false
  groupForm.value.name = ''
  editingGroup.value = null
  ElMessage.success(editingGroup.value ? t('dashboard.groupUpdated') : t('dashboard.groupAdded'))
}

async function deleteGroup(group: ActionGroup, event: MouseEvent) {
  event.stopPropagation()

  if (actionGroups.value.length <= 1) {
    ElMessage.warning(t('dashboard.keepAtLeastOneGroup'))
    return
  }

  try {
    await ElMessageBox.confirm(t('dashboard.confirmDeleteGroup', { name: group.name }), t('common.confirmDelete'), {
      confirmButtonText: t('common.confirm'),
      cancelButtonText: t('common.cancel'),
      type: 'warning'
    })

    actionGroups.value = actionGroups.value.filter(g => g.id !== group.id)

    if (activeGroupId.value === group.id && actionGroups.value.length > 0) {
      activeGroupId.value = actionGroups.value[0].id
      loadGroupActions()
    }

    saveGroups()
    ElMessage.success(t('dashboard.groupDeleted'))
  } catch {
    // cancelled
  }
}

function saveCurrentGroupActions() {
  const activeGroup = actionGroups.value.find(g => g.id === activeGroupId.value)
  if (activeGroup) {
    activeGroup.actions = [...quickActions.value]
    saveGroups()
  }
}

watch(quickActions, () => {
  saveCurrentGroupActions()
}, { deep: true })
</script>

<template>
  <div class="landing-page">
    <!-- 屏保层 -->
    <div 
      v-if="showSplashScreen" 
      class="splash-screen" 
      :class="{ exiting: isSplashExiting }"
      @click="closeSplashScreen"
    >
      <div class="splash-content">
        <div class="left-section">
          <div class="hero-text">
            <h1 class="title">{{ t('dashboard.title') }}</h1>
            <p class="subtitle">{{ t('dashboard.subtitle') }}</p>
          </div>
          
          <div class="description">
            <div class="intro-text" v-html="uiStore.splashIntroText.replace(/\n/g, '<br>')"></div>
          </div>

          <div class="stats-preview">
            <div class="stat-item" v-if="stats">
              <div class="stat-number">{{ stats.npk_count || 0 }}</div>
              <div class="stat-text">{{ t('dashboard.npkFiles') }}</div>
            </div>
            <div class="stat-item" v-if="stats">
              <div class="stat-number">{{ stats.album_count || 0 }}</div>
              <div class="stat-text">{{ t('dashboard.albumResources') }}</div>
            </div>
            <div class="stat-item" v-if="stats">
              <div class="stat-number">{{ stats.sprite_count || 0 }}</div>
              <div class="stat-text">{{ t('dashboard.imageResources') }}</div>
            </div>
          </div>
        </div>

        <div class="right-section">
          <div class="avatar-container">
            <div class="avatar-ring"></div>
            <div class="avatar-ring"></div>
            <div class="avatar-ring"></div>
            <div class="avatar">
              <div class="avatar-content">
                <img 
                  v-if="uiStore.splashAvatarImage" 
                  :src="uiStore.splashAvatarImage" 
                  class="custom-avatar" 
                />
                <Document v-else :size="80" />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="splash-hint">
        <span>{{ t('dashboard.splashHint') }}</span>
        <div class="arrow-down">
          <svg viewBox="0 0 24 24" width="24" height="24">
            <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"></path>
          </svg>
        </div>
      </div>
    </div>

    <!-- 主内容层 -->
    <div class="landing-content" :class="{ behind: showSplashScreen }">
      <div class="left-section">
        <div class="hero-text">
          <h1 class="title">{{ t('dashboard.title') }}</h1>
          <p class="subtitle">{{ t('dashboard.subtitle') }}</p>
        </div>
        
        <div class="description">
          <p v-html="uiStore.splashIntroText.replace(/\n/g, '<br>')"></p>
        </div>

        <div class="stats-preview">
          <div class="stat-item" v-if="stats">
            <div class="stat-number">{{ stats.npk_count || 0 }}</div>
            <div class="stat-text">{{ t('dashboard.npkFiles') }}</div>
          </div>
          <div class="stat-item" v-if="stats">
            <div class="stat-number">{{ stats.album_count || 0 }}</div>
            <div class="stat-text">{{ t('dashboard.albumResources') }}</div>
          </div>
          <div class="stat-item" v-if="stats">
            <div class="stat-number">{{ stats.sprite_count || 0 }}</div>
            <div class="stat-text">{{ t('dashboard.imageResources') }}</div>
          </div>
        </div>

        <div class="action-buttons">
          <el-button type="primary" size="large" class="start-button" @click="$router.push('/npk')">
            {{ t('dashboard.startUsing') }}
            <el-icon><ArrowRight /></el-icon>
          </el-button>
        </div>
      </div>

      <div class="right-section">
        <div class="avatar-container">
          <div class="avatar-ring"></div>
          <div class="avatar-ring"></div>
          <div class="avatar-ring"></div>
          <div class="avatar">
            <div class="avatar-content">
              <img 
                v-if="uiStore.splashAvatarImage" 
                :src="uiStore.splashAvatarImage" 
                class="custom-avatar" 
              />
              <Document v-else :size="80" />
            </div>
          </div>
        </div>
        
        <!-- 卡组切换 -->
        <div class="tag-group">
          <div 
            class="tag-item" 
            v-for="group in actionGroups" 
            :key="group.id" 
            :class="{ active: activeGroupId === group.id }" 
            @click="switchGroup(group.id)"
          >
            {{ group.name }}
            <div class="tag-actions">
              <el-icon class="tag-edit" @click="openEditGroupDialog(group, $event)"><Edit /></el-icon>
              <el-icon class="tag-delete" @click="deleteGroup(group, $event)"><Delete /></el-icon>
            </div>
          </div>
          <div class="tag-item add-tag" @click="openAddGroupDialog">
            <el-icon><Plus /></el-icon>
          </div>
        </div>

        <div class="feature-cards">
          <div 
            class="feature-card" 
            v-for="action in quickActions" 
            :key="action.id" 
            @click="$router.push(action.path)"
          >
            <div class="feature-actions">
              <el-button 
                size="small" 
                type="primary" 
                link 
                icon="Edit" 
                @click.stop="openEditActionDialog(action)"
              />
              <el-button 
                size="small" 
                type="danger" 
                link 
                icon="Delete" 
                @click.stop="deleteAction(action)"
              />
            </div>
            <el-icon :size="32" :color="action.color"><component :is="action.icon" /></el-icon>
            <h3>{{ action.title }}</h3>
            <p>{{ action.description }}</p>
            <div class="card-arrow">
              <el-icon><ArrowRight /></el-icon>
            </div>
          </div>
          
          <div class="feature-card add-card" @click="openAddActionDialog">
            <el-icon :size="32" color="var(--text-muted)"><Plus /></el-icon>
            <h3>{{ t('dashboard.addAction') }}</h3>
            <p>{{ t('dashboard.addCustomAction') }}</p>
          </div>
        </div>
      </div>
    </div>

    <el-dialog
      v-model="showActionDialog"
      :title="editingAction ? t('dashboard.editAction') : t('dashboard.addActionTitle')"
      width="450px"
    >
      <el-form :model="actionForm" label-width="80px">
        <el-form-item :label="t('dashboard.actionTitle')" required>
          <el-input
            v-model="actionForm.title"
            :placeholder="t('dashboard.actionTitlePlaceholder')"
          />
        </el-form-item>
        <el-form-item :label="t('dashboard.actionDesc')">
          <el-input
            v-model="actionForm.description"
            :placeholder="t('dashboard.actionDescPlaceholder')"
          />
        </el-form-item>
        <el-form-item :label="t('dashboard.actionIcon')">
          <el-select v-model="actionForm.iconName" :placeholder="t('dashboard.actionIconPlaceholder')">
            <el-option
              v-for="icon in iconOptions"
              :key="icon"
              :label="icon"
              :value="icon"
            />
          </el-select>
        </el-form-item>
        <el-form-item :label="t('dashboard.actionPath')" required>
          <el-input
            v-model="actionForm.path"
            :placeholder="t('dashboard.actionPathPlaceholder')"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showActionDialog = false">{{ t('common.cancel') }}</el-button>
        <el-button type="primary" @click="confirmSaveAction">
          {{ editingAction ? t('common.update') : t('common.add') }}
        </el-button>
      </template>
    </el-dialog>

    <el-dialog
      v-model="showGroupDialog"
      :title="editingGroup ? t('dashboard.editGroup') : t('dashboard.addGroup')"
      width="350px"
    >
      <el-form :model="groupForm" label-width="70px">
        <el-form-item :label="t('dashboard.groupName')">
          <el-input
            v-model="groupForm.name"
            :placeholder="t('dashboard.groupNamePlaceholder')"
            @keyup.enter="confirmSaveGroup"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showGroupDialog = false">{{ t('common.cancel') }}</el-button>
        <el-button type="primary" @click="confirmSaveGroup">
          {{ editingGroup ? t('common.update') : t('common.add') }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.landing-page {
  min-height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  position: relative;

  .splash-screen {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--bg-primary);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    animation: splashIn 0.6s ease-out;

    &.exiting {
      animation: splashOut 0.6s ease-in forwards;
    }

    .splash-content {
      display: flex;
      max-width: 1100px;
      width: 100%;
      gap: 60px;
      align-items: center;
      padding: 0 40px;
    }

    .splash-hint {
      position: absolute;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      color: var(--text-muted);
      font-size: 13px;

      .arrow-down svg {
        fill: var(--text-muted);
      }
    }

    .left-section {
      flex: 1;
      min-width: 0;

      .hero-text {
        margin-bottom: 24px;

        .title {
          font-size: 42px;
          font-weight: 700;
          color: var(--text-primary);
          margin: 0 0 10px;
          line-height: 1.2;
        }

        .subtitle {
          font-size: 16px;
          color: var(--text-secondary);
          margin: 0;
        }
      }

      .description {
        margin-bottom: 32px;

        .intro-text {
          font-size: 15px;
          color: var(--text-secondary);
          line-height: 1.7;
          margin: 0;
        }
      }

      .stats-preview {
        display: flex;
        gap: 32px;

        .stat-item {
          .stat-number {
            font-size: 36px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1;
          }

          .stat-text {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 6px;
          }
        }
      }
    }

    .right-section {
      flex: 1;
      min-width: 0;
      display: flex;
      justify-content: center;

      .avatar-container {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;

        .avatar-ring {
          position: absolute;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          border: 2px solid var(--accent-color);
          opacity: 0;
          animation: ripple 2s ease-out infinite;
        }

        .avatar-ring:nth-child(1) {
          animation-delay: 0s;
        }

        .avatar-ring:nth-child(2) {
          animation-delay: 0.6s;
        }

        .avatar-ring:nth-child(3) {
          animation-delay: 1.2s;
        }

        @keyframes ripple {
          0% {
            transform: scale(0.8);
            opacity: 0.8;
          }
          50% {
            opacity: 0.4;
          }
          100% {
            transform: scale(1.5);
            opacity: 0;
          }
        }

        .avatar {
          width: 180px;
          height: 180px;
          border-radius: 50%;
          background: var(--accent-color);
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;

          .avatar-content {
            width: 100%;
            height: 100%;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;

            .custom-avatar {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }

            .el-icon {
              font-size: 80px;
            }
          }
        }
      }
    }
  }

  .landing-content {
    display: flex;
    max-width: 1100px;
    width: 100%;
    gap: 60px;
    align-items: center;
    transition: opacity 0.3s;

    &.behind {
      opacity: 0;
    }

    .left-section {
      flex: 1;
      min-width: 0;

      .hero-text {
        margin-bottom: 24px;

        .title {
          font-size: 42px;
          font-weight: 700;
          color: var(--text-primary);
          margin: 0 0 10px;
          line-height: 1.2;
        }

        .subtitle {
          font-size: 16px;
          color: var(--text-secondary);
          margin: 0;
        }
      }

      .description {
        margin-bottom: 32px;

        p {
          font-size: 15px;
          color: var(--text-secondary);
          line-height: 1.7;
          margin: 0;
        }
      }

      .stats-preview {
        display: flex;
        gap: 32px;
        margin-bottom: 32px;

        .stat-item {
          .stat-number {
            font-size: 36px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1;
          }

          .stat-text {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 6px;
          }
        }
      }

      .action-buttons {
        .start-button {
          height: 48px;
          padding: 0 28px;
          font-size: 16px;
          font-weight: 600;
          border-radius: 8px;
        }
      }
    }

    .right-section {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 32px;

      .avatar-container {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;

        .avatar-ring {
          position: absolute;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          border: 2px solid var(--accent-color);
          opacity: 0;
          animation: ripple 2s ease-out infinite;
        }

        .avatar-ring:nth-child(1) {
          animation-delay: 0s;
        }

        .avatar-ring:nth-child(2) {
          animation-delay: 0.6s;
        }

        .avatar-ring:nth-child(3) {
          animation-delay: 1.2s;
        }

        .avatar {
          width: 180px;
          height: 180px;
          border-radius: 50%;
          background: var(--accent-color);
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;

          .avatar-content {
            width: 100%;
            height: 100%;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;

            .custom-avatar {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }

            .el-icon {
              font-size: 80px;
            }
          }
        }
      }

      .tag-group {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        justify-content: center;
        margin-top: 24px;

        .tag-item {
          padding: 4px 10px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.2s, border-color 0.2s, color 0.2s;
          background: var(--bg-primary);
          border: 1px solid var(--border-color);
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 3px;

          .tag-actions {
            display: none;
            gap: 3px;
            margin-left: 1px;
            
            .tag-edit, .tag-delete {
              font-size: 10px;
              padding: 1px;
              border-radius: 3px;
              transition: all 0.2s;
              
              &:hover {
                background: var(--bg-tertiary);
              }
              
              &.tag-delete:hover {
                color: #ef4444;
                background: rgba(239, 68, 68, 0.1);
              }
            }
          }

          &:hover {
            background: var(--bg-secondary);
            border-color: var(--accent-color);
            color: var(--text-primary);

            .tag-actions {
              display: flex;
            }
          }

          &.active {
            background: var(--accent-color);
            border-color: var(--accent-color);
            color: white;
            font-weight: 600;

            .tag-actions {
              .tag-edit:hover, .tag-delete:hover {
                background: rgba(255, 255, 255, 0.2);
              }
            }
          }

          &.add-tag {
            padding: 4px 8px;
            
            .el-icon {
              font-size: 12px;
            }
          }
        }
      }

      .feature-cards {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        width: 100%;

        .feature-card {
          background: var(--bg-primary);
          border: 1px solid var(--border-color);
          border-radius: 12px;
          padding: 20px;
          cursor: pointer;
          transition: background 0.2s, border-color 0.2s, box-shadow 0.2s, transform 0.2s;
          position: relative;

          &:hover {
            border-color: var(--accent-color);
            background: var(--bg-secondary);
            transform: translateY(-2px);

            .card-arrow {
              transform: translateX(4px);
            }
          }

          h3 {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 12px 0 8px;
          }

          p {
            font-size: 12px;
            color: var(--text-secondary);
            margin: 0;
            line-height: 1.6;
          }

          .card-arrow {
            position: absolute;
            right: 16px;
            top: 16px;
            color: var(--accent-color);
            transition: transform 0.2s;
          }

          .feature-actions {
            position: absolute;
            top: 8px;
            right: 8px;
            display: none;
            gap: 4px;

            :deep(.el-button) {
              padding: 2px 6px;
              font-size: 12px;
            }
          }

          &:hover .feature-actions {
            display: flex;
          }

          &.add-card {
            border-style: dashed;
            border-color: var(--border-color);
            background: transparent;
            opacity: 0.6;

            &:hover {
              opacity: 1;
              border-color: var(--accent-color);
              background: rgba(251, 113, 133, 0.05);
            }

            h3, p {
              color: var(--text-muted);
            }
          }
        }
      }
    }
  }
}

@keyframes splashIn {
  from {
    transform: translateY(-100%);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

@keyframes splashOut {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-100%);
    opacity: 0;
  }
}



@media (max-width: 768px) {
  .landing-page {
    padding: 24px 16px;

    .splash-screen,
    .landing-content {
      flex-direction: column;
      gap: 32px;
      text-align: center;

      .left-section {
        .stats-preview {
          justify-content: center;
        }
      }

      .right-section {
        width: 100%;
      }
    }
  }
}
</style>
