<script setup lang="ts">
import { ref, watch, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import {
  Search, View, FolderOpened, Picture, Edit, DocumentCopy, VideoPlay, VideoPause, Sunny, Moon, Monitor
} from '@element-plus/icons-vue'
import { albumApi, libraryApi, imgCacheApi } from '@/api/index'
import TextHighlight from '@/components/TextHighlight.vue'
import { ElMessage } from 'element-plus'
import { renderImageToCanvas } from '@/utils/canvas'
const { t } = useI18n()
const router = useRouter()

// 搜索
const searchQuery = ref('')
const loading = ref(false)

// 数据
interface AlbumEntry {
  npk_name: string
  npk_id: number
  album_path: string
  album_name: string
  sprite_count: number
  version: number | string
}

const resultList = ref<AlbumEntry[]>([])
const totalCount = ref(0)
const hasSearched = ref(false)

// 预览相关
const previewRow = ref<AlbumEntry | null>(null)
const previewUrl = ref('')
const previewLoading = ref(false)
const frameList = ref<any[]>([])
const frameListLoading = ref(false)
const selectedFrameIndex = ref<number>(0)
const albumVersion = ref<string>('')
const previewCanvas = ref<HTMLCanvasElement | null>(null)

// 搜索防抖
let searchTimer: number | null = null

// 去除黑色背景
const removeBlackBg = ref(false)
const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto')

function toggleCanvasBgMode() {
  if (canvasBgMode.value === 'auto') {
    canvasBgMode.value = 'light'
  } else if (canvasBgMode.value === 'light') {
    canvasBgMode.value = 'dark'
  } else {
    canvasBgMode.value = 'light'
  }
}

// 帧播放相关
const isPlaying = ref(false)
let playInterval: ReturnType<typeof setInterval> | null = null
const PLAY_INTERVAL = 200 // 0.2s 每帧

// IMG 缓存预加载
const MAX_PRELOADED = 10
type PreloadedEntry = { key: string; timestamp: number }
const preloadedImgKeys = ref<PreloadedEntry[]>([])

// 渲染图片到 canvas，可选去除黑色背景
let currentRenderCancel: (() => void) | null = null

async function renderToCanvas(url: string, removeBlack: boolean) {
  const canvas = previewCanvas.value
  if (!canvas) return

  // 取消之前的渲染
  if (currentRenderCancel) {
    currentRenderCancel()
  }

  try {
    const { promise, cancel } = renderImageToCanvas(canvas, url, removeBlack)
    currentRenderCancel = cancel
    await promise
    currentRenderCancel = null
  } catch {
    previewUrl.value = ''
    currentRenderCancel = null
  }
}

// 初始不加载，根据搜索输入加载

// === 服务端搜索（不分页，一次返回所有匹配结果） ===
async function fetchData() {
  if (!searchQuery.value.trim()) {
    resultList.value = []
    totalCount.value = 0
    hasSearched.value = false
    return
  }
  loading.value = true
  hasSearched.value = true
  try {
    // 使用大 pageSize 获取所有结果（上限 200）
    const res = await libraryApi.search(searchQuery.value, '', 1, 200)
    const data = res.data
    resultList.value = (data.results || []).map((item: any) => ({
      npk_name: item.npk_name || '',
      npk_id: item.npk_id || 0,
      album_path: item.album_path || '',
      album_name: item.album_name || '',
      sprite_count: item.sprite_count || 0,
      version: item.version || ''
    }))
    totalCount.value = data.total || 0

    // 预加载前3个结果的 IMG 缓存
    preloadTopResults(resultList.value.slice(0, 3))
  } catch (e: any) {
    console.error('Search failed:', e)
    resultList.value = []
    totalCount.value = 0
  } finally {
    loading.value = false
  }
}

// 预加载前3个搜索结果的 IMG 缓存
async function preloadTopResults(items: AlbumEntry[]) {
  for (const item of items) {
    const key = `${item.npk_name}:${item.album_path}`
    const existingIndex = preloadedImgKeys.value.findIndex(e => e.key === key)
    
    if (existingIndex >= 0) {
      // 已存在，移到最后（最近使用）
      const [entry] = preloadedImgKeys.value.splice(existingIndex, 1)
      entry.timestamp = Date.now()
      preloadedImgKeys.value.push(entry)
    } else {
      try {
        await imgCacheApi.load(item.npk_name, item.album_path)
        
        // 超过限制时清理最旧的
        if (preloadedImgKeys.value.length >= MAX_PRELOADED) {
          const oldest = preloadedImgKeys.value.shift()!
          const [npk, ...pathParts] = oldest.key.split(':')
          const path = pathParts.join(':')
          imgCacheApi.release(npk, path).catch(() => {})
        }
        
        preloadedImgKeys.value.push({ key, timestamp: Date.now() })
      } catch (e) {
        console.warn('Preload IMG cache failed:', item.npk_name, item.album_path, e)
      }
    }
  }
}

// 搜索输入防抖（300ms）
function onSearchInput() {
  if (searchTimer) clearTimeout(searchTimer)
  searchTimer = window.setTimeout(() => {
    fetchData()
  }, 300)
}

function onSearchClear() {
  if (searchTimer) clearTimeout(searchTimer)
  // 释放已预加载的缓存
  for (const entry of preloadedImgKeys.value) {
    const [npk, ...pathParts] = entry.key.split(':')
    const path = pathParts.join(':')
    imgCacheApi.release(npk, path).catch(() => {})
  }
  preloadedImgKeys.value = []
  resultList.value = []
  totalCount.value = 0
  hasSearched.value = false
  previewRow.value = null
  previewUrl.value = ''
  frameList.value = []
}

function locateNpk(npkName: string) {
  router.push({ path: '/npk', query: { name: npkName } })
}

function viewAnimation(row: AlbumEntry) {
  router.push({ path: '/animation', query: { npk: row.npk_name, album: row.album_path } })
}

function editImg(row: AlbumEntry) {
  router.push({ path: '/preview', query: { npk: row.npk_name, album: row.album_path } })
}

// 点击行预览
async function selectPreview(row: AlbumEntry) {
  // 用 album_path 判断是否为同一个预览（避免引用失效问题）
  if (previewRow.value && previewRow.value.album_path === row.album_path && previewRow.value.npk_name === row.npk_name) return
  
  // 切换文件时停止播放
  stopFramePlay()
  
  previewRow.value = row
  previewLoading.value = true
  previewUrl.value = ''
  frameListLoading.value = true
  selectedFrameIndex.value = 0

  // 确保当前项已缓存
  const key = `${row.npk_name}:${row.album_path}`
  const existingIndex = preloadedImgKeys.value.findIndex(e => e.key === key)
  
  if (existingIndex >= 0) {
    // 已存在，移到最后（最近使用）
    const [entry] = preloadedImgKeys.value.splice(existingIndex, 1)
    entry.timestamp = Date.now()
    preloadedImgKeys.value.push(entry)
  } else {
    try {
      await imgCacheApi.load(row.npk_name, row.album_path)
      
      // 超过限制时清理最旧的
      if (preloadedImgKeys.value.length >= MAX_PRELOADED) {
        const oldest = preloadedImgKeys.value.shift()!
        const [npk, ...pathParts] = oldest.key.split(':')
        const path = pathParts.join(':')
        imgCacheApi.release(npk, path).catch(() => {})
      }
      
      preloadedImgKeys.value.push({ key, timestamp: Date.now() })
    } catch (e) {
      console.warn('Preload IMG cache failed:', key, e)
    }
  }

  try {
    const url = `${albumApi.getPreviewUrl(row.npk_name, row.album_path)}&frame=0`
    previewUrl.value = url
    const res = await albumApi.getFrames(row.npk_name, row.album_path)
    frameList.value = res.data?.frames || []
    albumVersion.value = res.data?.version || ''
    // 渲染到 canvas
    setTimeout(() => renderToCanvas(url, removeBlackBg.value), 0)
  } catch {
    frameList.value = []
    albumVersion.value = ''
    previewUrl.value = ''
  } finally {
    previewLoading.value = false
    frameListLoading.value = false
  }
}

function onFrameClick(frame: any) {
  if (previewRow.value) {
    selectedFrameIndex.value = frame.index
    const url = `${albumApi.getPreviewUrl(previewRow.value.npk_name, previewRow.value.album_path)}&frame=${frame.index}`
    previewUrl.value = url
    setTimeout(() => renderToCanvas(url, removeBlackBg.value), 0)
  }
}

// 监听去黑底开关变化
watch(removeBlackBg, (newVal) => {
  if (previewUrl.value) {
    renderToCanvas(previewUrl.value, newVal)
  }
})

// 复制路径到剪贴板
function copyPath() {
  if (!previewRow.value) return
  const path = `${previewRow.value.npk_name} / ${previewRow.value.album_path}`
  navigator.clipboard.writeText(path).then(() => {
    ElMessage.success(t('imgBrowser.pathCopied'))
  }).catch(() => {
    ElMessage.error(t('common.copyFailed'))
  })
}

// 帧播放控制
function toggleFramePlay() {
  if (isPlaying.value) {
    stopFramePlay()
  } else {
    startFramePlay()
  }
}

function startFramePlay() {
  if (frameList.value.length === 0 || !previewRow.value) return
  isPlaying.value = true
  playInterval = setInterval(() => {
    const nextIndex = selectedFrameIndex.value + 1
    if (nextIndex < frameList.value.length) {
      const frame = frameList.value[nextIndex]
      onFrameClick(frame)
    } else {
      // 循环播放：回到第一帧
      const frame = frameList.value[0]
      onFrameClick(frame)
    }
  }, PLAY_INTERVAL)
}

function stopFramePlay() {
  isPlaying.value = false
  if (playInterval) {
    clearInterval(playInterval)
    playInterval = null
  }
}

// 获取版本标签样式类
function getVersionClass(version: number | string): string {
  let versionNum: number
  if (typeof version === 'string') {
    // 如果是字符串，移除前面的 V 后转数字
    versionNum = parseInt(version.replace(/^V/i, ''), 10)
  } else {
    versionNum = version
  }
  
  // 只匹配 V1 到 V6 范围内的版本
  if (versionNum >= 1 && versionNum <= 6) {
    return `v${versionNum}`
  }
  return 'other'
}

// 格式化版本显示
function formatVersion(version: number | string): string {
  if (!version && version !== 0) return 'IMG'
  
  let versionNum: number
  if (typeof version === 'string') {
    // 如果是字符串，移除前面的 V 后转数字
    versionNum = parseInt(version.replace(/^V/i, ''), 10)
  } else {
    versionNum = version
  }
  
  // 只显示 V1 到 V6 范围内的版本，其他显示为 IMG
  if (versionNum >= 1 && versionNum <= 6) {
    return `V${versionNum}`
  }
  return 'IMG'
}

// 页面卸载时释放所有预加载的缓存
onUnmounted(() => {
  if (currentRenderCancel) {
    currentRenderCancel()
  }
  for (const entry of preloadedImgKeys.value) {
    const [npk, ...pathParts] = entry.key.split(':')
    const path = pathParts.join(':')
    imgCacheApi.release(npk, path).catch(() => {})
  }
  preloadedImgKeys.value = []
})
</script>

<template>
  <div class="img-resources">
    <div class="page-header">
      <h2 class="page-title">{{ t('imgBrowser.title') }}</h2>
      <el-tag type="success" size="small">{{ t('imgBrowser.dbCount', { count: totalCount }) }}</el-tag>
    </div>

    <div class="content-wrapper">
    <el-row :gutter="16" class="content-row">
      <!-- 左侧: 列表 -->
      <el-col :span="14">
        <!-- 搜索栏 - 和左侧列表对齐 -->
        <div class="search-bar">
          <el-input
            v-model="searchQuery"
            :placeholder="t('imgBrowser.searchPlaceholder')"
            :prefix-icon="Search"
            clearable
            @input="onSearchInput"
            @clear="onSearchClear"
          />
        </div>
        <el-card class="table-card">
          <template #header>
            <span v-if="hasSearched">{{ t('imgBrowser.totalResults', { count: totalCount }) }}{{ searchQuery ? t('imgBrowser.searchResults') : '' }}</span>
            <span v-else>{{ t('imgBrowser.inputKeyword') }}</span>
          </template>

          <el-scrollbar v-loading="loading" class="result-scroll">
            <div v-if="resultList.length === 0 && !loading" class="empty-tip">
              <p v-if="hasSearched">{{ t('imgBrowser.noResults') }}</p>
              <p v-else>{{ t('imgBrowser.searchHint') }}</p>
            </div>
            <div class="result-list">
              <div
                v-for="row in resultList"
                :key="row.npk_name + '/' + row.album_path"
                class="list-item"
                :class="{ active: previewRow?.npk_name === row.npk_name && previewRow?.album_path === row.album_path }"
                @click="selectPreview(row)"
              >
                <div class="item-row">
                  <div class="item-info">
                    <div class="item-path"><TextHighlight :text="row.album_path" :keyword="searchQuery" /></div>
                    <div class="item-npk-name">{{ row.npk_name }}</div>
                  </div>
                  <div class="item-tags">
                    <el-tag size="small" class="item-tag count-tag">{{ row.sprite_count }} {{ t('imgBrowser.frames') }}</el-tag>
                    <el-tag size="small" class="item-tag version-tag" :class="getVersionClass(row.version)">
                      {{ formatVersion(row.version) }}
                    </el-tag>
                  </div>
                  <div class="item-actions">
                    <el-button size="small" type="primary" link @click.stop="editImg(row)">
                      <el-icon><Edit /></el-icon>
                    </el-button>
                    <el-button size="small" type="primary" link @click.stop="locateNpk(row.npk_name)">
                      <el-icon><FolderOpened /></el-icon>
                    </el-button>
                    <el-button size="small" type="primary" link @click.stop="viewAnimation(row)">
                      <el-icon><View /></el-icon>
                    </el-button>
                  </div>
                </div>
              </div>
            </div>
          </el-scrollbar>
        </el-card>
      </el-col>

      <!-- 右侧: 画布预览 + 帧列表 -->
      <el-col :span="10">
        <el-card class="preview-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('imgBrowser.canvasPreview') }}</span>
            </div>
          </template>

          <div v-if="!previewRow" class="preview-empty">
            <el-icon :size="48"><Picture /></el-icon>
            <span>{{ t('imgBrowser.clickToPreview') }}</span>
          </div>

          <div v-else class="preview-content">
            <div class="preview-path" v-if="previewRow">
              <el-tag size="small" type="info">{{ previewRow.album_path }}</el-tag>
              <el-button
                type="primary"
                link
                size="small"
                :icon="DocumentCopy"
                @click="copyPath"
                :title="t('imgBrowser.copyPathTitle')"
              />
              <el-checkbox v-model="removeBlackBg" size="small">{{ t('imgBrowser.removeBlackBg') }}</el-checkbox>
              <el-button size="small" :icon="canvasBgMode === 'auto' ? Monitor : canvasBgMode === 'light' ? Sunny : Moon" @click="toggleCanvasBgMode" />
            </div>
            <div class="canvas-container" :class="canvasBgMode" v-loading="previewLoading">
              <canvas v-if="previewUrl" ref="previewCanvas" class="canvas-image"></canvas>
              <div v-if="!previewUrl && !previewLoading && previewRow" class="preview-error">{{ t('imgBrowser.imageLoadFailed') }}</div>
            </div>

            <div class="frame-section">
              <div class="frame-section-header">
                <div class="frame-header-left">
                  <span>{{ t('imgBrowser.frameList') }}</span>
                  <el-tag size="small" v-if="frameList.length > 0">{{ frameList.length }}</el-tag>
                </div>
                <el-button
                  v-if="frameList.length > 0"
                  :icon="isPlaying ? VideoPause : VideoPlay"
                  size="small"
                  :type="isPlaying ? 'warning' : 'primary'"
                  @click="toggleFramePlay"
                >
                  {{ isPlaying ? t('common.stop') : t('common.play') }}
                </el-button>
              </div>
              <el-scrollbar v-if="frameList.length > 0" class="frame-scroll">
                <div class="frame-list">
                  <div
                    v-for="frame in frameList"
                    :key="frame.index"
                    class="frame-item"
                    :class="{ active: selectedFrameIndex === frame.index }"
                    @click="onFrameClick(frame)"
                  >
                    <span class="frame-number">{{ frame.index }}</span>
                    <template v-if="frame.is_link">
                      <span class="frame-link">
                        LINK
                        <template v-if="frame.link_status === 'normal'"> {{ t('imgBrowser.linkRef') }}：{{ frame.target_index }}</template>
                        <template v-else-if="frame.link_status === 'null'"> {{ t('imgBrowser.nullPointer') }}</template>
                        <template v-else-if="frame.link_status === 'circular'"> {{ t('imgBrowser.circularRef') }}</template>
                        <template v-else> {{ t('imgBrowser.linkRef') }}：{{ frame.target_index }}</template>
                      </span>
                    </template>
                    <template v-else>
                      <span class="frame-type">{{ frame.type_name || (albumVersion || 'IMG') }}</span>
                      <span class="frame-pos">{{ frame.x }},{{ frame.y }}</span>
                      <span class="frame-size">{{ frame.width }}×{{ frame.height }}</span>
                      <span class="frame-frame">{{ frame.frame_width }}×{{ frame.frame_height }}</span>
                    </template>
                  </div>
                </div>
              </el-scrollbar>
              <div v-else v-loading="frameListLoading" class="empty-tip" style="padding: 20px">
                {{ frameListLoading ? t('common.loading') : t('imgBrowser.noFrameData') }}
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.img-resources {
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 0;
  box-sizing: border-box;

  .page-header {
    flex-shrink: 0;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 0 16px;
    margin-top: 0;

    .page-title {
      margin: 0;
      font-size: 20px;
      font-weight: 600;
      color: var(--text-primary);
    }

    :deep(.el-tag) {
      border-radius: 6px;
      padding: 6px 10px;
      font-weight: 500;
      border: none;
      background: rgba(122, 205, 246, 0.1);
      color: var(--accent-color);
    }
  }

  .search-bar {
    flex-shrink: 0;
    display: flex;
    gap: 12px;
    margin-bottom: 16px;

    .el-input {
      width: 100%;
      max-width: none;

      :deep(.el-input__wrapper) {
        border-radius: 8px;
      }
    }
  }

  .content-wrapper {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
  }

  .content-row {
    flex: 1;
    min-height: 0;
    margin: 0;

    :deep(.el-col) {
      height: 100%;

      .el-card {
        height: 100%;
        display: flex;
        flex-direction: column;
        border-radius: 8px;

        :deep(.el-card__header) {
          padding: 14px 18px;
          border-bottom: 1px solid var(--border-color);
        }

        :deep(.el-card__body) {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
          padding: 16px;
        }
      }
    }
  }

  .table-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);

    :deep(.el-card__header) {
      padding: 14px 18px;
      border-bottom: 1px solid var(--border-color);
    }

    :deep(.el-card__body) {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      padding: 16px;
    }
  }

  .result-scroll {
    flex: 1;
    min-height: 0;

    :deep(.el-scrollbar__wrap) {
      overflow-x: auto !important;
      overflow-y: auto !important;
    }

    :deep(.el-scrollbar__bar.is-horizontal) {
      bottom: 0;
    }

    :deep(.el-scrollbar__thumb) {
      background: var(--accent-color);
      border-radius: 4px;
      opacity: 0.3;
    }
  }

  .result-list {
    display: flex;
    flex-direction: column;
    overflow-x: auto;
    gap: 4px;
    padding-bottom: 12px;

    &::-webkit-scrollbar {
      height: 6px;
    }
    &::-webkit-scrollbar-thumb {
      background: var(--accent-color);
      border-radius: 3px;
      opacity: 0.3;
    }
  }

  .list-item {
    position: relative;
    padding: 10px 14px;
    cursor: pointer;
    border-radius: 6px;
    transition: background 0.2s;
    margin: 2px 0;
    background: var(--bg-primary);
    border: 1px solid var(--border-color);

    &:hover {
      background: var(--bg-secondary);
    }

    &.active {
      background: rgba(251, 113, 133, 0.1);
      border-color: rgba(251, 113, 133, 0.3);
    }

    .item-row {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .item-info {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      gap: 4px;

      .item-path {
        white-space: nowrap;
        font-size: 13px;
        color: var(--text-primary);
        overflow: hidden;
        text-overflow: ellipsis;
        font-weight: 500;
      }

      .item-npk-name {
        white-space: nowrap;
        font-size: 12px;
        color: var(--text-muted);
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }

     .item-tags {
       display: flex;
       align-items: center;
       gap: 6px;
       flex-shrink: 0;
     }

     .item-actions {
       position: absolute;
       right: 14px;
       top: 50%;
       transform: translateY(-50%);
       display: flex;
       align-items: center;
       gap: 6px;
       opacity: 0;
       transition: opacity 0.2s;
       z-index: 5;
       background: var(--bg-primary);
       border: 1px solid var(--border-color);
       border-radius: 8px;
       padding: 4px 8px;

       :deep(.el-button) {
         padding: 6px;
         border-radius: 6px;
       }
     }

    &:hover .item-actions {
      opacity: 1;
    }

    .item-tag {
      flex-shrink: 0;
      border-radius: 4px !important;
      padding: 2px 8px !important;
      font-size: 11px !important;
      height: 20px !important;

      &.count-tag {
        background: rgba(122, 205, 246, 0.15);
        color: rgba(122, 205, 246, 0.9);
        border-color: transparent;
      }

      &.version-tag {
        border-color: transparent;

        &.v1 {
          background: rgba(128, 0, 128, 0.15);
          color: rgba(128, 0, 128, 0.9);
        }

        &.v2 {
          background: rgba(122, 205, 246, 0.15);
          color: rgba(122, 205, 246, 0.9);
        }

        &.v3 {
          background: rgba(0, 128, 128, 0.15);
          color: rgba(0, 128, 128, 0.9);
        }

        &.v4 {
          background: rgba(103, 194, 58, 0.15);
          color: rgba(103, 194, 58, 0.9);
        }

        &.v5 {
          background: rgba(230, 162, 60, 0.15);
          color: rgba(230, 162, 60, 0.9);
        }

        &.v6 {
          background: rgba(245, 108, 108, 0.15);
          color: rgba(245, 108, 108, 0.9);
        }

        &.other {
          background: rgba(144, 147, 153, 0.15);
          color: var(--text-secondary);
        }
      }
    }
  }

  .preview-card {
    margin-top: 0;

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: 600;
      font-size: 14px;
    }

    .preview-empty {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      color: var(--text-muted);
      font-size: 14px;
    }

    .preview-content {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      max-height: calc(100vh - 220px);
    }

    .preview-path {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 16px;
      flex-wrap: wrap;

      .el-tag {
        max-width: calc(100% - 60px);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        border-radius: 6px;
        padding: 4px 10px;
      }

      :deep(.el-button) {
        border-radius: 6px;
        padding: 6px 10px;
      }

      :deep(.el-checkbox) {
        padding: 6px 12px;
        background: var(--bg-tertiary);
        border-radius: 6px;
      }
    }
  }

  .canvas-container {
    display: flex;
    align-items: center;
    justify-content: center;
    background:
      linear-gradient(45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #fef0f0 75%),
      linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
      #fdf7f7;
    background-size: 20px 20px;
    background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    height: 300px;
    overflow: hidden;
    margin-top: 16px;
    margin-bottom: 16px;
    flex-shrink: 0;
    position: relative;

    .canvas-image {
      max-width: 100%;
      max-height: 300px;
      object-fit: contain;
      image-rendering: pixelated;
      border-radius: 6px;
    }

    .preview-error {
      color: var(--el-color-danger);
      font-size: 14px;
    }

    &.light {
      background:
        linear-gradient(45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #fef0f0 75%),
        linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
        #ffffff;
      background-size: 16px 16px;
      background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    }

    &.dark {
      background:
        linear-gradient(45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(-45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #2d1f1f 75%),
        linear-gradient(-45deg, transparent 75%, #2d1f1f 75%),
        #151010;
      background-size: 16px 16px;
      background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    }
  }

  .frame-section {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    .frame-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
      font-size: 14px;
      font-weight: 600;
      color: var(--text-primary);
      flex-shrink: 0;

      .frame-header-left {
        display: flex;
        align-items: center;
        gap: 10px;
      }
    }

    .frame-scroll {
      flex: 1;
      min-height: 0;
      overflow-y: auto;
      height: 0;

      :deep(.el-scrollbar) {
        height: 100%;
      }
      :deep(.el-scrollbar__wrap) {
        overflow-y: auto !important;
      }
    }
  }

  .frame-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding-bottom: 12px;
  }

  .frame-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    background: var(--bg-tertiary);
    border-radius: 12px;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.2s ease;

    &:hover {
      border-color: rgba(251, 113, 133, 0.3);
      background: var(--bg-secondary);
      transform: translateX(2px);
    }

    &.active {
      border-color: rgba(251, 113, 133, 0.4);
      background: rgba(251, 113, 133, 0.12);

      .frame-number,
      .frame-type,
      .frame-pos,
      .frame-size,
      .frame-frame,
      .frame-link {
        color: var(--accent-dark);
      }

      .frame-number {
        font-weight: 700;
      }
    }

    .frame-number {
      font-size: 13px;
      font-weight: 600;
      color: var(--accent-color);
      min-width: 28px;
      font-family: monospace;
    }

    .frame-link {
      font-size: 12px;
      font-family: monospace;
      white-space: nowrap;
      flex: 1;
    }

    .frame-type {
      font-size: 12px;
      width: 60px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-pos {
      font-size: 12px;
      width: 52px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-size {
      font-size: 12px;
      width: 60px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-frame {
      font-size: 12px;
      width: 60px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-detail {
      font-size: 12px;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-tag {
      margin-left: auto;
      flex-shrink: 0;
      border-radius: 6px !important;
    }
  }

  .empty-tip {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-muted);
    font-size: 14px;
  }
}

/* 深色模式样式覆盖 */
html.dark {
  .img-resources {
    // 所有样式通过 CSS 变量控制，不需要单独覆盖
  }
}
</style>
