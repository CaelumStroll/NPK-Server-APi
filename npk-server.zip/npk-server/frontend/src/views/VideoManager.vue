<script setup lang="ts">
import { ref, onMounted, watch, onUnmounted, nextTick, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { useVideoStore, type VideoFile } from '@/stores/video'
import { videoApi } from '@/api'
import {
  Search, Refresh, VideoPlay, Lock, Unlock,
  Delete, FolderOpened, Folder, ArrowUp, Microphone,
  Download
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const { t } = useI18n()
const videoStore = useVideoStore()

// ========== 文件浏览器核心逻辑（路径枚举） ==========

// 当前路径（空字符串表示 Video 根目录）
const currentPath = ref('')

// 收集所有唯一的 dir_path
const allDirPaths = computed(() => {
  const paths = new Set<string>()
  videoStore.videos.forEach(v => {
    if (v.dir_path) {
      paths.add(v.dir_path)
    }
  })
  return Array.from(paths)
})

// 获取当前路径下的直接子文件夹
// dir_path 例子: "CreateCharacter", "CreateCharacter/BackGround"
const currentSubFolders = computed(() => {
  const subFolders = new Map<string, number>()
  
  allDirPaths.value.forEach(dir => {
    if (currentPath.value === '') {
      // 根目录：提取第一级（不含 / 的路径）
      if (!dir.includes('/')) {
        // 直接子文件夹，统计其中的视频数
        const count = videoStore.videos.filter(v => v.dir_path === dir).length
        subFolders.set(dir, count)
      }
    } else {
      // 子目录：提取匹配前缀的下一级
      const prefix = currentPath.value + '/'
      if (dir.startsWith(prefix)) {
        const remainder = dir.substring(prefix.length)
        const firstSlash = remainder.indexOf('/')
        if (firstSlash === -1) {
          // 直接子文件夹（如 "CreateCharacter/BackGround"）
          subFolders.set(remainder, subFolders.get(remainder) || 0 + 1)
        } else {
          // 嵌套子文件夹（如 "CreateCharacter/BackGround/Detail"）
          const firstFolder = remainder.substring(0, firstSlash)
          subFolders.set(firstFolder, (subFolders.get(firstFolder) || 0) + 1)
        }
      }
    }
  })
  
  return Array.from(subFolders.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => a.name.localeCompare(b.name))
})

// 当前路径下的视频（dir_path 完全匹配）
const currentVideos = computed(() => {
  return videoStore.videos.filter(v => v.dir_path === currentPath.value)
})

// 当前路径显示名称
const currentPathDisplay = computed(() => {
  if (currentPath.value === '') return 'Video'
  return currentPath.value.split('/').pop() || currentPath.value
})

// 是否可返回上级
const canGoUp = computed(() => currentPath.value !== '')

// 返回上级
function goUp() {
  if (!canGoUp.value) return
  const idx = currentPath.value.lastIndexOf('/')
  currentPath.value = idx === -1 ? '' : currentPath.value.substring(0, idx)
}

// 进入子文件夹
function enterFolder(folder: string) {
  currentPath.value = currentPath.value === '' ? folder : `${currentPath.value}/${folder}`
}

// ========== 搜索与筛选 ==========

const searchQuery = ref('')
const formatFilter = ref('all')
const encryptedFilter = ref('all')
let debounceTimer: ReturnType<typeof setTimeout> | null = null

// 最终显示的视频列表（应用搜索和筛选）
// 搜索时：在所有视频中筛选
// 非搜索时：显示当前文件夹的视频
const filteredVideos = computed(() => {
  // 如果有搜索或筛选条件，在所有视频中筛选
  const isSearching = searchQuery.value || formatFilter.value !== 'all' || encryptedFilter.value !== 'all'
  let result = isSearching ? videoStore.videos : currentVideos.value
  
  if (searchQuery.value) {
    const q = searchQuery.value.toLowerCase()
    result = result.filter(v => v.name.toLowerCase().includes(q))
  }
  
  if (formatFilter.value !== 'all') {
    result = result.filter(v => v.format.toLowerCase() === formatFilter.value)
  }
  
  if (encryptedFilter.value !== 'all') {
    result = result.filter(v => encryptedFilter.value === 'encrypted' ? v.is_encrypted : !v.is_encrypted)
  }
  
  return result
})

// ========== 多选与操作 ==========
const selectedVideos = ref<VideoFile[]>([])

// 播放对话框
const playDialogVisible = ref(false)
const currentPlayingVideo = ref<VideoFile | null>(null)
const videoUrl = ref('')
const videoRef = ref<HTMLVideoElement | null>(null)
const isPlaying = ref(false)
const volume = ref(80)
const resolution = ref('800x600') // 默认分辨率

// 操作加载状态
const operationLoading = ref<string | null>(null)

onMounted(async () => {
  // 加载视频数据和统计
  await Promise.all([videoStore.fetchVideos(), videoStore.fetchStats()])
})

onUnmounted(() => {
  if (debounceTimer) clearTimeout(debounceTimer)
  if (videoUrl.value) {
    URL.revokeObjectURL(videoUrl.value)
  }
})

// === 搜索防抖 ===
watch([searchQuery, formatFilter, encryptedFilter], () => {
  if (debounceTimer) clearTimeout(debounceTimer)
  debounceTimer = setTimeout(() => {
    // 本地过滤，无需重新请求
  }, 300)
})

// === 扫描 ===
async function handleScan() {
  try {
    await ElMessageBox.confirm(
      t('videoManager.confirmScan'),
      t('videoManager.scanDir'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = 'scan'
    try {
      await videoStore.scanVideos()
      ElMessage.success(t('videoManager.scanComplete'))
    } catch (e: any) {
      ElMessage.error(t('common.scanFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

// === 刷新 ===
async function handleRefresh() {
  await Promise.all([
    videoStore.fetchVideos(),
    videoStore.fetchStats()
  ])
}

// === 多选 ===
function handleSelectionChange(selection: VideoFile[]) {
  selectedVideos.value = selection
}

// === 播放 ===
function handlePlay(video: VideoFile) {
  currentPlayingVideo.value = video
  const streamUrl = videoApi.getStreamUrl(video.id, video.is_encrypted, resolution.value)
  videoUrl.value = streamUrl
  playDialogVisible.value = true
  isPlaying.value = false
  // 等待对话框渲染后自动播放
  nextTick(() => {
    setTimeout(() => {
      if (videoRef.value) {
        videoRef.value.play().then(() => {
          isPlaying.value = true
        }).catch((err) => {
          console.log('Autoplay blocked:', err)
        })
      }
    }, 500)
  })
}

// === 切换分辨率 ===
function handleResolutionChange() {
  if (currentPlayingVideo.value && playDialogVisible.value) {
    const streamUrl = videoApi.getStreamUrl(currentPlayingVideo.value.id, currentPlayingVideo.value.is_encrypted, resolution.value)
    videoUrl.value = streamUrl
    if (videoRef.value) {
      videoRef.value.load()
      videoRef.value.play().then(() => {
        isPlaying.value = true
      }).catch((err) => {
        console.log('Playback failed:', err)
      })
    }
  }
}

// === 下载视频 ===
function handleDownload(video: VideoFile) {
  const url = videoApi.getDownloadUrl(video.id, video.is_encrypted, resolution.value)
  const a = document.createElement('a')
  a.href = url
  a.download = video.name.replace(/\.[^.]+$/, '') + '.mp4'
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

function handleVolumeChange(val: number | number[]) {
  if (videoRef.value) {
    const v = typeof val === 'number' ? val : val[0]
    videoRef.value.volume = v / 100
  }
}

function handleVideoError(e: Event) {
  const video = e.target as HTMLVideoElement
  if (!video.src || video.src === '' || video.src === window.location.href) {
    return
  }
  console.error('Video load/play error:', {
    error: video.error,
    src: video.src,
    networkState: video.networkState,
    readyState: video.readyState
  })
  ElMessage.error(t('common.requestFailed'))
  isPlaying.value = false
}

function onVideoLoaded() {
  console.log('Video data loaded')
}

function handleDialogClose() {
  if (videoRef.value) {
    videoRef.value.pause()
    videoRef.value.src = ''
  }
  isPlaying.value = false
  currentPlayingVideo.value = null
}

// === 加密/解密 ===
async function handleEncrypt(video: VideoFile) {
  try {
    await ElMessageBox.confirm(
      t('videoManager.confirmEncrypt', { name: video.name }),
      t('videoManager.batchEncrypt'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    operationLoading.value = `encrypt-${video.id}`
    try {
      await videoStore.encryptVideo(video.id)
      ElMessage.success(t('videoManager.encryptSuccess'))
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function handleDecrypt(video: VideoFile) {
  try {
    await ElMessageBox.confirm(
      t('videoManager.confirmDecrypt', { name: video.name }),
      t('videoManager.batchDecrypt'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = `decrypt-${video.id}`
    try {
      await videoStore.decryptVideo(video.id)
      ElMessage.success(t('videoManager.decryptSuccess'))
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

// === 删除 ===
async function handleDelete(video: VideoFile) {
  try {
    const action = await ElMessageBox.confirm(
      t('videoManager.confirmDeleteVideo', { name: video.name }),
      t('common.confirmDelete'),
      {
        confirmButtonText: t('videoManager.deleteWithFile'),
        cancelButtonText: t('videoManager.deleteRecordOnly'),
        type: 'warning',
        distinguishCancelAndClose: true
      }
    ).catch((action) => {
      return action
    })
    
    if (!action) return
    
    operationLoading.value = `delete-${video.id}`
    try {
      if (action === 'confirm') {
        await videoApi.deleteVideoWithFile(video.id)
        ElMessage.success(t('common.operationSuccess'))
      } else {
        await videoStore.deleteVideo(video.id)
        ElMessage.success(t('common.operationSuccess'))
      }
      await videoStore.fetchVideos()
      await videoStore.fetchStats()
    } catch (e: any) {
      ElMessage.error(t('videoManager.deleteFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

// === 打开文件夹位置 ===
async function openInFolder(video: VideoFile) {
  try {
    await fetch('/api/tools/open-folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: video.path })
    })
    ElMessage.success(t('common.operationSuccess'))
  } catch {
    ElMessage.error(t('common.operationFailed'))
  }
}

// === 批量操作 ===
async function handleBatchEncrypt() {
  if (selectedVideos.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  const unencrypted = selectedVideos.value.filter(v => !v.is_encrypted)
  if (unencrypted.length === 0) {
    ElMessage.info(t('videoManager.encrypted'))
    return
  }
  try {
    await ElMessageBox.confirm(
      t('videoManager.confirmBatchEncrypt', { count: unencrypted.length }),
      t('videoManager.batchEncrypt'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    operationLoading.value = 'batch-encrypt'
    try {
      await videoStore.batchEncrypt(unencrypted.map(v => v.id))
      ElMessage.success(t('videoManager.encryptSuccess'))
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function handleBatchDecrypt() {
  if (selectedVideos.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  const encrypted = selectedVideos.value.filter(v => v.is_encrypted)
  if (encrypted.length === 0) {
    ElMessage.info(t('videoManager.unencrypted'))
    return
  }
  try {
    await ElMessageBox.confirm(
      t('videoManager.confirmBatchDecrypt', { count: encrypted.length }),
      t('videoManager.batchDecrypt'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = 'batch-decrypt'
    try {
      await videoStore.batchDecrypt(encrypted.map(v => v.id))
      ElMessage.success(t('videoManager.decryptSuccess'))
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function handleBatchDelete() {
  if (selectedVideos.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  try {
    const action = await ElMessageBox.confirm(
      t('videoManager.confirmBatchDelete', { count: selectedVideos.value.length }),
      t('common.confirmDelete'),
      {
        confirmButtonText: t('videoManager.deleteWithFile'),
        cancelButtonText: t('videoManager.deleteRecordOnly'),
        type: 'warning',
        distinguishCancelAndClose: true
      }
    ).catch((action) => {
      return action
    })
    
    if (!action) return
    
    operationLoading.value = 'batch-delete'
    try {
      const ids = selectedVideos.value.map(v => v.id)
      const deleteFile = action === 'confirm'
      await videoApi.batchDeleteVideos(ids, deleteFile)
      ElMessage.success(t('common.operationSuccess'))
      selectedVideos.value = []
      await videoStore.fetchVideos()
      await videoStore.fetchStats()
    } catch (e: any) {
      ElMessage.error(t('videoManager.deleteFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

// === 格式化 ===
function formatSize(bytes: number): string {
  if (!bytes || isNaN(bytes)) return '0 B'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB'
  return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB'
}

function formatDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return '00:00'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
}

function formatTotalDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return `0 ${t('videoManager.minutes')}`
  if (seconds < 3600) return Math.floor(seconds / 60) + ` ${t('videoManager.minutes')}`
  const hours = Math.floor(seconds / 3600)
  const mins = Math.floor((seconds % 3600) / 60)
  return `${hours} ${t('videoManager.hours')} ${mins} ${t('videoManager.minutes')}`
}

function getResolution(video: VideoFile): string {
  if (video.width && video.height) {
    return `${video.width}x${video.height}`
  }
  return '-'
}

function getFormatTag(format: string): string {
  return (format || '').toUpperCase()
}

</script>

<template>
  <div class="video-manager">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">{{ t('videoManager.title') }}</h2>
      <div class="header-actions">
        <el-tag v-if="selectedVideos.length > 0" type="info" size="small" effect="dark">
          {{ t('videoManager.selectedCount', { count: selectedVideos.length }) }}
        </el-tag>
        <el-button
          v-if="selectedVideos.length > 0"
          type="warning"
          size="small"
          :loading="operationLoading === 'batch-encrypt'"
          @click="handleBatchEncrypt"
        >
          {{ t('videoManager.batchEncrypt') }}
        </el-button>
        <el-button
          v-if="selectedVideos.length > 0"
          type="success"
          size="small"
          :loading="operationLoading === 'batch-decrypt'"
          @click="handleBatchDecrypt"
        >
          {{ t('videoManager.batchDecrypt') }}
        </el-button>
        <el-button
          v-if="selectedVideos.length > 0"
          type="danger"
          size="small"
          :loading="operationLoading === 'batch-delete'"
          @click="handleBatchDelete"
        >
          {{ t('videoManager.batchDelete') }}
        </el-button>
        <el-button :icon="Refresh" size="small" :loading="videoStore.loading" @click="handleRefresh">
          {{ t('common.refresh') }}
        </el-button>
      </div>
    </div>

    <!-- 搜索与筛选工具栏 -->
    <div class="toolbar">
      <el-input
        v-model="searchQuery"
        :placeholder="t('videoManager.searchPlaceholder')"
        :prefix-icon="Search"
        clearable
        class="search-input"
      />
      <el-select v-model="formatFilter" :placeholder="t('videoManager.formatFilter')" class="filter-select">
        <el-option :label="t('videoManager.allFormats')" value="all" />
        <el-option label="AVI" value="avi" />
        <el-option label="BK2" value="bk2" />
        <el-option label="MP4" value="mp4" />
        <el-option label="WEBM" value="webm" />
        <el-option label="MKV" value="mkv" />
      </el-select>
      <el-select v-model="encryptedFilter" :placeholder="t('videoManager.encryptStatus')" class="filter-select">
        <el-option :label="t('videoManager.allStatus')" value="all" />
        <el-option :label="t('videoManager.encrypted')" value="encrypted" />
        <el-option :label="t('videoManager.unencrypted')" value="unencrypted" />
      </el-select>
      <el-button
        type="primary"
        :icon="FolderOpened"
        :loading="operationLoading === 'scan'"
        @click="handleScan"
      >
        {{ t('videoManager.scanDir') }}
      </el-button>
    </div>

    <!-- 统计卡片 -->
    <el-row :gutter="16" class="stats-row">
      <el-col :span="6">
        <el-card class="stat-card stat-card--total" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><VideoPlay /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ videoStore.totalCount }}</div>
              <div class="stat-label">{{ t('videoManager.totalVideos') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card stat-card--size" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><FolderOpened /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ formatSize(videoStore.totalSize) }}</div>
              <div class="stat-label">{{ t('videoManager.totalSize') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card stat-card--encrypted" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><Lock /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ videoStore.encryptedCount }}</div>
              <div class="stat-label">{{ t('videoManager.encryptedCount') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card stat-card--duration" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><VideoPlay /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ formatTotalDuration(videoStore.totalDuration) }}</div>
              <div class="stat-label">{{ t('videoManager.totalDuration') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主内容区：左侧文件夹列表 + 右侧视频列表 -->
    <div class="main-content">
      <!-- 左侧文件夹浏览器 -->
      <div class="folder-sidebar">
        <div class="folder-header">
          <el-icon><FolderOpened /></el-icon>
          <span>{{ currentPathDisplay }}</span>
          <el-button
            v-if="canGoUp"
            type="primary"
            link
            size="small"
            :icon="ArrowUp"
            @click="goUp"
          >
            {{ t('videoManager.goUp') }}
          </el-button>
        </div>
        <div class="folder-list">
          <div
            v-for="folder in currentSubFolders"
            :key="folder.name"
            class="folder-item"
            @click="enterFolder(folder.name)"
          >
            <el-icon><Folder /></el-icon>
            <span class="folder-name">{{ folder.name }}</span>
            <span class="folder-count">({{ folder.count }})</span>
          </div>
          <el-empty v-if="currentSubFolders.length === 0" :description="t('common.noData')" />
        </div>
      </div>

      <!-- 右侧视频列表 -->
      <el-card class="table-card">
      <el-table
        v-loading="videoStore.loading"
        :data="filteredVideos"
        stripe
        @selection-change="handleSelectionChange"
        class="video-table"
      >
        <el-table-column type="selection" width="50" />

        <el-table-column :label="t('videoManager.fileName')" prop="name" min-width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <div class="filename-cell">
              <el-icon v-if="row.is_encrypted" class="lock-icon"><Lock /></el-icon>
              <span>{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.format')" prop="format" width="80" align="center">
          <template #default="{ row }">
            <el-tag size="small" effect="plain" class="format-tag">
              {{ getFormatTag(row.format) }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.resolution')" width="100" align="center">
          <template #default="{ row }">
            <span class="mono-text">{{ getResolution(row) }}</span>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.frameRate')" prop="fps" width="80" align="center">
          <template #default="{ row }">
            <span class="mono-text">{{ row.fps ? row.fps.toFixed(1) : '-' }}</span>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.duration')" prop="duration" width="80" align="center">
          <template #default="{ row }">
            <span class="mono-text">{{ formatDuration(row.duration) }}</span>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.size')" prop="size" width="100" align="right">
          <template #default="{ row }">
            <span class="mono-text">{{ formatSize(row.size) }}</span>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.encrypt')" width="50" align="center">
          <template #default="{ row }">
            <el-icon
              :size="16"
              :color="row.is_encrypted ? '#f56c6c' : '#409eff'"
              style="cursor: pointer"
              @click="row.is_encrypted ? handleDecrypt(row) : handleEncrypt(row)"
            >
              <Lock v-if="row.is_encrypted" />
              <Unlock v-else />
            </el-icon>
          </template>
        </el-table-column>

        <el-table-column :label="t('videoManager.operation')" width="160" align="center" fixed="right">
          <template #default="{ row }">
            <div class="action-icons">
              <el-button
                type="primary"
                :icon="VideoPlay"
                circle
                size="small"
                :title="t('common.play')"
                @click="handlePlay(row)"
              />
              <el-button
                type="info"
                :icon="FolderOpened"
                circle
                size="small"
                @click="openInFolder(row)"
              />
              <el-button
                type="danger"
                :icon="Delete"
                circle
                size="small"
                :title="t('common.delete')"
                :loading="operationLoading === `delete-${row.id}`"
                @click="handleDelete(row)"
              />
            </div>
          </template>
        </el-table-column>
      </el-table>

      <!-- 统计信息 -->
      <div class="video-count-info">
        <el-tag type="info" effect="plain">{{ t('videoManager.videoCount', { count: filteredVideos.length }) }}</el-tag>
      </div>
      </el-card>
    </div>

    <!-- 视频播放对话框 -->
    <el-dialog
      v-model="playDialogVisible"
      :title="currentPlayingVideo ? `${t('common.play')}: ${currentPlayingVideo.name}` : t('common.play')"
      :width="resolution === 'original' ? '860px' : (resolution === '1066x600' ? '1126px' : '860px')"
      destroy-on-close
      align-center
      @close="handleDialogClose"
      class="play-dialog"
    >
      <div class="player-container" :class="'res-' + resolution">
        <video
          ref="videoRef"
          :src="videoUrl"
          class="video-player"
          :width="resolution === 'original' ? 800 : (resolution === '1066x600' ? 1066 : 800)"
          height="600"
          controls
          preload="auto"
          crossorigin="anonymous"
          :volume="volume / 100"
          @play="isPlaying = true"
          @pause="isPlaying = false"
          @ended="isPlaying = false"
          @error="handleVideoError"
          @loadeddata="onVideoLoaded"
        />
      </div>

      <!-- 控制栏（视频下方，分辨率选择前） -->
      <div class="player-controls-bar">
        <div class="volume-control">
          <el-icon :size="16"><Microphone /></el-icon>
          <el-slider
            v-model="volume"
            :min="0"
            :max="100"
            :show-tooltip="false"
            size="small"
            style="width: 100px"
            @input="handleVolumeChange"
          />
        </div>
        <el-button
          :icon="Download"
          circle
          size="small"
          :title="t('common.download')"
          @click="handleDownload(currentPlayingVideo!)"
        />
      </div>

      <!-- 分辨率选择（视频下方） -->
      <div class="resolution-selector">
        <el-radio-group v-model="resolution" size="small" @change="handleResolutionChange">
          <el-radio-button label="800x600">800x600</el-radio-button>
          <el-radio-button label="1066x600">1066x600</el-radio-button>
          <el-radio-button label="original">{{ t('videoManager.originalResolution') }}</el-radio-button>
        </el-radio-group>
      </div>


    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.video-manager {
  height: calc(100vh - 90px - 48px);
  display: flex;
  flex-direction: column;

  .page-header {
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-shrink: 0;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
  }

  .toolbar {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
    flex-shrink: 0;

    .search-input {
      width: 260px;
    }

    .filter-select {
      width: 140px;
    }
  }

  .stats-row {
    margin-bottom: 16px;
    flex-shrink: 0;

    .stat-card {
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 16px;
      transition: transform 0.2s ease, border-color 0.2s ease;
      position: relative;
      overflow: hidden;

      &:hover {
        transform: translateY(-2px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        border-radius: 14px 14px 0 0;
      }

      &--total::before {
        background: linear-gradient(90deg, #89b4fa, #74c7ec);
      }

      &--size::before {
        background: linear-gradient(90deg, #a6e3a1, #94e2d5);
      }

      &--encrypted::before {
        background: linear-gradient(90deg, #f38ba8, #eba0ac);
      }

      &--duration::before {
        background: linear-gradient(90deg, #cba6f7, #b4befe);
      }

      .stat-content {
        display: flex;
        align-items: center;
        gap: 14px;

        .stat-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .stat-info {
          .stat-value {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          .stat-label {
            font-size: 11px;
            color: var(--text-secondary);
          }
        }
      }
    }

    // 统计卡片图标背景色
    .stat-card--total .stat-icon {
      background: rgba(137, 180, 250, 0.15);
      color: #89b4fa;
    }

    .stat-card--size .stat-icon {
      background: rgba(166, 227, 161, 0.15);
      color: #a6e3a1;
    }

    .stat-card--encrypted .stat-icon {
      background: rgba(243, 139, 168, 0.15);
      color: #f38ba8;
    }

    .stat-card--duration .stat-icon {
      background: rgba(203, 166, 247, 0.15);
      color: #cba6f7;
    }
  }

  .table-card {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;
    background: var(--bg-primary);
    border: 1px solid var(--border-color);

    :deep(.el-card__body) {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
      padding: 12px;
    }

    .video-table {
      flex: 1;
      min-height: 0;

      :deep(.el-table__row) {
        transition: background-color 0.2s ease;

        &:hover > td {
          background-color: rgba(137, 180, 250, 0.06) !important;
        }
      }
    }

    .filename-cell {
      display: flex;
      align-items: center;
      gap: 6px;

      .lock-icon {
        color: var(--el-color-warning);
        flex-shrink: 0;
      }
    }

    .format-tag {
      font-family: monospace;
      font-size: 11px;
    }

    .mono-text {
      font-family: monospace;
      font-size: 12px;
    }

    .action-icons {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .video-count-info {
      display: flex;
      justify-content: flex-end;
      padding-top: 12px;
      flex-shrink: 0;
    }
  }

  // 主内容区布局
  .main-content {
    flex: 1;
    display: flex;
    gap: 16px;
    min-height: 0;
    overflow: hidden;

    .folder-sidebar {
      width: 240px;
      flex-shrink: 0;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      overflow: hidden;

      .folder-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 16px;
        font-weight: 600;
        font-size: 14px;
        border-bottom: 1px solid var(--border-color);
        background: var(--el-fill-color-light);

        .el-icon {
          font-size: 18px;
          color: var(--el-color-primary);
        }
      }

      .folder-list {
        flex: 1;
        overflow-y: auto;
        padding: 8px;

        .folder-item {
          display: flex;
          align-items: center;
          padding: 10px 12px;
          cursor: pointer;
          transition: background-color 0.2s;
          border-radius: 4px;
          margin: 4px 0;
          border: 1px solid transparent;

          &:hover {
            background-color: var(--el-fill-color-light);
            border-color: var(--el-color-primary-light-5);
          }

          .el-icon {
            margin-right: 8px;
            font-size: 20px;
            color: var(--el-color-warning);
          }

          .folder-name {
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 14px;
            font-weight: 500;
          }

          .folder-count {
            font-size: 11px;
            color: var(--el-text-color-secondary);
            margin-left: 4px;
          }
        }
      }
    }

    .table-card {
      flex: 1;
      min-width: 0;
    }
  }

  // 播放对话框
  .play-dialog {
    :deep(.el-dialog__body) {
      padding: 0 20px 20px;
    }
  }

  .resolution-selector {
    display: flex;
    justify-content: center;
    padding: 12px 0;
    background: var(--bg-secondary, #f5f7fa);
    border-top: 1px solid var(--border-color, #e4e7ed);
    border-radius: 0 0 8px 8px;

    :deep(.el-radio-button__inner) {
      background: var(--bg-primary, #ffffff);
      border-color: var(--border-color, #dcdfe6);
      color: var(--text-primary, #606266);

      &:hover {
        color: var(--el-color-primary, #409eff);
      }
    }

    :deep(.el-radio-button__original-radio:checked + .el-radio-button__inner) {
      background: var(--el-color-primary, #409eff);
      border-color: var(--el-color-primary, #409eff);
      color: #ffffff;
    }
  }

  .player-container {
    background: #000;
    border-radius: 0 0 8px 8px;
    overflow: hidden;
    width: 800px;
    height: 600px;

    &.res-1066x600 {
      width: 1066px;
    }

    &.res-original {
      width: 800px;
      display: flex;
      align-items: center;
      justify-content: center;

      .video-player {
        width: auto;
        height: auto;
        max-width: 800px;
        max-height: 600px;
        object-fit: contain;
      }
    }

    .video-player {
      width: 100%;
      height: 100%;
      display: block;
      outline: none;
      object-fit: fill;
    }

  }

  // 控制栏（视频下方，分辨率选择前）
  .player-controls-bar {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    padding: 12px;
    background: var(--bg-secondary, #f5f7fa);
    border-top: 1px solid var(--border-color, #e4e7ed);
    border-radius: 0;

    .volume-control {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--text-primary, #303133);

      :deep(.el-slider__runway) {
        background: var(--slider-bg, rgba(0, 0, 0, 0.1));
      }

      :deep(.el-slider__bar) {
        background: var(--el-color-primary, #409eff);
      }

      :deep(.el-slider__button) {
        border-color: var(--el-color-primary, #409eff);
      }
    }

    .el-button {
      color: var(--text-primary, #303133);
      border-color: var(--border-color, #dcdfe6);
      background: var(--bg-primary, #ffffff);

      &:hover {
        color: var(--el-color-primary, #409eff);
        border-color: var(--el-color-primary-light-7, #c6e2ff);
        background: var(--el-color-primary-light-9, #ecf5ff);
      }
    }
  }
}
</style>
