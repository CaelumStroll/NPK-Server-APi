<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, computed, reactive, shallowRef } from 'vue'
import { xmlAudioApi } from '@/api'
import { Search, Refresh, Delete, Edit, Plus, VideoPlay, FolderOpened, Link, ArrowDown, ArrowRight } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useI18n } from 'vue-i18n'

interface XmlItem { tag: string; prob: string; delay?: string; delay_range?: string; loop_delay?: string; loop_delay_range?: string }
interface XmlEntry { type: string; id: string; file?: string; file_missing?: boolean; attributes?: Record<string, string>; items?: XmlItem[] }

const { t } = useI18n()
const entries = shallowRef<XmlEntry[]>([])
const stats = ref({ effect_count: 0, random_count: 0, group_count: 0, music_count: 0, ambient_count: 0 })
const loading = ref(false)
const searchQuery = ref('')
const typeFilter = ref('MUSIC')
const groupBy = ref(true)
const expandedGroups = reactive<Record<string, boolean>>({})

const editorVisible = ref(false)
const editingEntry = ref<XmlEntry | null>(null)
const isNewEntry = ref(false)
const operationLoading = ref<string | null>(null)

const currentXmlPath = ref('')
const showXmlFileDialog = ref(false)
const xmlDirPath = ref('')
const xmlFileList = ref<any[]>([])

const playerVisible = ref(false)
const playingFile = ref('')
const audioUrl = ref('')
const audioEl = ref<HTMLAudioElement | null>(null)

function onPlayerClosed() {
  if (audioEl.value) {
    audioEl.value.pause()
    audioEl.value.currentTime = 0
  }
}

const filePickVisible = ref(false)
const filePickSource = ref('music' as 'music' | 'soundpack')
const filePickList = ref<Array<{ path: string; name: string }>>([])
const filePickSearch = ref('')

const entryTypes = [
  { label: t('xmlAudioEditor.all'), value: 'all' }, { label: 'EFFECT', value: 'EFFECT' }, { label: 'RANDOM', value: 'RANDOM' },
  { label: 'GROUP', value: 'GROUP' }, { label: 'MUSIC', value: 'MUSIC' }, { label: 'AMBIENT', value: 'AMBIENT' },
]

function fmtProb(v: string): string { const n = parseFloat(v); return isNaN(n) ? v : Math.round(n) + '%' }
function fmtDelay(v?: string): string { if (!v) return ''; const n = parseFloat(v) / 1000; return n ? n.toFixed(1) + 's' : '' }
function fmtTypeTag(t: string): 'success'|'warning'|'danger'|'info'|undefined { const m: Record<string, any> = { EFFECT: 'success', RANDOM: 'warning', GROUP: 'danger', MUSIC: 'info' }; return m[t] }

// 构建引用映射：被引用ID → 引用它的条目列表
const refMap = computed(() => {
  const m: Record<string, XmlEntry[]> = {}
  for (const e of entries.value) {
    if (!e.items) continue
    for (const it of e.items) {
      if (!it.tag) continue
      if (!m[it.tag]) m[it.tag] = []
      if (!m[it.tag].find(x => x.id === e.id)) m[it.tag].push(e)
    }
  }
  return m
})

// 条目分组：每个 EFFECT/MUSIC/AMBIENT 作为一组的主条目
const groups = computed(() => {
  const gs: Array<{ key: string; main: XmlEntry; refs: XmlEntry[] }> = []
  const addedRefs = new Set<string>()
  for (const e of entries.value) {
    if (e.type === 'EFFECT' || e.type === 'MUSIC' || e.type === 'AMBIENT') {
      if (typeFilter.value !== 'all' && e.type !== typeFilter.value) continue
      gs.push({ key: e.type + ':' + e.id, main: e, refs: refMap.value[e.id] || [] })
      for (const r of refMap.value[e.id] || []) addedRefs.add(r.type + ':' + r.id)
    }
  }
  // 孤立的 RANDOM/GROUP（没被任何 EFFECT 引用到，但也通过筛选）
  for (const e of entries.value) {
    if (e.type !== 'RANDOM' && e.type !== 'GROUP') continue
    if (typeFilter.value !== 'all' && e.type !== typeFilter.value) continue
    if (addedRefs.has(e.type + ':' + e.id)) continue
    gs.push({ key: e.type + ':' + e.id, main: e, refs: [] })
  }
  return gs
})

const filteredGroups = computed(() => {
  if (!searchQuery.value) return groups.value
  const q = searchQuery.value.toLowerCase()
  return groups.value.filter(g =>
    g.main.id.toLowerCase().includes(q) ||
    (g.main.file || '').toLowerCase().includes(q) ||
    g.refs.some(r => r.id.toLowerCase().includes(q))
  )
})

// 平铺显示
const flatEntries = computed(() => {
  let list = entries.value
  if (typeFilter.value !== 'all') list = list.filter(e => e.type === typeFilter.value)
  if (searchQuery.value) {
    const q = searchQuery.value.toLowerCase()
    list = list.filter(e => e.id.toLowerCase().includes(q) || (e.file || '').toLowerCase().includes(q))
  }
  return list
})

// 缺失文件
const missingFiles = ref<Array<{ type: string; id: string; file: string }>>([])
const showMissingDialog = ref(false)
const missingLoading = ref(false)

// RANDOM 概率总和
const randomProbTotal = computed(() => {
  if (!editingEntry.value?.items) return 0
  return editingEntry.value.items.reduce((s, it) => s + (parseFloat(it.prob) || 0), 0)
})

onMounted(() => { loadEntries() })
onBeforeUnmount(() => {
  if (audioEl.value) {
    audioEl.value.pause()
  }
})

async function loadEntries() {
  loading.value = true
  try {
    const res = await xmlAudioApi.list() as any
    const d = res.data || {}
    entries.value = d.items || []
    stats.value = d.stats || { effect_count: 0, random_count: 0, group_count: 0, music_count: 0, ambient_count: 0 }
  } catch (e: any) { ElMessage.error(t('common.requestFailed') + ': ' + e.message) }
  finally { loading.value = false }
}

async function exportXml() {
  try {
    await xmlAudioApi.export() as any
    ElMessage.success(t('common.operationSuccess'))
  } catch (e: any) { ElMessage.error(t('common.operationFailed') + ': ' + e.message) }
}

async function checkMissing() {
  try {
    missingLoading.value = true
    const res = await xmlAudioApi.checkMissing() as any
    const d = res.data?.data || res.data || {}
    missingFiles.value = d.missing || []
    showMissingDialog.value = true
    if (!missingFiles.value.length) ElMessage.success(t('xmlAudioEditor.allFilesExist'))
  } catch (e: any) { ElMessage.error(t('common.operationFailed') + ': ' + e.message) }
  finally { missingLoading.value = false }
}

async function loadXmlFile(p: string) {
  loading.value = true
  try {
    const res = await xmlAudioApi.open(p) as any; const d = res.data || {}
    entries.value = []; stats.value = d.stats || { effect_count: 0, random_count: 0, group_count: 0, music_count: 0, ambient_count: 0 }
    currentXmlPath.value = d.path || p
    ElMessage.success(d.message || t('common.operationSuccess')); await loadEntries()
  } catch (e: any) { ElMessage.error(t('common.operationFailed') + ': ' + e.message) }
  finally { loading.value = false }
}
const browsingFiles = ref(false)

function openXmlBrowseDialog() {
  xmlDirPath.value = currentXmlPath.value ? currentXmlPath.value.replace(/[/\\][^/\\]*\.xml$/i, '') : ''
  xmlFileList.value = []
  showXmlFileDialog.value = true
  browseXmlDir()
}
async function browseXmlDir() {
  browsingFiles.value = true
  try { const res = await xmlAudioApi.listFiles(xmlDirPath.value || '') as any; xmlFileList.value = res.data?.files || []; xmlDirPath.value = res.data?.dir || xmlDirPath.value }
  catch (e: any) { ElMessage.error(t('common.requestFailed') + ': ' + (e.message || '')); xmlFileList.value = [] }
  finally { browsingFiles.value = false }
}
function selectXmlFile(f: any) { currentXmlPath.value = f.path; showXmlFileDialog.value = false; loadXmlFile(f.path) }

function openNewEntry() { editingEntry.value = { type: 'EFFECT', id: '', file: '', attributes: {}, items: [] }; isNewEntry.value = true; editorVisible.value = true }
function openEditEntry(e: XmlEntry) {
  const clone = JSON.parse(JSON.stringify(e))
  if (!clone.attributes) clone.attributes = {}
  if (!clone.items && (clone.type === 'RANDOM' || clone.type === 'GROUP')) clone.items = []
  editingEntry.value = clone
  isNewEntry.value = false
  editorVisible.value = true
}
function playFile(file: string) {
  if (playingFile.value === file && playerVisible.value) {
    return // 同一个文件正在播放，不做任何操作
  }
  playingFile.value = file
  audioUrl.value = xmlAudioApi.getStreamUrl(file)
  playerVisible.value = true
}

async function saveEntry() {
  if (!editingEntry.value) return; const e = JSON.parse(JSON.stringify(editingEntry.value)) as XmlEntry
  if (!e.id || !e.type) { ElMessage.warning(t('common.warning')); return }
  if (e.type === 'RANDOM' && e.items?.length) {
    const total = e.items.reduce((s, it) => s + (parseFloat(it.prob) || 0), 0)
    if (Math.abs(total - 100) > 0.01) { ElMessage.warning(t('common.warning') + `: ${total}%`); return }
  }
  if ((e.type === 'EFFECT' || e.type === 'MUSIC' || e.type === 'AMBIENT') && !e.file) { ElMessage.warning(t('common.warning')); return }

  // 新增时查重
  if (isNewEntry.value) {
    const dup = entries.value.find(x => x.type === e.type && x.id === e.id)
    if (dup) { ElMessage.warning(t('common.warning') + `: ${e.type}:${e.id}`); return }
  }

  operationLoading.value = 'save'
  try {
    await xmlAudioApi.saveEntry(e)
    ElMessage.success(isNewEntry.value ? t('xmlAudioEditor.added') : t('xmlAudioEditor.saved'))
    // 本地更新避免全量刷新
    if (isNewEntry.value) {
      entries.value = [...entries.value, e]
    } else {
      const idx = entries.value.findIndex(x => x.type === e.type && x.id === e.id)
      if (idx >= 0) entries.value[idx] = e
    }
    editorVisible.value = false
  }
  catch (err: any) { ElMessage.error(t('xmlAudioEditor.saveFailed') + ': ' + err.message) }
  finally { operationLoading.value = null }
}

async function deleteEntry(e: XmlEntry) {
  try {
    await ElMessageBox.confirm(t('common.confirmDelete') + ` "${e.id}"?`, t('xmlAudioEditor.deleteConfirm'), { type: 'warning' })
    operationLoading.value = `delete-${e.id}`
    await xmlAudioApi.deleteEntry(e.type, e.id)
    entries.value = entries.value.filter(x => !(x.type === e.type && x.id === e.id))
    ElMessage.success(t('xmlAudioEditor.deleted'))
  } catch (err: any) { if (err !== 'cancel') ElMessage.error(t('common.operationFailed') + ': ' + err.message) }
  finally { operationLoading.value = null }
}

function addItem() { if (editingEntry.value) { if (!editingEntry.value.items) editingEntry.value.items = []; editingEntry.value.items.push({ tag: '', prob: '' }) } }
function removeItem(i: number) { editingEntry.value?.items?.splice(i, 1) }

function openFilePick(src: 'music' | 'soundpack') {
  filePickSource.value = src; filePickSearch.value = ''; filePickList.value = []; filePickVisible.value = true; loadFilePickList()
}
async function loadFilePickList() {
  filePickList.value = []
  try {
    if (filePickSource.value === 'music') {
      const q = filePickSearch.value || ''; const r = await fetch(`/api/music/list?query=${encodeURIComponent(q)}&size=200`); const d = await r.json()
      filePickList.value = (d.data?.items || []).map((m: any) => ({ path: m.path, name: m.name }))
    } else {
      const r = await fetch('/api/soundpacks/list'); const d = await r.json()
      const items = d.data?.items || []
      if (items.length > 0) {
        const er = await fetch('/api/soundpacks/' + items[0].id + '/entries'); const ed = await er.json()
        filePickList.value = (ed.data?.items || []).map((e: any) => ({ path: e.entry_path, name: e.entry_path }))
      }
    }
  } catch {}
}

function selectPickFile(f: { path: string }) {
  if (!editingEntry.value) return
  const fp = f.path.replace(/\//g, '\\')
  if (filePickSource.value === 'music') {
    const musicMatch = fp.match(/(?:^|\\)music\\(.+)/i)
    if (musicMatch) {
      editingEntry.value.file = 'music\\' + musicMatch[1]
    } else {
      editingEntry.value.file = 'music\\' + fp.replace(/^.*[\\]/, '')
    }
  } else {
    editingEntry.value.file = fp
  }
  filePickVisible.value = false
}

function toggleGroup(key: string) {
  if (expandedGroups[key]) delete expandedGroups[key]
  else expandedGroups[key] = true
}

function copyId(id: string) { navigator.clipboard.writeText(id); ElMessage.success(t('common.copySuccess')) }

// 概率加权随机选择 ITEM，返回选中的 target ID
function weightedPick(items: XmlItem[]): string | null {
  if (!items.length) return null
  const weights = items.map(it => { const v = parseFloat(it.prob); return isNaN(v) || v <= 0 ? 0 : v })
  const total = weights.reduce((a, b) => a + b, 0)
  if (total === 0) return items[Math.floor(Math.random() * items.length)].tag
  let r = Math.random() * total
  for (let i = 0; i < items.length; i++) { r -= weights[i]; if (r <= 0) return items[i].tag }
  return items[items.length - 1].tag
}

// 按 ID 查找条目
function findEntryById(id: string): XmlEntry | undefined {
  return entries.value.find(e => e.id === id)
}

// 解析播放路径：ITEM tag → EFFECT file
function resolvePlayFile(tagId: string): string | null {
  // 直接查 EFFECT/MUSIC/AMBIENT
  const e = findEntryById(tagId)
  if (e && e.file) return e.file
  // 如果是 RANDOM，递归随机选
  if (e && e.type === 'RANDOM' && e.items?.length) {
    const picked = weightedPick(e.items)
    if (picked) return resolvePlayFile(picked)
  }
  // 如果是 GROUP，取第一个 ITEM
  if (e && e.type === 'GROUP' && e.items?.length) {
    return resolvePlayFile(e.items[0].tag)
  }
  return null
}

// 播放 RANDOM/GROUP（概率随机）
function playRandom(entry: XmlEntry) {
  if (!entry.items?.length) return
  const tag = weightedPick(entry.items)
  if (!tag) return
  const file = resolvePlayFile(tag)
  if (!file) { ElMessage.warning(t('common.warning') + ': ' + tag); return }
  playFile(file)
}

// 播放 GROUP 序列
function playSequence(entry: XmlEntry) {
  if (!entry.items?.length) return
  const file = resolvePlayFile(entry.items[0].tag)
  if (!file) { ElMessage.warning(t('common.warning') + ': ' + entry.items[0].tag); return }
  playFile(file)
}

// 播放单个 ITEM 引用的音频
function playItemTag(tag: string) {
  const file = resolvePlayFile(tag)
  if (!file) { ElMessage.warning(t('common.warning') + ': ' + tag); return }
  playFile(file)
}

// 判断是否有可行的音频文件
function hasPlayable(main: XmlEntry): boolean {
  if (main.file) return true
  if (main.items?.length) {
    return main.items.some(it => !!resolvePlayFile(it.tag))
  }
  return false
}
</script>

<template>
  <div class="xml-editor">
    <div class="page-header">
      <h2 class="page-title">{{ t('xmlAudioEditor.title') }}</h2>
      <div class="header-actions">
        <el-switch v-model="groupBy" :active-text="t('xmlAudioEditor.groupView')" :inactive-text="t('xmlAudioEditor.flatView')" size="small" />
        <el-button size="small" @click="exportXml">{{ t('xmlAudioEditor.exportXml') }}</el-button>
        <el-button size="small" @click="checkMissing" :loading="missingLoading">{{ t('xmlAudioEditor.checkMissing') }}</el-button>
        <el-button :icon="Refresh" size="small" :loading="loading" @click="loadEntries">{{ t('common.refresh') }}</el-button>
        <el-button :icon="Plus" type="primary" size="small" @click="openNewEntry">{{ t('xmlAudioEditor.addEntry') }}</el-button>
      </div>
    </div>

    <div class="toolbar">
      <el-button :icon="FolderOpened" size="small" type="primary" @click="openXmlBrowseDialog">{{ t('xmlAudioEditor.selectXml') }}</el-button>
      <span v-if="currentXmlPath" class="current-path" :title="currentXmlPath"><el-icon class="path-icon"><FolderOpened /></el-icon>{{ currentXmlPath }}</span>
      <div style="flex:1" />
      <el-input v-model="searchQuery" :placeholder="t('xmlAudioEditor.searchPlaceholder')" :prefix-icon="Search" clearable class="search-input" />
      <el-select v-model="typeFilter" class="filter-select">
        <el-option v-for="tp in entryTypes" :key="tp.value" :label="tp.label" :value="tp.value" />
      </el-select>
    </div>

    <el-row :gutter="10" class="stats-row">
      <el-col :span="4" v-for="s in [{k:'EFFECT',v:stats.effect_count},{k:'RANDOM',v:stats.random_count},{k:'GROUP',v:stats.group_count},{k:'MUSIC',v:stats.music_count},{k:'AMBIENT',v:stats.ambient_count}]" :key="s.k">
        <div class="stat-chip"><b>{{ s.v }}</b><span>{{ s.k }}</span></div>
      </el-col>
    </el-row>

    <!-- 分组视图 -->
    <el-card v-if="groupBy" class="table-card" v-loading="loading">
      <div class="group-list" v-if="filteredGroups.length">
        <div v-for="g in filteredGroups" :key="g.key" class="group-block">
          <div class="group-header" @click="toggleGroup(g.key)">
            <el-icon v-if="g.refs.length" class="group-arrow"><ArrowDown v-if="expandedGroups[g.key]" /><ArrowRight v-else /></el-icon>
            <el-icon v-else class="group-arrow" style="visibility:hidden"><ArrowRight /></el-icon>
            <el-tag :type="fmtTypeTag(g.main.type)" size="small" effect="dark">{{ g.main.type }}</el-tag>
            <span class="group-id">{{ g.main.id }}</span>
            <span v-if="g.main.file" class="group-file" :class="{ missing: g.main.file_missing }">
              <el-icon v-if="g.main.file_missing" class="missing-icon"><svg viewBox="0 0 1024 1024" width="12" height="12"><path d="M512 64a448 448 0 110 896 448 448 0 010-896zm0 64a384 384 0 100 768 384 384 0 000-768zm0 512a32 32 0 0132 32v96a32 32 0 01-64 0v-96a32 32 0 0132-32zm0-288a32 32 0 0132 32v192a32 32 0 01-64 0V384a32 32 0 0132-32z" fill="currentColor"/></svg></el-icon>
              {{ g.main.file }}
            </span>
            <span v-if="g.refs.length" class="group-refs-count">{{ g.refs.length }} {{ t('xmlAudioEditor.reference') }}</span>
            <div class="group-actions">
              <el-button v-if="hasPlayable(g.main)" :icon="VideoPlay" circle size="small" :title="g.main.type === 'RANDOM' ? t('xmlAudioEditor.randomPlay') : t('xmlAudioEditor.playTitle')" @click.stop="g.main.file ? playFile(g.main.file!) : (g.main.type === 'RANDOM' ? playRandom(g.main) : playSequence(g.main))" />
              <el-button :icon="Edit" circle size="small" type="primary" :title="t('xmlAudioEditor.editTitle')" @click.stop="openEditEntry(g.main)" />
              <el-button :icon="Delete" circle size="small" type="danger" :title="t('xmlAudioEditor.deleteTitle')" :loading="operationLoading === `delete-${g.main.id}`" @click.stop="deleteEntry(g.main)" />
            </div>
          </div>
          <div v-if="g.refs.length && expandedGroups[g.key]" class="group-body">
            <div v-for="ref in g.refs" :key="ref.type + ':' + ref.id" class="ref-row">
              <el-icon class="ref-icon"><Link /></el-icon>
              <el-tag :type="fmtTypeTag(ref.type)" size="small">{{ ref.type }}</el-tag>
              <span class="ref-id">{{ ref.id }}</span>
              <span v-if="ref.items" class="ref-props">
                <template v-for="(it, i) in ref.items" :key="i">
                  <span v-if="it.prob" class="ref-prob">{{ fmtProb(it.prob) }}</span>
                  <span v-if="it.delay" class="ref-delay">{{ t('xmlAudioEditor.delayLabel') }} {{ fmtDelay(it.delay) }}</span>
                  <span v-if="it.loop_delay" class="ref-delay">{{ t('xmlAudioEditor.loopLabel') }} {{ fmtDelay(it.loop_delay) }}</span>
                </template>
              </span>
              <div class="ref-actions">
                <el-button :icon="Edit" link size="small" type="primary" @click.stop="openEditEntry(ref)">{{ t('common.edit') }}</el-button>
                <el-button :icon="Delete" link size="small" type="danger" :loading="operationLoading === `delete-${ref.id}`" @click.stop="deleteEntry(ref)">{{ t('common.delete') }}</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-empty v-else :description="t('xmlAudioEditor.noData')" />
    </el-card>

    <!-- 平铺视图 -->
    <el-card v-else class="table-card" v-loading="loading">
      <el-table :data="flatEntries" stripe height="calc(100vh - 340px)" size="small">
        <el-table-column :label="t('xmlAudioEditor.type')" width="90"><template #default="{ row }"><el-tag :type="fmtTypeTag(row.type)" size="small">{{ row.type }}</el-tag></template></el-table-column>
        <el-table-column :label="t('xmlAudioEditor.id')" min-width="160" show-overflow-tooltip><template #default="{ row }">{{ row.id }}<el-button link size="small" style="margin-left:4px;opacity:.4" @click="copyId(row.id)"><el-icon :size="12"><Link /></el-icon></el-button></template></el-table-column>
        <el-table-column label="FILE" min-width="200" show-overflow-tooltip><template #default="{ row }"><span v-if="row.file" :class="{ missing: row.file_missing }">{{ row.file_missing ? '⚠ ' : '' }}{{ row.file }}</span><span v-else>-</span></template></el-table-column>
        <el-table-column label="ITEM" min-width="240"><template #default="{ row }"><span v-if="row.items?.length"><span v-for="(it,i) in row.items" :key="i" class="item-chip">{{ it.tag }}{{ it.prob ? ' ' + fmtProb(it.prob) : '' }}{{ it.delay ? ' +'+fmtDelay(it.delay) : '' }}</span></span><span v-else>-</span></template></el-table-column>
        <el-table-column :label="t('xmlAudioEditor.operation')" width="150" fixed="right"><template #default="{ row }"><el-button v-if="row.file" :icon="VideoPlay" circle size="small" @click="playFile(row.file!)" /><el-button :icon="Edit" circle size="small" type="primary" @click="openEditEntry(row)" /><el-button :icon="Delete" circle size="small" type="danger" :loading="operationLoading === `delete-${row.id}`" @click="deleteEntry(row)" /></template></el-table-column>
      </el-table>
    </el-card>

    <!-- Editor -->
    <el-dialog v-model="editorVisible" :title="isNewEntry ? t('xmlAudioEditor.addEntryTitle') : t('xmlAudioEditor.editEntryTitle')" width="680px">
      <template v-if="editingEntry">
        <el-form label-width="100px" size="small">
          <el-form-item :label="t('xmlAudioEditor.type')"><el-select v-model="editingEntry.type" :disabled="!isNewEntry"><el-option v-for="tp in entryTypes.slice(1)" :key="tp.value" :label="tp.label" :value="tp.value" /></el-select></el-form-item>
          <el-form-item :label="t('xmlAudioEditor.id')"><el-input v-model="editingEntry.id" :disabled="!isNewEntry" /></el-form-item>
          <template v-if="editingEntry.type === 'MUSIC'">
            <el-form-item label="FILE">
              <el-input v-model="editingEntry.file" :placeholder="t('xmlAudioEditor.filenamePlaceholder')">
                <template #prepend>music\</template>
                <template #append><el-button :icon="Link" @click="openFilePick('music')">{{ t('xmlAudioEditor.selectFile') }}</el-button></template>
              </el-input>
            </el-form-item>
          </template>
          <template v-if="editingEntry.type === 'EFFECT' || editingEntry.type === 'AMBIENT'">
            <el-form-item label="FILE">
              <el-input v-model="editingEntry.file" :placeholder="t('xmlAudioEditor.filenamePlaceholder')">
                <template #prepend>sounds\</template>
                <template #append><el-button :icon="Link" @click="openFilePick('soundpack')">{{ t('xmlAudioEditor.selectFile') }}</el-button></template>
              </el-input>
            </el-form-item>
          </template>
          <template v-if="editingEntry.type === 'EFFECT'">
            <el-row :gutter="12"><el-col :span="12"><el-form-item :label="t('xmlAudioEditor.volume')"><el-input v-model="editingEntry.attributes!.volume_adjust" placeholder="0"/></el-form-item></el-col><el-col :span="12"><el-form-item :label="t('xmlAudioEditor.priority')"><el-input v-model="editingEntry.attributes!.priority" placeholder="0"/></el-form-item></el-col></el-row>
            <el-row :gutter="12"><el-col :span="12"><el-form-item :label="t('xmlAudioEditor.delay')"><el-input v-model="editingEntry.attributes!.delay" placeholder="0"/></el-form-item></el-col><el-col :span="12"><el-form-item label="delay_range"><el-input v-model="editingEntry.attributes!.delay_range" placeholder="0"/></el-form-item></el-col></el-row>
            <el-row :gutter="12"><el-col :span="12"><el-form-item :label="t('xmlAudioEditor.loop') + ' ' + t('xmlAudioEditor.delay')"><el-input v-model="editingEntry.attributes!.loop_delay" placeholder="0"/></el-form-item></el-col><el-col :span="12"><el-form-item label="loop_delay_range"><el-input v-model="editingEntry.attributes!.loop_delay_range" placeholder="0"/></el-form-item></el-col></el-row>
          </template>
          <template v-if="editingEntry.type === 'RANDOM'">
            <el-row :gutter="12"><el-col :span="12"><el-form-item :label="t('xmlAudioEditor.delay')"><el-input v-model="editingEntry.attributes!.delay" placeholder=""/></el-form-item></el-col><el-col :span="12"><el-form-item :label="t('xmlAudioEditor.loop') + ' ' + t('xmlAudioEditor.delay')"><el-input v-model="editingEntry.attributes!.loop_delay" placeholder=""/></el-form-item></el-col></el-row>
            <el-divider>ITEM {{ t('xmlAudioEditor.reference') }} <el-tag :type="randomProbTotal === 100 ? 'success' : 'danger'" size="small">{{ randomProbTotal }}%</el-tag></el-divider>
            <div v-for="(it, i) in editingEntry.items" :key="i" class="item-row"><el-row :gutter="8"><el-col :span="12"><el-input v-model="it.tag" :placeholder="t('xmlAudioEditor.targetEffectId')" size="small" /></el-col><el-col :span="5"><el-input v-model="it.prob" :placeholder="t('xmlAudioEditor.probability')" size="small" type="number" min="0" max="100"><template #prepend>%</template></el-input></el-col><el-col :span="3"><el-input v-model="it.loop_delay" :placeholder="t('xmlAudioEditor.loopPlaceholder')" size="small" /></el-col><el-col :span="2"><el-button v-if="it.tag" :icon="VideoPlay" size="small" circle :title="t('xmlAudioEditor.audition')" @click="playItemTag(it.tag)" /></el-col><el-col :span="2"><el-button :icon="Delete" size="small" circle type="danger" @click="removeItem(i)" /></el-col></el-row></div>
            <el-button :icon="Plus" size="small" @click="addItem">{{ t('common.add') }} ITEM</el-button>
          </template>
          <template v-if="editingEntry.type === 'GROUP'">
            <el-divider>ITEM</el-divider>
            <div v-for="(it, i) in editingEntry.items" :key="i" class="item-row"><el-row :gutter="8"><el-col :span="7"><el-input v-model="it.tag" :placeholder="t('xmlAudioEditor.targetId')" size="small" /></el-col><el-col :span="5"><el-input v-model="it.delay" :placeholder="t('xmlAudioEditor.delayPlaceholder')" size="small" /></el-col><el-col :span="5"><el-input v-model="it.loop_delay" :placeholder="t('xmlAudioEditor.loopPlaceholder')" size="small" /></el-col><el-col :span="2"><el-button v-if="it.tag" :icon="VideoPlay" size="small" circle :title="t('xmlAudioEditor.audition')" @click="playItemTag(it.tag)" /></el-col><el-col :span="2"><el-button :icon="Delete" size="small" circle type="danger" @click="removeItem(i)" /></el-col></el-row></div>
            <el-button :icon="Plus" size="small" @click="addItem">{{ t('common.add') }} ITEM</el-button>
          </template>
        </el-form>
      </template>
      <template #footer><el-button @click="editorVisible = false">{{ t('xmlAudioEditor.cancel') }}</el-button><el-button type="primary" :loading="operationLoading === 'save'" @click="saveEntry">{{ t('xmlAudioEditor.save') }}</el-button></template>
    </el-dialog>

    <el-dialog v-model="playerVisible" :title="t('xmlAudioEditor.audioPreview')" width="450px" @closed="onPlayerClosed"><div class="player-box"><p>{{ playingFile }}</p><audio ref="audioEl" :src="audioUrl" controls autoplay class="audio-el" /></div></el-dialog>
    <el-dialog v-model="showXmlFileDialog" :title="t('xmlAudioEditor.selectXml')" width="550px" destroy-on-close>
      <el-input v-model="xmlDirPath" placeholder="" @keyup.enter="browseXmlDir" style="margin-bottom:12px"><template #append><el-button :loading="browsingFiles" :icon="Search" @click="browseXmlDir">{{ t('common.search') }}</el-button></template></el-input>
      <el-table v-loading="browsingFiles" :data="xmlFileList" size="small" max-height="340" :empty-text="t('xmlAudioEditor.noData')">
        <el-table-column prop="name" label="Name" min-width="200" show-overflow-tooltip />
        <el-table-column prop="path" label="Path" show-overflow-tooltip />
        <el-table-column width="70" fixed="right">
          <template #default="{ row }"><el-button size="small" type="primary" @click="selectXmlFile(row)">{{ t('xmlAudioEditor.load') }}</el-button></template>
        </el-table-column>
      </el-table>
    </el-dialog>
    <el-dialog v-model="filePickVisible" :title="t('xmlAudioEditor.selectXml')" width="500px">
      <el-input v-model="filePickSearch" :placeholder="t('xmlAudioEditor.searchPlaceholder')" :prefix-icon="Search" clearable style="margin-bottom:12px" />
      <el-table :data="filePickList.filter(f => !filePickSearch || f.name.toLowerCase().includes(filePickSearch.toLowerCase()) || f.path.toLowerCase().includes(filePickSearch.toLowerCase()))" size="small" max-height="350"><el-table-column prop="name" label="Name" show-overflow-tooltip /><el-table-column prop="path" label="Path" min-width="200" show-overflow-tooltip /><el-table-column width="60"><template #default="{ row }"><el-button size="small" type="primary" link @click="selectPickFile(row)">{{ t('common.confirm') }}</el-button></template></el-table-column></el-table>
    </el-dialog>

    <!-- 缺失文件 -->
    <el-dialog v-model="showMissingDialog" :title="t('xmlAudioEditor.missingFileCheck')" width="700px">
      <p v-if="!missingFiles.length" style="color: var(--el-color-success)">✓ {{ t('xmlAudioEditor.allFilesExist') }}</p>
      <el-table v-else :data="missingFiles" size="small" max-height="400">
        <el-table-column prop="type" :label="t('xmlAudioEditor.type')" width="80" />
        <el-table-column prop="id" :label="t('xmlAudioEditor.id')" min-width="150" show-overflow-tooltip />
        <el-table-column prop="file" label="FILE" min-width="300" show-overflow-tooltip />
      </el-table>
      <template #footer>
        <span v-if="missingFiles.length">{{ t('xmlAudioEditor.missingCount', { count: missingFiles.length }) }}</span>
        <el-button @click="showMissingDialog = false">{{ t('xmlAudioEditor.close') }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.xml-editor { height: calc(100vh - 90px - 48px); display: flex; flex-direction: column; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;
  .page-title { margin: 0; font-size: 18px; }
  .header-actions { display: flex; gap: 8px; align-items: center; }
}
.toolbar { display: flex; gap: 10px; margin-bottom: 10px; align-items: center;
  .current-path { font-size: 12px; color: var(--text-secondary); max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: flex; align-items: center; gap: 4px; .path-icon { flex-shrink: 0; } }
  .search-input { width: 240px; } .filter-select { width: 110px; }
}
.stats-row { margin-bottom: 10px; .stat-chip { display: flex; align-items: baseline; gap: 6px; background: var(--el-fill-color-light); border-radius: 6px; padding: 6px 14px; font-size: 13px; b { font-size: 18px; } span { color: var(--text-muted); font-size: 11px; } } }
.table-card { flex: 1; min-height: 0; overflow-y: auto; :deep(.el-card__body) { padding: 8px; height: 100%; } }

.group-list { display: flex; flex-direction: column; gap: 2px; }
.group-block { border: 1px solid var(--el-border-color-light); border-radius: 6px; overflow: hidden; }
.group-header { display: flex; align-items: center; gap: 8px; padding: 8px 12px; cursor: pointer; background: var(--el-fill-color-lighter); &:hover { background: var(--el-fill-color); }
  .group-arrow { font-size: 12px; flex-shrink: 0; }
  .group-id { font-weight: 600; font-size: 14px; word-break: break-all; flex: 1; }
  .group-file { font-size: 12px; color: var(--text-secondary); max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: flex; align-items: center; gap: 4px;
    &.missing { color: var(--el-color-danger); .missing-icon { color: var(--el-color-danger); flex-shrink: 0; } } }
  .group-refs-count { font-size: 11px; color: var(--el-color-primary); background: var(--el-color-primary-light-9); padding: 1px 8px; border-radius: 10px; white-space: nowrap; }
  .group-actions { display: flex; gap: 4px; margin-left: 8px; flex-shrink: 0; }
}
.group-body { border-top: 1px solid var(--el-border-color-lighter); }
.ref-row { display: flex; align-items: center; gap: 8px; padding: 6px 12px 6px 32px; font-size: 13px;
  &:nth-child(odd) { background: var(--el-fill-color-lighter); }
  .ref-icon { font-size: 11px; color: var(--text-muted); flex-shrink: 0; }
  .ref-id { font-weight: 500; word-break: break-all; flex: 1; }
  .ref-props { display: flex; gap: 6px; }
  .ref-prob { font-size: 11px; background: var(--el-color-success-light-9); color: var(--el-color-success); padding: 1px 6px; border-radius: 4px; white-space: nowrap; }
  .ref-delay { font-size: 11px; color: var(--text-muted); white-space: nowrap; }
  .ref-actions { display: flex; gap: 2px; flex-shrink: 0; margin-left: 4px; }
}

.item-row { margin-bottom: 8px; }
.item-chip { display: inline-block; font-size: 11px; background: var(--el-fill-color); padding: 1px 6px; border-radius: 4px; margin-right: 4px; margin-bottom: 2px; }
.missing { color: var(--el-color-danger); }
.player-box { text-align: center; p { font-size: 12px; word-break: break-all; margin-bottom: 12px; } .audio-el { width: 100%; } }
</style>
