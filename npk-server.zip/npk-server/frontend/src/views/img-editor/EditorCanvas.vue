<script setup lang="ts">
import { ref, computed, watch, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import {
  ZoomIn, ZoomOut, Picture,
  ArrowLeft, ArrowRight, Download,
  VideoPlay, VideoPause, Grid, Aim
} from '@element-plus/icons-vue'
import { useImgEditorStore } from '@/stores/imgEditor'
import { compatApi } from '@/api'

const { t } = useI18n()
const store = useImgEditorStore()

// 本地状态
const previewAreaRef = ref<HTMLElement | null>(null)
const previewLoading = ref(false)
const previewError = ref(false)
const imageNaturalSize = ref({ width: 0, height: 0 })

// 拖拽偏移
const dragStartPos = ref({ x: 0, y: 0 })
const dragFrameOffset = ref({ x: 0, y: 0 })
const dragCurrentOffset = ref({ x: 0, y: 0 })
const lastDragOffset = ref({ x: 0, y: 0 })

// 画布拖动
const panStartPos = ref({ x: 0, y: 0 })
const panCurrentOffset = ref({ x: 0, y: 0 })

// 播放定时器
let playInterval: number | null = null

// 预加载定时器
let preloadTimeout: number | null = null

// 预加载图片管理
const preloadingImages = ref<Map<string, HTMLImageElement>>(new Map())

// === 计算属性 ===

const dragImgStyle = computed(() => {
  if (!imageNaturalSize.value.width) return {}
  const offsetX = dragCurrentOffset.value.x
  const offsetY = dragCurrentOffset.value.y
  return {
    width: imageNaturalSize.value.width + 'px',
    height: imageNaturalSize.value.height + 'px',
    imageRendering: store.zoomLevel >= 2 ? 'pixelated' : 'auto',
    display: 'block',
    cursor: store.enableDrag ? (store.isDragging ? 'grabbing' : 'grab') : (store.enablePan ? (store.isPanning ? 'grabbing' : 'grab') : 'default'),
    transform: `translate(${offsetX}px, ${offsetY}px)`
  } as Record<string, string>
})

const previewCanvasStyle = computed(() => {
  return {
    transform: `translate(${store.panOffset.x}px, ${store.panOffset.y}px) scale(${store.zoomLevel})`
  }
})

const canvasStyle = computed(() => {
  if (!imageNaturalSize.value.width) return {}
  return {
    width: imageNaturalSize.value.width + 'px',
    height: imageNaturalSize.value.height + 'px'
  }
})

// 像素尺
interface RulerTick {
  pos: number
  label: string
  showLabel: boolean
}

const rulerTicksH = computed<RulerTick[]>(() => {
  const ticks: RulerTick[] = []
  const width = imageNaturalSize.value.width
  const step = 100
  const offset = store.panOffset.x % step
  const start = -offset
  for (let x = start; x <= width + step; x += step) {
    const value = Math.round((x - store.panOffset.x) / step) * step
    ticks.push({ pos: x, label: value.toString(), showLabel: value >= 0 && value <= width })
  }
  return ticks
})

const rulerTicksV = computed<RulerTick[]>(() => {
  const ticks: RulerTick[] = []
  const height = imageNaturalSize.value.height
  const step = 100
  const offset = store.panOffset.y % step
  const start = -offset
  for (let y = start; y <= height + step; y += step) {
    const value = Math.round((y - store.panOffset.y) / step) * step
    ticks.push({ pos: y, label: value.toString(), showLabel: value >= 0 && value <= height })
  }
  return ticks
})

const rulerContainerStyle = computed(() => {
  return {
    width: (imageNaturalSize.value.width + 24) + 'px',
    height: (imageNaturalSize.value.height + 24) + 'px'
  }
})

// === 帧切换 ===

function onFrameChange(index: number, isPlayingMode = false) {
  if (index < 0 || index >= store.frameList.length) return
  store.selectedFrameIndex = index

  if (!isPlayingMode) {
    previewLoading.value = true
    previewError.value = false
  }

  dragCurrentOffset.value = { x: 0, y: 0 }
  lastDragOffset.value = { x: 0, y: 0 }
  const frame = store.frameList.find(f => f.index === index)
  store.syncEditFields(frame)
}

function prevFrame() {
  if (store.selectedFrameIndex > 0) {
    onFrameChange(store.selectedFrameIndex - 1)
  }
}

function nextFrame() {
  if (store.selectedFrameIndex < store.totalFrames - 1) {
    onFrameChange(store.selectedFrameIndex + 1)
  }
}

// === 播放动画 ===

function togglePlay() {
  if (store.isPlaying) {
    stopPlay()
  } else {
    startPlay()
  }
}

async function startPlay() {
  if (store.totalFrames <= 1) return
  store.isPlaying = true

  // 先预加载所有帧，再开始播放
  await store.preloadAllFrames()

  playInterval = window.setInterval(() => {
    const nextIdx = (store.selectedFrameIndex + 1) % store.totalFrames
    onFrameChange(nextIdx, true)
  }, store.playSpeed)
}

function stopPlay() {
  store.isPlaying = false
  if (playInterval) {
    clearInterval(playInterval)
    playInterval = null
  }
}

watch(() => store.playSpeed, () => {
  if (store.isPlaying) {
    stopPlay()
    startPlay()
  }
})

// 监听预览 URL 变化
watch(() => store.previewUrl, (newUrl) => {
  if (newUrl && !store.isPlaying) {
    const key = store.cacheKey
    const isCached = store.frameCache.has(key)
    if (!isCached) {
      previewLoading.value = true
      previewError.value = false
    }
  }
})

// === 预加载相邻帧 ===

function preloadAdjacentFrames(currentIndex: number) {
  if (!store.selectedNpk || !store.selectedAlbumPath) return
  if (preloadTimeout) clearTimeout(preloadTimeout)

  // 清理旧的预加载图片
  cleanupPreloadingImages()

  preloadTimeout = window.setTimeout(() => {
    const indices = [currentIndex - 1, currentIndex + 1].filter(
      i => i >= 0 && i < store.totalFrames
    )
    let loadedCount = 0
    for (const idx of indices) {
      if (loadedCount >= 2) break
      const key = `${store.selectedNpk!.name}:${store.selectedAlbumPath}:${idx}`
      if (!store.frameCache.has(key)) {
        const url = compatApi.getFrameByPathUrl(store.selectedAlbumPath, idx)
        try {
          const img = new Image()
          img.src = url
          img.onload = () => {
            store.setCache(key, url)
            // 加载完成后从追踪中移除
            preloadingImages.value.delete(key)
          }
          img.onerror = () => {
            preloadingImages.value.delete(key)
          }
          preloadingImages.value.set(key, img)
          loadedCount++
        } catch (e) { /* 静默 */ }
      }
    }
  }, 300)
}

// 清理预加载图片
function cleanupPreloadingImages() {
  preloadingImages.value.forEach((img) => {
    img.onload = null
    img.onerror = null
    img.src = ''
  })
  preloadingImages.value.clear()
}

// === 图片加载 ===

function onPreviewLoad(e: Event) {
  const img = e.target as HTMLImageElement
  imageNaturalSize.value = { width: img.naturalWidth, height: img.naturalHeight }
  previewLoading.value = false
  previewError.value = false
  const key = store.cacheKey
  if (key && !store.frameCache.has(key)) {
    store.setCache(key, img.src)
  }
  preloadAdjacentFrames(store.selectedFrameIndex)
}

function onPreviewError() {
  previewLoading.value = false
  previewError.value = true
}

// === 拖拽调整偏移 ===

function onDragStart(e: MouseEvent) {
  if (!store.selectedFrame || !store.enableDrag) return
  e.preventDefault()
  store.isDragging = true
  dragStartPos.value = { x: e.clientX, y: e.clientY }
  dragFrameOffset.value = { x: store.editX, y: store.editY }
  dragCurrentOffset.value = { ...lastDragOffset.value }
  document.addEventListener('mousemove', onDragMove)
  document.addEventListener('mouseup', onDragEnd)
}

function onDragMove(e: MouseEvent) {
  if (!store.isDragging) return
  const dx = Math.round((e.clientX - dragStartPos.value.x) / store.zoomLevel)
  const dy = Math.round((e.clientY - dragStartPos.value.y) / store.zoomLevel)
  store.editX = dragFrameOffset.value.x + dx
  store.editY = dragFrameOffset.value.y + dy
  dragCurrentOffset.value = {
    x: lastDragOffset.value.x + dx * store.zoomLevel,
    y: lastDragOffset.value.y + dy * store.zoomLevel
  }
}

function onDragEnd() {
  if (store.isDragging) {
    store.markFrameModified(store.selectedFrameIndex)
    lastDragOffset.value = {
      x: store.editX * store.zoomLevel,
      y: store.editY * store.zoomLevel
    }
  }
  store.isDragging = false
  document.removeEventListener('mousemove', onDragMove)
  document.removeEventListener('mouseup', onDragEnd)
}

// === 画布拖动 ===

function onEnableDragChange(val: any) {
  if (val === true) store.enablePan = false
}

function onEnablePanChange(val: any) {
  if (val === true) store.enableDrag = false
}

function onPanStart(e: MouseEvent) {
  if (!store.enablePan) return
  e.preventDefault()
  store.isPanning = true
  panStartPos.value = { x: e.clientX, y: e.clientY }
  panCurrentOffset.value = { ...store.panOffset }
  document.addEventListener('mousemove', onPanMove)
  document.addEventListener('mouseup', onPanEnd)
}

function onPanMove(e: MouseEvent) {
  if (!store.isPanning) return
  const dx = e.clientX - panStartPos.value.x
  const dy = e.clientY - panStartPos.value.y
  store.panOffset = {
    x: panCurrentOffset.value.x + dx,
    y: panCurrentOffset.value.y + dy
  }
}

function onPanEnd() {
  store.isPanning = false
  document.removeEventListener('mousemove', onPanMove)
  document.removeEventListener('mouseup', onPanEnd)
}

// === 缩放 ===

function zoomIn() {
  store.zoomLevel = Math.min(store.zoomLevel + 0.25, 5)
  store.fitMode = 'original'
}

function zoomOut() {
  store.zoomLevel = Math.max(store.zoomLevel - 0.25, 0.25)
}

function zoomReset() {
  store.zoomLevel = 1
  store.fitMode = 'contain'
}

function toggleFitMode() {
  if (store.fitMode === 'original') {
    store.fitMode = 'contain'
    if (imageNaturalSize.value.width > 0 && previewAreaRef.value) {
      const areaW = previewAreaRef.value.clientWidth
      const areaH = previewAreaRef.value.clientHeight
      const scale = Math.min(areaW / imageNaturalSize.value.width, areaH / imageNaturalSize.value.height, 1)
      store.zoomLevel = Math.round(scale * 100) / 100
    }
  } else {
    store.fitMode = 'original'
    store.zoomLevel = 1
  }
}

function downloadFrame() {
  if (!store.previewUrl) return
  const a = document.createElement('a')
  a.href = store.previewUrl
  const albumName = store.selectedAlbumPath.split('/').pop() || 'frame'
  a.download = `${albumName}_frame${store.selectedFrameIndex}.png`
  a.click()
}

function resetFrameProperties() {
  if (!store.selectedFrame) return
  store.editX = store.selectedFrame.x
  store.editY = store.selectedFrame.y
  store.editFrameWidth = store.selectedFrame.frame_width
  store.editFrameHeight = store.selectedFrame.frame_height
  dragCurrentOffset.value = { x: 0, y: 0 }
  lastDragOffset.value = { x: 0, y: 0 }
}

// 监听 Album 切换，重置偏移
watch(() => store.selectedAlbumPath, () => {
  store.panOffset = { x: 0, y: 0 }
  dragCurrentOffset.value = { x: 0, y: 0 }
  lastDragOffset.value = { x: 0, y: 0 }
  imageNaturalSize.value = { width: 0, height: 0 }
})

// 监听 NPK 切换
watch(() => store.selectedNpkId, () => {
  store.panOffset = { x: 0, y: 0 }
  dragCurrentOffset.value = { x: 0, y: 0 }
  lastDragOffset.value = { x: 0, y: 0 }
  imageNaturalSize.value = { width: 0, height: 0 }
  stopPlay()
})

onUnmounted(() => {
  stopPlay()
  if (preloadTimeout) clearTimeout(preloadTimeout)
  cleanupPreloadingImages()
  document.removeEventListener('mousemove', onDragMove)
  document.removeEventListener('mouseup', onDragEnd)
  document.removeEventListener('mousemove', onPanMove)
  document.removeEventListener('mouseup', onPanEnd)
})

// 暴露方法给父组件
defineExpose({
  resetFrameProperties,
  onEnableDragChange,
  onEnablePanChange
})
</script>

<template>
  <div class="preview-panel">
    <!-- 工具栏 -->
    <div class="toolbar" v-if="store.canPreview">
      <div class="toolbar-left">
        <el-button-group size="small">
          <el-button :icon="ArrowLeft" @click="prevFrame" :disabled="store.selectedFrameIndex <= 0" />
          <el-button disabled style="min-width: 80px;">
            {{ store.selectedFrameIndex + 1 }} / {{ store.totalFrames || 0 }}
          </el-button>
          <el-button :icon="ArrowRight" @click="nextFrame" :disabled="store.selectedFrameIndex >= store.totalFrames - 1" />
        </el-button-group>
        <el-button size="small" :icon="store.isPlaying ? VideoPause : VideoPlay" @click="togglePlay" :disabled="store.totalFrames <= 1">
          {{ store.isPlaying ? t('editorCanvas.pause') : t('editorCanvas.play') }}
        </el-button>
        <el-input-number v-model="store.playSpeed" :min="50" :max="1000" :step="50" size="small" style="width: 90px" />
        <span class="speed-label">ms</span>
      </div>
      <div class="toolbar-right">
        <el-button-group size="small">
          <el-button :icon="ZoomOut" @click="zoomOut" :disabled="store.zoomLevel <= 0.25" />
          <el-button @click="zoomReset" style="min-width: 60px;">{{ Math.round(store.zoomLevel * 100) }}%</el-button>
          <el-button :icon="ZoomIn" @click="zoomIn" :disabled="store.zoomLevel >= 5" />
        </el-button-group>
        <el-button size="small" @click="toggleFitMode">{{ store.fitMode === 'original' ? t('editorCanvas.fit') : t('editorCanvas.original') }}</el-button>
        <el-button size="small" :icon="Grid" :type="store.showGrid ? 'primary' : 'default'" @click="store.showGrid = !store.showGrid" :title="t('editorCanvas.grid')" />
        <el-button size="small" :icon="Aim" :type="store.showRuler ? 'primary' : 'default'" @click="store.showRuler = !store.showRuler" :title="t('editorCanvas.ruler')" />
        <el-button size="small" :type="store.showCrosshair ? 'primary' : 'default'" @click="store.showCrosshair = !store.showCrosshair" :title="t('editorCanvas.crosshair')">{{ t('editorCanvas.crosshairShort') }}</el-button>
        <el-button size="small" :icon="Download" @click="downloadFrame">{{ t('editorCanvas.download') }}</el-button>
      </div>
    </div>

    <!-- 帧信息栏 -->
    <div class="frame-info-bar" v-if="store.selectedFrame">
      <span><strong>{{ t('editorCanvas.frame', { index: store.selectedFrame.index }) }}</strong></span>
      <span>{{ t('editorCanvas.size') }} {{ store.selectedFrame.width }}x{{ store.selectedFrame.height }}</span>
      <span v-if="store.selectedFrame.frame_width !== store.selectedFrame.width">
        {{ t('editorCanvas.frameBounds') }} {{ store.selectedFrame.frame_width }}x{{ store.selectedFrame.frame_height }}
      </span>
      <span v-if="store.selectedFrame.x || store.selectedFrame.y">{{ t('editorCanvas.offset') }} ({{ store.selectedFrame.x }}, {{ store.selectedFrame.y }})</span>
    </div>

    <!-- 预览区域 -->
    <div class="preview-area" ref="previewAreaRef" @mousedown="onPanStart">
      <!-- 全局网格（在 transform 外部，随缩放调整间距） -->
      <div v-if="store.showGrid" class="grid-overlay-global" :style="{ backgroundSize: `${16 * store.zoomLevel}px ${16 * store.zoomLevel}px` }"></div>
      <div v-if="store.canPreview" class="preview-canvas" :style="previewCanvasStyle">

        <!-- 图片层 -->
        <div class="canvas-inner" :style="canvasStyle">
          <img
            v-if="!previewError"
            :src="store.previewUrl"
            :style="dragImgStyle"
            @load="onPreviewLoad"
            @error="onPreviewError"
            @mousedown.stop="onDragStart"
            draggable="false"
          />
          <!-- 十字线 -->
          <div v-if="store.showCrosshair" class="crosshair-overlay">
            <div class="crosshair-h"></div>
            <div class="crosshair-v"></div>
            <div class="crosshair-center">{{ store.editX || 0 }},{{ store.editY || 0 }}</div>
          </div>
        </div>

        <!-- 像素尺 -->
        <div v-if="store.showRuler" class="ruler-container" :style="rulerContainerStyle">
          <div class="ruler-top">
            <div
              v-for="tick in rulerTicksH"
              :key="'rt' + tick.pos"
              v-memo="[tick]"
              class="ruler-tick-h"
              :style="{ left: tick.pos + 'px' }"
            >
              <span class="ruler-label" v-if="tick.showLabel">{{ tick.label }}</span>
            </div>
          </div>
          <div class="ruler-left">
            <div
              v-for="tick in rulerTicksV"
              :key="'rl' + tick.pos"
              v-memo="[tick]"
              class="ruler-tick-v"
              :style="{ top: tick.pos + 'px' }"
            >
              <span class="ruler-label" v-if="tick.showLabel">{{ tick.label }}</span>
            </div>
          </div>
        </div>
      </div>
      <div v-if="previewLoading && store.canPreview" class="loading-overlay">
        <el-icon :size="32" class="is-loading"><Picture /></el-icon>
        <span>{{ t('editorCanvas.loading') }}</span>
      </div>
      <div v-if="previewError" class="error-overlay">
        <span>{{ t('editorCanvas.loadFailed') }}</span>
      </div>
      <div v-if="!store.canPreview" class="placeholder">
        <el-icon :size="64"><Picture /></el-icon>
        <span>{{ t('editorCanvas.selectHint') }}</span>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.preview-panel {
  flex: 1;
  min-width: 0;
  background: var(--bg-primary);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;

  .toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 12px;
    border-bottom: 1px solid var(--border-color);
    flex-shrink: 0;
    flex-wrap: wrap;
    gap: 8px;

    .toolbar-left, .toolbar-right {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .speed-label {
      font-size: 11px;
      color: var(--text-muted);
    }
  }

  .frame-info-bar {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 6px 12px;
    background: var(--bg-secondary);
    border-bottom: 1px solid var(--border-color);
    font-size: 12px;
    color: var(--text-secondary);
    flex-shrink: 0;

    strong {
      color: var(--accent-color);
    }
  }

  .preview-area {
    flex: 1;
    min-height: 0;
    overflow: auto;
    position: relative;
    background-color: var(--bg-secondary);
    background-image:
      linear-gradient(45deg, var(--bg-tertiary) 25%, transparent 25%),
      linear-gradient(-45deg, var(--bg-tertiary) 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, var(--bg-tertiary) 75%),
      linear-gradient(-45deg, transparent 75%, var(--bg-tertiary) 75%);
    background-size: 16px 16px;
    background-position: 0 0, 0 8px, 8px -8px, -8px 0px;

    .preview-canvas {
      display: inline-block;
      padding: 24px 0 0 24px;
      transform-origin: top left;
      position: relative;
      min-width: 100%;
      min-height: 100%;
    }

    .grid-overlay-global {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      pointer-events: none;
      background-image:
        linear-gradient(rgba(128, 128, 128, 0.2) 1px, transparent 1px),
        linear-gradient(90deg, rgba(128, 128, 128, 0.2) 1px, transparent 1px);
      background-size: 16px 16px;
      z-index: 1;
    }

    .canvas-inner {
      position: relative;
      display: inline-block;
      z-index: 2;

      img {
        display: block;
      }

      .frame-bounds {
        position: absolute;
        top: 0;
        left: 0;
        border: 2px dashed rgba(255, 0, 0, 0.8);
        pointer-events: none;
        z-index: 10;
        box-sizing: border-box;
      }

      .crosshair-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 0;
        height: 0;
        pointer-events: none;
        z-index: 11;

        .crosshair-h {
          position: absolute;
          top: 0;
          left: -5000px;
          width: 10000px;
          height: 1px;
          background: rgba(255, 0, 0, 0.6);
        }

        .crosshair-v {
          position: absolute;
          top: -5000px;
          left: 0;
          width: 1px;
          height: 10000px;
          background: rgba(255, 0, 0, 0.6);
        }

        .crosshair-center {
          position: absolute;
          top: -20px;
          left: 4px;
          font-size: 10px;
          color: rgba(255, 0, 0, 0.8);
          white-space: nowrap;
        }
      }
    }

    .ruler-container {
      position: absolute;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 20;

      .ruler-top {
        position: absolute;
        top: 0;
        left: 24px;
        right: 0;
        height: 24px;
        background: var(--bg-primary, rgba(30, 30, 30, 0.95));
        border-bottom: 1px solid var(--border-color, rgba(255, 255, 255, 0.1));
        overflow: hidden;

        .ruler-tick-h {
          position: absolute;
          top: 0;
          bottom: 0;
          width: 1px;
          background: var(--border-color);

          .ruler-label {
            position: absolute;
            top: 2px;
            left: 2px;
            font-size: 9px;
            color: var(--text-muted, rgba(255, 255, 255, 0.5));
            white-space: nowrap;
          }
        }
      }

      .ruler-left {
        position: absolute;
        top: 24px;
        left: 0;
        bottom: 0;
        width: 24px;
        background: var(--bg-primary, rgba(30, 30, 30, 0.95));
        border-right: 1px solid var(--border-color, rgba(255, 255, 255, 0.1));
        overflow: hidden;

        .ruler-tick-v {
          position: absolute;
          left: 0;
          right: 0;
          height: 1px;
          background: var(--border-color);

          .ruler-label {
            position: absolute;
            left: 2px;
            top: 2px;
            font-size: 9px;
            color: var(--text-muted, rgba(255, 255, 255, 0.5));
            white-space: nowrap;
            writing-mode: vertical-rl;
          }
        }
      }
    }

    .loading-overlay, .error-overlay, .placeholder {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      color: var(--text-muted);
      font-size: 14px;
      z-index: 30;
    }

    .error-overlay {
      color: var(--el-color-danger);
    }
  }
}
</style>
