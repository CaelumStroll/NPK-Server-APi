<script setup lang="ts">
import { ref, computed, onMounted, watch, onUnmounted, nextTick, onActivated, onDeactivated } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute } from 'vue-router'
import { animationApi, imgCacheApi, albumApi } from '@/api'
import {
  VideoPlay,
  VideoPause,
  DArrowLeft,
  DArrowRight,
  Download,
  ZoomIn,
  ZoomOut,
  CircleCheck,
  CircleClose,
  ArrowLeft,
  Sunny
} from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useNpkStore } from '@/stores/npk'
import { useCacheStore } from '@/stores/cache'
import { renderImageToCanvas } from '@/utils/canvas'
import { Search } from '@element-plus/icons-vue'

const { t } = useI18n()
const route = useRoute()
const npkStore = useNpkStore()
const cacheStore = useCacheStore()

const npkSearchQuery = ref('')

const selectedNpk = ref('')
const selectedAlbum = ref('')
const npkCollapsed = ref(false)
const animationInfo = ref<any>(null)
const currentFrame = ref(0)
const isPlaying = ref(false)
const frameDelay = ref(80)
const zoomLevel = ref(1)
const fitMode = ref<'contain' | 'original'>('original')
const previewAreaRef = ref<HTMLElement | null>(null)
const previewCanvas = ref<HTMLCanvasElement | null>(null)
const removeBlackBg = ref(false)
const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto')

const selectedFrames = ref<number[]>([])
const gifFrameRate = ref(10)
const frameData = ref<any[]>([])

let animationTimer: number | null = null

// 从 store 获取数据
const npkList = computed(() => npkStore.npkFiles)
const currentAlbums = computed(() => npkStore.currentAlbums)

const filteredNpkList = computed(() => {
  if (!npkSearchQuery.value) return npkList.value
  const query = npkSearchQuery.value.toLowerCase()
  return npkList.value.filter((npk: any) =>
    npk.name.toLowerCase().includes(query)
  )
})

async function fetchNpkInfo(name: string) {
  const cached = cacheStore.getAlbumListCache(name)
  if (cached) {
    // 如果有缓存，先显示缓存，同时后台刷新
    await npkStore.fetchNpkInfo(name)
    return
  }

  // 没有缓存，直接请求
  await npkStore.fetchNpkInfo(name)
}

onMounted(async () => {
  // 初始化只执行一次
})

onActivated(async () => {
  // 获取路由参数
  const queryNpk = route.query.npk as string
  const queryAlbum = route.query.album as string
  
  // 如果有参数，重新选择
  if (queryNpk) {
    // 检查 NPK 是否已加载
    if (npkList.value.length === 0) {
      await npkStore.fetchNpkList()
    }
    
    const exists = npkList.value.some(n => n.name === queryNpk)
    if (exists) {
      selectedNpk.value = queryNpk
      await fetchNpkInfo(queryNpk)
      if (queryAlbum) {
        selectedAlbum.value = queryAlbum
      }
      return // 如果有参数，保持选中状态
    }
  }
  
  // 没有参数时，清除选中状态（返回页面时）
  clearSelection()
})

// 清除所有选中状态
function clearSelection() {
  selectedNpk.value = ''
  selectedAlbum.value = ''
  animationInfo.value = null
  currentFrame.value = 0
  selectedFrames.value = []
  npkStore.clearCurrent()
}

onDeactivated(() => {
  stopAnimation()
})

onUnmounted(() => {
  stopAnimation()
  if (cachedImgKey) {
    const [npk, ...pathParts] = cachedImgKey.split(':')
    const path = pathParts.join(':')
    imgCacheApi.release(npk, path).catch(() => {})
    cachedImgKey = null
  }
})

watch(selectedNpk, async (newNpk) => {
  selectedAlbum.value = ''
  animationInfo.value = null
  currentFrame.value = 0
  selectedFrames.value = []
  stopAnimation()

  if (newNpk) {
    npkCollapsed.value = true
    await fetchNpkInfo(newNpk)
  } else {
    npkCollapsed.value = false
    npkStore.clearCurrent()
  }
})

function goBackToNpk() {
  npkCollapsed.value = false
  selectedNpk.value = ''
  selectedAlbum.value = ''
  animationInfo.value = null
}

let cachedImgKey: string | null = null

watch(selectedAlbum, async (newAlbum, oldAlbum) => {
  animationInfo.value = null
  currentFrame.value = 0
  selectedFrames.value = []
  stopAnimation()

  if (cachedImgKey && oldAlbum) {
    const [oldNpk, ...oldPathParts] = cachedImgKey.split(':')
    const oldPath = oldPathParts.join(':')
    imgCacheApi.release(oldNpk, oldPath).catch(() => {})
    cachedImgKey = null
  }

  if (selectedNpk.value && newAlbum) {
    try {
      await imgCacheApi.load(selectedNpk.value, newAlbum)
      cachedImgKey = `${selectedNpk.value}:${newAlbum}`
    } catch (e) {
      console.warn('Preload IMG cache failed:', e)
    }
    await loadAnimation()
  }
})

async function loadAnimation() {
  try {
    const res = await animationApi.getInfo(selectedNpk.value, selectedAlbum.value) as any
    animationInfo.value = res.data
    currentFrame.value = 0
    selectedFrames.value = Array.from({ length: animationInfo.value.frame_count }, (_, i) => i)
    
    // 获取帧列表详细信息，包括 LINK 状态
    const framesRes = await albumApi.getFrames(selectedNpk.value, selectedAlbum.value)
    frameData.value = framesRes.data?.frames || []
    
    await nextTick()
    renderCurrentFrame()
  } catch (e: any) {
    console.error('Failed to load animation', e)
    ElMessage.error(t('animationPlayer.loadAnimationFailed') + ': ' + e.message)
    animationInfo.value = null
    frameData.value = []
  }
}

function getFrameUrl(index: number): string {
  if (!selectedNpk.value || !selectedAlbum.value) return ''
  return animationApi.getFrameUrl(selectedNpk.value, selectedAlbum.value, index)
}

async function renderCurrentFrame() {
  if (!previewCanvas.value || !animationInfo.value) return
  const url = getFrameUrl(currentFrame.value)
  try {
    await renderImageToCanvas(previewCanvas.value, url, removeBlackBg.value)
  } catch {}
}

watch(currentFrame, () => {
  nextTick(renderCurrentFrame)
})

watch(removeBlackBg, () => {
  renderCurrentFrame()
})

function playAnimation() {
  if (!animationInfo.value) return
  isPlaying.value = true
  animationTimer = window.setInterval(() => {
    if (currentFrame.value < animationInfo.value.frame_count - 1) {
      currentFrame.value++
    } else {
      currentFrame.value = 0
    }
  }, frameDelay.value)
}

function stopAnimation() {
  isPlaying.value = false
  if (animationTimer) {
    clearInterval(animationTimer)
    animationTimer = null
  }
}

function togglePlay() {
  if (isPlaying.value) {
    stopAnimation()
  } else {
    playAnimation()
  }
}

function prevFrame() {
  stopAnimation()
  if (currentFrame.value > 0) {
    currentFrame.value--
  }
}

function nextFrame() {
  stopAnimation()
  if (animationInfo.value && currentFrame.value < animationInfo.value.frame_count - 1) {
    currentFrame.value++
  }
}

function selectFrame(index: number) {
  stopAnimation()
  currentFrame.value = index
}

function toggleFrameSelection(index: number) {
  const idx = selectedFrames.value.indexOf(index)
  if (idx >= 0) {
    selectedFrames.value.splice(idx, 1)
  } else {
    selectedFrames.value.push(index)
  }
}

function exportGif() {
  if (!selectedNpk.value || !selectedAlbum.value || selectedFrames.value.length === 0) {
    ElMessage.warning(t('animationPlayer.selectAtLeastOneFrame'))
    return
  }
  const framesParam = selectedFrames.value.join(',')
  const removeBlackParam = removeBlackBg.value ? '&removeBlack=true' : ''
  const url = `${animationApi.getExportGifUrl(selectedNpk.value, selectedAlbum.value)}&frames=${framesParam}&fps=${gifFrameRate.value}${removeBlackParam}`
  window.open(url, '_blank')
}

function selectAllFrames() {
  if (animationInfo.value) {
    selectedFrames.value = Array.from({ length: animationInfo.value.frame_count }, (_, i) => i)
  }
}

function clearAllFrames() {
  selectedFrames.value = []
}

function zoomIn() {
  zoomLevel.value = Math.min(zoomLevel.value + 0.25, 5)
  fitMode.value = 'original'
}

function zoomOut() {
  zoomLevel.value = Math.max(zoomLevel.value - 0.25, 0.25)
}

function zoomReset() {
  zoomLevel.value = 1
  fitMode.value = 'contain'
}

function toggleFitMode() {
  if (fitMode.value === 'original') {
    fitMode.value = 'contain'
    if (animationInfo.value && previewAreaRef.value) {
      const areaW = previewAreaRef.value.clientWidth
      const areaH = previewAreaRef.value.clientHeight
      const imgW = animationInfo.value.width
      const imgH = animationInfo.value.height
      if (imgW > 0 && imgH > 0) {
        const scale = Math.min(areaW / imgW, areaH / imgH, 1)
        zoomLevel.value = Math.round(scale * 100) / 100
      }
    }
  } else {
    fitMode.value = 'original'
    zoomLevel.value = 1
  }
}

watch(animationInfo, () => {
  zoomLevel.value = 1
  fitMode.value = 'original'
})

const imgStyle = computed(() => {
  if (!animationInfo.value) return {}
  return {
    imageRendering: zoomLevel.value >= 2 ? 'pixelated' : 'auto'
  } as Record<string, string>
})

const canvasStyle = computed(() => {
  if (!animationInfo.value) return {}
  return {
    transform: `scale(${zoomLevel.value})`,
    transformOrigin: 'top left'
  }
})

const animationAlbums = computed(() => {
  return currentAlbums.value.filter(a => a.sprite_count > 1)
})

const currentAlbumVersion = computed(() => {
  const album = currentAlbums.value.find(a => a.path === selectedAlbum.value)
  return album?.version || t('animationPlayer.unknown')
})

const frameList = computed(() => {
  if (!animationInfo.value) return []
  return Array.from({ length: animationInfo.value.frame_count }, (_, i) => i)
})

const animationDisplayName = computed(() => {
  if (!selectedAlbum.value) return ''
  const parts = selectedAlbum.value.split('/')
  const name = parts[parts.length - 1]
  if (name.toLowerCase().endsWith('.img')) {
    return name
  }
  return name + '.img'
})

const canvasBgClass = computed(() => {
  switch (canvasBgMode.value) {
    case 'light':
      return 'bg-light'
    case 'dark':
      return 'bg-dark'
    default:
      return 'bg-auto'
  }
})

function toggleCanvasBgMode() {
  if (canvasBgMode.value === 'auto') {
    canvasBgMode.value = 'light'
  } else if (canvasBgMode.value === 'light') {
    canvasBgMode.value = 'dark'
  } else {
    canvasBgMode.value = 'light'
  }
}
</script>

<template>
  <div class="animation-player">
    <div class="page-header">
      <h2 class="page-title">{{ t('animationPlayer.title') }}</h2>
    </div>

    <el-row :gutter="12" class="main-row">
      <!-- 左侧：NPK + Album -->
      <el-col :span="6" class="left-col">
        <el-card class="list-card npk-card" v-if="!npkCollapsed">
          <template #header>
            <div class="card-header">
              <span>{{ t('animationPlayer.npkFiles') }} ({{ npkList.length }})</span>
            </div>
          </template>
          <div class="search-box">
            <el-input
              v-model="npkSearchQuery"
              :placeholder="t('animationPlayer.searchNpk')"
              :prefix-icon="Search"
              clearable
              size="small"
            />
          </div>
          <el-scrollbar class="npk-scrollbar">
            <div class="npk-list">
              <div
                v-for="npk in filteredNpkList"
                :key="npk.name"
                class="list-item"
                :class="{ active: selectedNpk === npk.name }"
                @click="selectedNpk = npk.name"
              >
                <span class="item-name">{{ npk.name }}</span>
              </div>
            </div>
          </el-scrollbar>
        </el-card>

        <el-card class="list-card album-card" v-show="npkCollapsed">
          <template #header>
            <div class="card-header">
              <el-button size="small" @click="goBackToNpk" class="back-btn"><ArrowLeft /> {{ t('animationPlayer.back') }}</el-button>
              <span>Album ({{ animationAlbums.length }})</span>
            </div>
          </template>
          <el-scrollbar class="album-scrollbar">
            <div v-if="animationAlbums.length === 0" class="empty-tip">{{ t('animationPlayer.noAnimationAlbum') }}</div>
            <div v-else class="album-list">
              <div
                v-for="album in animationAlbums"
                :key="album.path"
                class="list-item album-item"
                :class="{ active: selectedAlbum === album.path }"
                @click="selectedAlbum = album.path"
              >
                <span class="item-name">{{ album.name }}</span>
                <span class="item-meta">{{ album.sprite_count }} {{ t('animationPlayer.frame') }}</span>
              </div>
            </div>
          </el-scrollbar>
        </el-card>
      </el-col>

      <!-- 中间：播放器 -->
      <el-col :span="13" class="center-col">
        <el-card class="player-card">
          <div class="zoom-toolbar">
            <el-button-group size="small">
              <el-button :icon="ZoomOut" @click="zoomOut" :disabled="!animationInfo || zoomLevel <= 0.25" />
              <el-button @click="zoomReset" style="min-width: 60px;">
                {{ Math.round(zoomLevel * 100) }}%
              </el-button>
              <el-button :icon="ZoomIn" @click="zoomIn" :disabled="!animationInfo || zoomLevel >= 5" />
            </el-button-group>
            <el-button size="small" @click="toggleFitMode" :disabled="!animationInfo">
              {{ fitMode === 'original' ? t('animationPlayer.originalSize') : t('animationPlayer.fitWindow') }}
            </el-button>
            <el-checkbox v-model="removeBlackBg" size="small" :disabled="!animationInfo">{{ t('animationPlayer.removeBlackBg') }}</el-checkbox>
            <el-button size="small" :icon="Sunny" @click="toggleCanvasBgMode" :disabled="!animationInfo" :title="canvasBgMode === 'auto' ? t('animationPlayer.auto') : canvasBgMode === 'light' ? t('animationPlayer.light') : t('animationPlayer.dark')">
              {{ canvasBgMode === 'auto' ? t('animationPlayer.auto') : canvasBgMode === 'light' ? t('animationPlayer.light') : t('animationPlayer.dark') }}
            </el-button>
            <el-button type="primary" size="small" :icon="Download" @click="exportGif" :disabled="selectedFrames.length === 0">
              {{ t('animationPlayer.exportGif') }}
            </el-button>
          </div>

          <div class="preview-area" :class="canvasBgClass" ref="previewAreaRef">
            <div v-if="animationInfo" class="preview-canvas" :style="canvasStyle">
              <canvas
                ref="previewCanvas"
                :width="animationInfo?.width || 0"
                :height="animationInfo?.height || 0"
                :style="imgStyle"
              />
            </div>
            <div v-else class="placeholder">
              <el-icon :size="64"><VideoPlay /></el-icon>
              <span>{{ t('animationPlayer.selectNpkAndAlbum') }}</span>
            </div>
          </div>

          <div class="controls">
            <el-button :icon="DArrowLeft" @click="prevFrame" :disabled="!animationInfo" />
            <el-button
              :type="isPlaying ? 'danger' : 'primary'"
              :icon="isPlaying ? VideoPause : VideoPlay"
              @click="togglePlay"
              :disabled="!animationInfo"
            >
              {{ isPlaying ? t('animationPlayer.pause') : t('animationPlayer.play') }}
            </el-button>
            <el-button :icon="DArrowRight" @click="nextFrame" :disabled="!animationInfo" />

            <el-divider direction="vertical" />

            <span class="frame-info">
              {{ t('animationPlayer.frame') }}: {{ currentFrame + 1 }} / {{ animationInfo?.frame_count || 0 }}
            </span>

            <span class="delay-info">
              {{ t('animationPlayer.delay') }}:
              <el-input-number
                v-model="frameDelay"
                :min="10"
                :max="1000"
                :step="10"
                size="small"
                style="width: 100px"
              />
              ms
            </span>
          </div>
        </el-card>
      </el-col>

      <!-- 右侧：帧列表 + 帧信息 -->
      <el-col :span="5" class="right-col">
        <el-card class="frames-card">
          <template #header>
            <div class="frames-header">
              <span>{{ t('animationPlayer.frameList') }} ({{ selectedFrames.length }}/{{ frameList.length }})</span>
              <div class="frames-actions">
                <el-button size="small" :icon="CircleCheck" @click="selectAllFrames" :title="t('animationPlayer.selectAll')" />
                <el-button size="small" :icon="CircleClose" @click="clearAllFrames" :title="t('animationPlayer.clearAll')" />
              </div>
            </div>
          </template>
          
          <div class="frames-content">
            <el-scrollbar class="frames-scrollbar" v-if="frameList.length > 0">
              <div class="frame-list">
                <div
                  v-for="i in frameList"
                  :key="i"
                  class="frame-item"
                  :class="{ active: currentFrame === i }"
                  @click="selectFrame(i)"
                >
                  <input
                    type="checkbox"
                    :checked="selectedFrames.includes(i)"
                    @change="toggleFrameSelection(i)"
                    class="frame-checkbox-input"
                    @click.stop
                  />
                  <span class="frame-number">{{ i }}</span>
                </div>
              </div>
            </el-scrollbar>
            <div v-else class="frames-empty">
              <el-empty :description="t('animationPlayer.showFrameListAfterSelect')" :image-size="60" />
            </div>
          </div>
        </el-card>

        <el-card class="frame-info-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('animationPlayer.frameInfo') }}</span>
            </div>
          </template>
          <div v-if="animationInfo" class="frame-info-content">
            <div class="info-row">
              <span class="info-label">{{ t('animationPlayer.name') }}:</span>
              <span class="info-value">{{ animationDisplayName }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">{{ t('animationPlayer.frameCount') }}:</span>
              <span class="info-value">{{ animationInfo.frame_count }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">{{ t('animationPlayer.size') }}:</span>
              <span class="info-value">{{ animationInfo.width }} × {{ animationInfo.height }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">{{ t('animationPlayer.version') }}:</span>
              <span class="info-value">{{ currentAlbumVersion }}</span>
            </div>
          </div>
          <div v-else class="frame-info-empty">
            <el-empty :description="t('animationPlayer.showFrameInfoAfterSelect')" :image-size="40" />
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.animation-player {
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 0;
  box-sizing: border-box;

  .page-header {
    flex-shrink: 0;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 12px;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }
  }

  .main-row {
    flex: 1;
    min-height: 0;
    margin: 0;

    .el-col {
      height: 100%;

      .el-card {
        height: 100%;
        display: flex;
        flex-direction: column;

        :deep(.el-card__body) {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
        }
      }
    }
  }

  .left-col, .center-col, .right-col {
    display: flex;
    flex-direction: column;
    height: 100%;
    align-items: stretch;
  }

  .list-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;
    flex: 1;
    min-height: 0;

    :deep(.el-card__header) {
      padding: 10px 12px;
      border-bottom: 1px solid var(--border-color);
      flex-shrink: 0;
    }

    :deep(.el-card__body) {
      padding: 0;
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      font-weight: 500;
    }

    .search-box {
      padding: 8px 12px;
      border-bottom: 1px solid var(--border-color);
      flex-shrink: 0;
    }

    .npk-list, .album-list {
      padding: 4px 0;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      margin: 4px 8px;
      position: relative;
    }

    .list-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 14px;
      cursor: pointer;
      transition: background 0.2s ease;
      border-left: 3px solid transparent;
      border-radius: 10px;
      margin: 2px 0;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      position: relative;

      &:hover {
        background: var(--bg-tertiary);
      }

      &.active {
        background: rgba(251, 113, 133, 0.12);
        border-left-color: var(--accent-color);

        .item-name {
          color: var(--accent-dark);
          font-weight: 600;
        }
      }

      .item-name {
        font-size: 12px;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex: 1;
      }

      .item-meta {
        font-size: 11px;
        color: var(--text-muted);
        margin-left: 8px;
        flex-shrink: 0;
      }
    }

    .npk-card {
      flex: 1;
      margin-bottom: 12px;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }

    .album-card {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }

    .npk-scrollbar, .album-scrollbar {
      flex: 1;
      min-height: 0;
    }
  }

  .empty-tip {
    text-align: center;
    color: var(--text-muted);
    font-size: 12px;
    padding: 20px 0;
  }

  .player-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    height: 100%;
    display: flex;
    flex-direction: column;

    :deep(.el-card__body) {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .zoom-toolbar {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
      padding: 8px 12px;
      background: var(--bg-tertiary);
      border-radius: 8px;
      flex-shrink: 0;
    }

    .preview-area {
      flex: 1;
      min-height: 0;
      overflow: auto;
      border-radius: 8px;
      margin-bottom: 12px;
      position: relative;
      background:
        linear-gradient(45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #fef0f0 75%),
        linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
        #fdf7f7;
      background-size: 20px 20px;
      background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
      border: 1px solid var(--border-color);

      &.bg-auto {
        background:
          linear-gradient(45deg, #fef0f0 25%, transparent 25%),
          linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
          linear-gradient(45deg, transparent 75%, #fef0f0 75%),
          linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
          #fdf7f7;
        background-size: 20px 20px;
        background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
      }

      &.bg-light {
        background:
          linear-gradient(45deg, #fef0f0 25%, transparent 25%),
          linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
          linear-gradient(45deg, transparent 75%, #fef0f0 75%),
          linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
          #ffffff;
        background-size: 16px 16px;
        background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
      }

      &.bg-dark {
        background:
          linear-gradient(45deg, #2d1f1f 25%, transparent 25%),
          linear-gradient(-45deg, #2d1f1f 25%, transparent 25%),
          linear-gradient(45deg, transparent 75%, #2d1f1f 75%),
          linear-gradient(-45deg, transparent 75%, #2d1f1f 75%),
          #151010;
        background-size: 16px 16px;
        background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
      }

      .preview-canvas {
        flex-shrink: 0;
      }

      .preview-canvas canvas {
        display: block;
      }

      .placeholder {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 16px;
        color: var(--text-muted);
      }
    }

    .controls {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      background: var(--bg-tertiary);
      border-radius: 8px;
      flex-shrink: 0;

      :deep(.el-button) {
        min-width: auto;
      }

      .frame-info {
        color: var(--text-primary);
        font-size: 14px;
      }

      .delay-info {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-secondary);
        font-size: 14px;
      }
    }
  }

  .frames-card, .frame-info-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;

    :deep(.el-card__header) {
      padding: 10px 12px;
      border-bottom: 1px solid var(--border-color);
      flex-shrink: 0;
    }

    :deep(.el-card__body) {
      padding: 0;
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
    }

    .frames-header {
      display: flex;
      justify-content: space-between;
      align-items: center;

      .frames-actions {
        display: flex;
        gap: 8px;
      }
    }

    .frame-list {
      display: flex;
      flex-direction: column;
      gap: 3px;
      padding: 8px 4px;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      margin: 4px 8px;
      position: relative;
    }

    .frame-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      cursor: pointer;
      border: 2px solid transparent;
      transition: background 0.2s ease;
      position: relative;

      &:hover {
        background: var(--bg-secondary);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &.active {
        border-color: rgba(251, 113, 133, 0.5);
        background: rgba(251, 113, 133, 0.12);

        .frame-number {
          color: var(--accent-dark);
          font-weight: 600;
        }
      }

      .frame-checkbox-input {
        flex-shrink: 0;
        width: 14px;
        height: 14px;
        cursor: pointer;
        accent-color: var(--accent-color);
      }

      .frame-number {
        color: var(--accent-color);
        font-size: 12px;
        font-weight: 500;
        font-family: monospace;
        min-width: 32px;
      }
    }
  }

  .frames-card {
    flex: 1;
    min-height: 0;
    margin-bottom: 12px;

    :deep(.el-card__body) {
      padding: 0;
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
    }
  }

  .frames-content {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .frames-empty {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 200px;
  }

  .frames-scrollbar {
    flex: 1;
    min-height: 0;
  }

  .frame-info-card {
    flex-shrink: 0;
    max-height: 30%;

    :deep(.el-card__body) {
      padding: 12px;
      max-height: calc(100% - 48px);
      overflow-y: auto;
    }

    .frame-info-empty {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 80px;
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      font-weight: 500;
    }

    .frame-info-content {
      .info-row {
        display: block;
        padding: 6px 0;
        font-size: 12px;
        word-break: break-all;
        white-space: normal;

        .info-label {
          color: var(--text-muted);
          display: inline-block;
          min-width: 40px;
          flex-shrink: 0;
        }

        .info-value {
          color: var(--text-primary);
          text-align: right;
          word-break: break-all;
          max-width: 220px;

          &.path {
            font-family: monospace;
            font-size: 11px;
          }
        }
      }
    }
  }
}


</style>
