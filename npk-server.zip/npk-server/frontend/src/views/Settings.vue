<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { settingsApi } from '@/api'
import { ElMessage } from 'element-plus'
import { FolderAdd, Delete, Refresh, Upload, Delete as DeleteIcon, Check, Loading } from '@element-plus/icons-vue'
import { useSystemWebSocket } from '@/composables/useWebSocketPool'
import { useUiStore } from '@/stores/ui'
import { setLanguage, getLanguage, fetchAvailableLanguages } from '@/language'

const { t } = useI18n()
const uiStore = useUiStore()
const currentLanguage = ref(getLanguage())
const availableLanguages = ref<string[]>(['zh-CN', 'en-US'])

async function loadAvailableLanguages() {
  availableLanguages.value = await fetchAvailableLanguages()
}

async function onLanguageChange(lang: string) {
  await setLanguage(lang)
  currentLanguage.value = lang
}

const settings = ref({
  server_port: 8556,
  data_dir: '',
  cache_dir: '',
  npk_dirs: [] as string[],
  video_dirs: [] as string[],
  music_dirs: [] as string[],
  soundpack_dirs: [] as string[],
  audio_xml_path: '',
  auto_scan: true,
  thumbnail_size: 128,
  cache_max_size: 500,
  enable_log_ws: true,
  ws_stats_interval: 3
})

// 单一路径（从数组中取第一个，后端存数组前端取 index 0）
const videoDir = ref('')
const musicDir = ref('')
const soundpackDir = ref('')
const audioXmlPath = ref('')

// 本地临时状态
const tempIntroText = ref(uiStore.splashIntroText)
const tempAvatarImage = ref(uiStore.splashAvatarImage)
const tempAutoSplashTimeout = ref(uiStore.autoSplashTimeout)

// 监听变化并保存
watch(() => uiStore.enableSplashScreen, () => {
  uiStore.saveToStorage()
})
watch(tempIntroText, (val) => {
  uiStore.splashIntroText = val
  uiStore.saveToStorage()
})
watch(() => uiStore.splashIntroText, (val) => {
  if (val !== tempIntroText.value) {
    tempIntroText.value = val
  }
})
watch(() => uiStore.splashAvatarImage, (val) => {
  tempAvatarImage.value = val
})
watch(tempAvatarImage, (val) => {
  uiStore.splashAvatarImage = val
  uiStore.saveToStorage()
})
watch(tempAutoSplashTimeout, (val) => {
  uiStore.autoSplashTimeout = val
  uiStore.saveToStorage()
})

// WebSocket 实时缓存统计
const { stats: wsStats } = useSystemWebSocket()

// 缓存统计（从 WebSocket 实时更新）
const cacheStats = computed(() => ({
  used: Math.round((wsStats.value.cache_used_mb || 0) * 10) / 10,
  total: wsStats.value.cache_max_size ? Math.round(wsStats.value.cache_max_size / 1024 / 1024 * 10) / 10 : 500,
  percent: Math.round(wsStats.value.cache_percent || 0),
  hitRate: Math.round(wsStats.value.cache_hit_rate || 0),
  count: wsStats.value.cache_count || 0,
  hits: wsStats.value.cache_hits || 0,
  misses: wsStats.value.cache_misses || 0
}))

const loading = ref(false)
const saving = ref(false)
const newNpkDir = ref('')

const derivedBase = computed(() => {
  const dir = settings.value.npk_dirs?.[0] || ''
  if (!dir) return ''
  return dir.replace(/[/\\][^/\\]*$/, '').replace(/[/\\]ImagePacks2$/i, '') || dir.replace(/[/\\]ImagePacks2$/i, '')
})
const avatarInputRef = ref<HTMLInputElement | null>(null)

onMounted(async () => {
  await loadSettings()
  await loadAvailableLanguages()
})

function triggerUpload() {
  avatarInputRef.value?.click()
}

function handleAvatarFileChange(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (file) {
    handleAvatarUpload(file)
    target.value = ''
  }
}

async function loadSettings() {
  loading.value = true
  try {
    const res = await settingsApi.get() as any
    const data = res.data || {}
    if (data) {
      // 完整替换确保响应式更新
      settings.value = { ...settings.value, ...data }
      // 同步数组到单值 ref
      videoDir.value = Array.isArray(data.video_dirs) ? (data.video_dirs[0] || '') : (data.video_dirs || '')
      musicDir.value = Array.isArray(data.music_dirs) ? (data.music_dirs[0] || '') : (data.music_dirs || '')
      soundpackDir.value = Array.isArray(data.soundpack_dirs) ? (data.soundpack_dirs[0] || '') : (data.soundpack_dirs || '')
      audioXmlPath.value = data.audio_xml_path || ''
    }
  } catch (e: any) {
    ElMessage.error(t('settings.loadFailed') + ': ' + (e.message || ''))
  } finally {
    loading.value = false
  }
}

async function saveSettings() {
  saving.value = true
  try {
    // 只保存基本设置，不覆盖已单独保存的路径字段
    await settingsApi.update({
      server_port: settings.value.server_port,
      data_dir: settings.value.data_dir,
      cache_dir: settings.value.cache_dir,
      auto_scan: settings.value.auto_scan,
      thumbnail_size: settings.value.thumbnail_size,
      cache_max_size: settings.value.cache_max_size,
      ws_stats_interval: settings.value.ws_stats_interval,
      enable_log_ws: settings.value.enable_log_ws,
    })
    ElMessage.success(t('settings.settingsSaved'))
  } catch (e: any) {
    ElMessage.error(e.message || t('settings.saveFailed'))
  } finally {
    saving.value = false
  }
}

async function addNpkDir() {
  if (!newNpkDir.value) {
    ElMessage.warning(t('settings.npkDirs.enterPath'))
    return
  }

  try {
    await settingsApi.addNpkDir(newNpkDir.value)
    newNpkDir.value = ''
    ElMessage.success(t('settings.npkDirs.dirAdded'))
    await loadSettings()
  } catch (e: any) {
    ElMessage.error(e.response?.data?.message || e.message || t('settings.npkDirs.addFailed'))
  }
}

async function removeNpkDir(dir: string) {
  try {
    await settingsApi.removeNpkDir(dir)
    settings.value = { ...settings.value, npk_dirs: settings.value.npk_dirs.filter(d => d !== dir) }
    ElMessage.success(t('settings.npkDirs.dirRemoved'))
  } catch (e: any) {
    ElMessage.error(e.response?.data?.message || e.message || t('settings.npkDirs.removeFailed'))
  }
}

async function saveDerivedPath(key: string, value: string) {
  if (!value) return
  try {
    await settingsApi.update({ [key]: [value] })
    settings.value = { ...settings.value, [key]: [value] }
    ElMessage.success(t('settings.derivedPaths.pathSaved'))
  } catch (e: any) {
    ElMessage.error(e.message || t('settings.saveFailed'))
  }
}

async function saveAudioXmlPath() {
  if (!audioXmlPath.value) return
  try {
    await settingsApi.update({ audio_xml_path: audioXmlPath.value })
    settings.value = { ...settings.value, audio_xml_path: audioXmlPath.value }
    ElMessage.success(t('settings.derivedPaths.audioXmlSaved'))
  } catch (e: any) {
    ElMessage.error(e.message || t('settings.saveFailed'))
  }
}

// 处理头像上传
async function handleAvatarUpload(file: File) {
  const formData = new FormData()
  formData.append('file', file)
  try {
    const res = await fetch('/api/avatars/upload', { method: 'POST', body: formData })
    const data = await res.json()
    if (data.code === 0 && data.data?.url) {
      tempAvatarImage.value = data.data.url
      ElMessage.success(t('settings.splash.avatarUploaded'))
      await uiStore.loadAvatarsFromAPI()
    } else {
      ElMessage.error(t('settings.splash.uploadFailed'))
    }
  } catch (e: any) {
    ElMessage.error(t('settings.splash.uploadFailed') + ': ' + e.message)
  }
  return false
}

// 清除头像
function clearAvatar() {
  tempAvatarImage.value = '/avatars/avatar_01.JPG'
  ElMessage.success(t('settings.splash.avatarReset'))
}
</script>

<template>
  <div class="settings">
    <div class="page-header">
      <h2 class="page-title">{{ t('settings.title') }}</h2>
      <el-button type="primary" :loading="saving" @click="saveSettings">{{ t('settings.saveSettings') }}</el-button>
    </div>

    <el-row :gutter="20">
      <el-col :span="24" style="margin-bottom: 20px;">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>{{ t('settings.language.title') }}</span>
            </div>
          </template>
          <el-form label-width="120px">
            <el-form-item :label="t('settings.language.label')">
              <el-select v-model="currentLanguage" @change="onLanguageChange" style="width: 200px">
                <el-option
                  v-for="lang in availableLanguages"
                  :key="lang"
                  :value="lang"
                  :label="lang"
                />
              </el-select>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>

      <el-col :span="12">
        <el-card class="splash-settings-card">
          <template #header>
            <span>{{ t('settings.splash.title') }}</span>
          </template>
          <el-form label-width="120px">
            <el-form-item :label="t('settings.splash.enable')">
              <el-switch v-model="uiStore.enableSplashScreen" />
            </el-form-item>
            <el-form-item :label="t('settings.splash.autoSplash')">
              <div class="auto-splash-control">
                <el-select v-model="tempAutoSplashTimeout" style="width: 120px">
                  <el-option :value="0" :label="t('settings.splash.disabled')" />
                  <el-option :value="5" :label="t('settings.splash.5min')" />
                  <el-option :value="10" :label="t('settings.splash.10min')" />
                  <el-option :value="15" :label="t('settings.splash.15min')" />
                  <el-option :value="30" :label="t('settings.splash.30min')" />
                </el-select>
                <span style="margin-left: 8px; color: var(--text-muted); font-size: 12px">
                  {{ t('settings.splash.autoHint') }}
                </span>
              </div>
            </el-form-item>
            <el-form-item :label="t('settings.splash.builtInAvatars')">
              <div v-if="uiStore.isLoadingAvatars" class="loading-text">
                <el-icon class="is-loading"><Loading /></el-icon>
                {{ t('common.loading') }}
              </div>
              <div v-else-if="uiStore.builtInAvatars.length === 0" class="empty-text">
                {{ t('settings.splash.noAvatars') }}
              </div>
              <div v-else class="built-in-avatars">
                <div 
                  v-for="avatar in uiStore.builtInAvatars" 
                  :key="avatar"
                  class="avatar-option"
                  :class="{ selected: tempAvatarImage === avatar }"
                  @click="uiStore.selectAvatar(avatar)"
                >
                  <img :src="avatar" class="avatar-thumb" />
                  <el-icon v-if="tempAvatarImage === avatar" class="check-icon"><Check /></el-icon>
                </div>
              </div>
            </el-form-item>
            <el-form-item :label="t('settings.splash.customAvatar')">
              <div class="avatar-uploader">
                <div class="avatar-preview">
                  <img :src="tempAvatarImage" class="preview-image" />
                  <el-button 
                    type="primary" 
                    :icon="Upload" 
                    class="change-avatar"
                    circle
                    size="small"
                    @click="triggerUpload"
                  />
                  <el-button 
                    type="danger" 
                    :icon="DeleteIcon" 
                    class="remove-avatar"
                    circle
                    size="small"
                    @click="clearAvatar"
                  />
                </div>
                <input 
                  type="file" 
                  ref="avatarInputRef" 
                  style="display: none" 
                  accept="image/*" 
                  @change="handleAvatarFileChange"
                />
              </div>
            </el-form-item>
            <el-form-item :label="t('settings.splash.welcomeText')">
              <el-input 
                v-model="tempIntroText" 
                type="textarea" 
                :rows="4" 
                :placeholder="t('settings.splash.welcomePlaceholder')"
              />
            </el-form-item>
          </el-form>
        </el-card>

        <!-- 基本设置 -->
        <el-card v-loading="loading" style="margin-top: 20px;">
          <template #header>
            <span>{{ t('settings.basic.title') }}</span>
          </template>
          <el-form label-width="120px">
            <el-form-item :label="t('settings.basic.serverPort')">
              <el-input-number v-model="settings.server_port" :min="1" :max="65535" />
            </el-form-item>
            <el-form-item :label="t('settings.basic.dataDir')">
              <el-input v-model="settings.data_dir" placeholder="./data" />
            </el-form-item>
            <el-form-item :label="t('settings.basic.cacheDir')">
              <el-input v-model="settings.cache_dir" placeholder="./cache" />
            </el-form-item>
            <el-form-item :label="t('settings.basic.autoScan')">
              <el-switch v-model="settings.auto_scan" />
            </el-form-item>
          </el-form>
        </el-card>

      </el-col>

      <el-col :span="12">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>{{ t('settings.npkDirs.title') }}</span>
            </div>
          </template>
          <div class="npk-dirs">
            <div v-for="dir in settings.npk_dirs" :key="dir" class="dir-item">
              <span class="dir-path">{{ dir }}</span>
              <el-button type="danger" :icon="Delete" link @click="removeNpkDir(dir)" />
            </div>
            <div v-if="settings.npk_dirs.length === 0" class="empty-tip">
              {{ t('settings.npkDirs.empty') }}
            </div>
            <el-input
              v-model="newNpkDir"
              :placeholder="t('settings.npkDirs.inputPlaceholder')"
              @keyup.enter="addNpkDir"
            >
              <template #append>
                <el-button :icon="FolderAdd" @click="addNpkDir">{{ t('settings.npkDirs.add') }}</el-button>
              </template>
            </el-input>
           </div>
        </el-card>

        <el-card style="margin-top: 20px">
          <template #header>
            <div class="card-header">
              <span>{{ t('settings.derivedPaths.title') }}</span>
              <el-tag size="small" type="info" v-if="derivedBase">{{ t('settings.derivedPaths.rootDir') }}: {{ derivedBase }}</el-tag>
            </div>
          </template>
          <div v-if="!derivedBase" class="empty-tip" style="padding:12px">
            {{ t('settings.derivedPaths.noNpkDir') }}
          </div>
          <el-form v-else label-width="140px" size="small">
            <el-form-item label="Video">
              <el-input v-model="videoDir" :placeholder="derivedBase + '/Video'" @blur="saveDerivedPath('video_dirs', videoDir)" />
            </el-form-item>
            <el-form-item label="Music">
              <el-input v-model="musicDir" :placeholder="derivedBase + '/Music'" @blur="saveDerivedPath('music_dirs', musicDir)" />
            </el-form-item>
            <el-form-item label="SoundPacks">
              <el-input v-model="soundpackDir" :placeholder="derivedBase + '/SoundPacks'" @blur="saveDerivedPath('soundpack_dirs', soundpackDir)" />
            </el-form-item>
            <el-form-item label="Audio.xml">
              <el-input v-model="audioXmlPath" :placeholder="derivedBase + '/Audio.xml'" @blur="saveAudioXmlPath" />
            </el-form-item>
          </el-form>
        </el-card>

        <el-card style="margin-top: 20px">
          <template #header>
            <div class="card-header">
              <span>{{ t('settings.cache.title') }}</span>
              <el-button :icon="Refresh" link @click="loadSettings">{{ t('common.refresh') }}</el-button>
            </div>
          </template>

          <div class="cache-stats">
            <div class="stat-row">
              <span class="stat-label">{{ t('settings.cache.usage') }}:</span>
              <el-progress :percentage="cacheStats.percent" :stroke-width="8" color="var(--accent-color)" style="flex: 1" />
              <span class="stat-value">{{ cacheStats.used }}MB / {{ cacheStats.total }}MB ({{ cacheStats.count }}{{ t('common.items') }})</span>
            </div>
            <div class="stat-row">
              <span class="stat-label">{{ t('settings.cache.hitRate') }}:</span>
              <el-progress :percentage="cacheStats.hitRate" :stroke-width="8" color="var(--accent-color)" style="flex: 1" />
              <span class="stat-value">{{ cacheStats.hitRate }}% ({{ cacheStats.hits }}/{{ cacheStats.hits + cacheStats.misses }})</span>
            </div>
          </div>

          <el-divider />

          <el-form label-width="120px">
            <el-form-item :label="t('settings.cache.thumbnailSize')">
              <el-input-number v-model="settings.thumbnail_size" :min="32" :max="512" />
            </el-form-item>
            <el-form-item :label="t('settings.cache.maxSize')">
              <el-input-number v-model="settings.cache_max_size" :min="100" :max="5000" />
              <span style="margin-left: 8px">MB</span>
            </el-form-item>
          </el-form>
        </el-card>

        <el-card style="margin-top: 20px">
          <template #header>
            <div class="card-header">
              <span>{{ t('settings.websocket.title') }}</span>
            </div>
          </template>
          <el-form label-width="140px">
            <el-form-item :label="t('settings.websocket.pushFrequency')">
              <el-input-number v-model="settings.ws_stats_interval" :min="1" :max="30" />
              <span style="margin-left: 8px">{{ t('common.seconds') }}</span>
            </el-form-item>
            <el-form-item :label="t('settings.websocket.enableLogPush')">
              <el-switch v-model="settings.enable_log_ws" />
              <span style="margin-left: 8px; color: var(--text-muted); font-size: 12px">
                {{ t('settings.websocket.logPushHint') }}
              </span>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.settings {
  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }
  }

  .el-card {
    background: var(--bg-primary);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    box-shadow: 0 8px 32px rgba(251, 113, 133, 0.1),
                0 2px 8px rgba(251, 113, 133, 0.05);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);

    &:hover {
      transform: translateY(-4px) scale(1.01);
      border-color: rgba(251, 113, 133, 0.4);
      box-shadow: 0 12px 40px rgba(251, 113, 133, 0.2),
                  0 6px 20px rgba(251, 113, 133, 0.12);
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }

  // 屏保设置
  .splash-settings-card {
    .auto-splash-control {
      display: flex;
      align-items: center;
    }

    .built-in-avatars {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;

      .avatar-option {
        position: relative;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        overflow: hidden;
        cursor: pointer;
        border: 2px solid var(--border-color);
        transition: all 0.2s ease;

        .avatar-thumb {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .check-icon {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          font-size: 24px;
          color: white;
          background: rgba(0, 0, 0, 0.4);
          border-radius: 50%;
          padding: 4px;
        }

        &:hover {
          border-color: var(--accent-color);
          transform: scale(1.05);
        }

        &.selected {
          border-color: var(--accent-color);
          box-shadow: 0 0 0 2px rgba(251, 113, 133, 0.3);
        }
      }
    }

    .loading-text,
    .empty-text {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--text-muted);
      font-size: 13px;
      padding: 8px 0;
    }

    .avatar-uploader {
      display: flex;
      align-items: center;

      .avatar-preview {
        position: relative;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        overflow: hidden;
        border: 2px solid var(--border-color);

        .preview-image {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .change-avatar,
        .remove-avatar {
          position: absolute;
          opacity: 0;
          transition: opacity 0.2s;
        }

        .change-avatar {
          bottom: -8px;
          right: -8px;
        }

        .remove-avatar {
          top: -8px;
          right: -8px;
        }

        &:hover .change-avatar,
        &:hover .remove-avatar {
          opacity: 1;
        }
      }
    }
  }

  .npk-dirs {
    .dir-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 12px;
      background: var(--bg-tertiary);
      border-radius: 6px;
      margin-bottom: 8px;
      color: var(--text-primary);

      .dir-path {
        flex: 1;
        word-break: break-all;
      }
    }

    .empty-tip {
      color: var(--text-muted);
      text-align: center;
      padding: 20px;
      margin-bottom: 12px;
    }
  }

  // 缓存统计（与仪表盘一致）
  .cache-stats {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 16px;

    .stat-row {
      display: flex;
      align-items: center;
      gap: 12px;

      .stat-label {
        font-size: 13px;
        color: var(--text-secondary);
        min-width: 80px;
      }

      .stat-value {
        font-size: 12px;
        color: var(--text-muted);
        min-width: 100px;
        text-align: right;
      }
    }
  }

  .documentation-card {
    .documentation-content {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }
  }
}

html.dark .settings {
  .el-card {
    background: linear-gradient(
      135deg,
      rgba(30, 18, 18, 0.95) 0%,
      rgba(40, 24, 24, 0.95) 50%,
      rgba(30, 18, 18, 0.95) 100%
    );
    border-color: rgba(255, 255, 255, 0.08);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4),
                0 2px 8px rgba(0, 0, 0, 0.2);

    &::before {
      background: linear-gradient(
        120deg,
        transparent 0%,
        rgba(251, 113, 133, 0.15) 25%,
        rgba(251, 113, 133, 0.25) 50%,
        rgba(251, 113, 133, 0.15) 75%,
        transparent 100%
      );
    }

    &:hover {
      background: linear-gradient(
        135deg,
        rgba(45, 28, 28, 0.98) 0%,
        rgba(55, 35, 35, 0.98) 50%,
        rgba(45, 28, 28, 0.98) 100%
      );
      border-color: rgba(251, 113, 133, 0.25);
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5),
                  0 6px 20px rgba(0, 0, 0, 0.3);
    }
  }
}

.form-help { font-size: 12px; color: var(--text-muted); margin-top: 6px; }
</style>
