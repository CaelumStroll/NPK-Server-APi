<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { dbApi, videoDbApi, musicDbApi, soundpackDbApi } from '@/api'
import {
  DataAnalysis, Delete, Download, Refresh, Setting,
  InfoFilled, RefreshRight, VideoCamera, Headset
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const { t } = useI18n()

// 数据库统计
const dbStats = ref<any>(null)
const tableStats = ref<any[]>([])
const loading = ref(false)
const operationLoading = ref<string | null>(null)

// 视频数据库统计
const videoDbStats = ref<any>(null)

// 音乐数据库统计
const musicDbStats = ref<any>(null)

// 音效数据库统计
const soundpackDbStats = ref<any>(null)

// 内存分析
const memoryAnalysis = ref<any>(null)

// 各页面内存消耗
const pageMemoryItems = ref<any[]>([])

// 后端问题列表
const backendIssues = ref<any[]>([])

onMounted(async () => {
  await Promise.all([fetchDbStats(), fetchTableStats(), fetchVideoDbStats(), fetchMusicDbStats(), fetchSoundPackDbStats()])
})

// === 数据获取 ===
async function fetchDbStats() {
  loading.value = true
  try {
    const res = await dbApi.getStats() as any
    dbStats.value = res.data
    analyzeMemory()
    analyzePageMemory()
    analyzeBackendIssues()
  } catch (e: any) {
    ElMessage.error(t('common.requestFailed') + ': ' + (e.message))
  } finally {
    loading.value = false
  }
}

async function fetchTableStats() {
  try {
    const res = await dbApi.getTables() as any
    tableStats.value = res.data || []
    calculateTablePercentages()
  } catch (e: any) {
    ElMessage.error(t('common.requestFailed'))
  }
}

function calculateTablePercentages() {
  if (!tableStats.value || tableStats.value.length === 0) return
  const totalRows = tableStats.value.reduce((sum: number, t: any) => sum + (t.rows || 0), 0)
  tableStats.value.forEach((t: any) => {
    t.percentage = totalRows > 0 ? Math.round((t.rows || 0) / totalRows * 100) : 0
  })
}

// === 视频数据库 ===
async function fetchVideoDbStats() {
  try {
    const res = await videoDbApi.getStats() as any
    videoDbStats.value = res.data
  } catch (e: any) {
    console.error('Failed to fetch video DB stats:', e)
  }
}

async function cleanupVideoDB() {
  operationLoading.value = 'videoCleanup'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCleanVideo'),
      t('databaseView.cleanInvalid'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await videoDbApi.cleanup() as any
    ElMessage.success(t('databaseView.cleanComplete'))
    await fetchVideoDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

async function compactVideoDB() {
  operationLoading.value = 'videoCompact'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCompactGeneric'),
      t('databaseView.compactDb'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await videoDbApi.compact() as any
    ElMessage.success(t('databaseView.compactComplete'))
    await fetchVideoDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

async function rebuildVideoDB() {
  operationLoading.value = 'videoRebuild'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmRebuildVideo'),
      t('databaseView.rebuildDb'),
      { confirmButtonText: t('databaseView.rebuild'), cancelButtonText: t('common.cancel'), type: 'error' }
    )
    await videoDbApi.rebuild() as any
    ElMessage.success(t('databaseView.rebuildComplete'))
    await fetchVideoDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

// === 音乐数据库 ===
async function fetchMusicDbStats() {
  try {
    const res = await musicDbApi.getStats() as any
    musicDbStats.value = res.data
  } catch (e: any) {
    console.error('Failed to fetch music DB stats:', e)
  }
}

async function cleanupMusicDB() {
  operationLoading.value = 'musicCleanup'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCleanMusic'),
      t('databaseView.cleanInvalid'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await musicDbApi.cleanup() as any
    ElMessage.success(t('databaseView.cleanComplete'))
    await fetchMusicDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

async function compactMusicDB() {
  operationLoading.value = 'musicCompact'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCompactGeneric'),
      t('databaseView.compactDb'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await musicDbApi.compact() as any
    ElMessage.success(t('databaseView.compactComplete'))
    await fetchMusicDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

async function rebuildMusicDB() {
  operationLoading.value = 'musicRebuild'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmRebuildMusic'),
      t('databaseView.rebuildDb'),
      { confirmButtonText: t('databaseView.rebuild'), cancelButtonText: t('common.cancel'), type: 'error' }
    )
    await musicDbApi.rebuild() as any
    ElMessage.success(t('databaseView.rebuildComplete'))
    await fetchMusicDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

// === 音效数据库 ===
async function fetchSoundPackDbStats() {
  try {
    const res = await soundpackDbApi.getStats() as any
    soundpackDbStats.value = res.data
  } catch (e: any) {
    console.error('Failed to fetch sound DB stats:', e)
  }
}

async function cleanupSoundPackDB() {
  operationLoading.value = 'soundpackCleanup'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCleanSound'),
      t('databaseView.cleanInvalid'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await soundpackDbApi.cleanup() as any
    ElMessage.success(t('databaseView.cleanComplete'))
    await fetchSoundPackDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

async function compactSoundPackDB() {
  operationLoading.value = 'soundpackCompact'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCompactGeneric'),
      t('databaseView.compactDb'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    await soundpackDbApi.compact() as any
    ElMessage.success(t('databaseView.compactComplete'))
    await fetchSoundPackDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

async function rebuildSoundPackDB() {
  operationLoading.value = 'soundpackRebuild'
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmRebuildSound'),
      t('databaseView.rebuildDb'),
      { confirmButtonText: t('databaseView.rebuild'), cancelButtonText: t('common.cancel'), type: 'error' }
    )
    await soundpackDbApi.rebuild() as any
    ElMessage.success(t('databaseView.rebuildComplete'))
    await fetchSoundPackDbStats()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    }
  } finally {
    operationLoading.value = null
  }
}

// === 内存分析 ===
function analyzeMemory() {
	if (!dbStats.value) return

	const albumCount = dbStats.value.album_count || 0
	const spriteCount = dbStats.value.sprite_count || 0
	const npkCount = dbStats.value.npk_count || 0

	// 从 tableStats 获取 sprites 表的实际行数
	const spritesTableRows = tableStats.value.find((t: any) => t.table === 'sprites')?.rows || 0

	// sprites 表存储大小估算
	// sprites 表有 14 个字段，每条记录约 100 字节
	const spriteMemoryMB = spritesTableRows > 0
		? (spritesTableRows * 100) / 1024 / 1024
		: 0

	// 估算 albums 表记录存储大小
	// albums 表有 12 个字段，每条记录约 200 字节
	const albumMemoryMB = (albumCount * 200) / 1024 / 1024

	// 估算 npk_files 表记录存储大小
	const npkMemoryMB = (npkCount * 150) / 1024 / 1024
	const dbMemoryMB = dbStats.value.db_size ? dbStats.value.db_size / 1024 / 1024 : 0

	// 后端内存中的 NPK 文件信息（启动时预加载）
	// 每个 NPK FileInfo 约 300 字节（含 Album 列表指针）
	const backendNpkMemoryMB = (npkCount * 300) / 1024 / 1024

	// 后端缓存估算
	const imageCacheMB = 200 // ImageCache 可配置上限
	const thumbCacheMB = 100 // ThumbnailCache 上限

	memoryAnalysis.value = {
		dbSizeMB: dbMemoryMB.toFixed(1),
		dbTablesMemoryMB: (albumMemoryMB + spriteMemoryMB + npkMemoryMB).toFixed(1),
		albumMemoryMB: albumMemoryMB.toFixed(1),
		spriteMemoryMB: spriteMemoryMB > 0 ? spriteMemoryMB.toFixed(1) : '0',
		npkMemoryMB: npkMemoryMB.toFixed(1),
		backendNpkMemoryMB: backendNpkMemoryMB.toFixed(1),
		imageCacheMB,
		thumbCacheMB,
		backendResidentMB: (backendNpkMemoryMB + imageCacheMB + thumbCacheMB + 2.5).toFixed(1),
		totalEstimateMB: (dbMemoryMB + albumMemoryMB + spriteMemoryMB + npkMemoryMB + backendNpkMemoryMB + imageCacheMB + thumbCacheMB).toFixed(1),
		warnings: generateWarnings(albumCount, spriteCount, npkCount, dbMemoryMB)
	}
}

function generateWarnings(albumCount: number, spriteCount: number, npkCount: number, dbSizeMB: number): string[] {
  const warnings: string[] = []

  if (npkCount > 5000) {
    warnings.push(t('databaseView.warningNpkCount', { count: npkCount.toLocaleString(), memory: (npkCount * 300 / 1024 / 1024).toFixed(1) }))
  }

  if (albumCount > 100000) {
    warnings.push(t('databaseView.warningAlbumCount', { count: (albumCount / 10000).toFixed(1) }))
  }

  if (spriteCount > 500000) {
    warnings.push(t('databaseView.warningSpriteCount', { count: (spriteCount / 10000).toFixed(1) }))
  }

  if (dbSizeMB > 500) {
    warnings.push(t('databaseView.warningDbSize', { size: dbSizeMB.toFixed(0) }))
  }

  if (npkCount > 3000) {
    warnings.push(t('databaseView.warningNpkDom', { count: npkCount.toLocaleString() }))
  }

  if (warnings.length === 0) {
    warnings.push(t('databaseView.warningNoIssue'))
  }

  return warnings
}

// === 各页面内存消耗分析 ===
function analyzePageMemory() {
  if (!dbStats.value) return

  const npkCount = dbStats.value.npk_count || 0

  pageMemoryItems.value = [
    {
      page: t('databaseView.pageNpkManager'),
      icon: 'folder',
      memory: npkCount > 0 ? `${Math.max(5, (npkCount * 0.005)).toFixed(0)}~${Math.max(10, (npkCount * 0.005)).toFixed(0)} MB` : '< 1 MB',
      detail: npkCount > 0
        ? t('databaseView.pageNpkMemDetail', { count: npkCount.toLocaleString() })
        : t('databaseView.pageNpkMemSmall'),
      status: npkCount > 3000 ? 'danger' : npkCount > 1000 ? 'warning' : 'good',
      suggestion: npkCount > 3000 ? t('databaseView.needVirtualScroll') : ''
    },
    {
      page: t('databaseView.pageImgEditor'),
      icon: 'edit',
      memory: '10~20 MB',
      detail: t('databaseView.pageImgMemDetail'),
      status: 'good',
      suggestion: t('databaseView.goodMemDesign')
    },
    {
      page: t('databaseView.pageResourceBrowser'),
      icon: 'search',
      memory: '< 2 MB',
      detail: t('databaseView.pageResourceMemDetail'),
      status: 'good',
      suggestion: t('databaseView.noOptNeeded')
    },
    {
      page: t('databaseView.pageApiDebug'),
      icon: 'api',
      memory: '< 1 MB',
      detail: t('databaseView.pageApiMemDetail'),
      status: 'good',
      suggestion: t('databaseView.apiWarning')
    },
    {
      page: t('databaseView.pageDbManager'),
      icon: 'database',
      memory: '< 1 MB',
      detail: t('databaseView.pageDbMemDetail'),
      status: 'good',
      suggestion: t('databaseView.exportTempMem')
    }
  ]
}

// === 后端问题分析 ===
function analyzeBackendIssues() {
  if (!dbStats.value) return

  backendIssues.value = [
    {
      priority: 'P1',
      title: t('databaseView.issueNoSizeLimit'),
      location: 'npk_service.go',
      impact: t('databaseView.issueImpactNoLimit'),
      estimate: t('databaseView.issueEstimateFrames'),
      solution: t('databaseView.issueSolutionLimit'),
      status: 'warning'
    },
    {
      priority: 'P1',
      title: t('databaseView.issueSaveClears'),
      location: 'npk_service.go',
      impact: t('databaseView.issueSaveImpact'),
      estimate: t('databaseView.issueSaveEstimate'),
      solution: t('databaseView.issueSaveSolution'),
      status: 'warning'
    },
    {
      priority: 'P2',
      title: t('databaseView.issueNoCache'),
      location: 'npk_service.go',
      impact: t('databaseView.issueNoCacheImpact'),
      estimate: t('databaseView.issueNoCacheEstimate'),
      solution: t('databaseView.issueNoCacheSolution'),
      status: 'info'
    },
    {
      priority: 'P2',
      title: t('databaseView.issueLikeSearch'),
      location: 'database.go',
      impact: t('databaseView.issueLikeImpact'),
      estimate: t('databaseView.issueLikeEstimate'),
      solution: t('databaseView.issueLikeSolution'),
      status: 'info'
    },
    {
      priority: 'P2',
      title: t('databaseView.issueResolve'),
      location: 'npk_service.go',
      impact: t('databaseView.issueResolveImpact'),
      estimate: t('databaseView.issueResolveEstimate'),
      solution: t('databaseView.issueResolveSolution'),
      status: 'info'
    }
  ]
}

// === 操作 ===
async function cleanupDB() {
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCleanNpk'),
      t('databaseView.cleanInvalid'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    operationLoading.value = 'cleanup'
    try {
      await dbApi.cleanup() as any
      ElMessage.success(t('databaseView.cleanComplete'))
      await Promise.all([fetchDbStats(), fetchTableStats()])
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function compactDB() {
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmCompactNpk'),
      t('databaseView.compactDb'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'warning' }
    )
    operationLoading.value = 'compact'
    try {
      await dbApi.compact() as any
      ElMessage.success(t('databaseView.compactComplete'))
      await fetchDbStats()
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function incrementalDB() {
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmIncremental'),
      t('databaseView.incrementalUpdate'),
      { confirmButtonText: t('databaseView.execute'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = 'incremental'
    try {
      await dbApi.incremental() as any
      ElMessage.success(t('databaseView.incrementalComplete'))
      await Promise.all([fetchDbStats(), fetchTableStats()])
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function rebuildDB() {
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmRebuildNpk'),
      t('databaseView.rebuildDb'),
      { confirmButtonText: t('databaseView.rebuild'), cancelButtonText: t('common.cancel'), type: 'error' }
    )
    operationLoading.value = 'rebuild'
    try {
      await dbApi.rebuild() as any
      ElMessage.success(t('databaseView.rebuildComplete'))
      await Promise.all([fetchDbStats(), fetchTableStats()])
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + (e.message))
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function exportDB() {
  try {
    await ElMessageBox.confirm(
      t('databaseView.confirmExport'),
      t('databaseView.exportDb'),
      { confirmButtonText: t('databaseView.export'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = 'export'
    try {
      const res = await fetch('/api/db/export')
      if (!res.ok) throw new Error(t('databaseView.exportFailed'))
      const blob = await res.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `npk-database-export-${new Date().toISOString().slice(0, 10)}.json`
      a.click()
      window.URL.revokeObjectURL(url)
      ElMessage.success(t('databaseView.exportSuccess'))
    } catch (e: any) {
      ElMessage.error(t('databaseView.exportFailed') + ': ' + (e.message))
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

function formatSize(bytes: number): string {
  if (!bytes || isNaN(bytes)) return '0 B'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB'
  return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB'
}

function formatCount(n: number): string {
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  return n.toLocaleString()
}

async function refreshData() {
  await Promise.all([fetchDbStats(), fetchTableStats()])
}

function getPriorityType(priority: string): 'danger' | 'warning' | 'info' {
  if (priority === 'P0') return 'danger'
  if (priority === 'P1') return 'warning'
  return 'info'
}

const issueStats = computed(() => {
  const p0 = backendIssues.value.filter(i => i.priority === 'P0').length
  const p1 = backendIssues.value.filter(i => i.priority === 'P1').length
  const p2 = backendIssues.value.filter(i => i.priority === 'P2').length
  return { p0, p1, p2 }
})
</script>

<template>
  <div class="database-view">
    <div class="page-header">
      <h2 class="page-title">{{ t('databaseView.title') }}</h2>
      <div class="header-actions">
        <el-tag v-if="issueStats.p0 > 0" type="danger" size="small" effect="dark">
          {{ t('databaseView.criticalIssues', { count: issueStats.p0 }) }}
        </el-tag>
        <el-tag v-if="issueStats.p1 > 0" type="warning" size="small" effect="plain">
          {{ t('databaseView.warningCount', { count: issueStats.p1 }) }}
        </el-tag>
        <el-button :icon="Refresh" size="small" :loading="loading" @click="refreshData">
          {{ t('databaseView.refresh') }}
        </el-button>
      </div>
    </div>

    <!-- 统计概览 -->
    <el-row :gutter="16" class="stats-row">
      <el-col :span="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-value">{{ formatCount(dbStats?.npk_count || 0) }}</div>
              <div class="stat-label">{{ t('databaseView.npkFiles') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-value">{{ formatCount(dbStats?.album_count || 0) }}</div>
              <div class="stat-label">{{ t('databaseView.albums') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-value">{{ formatCount(dbStats?.sprite_count || 0) }}</div>
              <div class="stat-label">{{ t('databaseView.sprites') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-value">{{ formatSize(dbStats?.total_size || 0) }}</div>
              <div class="stat-label">{{ t('databaseView.npkTotalSize') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-value">{{ formatSize(dbStats?.db_size || 0) }}</div>
              <div class="stat-label">{{ t('databaseView.dbSize') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card" shadow="hover">
          <div class="stat-content">
            <div class="stat-info">
              <div class="stat-value">{{ dbStats?.album_count ? (dbStats.sprite_count / dbStats.album_count).toFixed(1) : '0' }}</div>
              <div class="stat-label">{{ t('databaseView.avgFramesPerImg') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 第二行：两列布局 -->
    <el-row :gutter="16" class="content-row">
      <!-- 左侧：各表行数统计 -->
      <el-col :span="12">
        <el-card class="table-card">
          <template #header><span>{{ t('databaseView.tableRowStats') }}</span></template>
          <el-table :data="tableStats" stripe size="small">
            <el-table-column prop="table" :label="t('databaseView.tableName')" min-width="140" />
            <el-table-column prop="rows" :label="t('databaseView.rowCount')" width="120" align="right">
              <template #default="{ row }">
                <span :class="{ 'large-count': row.rows > 100000 }">
                  {{ formatCount(row.rows) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column :label="t('databaseView.proportion')" width="150">
              <template #default="{ row }">
                <el-progress
                  :percentage="row.percentage || 0"
                  :stroke-width="8"
                  :show-text="false"
                />
              </template>
            </el-table-column>
            <el-table-column :label="t('databaseView.description')" min-width="180">
              <template #default="{ row }">
                <span class="table-desc">{{ row.description || '-' }}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!-- 右侧：后端性能问题 -->
      <el-col :span="12">
        <el-card v-if="backendIssues.length > 0" class="issues-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('databaseView.backendIssues') }}</span>
              <div class="header-tags">
                <el-tag v-if="issueStats.p0 > 0" type="danger" size="small" effect="dark">P0: {{ issueStats.p0 }}</el-tag>
                <el-tag v-if="issueStats.p1 > 0" type="warning" size="small">P1: {{ issueStats.p1 }}</el-tag>
                <el-tag v-if="issueStats.p2 > 0" type="info" size="small">P2: {{ issueStats.p2 }}</el-tag>
              </div>
            </div>
          </template>

          <el-scrollbar class="issues-scroll">
            <div class="issues-list">
              <div v-for="issue in backendIssues" :key="issue.title" class="issue-item" :class="issue.status">
                <div class="issue-header">
                  <el-tag :type="getPriorityType(issue.priority)" size="small" effect="dark" class="priority-tag">
                    {{ issue.priority }}
                  </el-tag>
                  <span class="issue-title">{{ issue.title }}</span>
                </div>
                <div class="issue-location">{{ issue.location }}</div>
                <div class="issue-row">
                  <span class="issue-label">{{ t('databaseView.impact') }}</span>
                  <span>{{ issue.impact }}</span>
                </div>
                <div class="issue-row">
                  <span class="issue-label">{{ t('databaseView.estimateLabel') }}</span>
                  <span>{{ issue.estimate }}</span>
                </div>
                <div class="issue-row">
                  <span class="issue-label">{{ t('databaseView.solutionLabel') }}</span>
                  <span class="issue-solution">{{ issue.solution }}</span>
                </div>
              </div>
            </div>
          </el-scrollbar>
        </el-card>
      </el-col>
    </el-row>

    <!-- 第三行：两列布局 -->
    <el-row :gutter="16" class="content-row">
      <!-- 左侧：内存分析 + 各页面内存消耗 -->
      <el-col :span="12">
        <el-card v-if="memoryAnalysis" class="memory-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('databaseView.memoryAnalysis') }}</span>
              <el-tag type="info" size="small" effect="plain">{{ t('databaseView.estimated') }}</el-tag>
            </div>
          </template>
          <div class="memory-grid">
            <div class="memory-item">
              <div class="memory-label">{{ t('databaseView.dbFile') }}</div>
              <div class="memory-value">{{ memoryAnalysis.dbSizeMB }} MB</div>
            </div>
            <div class="memory-item">
              <div class="memory-label">{{ t('databaseView.albumRecords') }}</div>
              <div class="memory-value">{{ memoryAnalysis.albumMemoryMB }} MB</div>
            </div>
            <div class="memory-item">
              <div class="memory-label">{{ t('databaseView.spriteRecords') }}</div>
              <div class="memory-value">{{ memoryAnalysis.spriteMemoryMB }} MB</div>
            </div>
            <div class="memory-item">
              <div class="memory-label">{{ t('databaseView.npkRecords') }}</div>
              <div class="memory-value">{{ memoryAnalysis.npkMemoryMB }} MB</div>
            </div>
            <div class="memory-item">
              <div class="memory-label">{{ t('databaseView.backendStartup') }}</div>
              <div class="memory-value">{{ memoryAnalysis.backendNpkMemoryMB }} MB</div>
            </div>
            <div class="memory-item">
              <div class="memory-label">ImageCache</div>
              <div class="memory-value">{{ memoryAnalysis.imageCacheMB }} MB</div>
            </div>
            <div class="memory-item">
              <div class="memory-label">ThumbnailCache</div>
              <div class="memory-value">{{ memoryAnalysis.thumbCacheMB }} MB</div>
            </div>
            <div class="memory-item highlight">
              <div class="memory-label">{{ t('databaseView.backendResident') }}</div>
              <div class="memory-value">{{ memoryAnalysis.backendResidentMB }} MB</div>
            </div>
            <div class="memory-item total">
              <div class="memory-label">{{ t('databaseView.systemTotal') }}</div>
              <div class="memory-value">{{ memoryAnalysis.totalEstimateMB }} MB</div>
            </div>
          </div>
        </el-card>

        <el-card v-if="pageMemoryItems.length > 0" class="page-memory-card" style="margin-top: 12px">
          <template #header>
            <div class="card-header">
              <span>{{ t('databaseView.pageMemory') }}</span>
              <el-tag type="info" size="small" effect="plain">{{ t('databaseView.frontend') }}</el-tag>
            </div>
          </template>
          <div class="page-memory-list">
            <div v-for="item in pageMemoryItems" :key="item.page" class="page-memory-item" :class="item.status">
              <div class="pm-header">
                <span class="pm-name">{{ item.page }}</span>
                <el-tag :type="item.status === 'danger' ? 'danger' : item.status === 'warning' ? 'warning' : 'success'" size="small">
                  {{ item.memory }}
                </el-tag>
              </div>
              <div class="pm-detail">{{ item.detail }}</div>
              <div v-if="item.suggestion" class="pm-suggestion">
                <el-icon><InfoFilled /></el-icon>
                {{ item.suggestion }}
              </div>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 右侧：数据库操作 -->
      <el-col :span="12">
        <el-card class="ops-card">
          <template #header><span>{{ t('databaseView.dbOperations') }}</span></template>

          <div class="ops-list">
            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Delete /></el-icon>
                  {{ t('databaseView.cleanInvalid') }}
                </div>
                <div class="op-desc">{{ t('databaseView.cleanDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="warning" size="small">{{ t('databaseView.slow') }}</el-tag>
                  <span>{{ t('databaseView.cleanPerf') }}</span>
                </div>
              </div>
              <el-button type="warning" size="small" :loading="operationLoading === 'cleanup'" @click="cleanupDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><DataAnalysis /></el-icon>
                  {{ t('databaseView.compactDb') }} (VACUUM)
                </div>
                <div class="op-desc">{{ t('databaseView.compactDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="warning" size="small">{{ t('databaseView.slow') }}</el-tag>
                  <span>{{ t('databaseView.compactPerf') }}</span>
                </div>
              </div>
              <el-button type="warning" size="small" :loading="operationLoading === 'compact'" @click="compactDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><RefreshRight /></el-icon>
                  {{ t('databaseView.incrementalUpdate') }}
                </div>
                <div class="op-desc">{{ t('databaseView.incrementalDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="success" size="small">{{ t('databaseView.fast') }}</el-tag>
                  <span>{{ t('databaseView.incrementalPerf') }}</span>
                </div>
              </div>
              <el-button type="success" size="small" :loading="operationLoading === 'incremental'" @click="incrementalDB">{{ t('common.update') }}</el-button>
            </div>

            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Download /></el-icon>
                  {{ t('databaseView.exportDb') }} (JSON)
                </div>
                <div class="op-desc">{{ t('databaseView.exportDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="danger" size="small">{{ t('databaseView.heavy') }}</el-tag>
                  <span>{{ t('databaseView.exportPerf') }}</span>
                </div>
              </div>
              <el-button type="primary" size="small" :loading="operationLoading === 'export'" @click="exportDB">{{ t('databaseView.export') }}</el-button>
            </div>

            <div class="op-item danger-op">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Setting /></el-icon>
                  {{ t('databaseView.rebuildDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.rebuildDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="danger" size="small">{{ t('databaseView.heavy') }}</el-tag>
                  <span>{{ t('databaseView.rebuildPerf') }}</span>
                </div>
              </div>
              <el-button type="danger" size="small" :loading="operationLoading === 'rebuild'" @click="rebuildDB">{{ t('databaseView.rebuild') }}</el-button>
            </div>
          </div>

          <div class="strategy-section">
            <h4>
              <el-icon><InfoFilled /></el-icon>
              {{ t('databaseView.dataLoadStrategy') }}
            </h4>
            <div class="strategy-list">
              <div class="strategy-item">
                <el-icon><Check /></el-icon>
                <span>{{ t('databaseView.strategyNpk') }}</span>
              </div>
              <div class="strategy-item">
                <el-icon><Check /></el-icon>
                <span>{{ t('databaseView.strategyAlbum') }}</span>
              </div>
              <div class="strategy-item">
                <el-icon><Check /></el-icon>
                <span>{{ t('databaseView.strategySprite') }}</span>
              </div>
            </div>
          </div>
        </el-card>

        <!-- 视频数据库管理 -->
        <el-card class="video-db-card" style="margin-top: 16px">
          <template #header>
            <div class="card-header">
              <span>{{ t('databaseView.videoDbTitle') }}</span>
            </div>
          </template>

          <div class="ops-list">
            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><VideoCamera /></el-icon>
                  {{ t('databaseView.cleanInvalid') }}
                </div>
                <div class="op-desc">{{ t('databaseView.videoCleanDesc') }}</div>
              </div>
              <el-button type="warning" size="small" :loading="operationLoading === 'videoCleanup'" @click="cleanupVideoDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Refresh /></el-icon>
                  {{ t('databaseView.compactDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.videoCompactDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="info" size="small">{{ t('databaseView.light') }}</el-tag>
                  <span>{{ t('databaseView.usuallySeconds') }}</span>
                </div>
              </div>
              <el-button type="primary" size="small" :loading="operationLoading === 'videoCompact'" @click="compactVideoDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item danger-op">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><RefreshRight /></el-icon>
                  {{ t('databaseView.rebuildDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.videoRebuildDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="danger" size="small">{{ t('databaseView.heavy') }}</el-tag>
                  <span>{{ t('databaseView.mayTakeMinutes') }}</span>
                </div>
              </div>
              <el-button type="danger" size="small" :loading="operationLoading === 'videoRebuild'" @click="rebuildVideoDB">{{ t('databaseView.rebuild') }}</el-button>
            </div>
          </div>
        </el-card>

        <!-- 音乐数据库管理 -->
        <el-card class="video-db-card" style="margin-top: 16px">
          <template #header>
            <div class="card-header">
              <span>{{ t('databaseView.audioDbTitle') }}</span>
            </div>
          </template>

          <div class="ops-list">
            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Headset /></el-icon>
                  {{ t('databaseView.cleanInvalid') }}
                </div>
                <div class="op-desc">{{ t('databaseView.musicCleanDesc') }}</div>
              </div>
              <el-button type="warning" size="small" :loading="operationLoading === 'musicCleanup'" @click="cleanupMusicDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Refresh /></el-icon>
                  {{ t('databaseView.compactDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.musicCompactDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="info" size="small">{{ t('databaseView.light') }}</el-tag>
                  <span>{{ t('databaseView.usuallySeconds') }}</span>
                </div>
              </div>
              <el-button type="primary" size="small" :loading="operationLoading === 'musicCompact'" @click="compactMusicDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item danger-op">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><RefreshRight /></el-icon>
                  {{ t('databaseView.rebuildDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.musicRebuildDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="danger" size="small">{{ t('databaseView.heavy') }}</el-tag>
                  <span>{{ t('databaseView.audioMayTakeMinutes') }}</span>
                </div>
              </div>
              <el-button type="danger" size="small" :loading="operationLoading === 'musicRebuild'" @click="rebuildMusicDB">{{ t('databaseView.rebuild') }}</el-button>
            </div>
          </div>
        </el-card>

        <!-- 音效数据库管理 -->
        <el-card class="video-db-card" style="margin-top: 16px">
          <template #header>
            <div class="card-header">
              <span>{{ t('databaseView.soundDbTitle') }}</span>
            </div>
          </template>

          <div class="ops-list">
            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Headset /></el-icon>
                  {{ t('databaseView.cleanInvalid') }}
                </div>
                <div class="op-desc">{{ t('databaseView.soundCleanDesc') }}</div>
              </div>
              <el-button type="warning" size="small" :loading="operationLoading === 'soundpackCleanup'" @click="cleanupSoundPackDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><Refresh /></el-icon>
                  {{ t('databaseView.compactDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.soundCompactDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="info" size="small">{{ t('databaseView.light') }}</el-tag>
                  <span>{{ t('databaseView.usuallySeconds') }}</span>
                </div>
              </div>
              <el-button type="primary" size="small" :loading="operationLoading === 'soundpackCompact'" @click="compactSoundPackDB">{{ t('databaseView.execute') }}</el-button>
            </div>

            <div class="op-item danger-op">
              <div class="op-info">
                <div class="op-name">
                  <el-icon><RefreshRight /></el-icon>
                  {{ t('databaseView.rebuildDb') }}
                </div>
                <div class="op-desc">{{ t('databaseView.soundRebuildDesc') }}</div>
                <div class="op-perf">
                  <el-tag type="danger" size="small">{{ t('databaseView.heavy') }}</el-tag>
                  <span>{{ t('databaseView.audioMayTakeMinutes') }}</span>
                </div>
              </div>
              <el-button type="danger" size="small" :loading="operationLoading === 'soundpackRebuild'" @click="rebuildSoundPackDB">{{ t('databaseView.rebuild') }}</el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.database-view {
  height: calc(100vh - 90px);
  display: flex;
  flex-direction: column;

  .page-header {
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-shrink: 0;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
  }

  .stats-row {
    margin-bottom: 12px;
    flex-shrink: 0;

    .stat-card {
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 12px;
      transition: transform 0.2s ease, border-color 0.2s ease;
      position: relative;

      &:hover {
        transform: translateY(-2px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      .stat-content {
        .stat-info {
          .stat-value {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 2px;
          }

          .stat-label {
            font-size: 11px;
            color: var(--text-secondary);
          }
        }
      }
    }
  }

  .content-row {
    margin-bottom: 12px;

    .el-col {
      display: flex;
      flex-direction: column;
    }
  }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .header-tags {
      display: flex;
      align-items: center;
      gap: 6px;
    }
  }

  .table-desc {
    font-size: 12px;
    color: var(--text-muted);
  }

  .large-count {
    color: var(--el-color-warning);
    font-weight: 500;
  }

  .memory-card {
    .memory-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;

      .memory-item {
        padding: 10px 8px;
        background: var(--bg-secondary);
        border-radius: 10px;
        border: 1px solid var(--border-color);
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        transition: transform 0.2s ease;
        position: relative;

        &:hover {
          transform: translateY(-2px);
        }

        &.highlight {
          background: rgba(137, 180, 250, 0.15);
          border-color: rgba(137, 180, 250, 0.3);
        }

        &.total {
          background: rgba(166, 227, 161, 0.15);
          border-color: rgba(166, 227, 161, 0.3);
        }

        .memory-label {
          font-size: 10px;
          color: var(--text-muted);
          margin-bottom: 4px;
        }

        .memory-value {
          font-size: 14px;
          font-weight: 600;
          color: var(--text-primary);
        }
      }
    }

    .warnings-section {
      h4 {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 14px 0;
        font-size: 13px;
        color: var(--text-primary);
      }

      .warning-item {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        padding: 10px 14px;
        background: var(--bg-tertiary);
        border-radius: 8px;
        margin-bottom: 8px;
        font-size: 12px;
        color: var(--text-secondary);
        line-height: 1.6;
      }
    }
  }

  .page-memory-card {
    .page-memory-list {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .page-memory-item {
      padding: 10px 12px;
      background: var(--bg-primary);
      border-radius: 10px;
      border: 1px solid var(--border-color);
      border-left: 3px solid var(--border-color);
      transition: transform 0.2s ease;
      position: relative;

      &:hover {
        transform: translateX(4px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &.danger {
        border-left-color: var(--el-color-danger);
      }

      &.warning {
        border-left-color: var(--el-color-warning);
      }

      &.good {
        border-left-color: var(--el-color-success);
      }

      .pm-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 4px;

        .pm-name {
          font-size: 13px;
          font-weight: 500;
          color: var(--text-primary);
        }
      }

      .pm-detail {
        font-size: 11px;
        color: var(--text-secondary);
        line-height: 1.4;
      }

      .pm-suggestion {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        font-size: 12px;
        color: var(--el-color-warning);
      }
    }
  }

  .table-card {
    height: 300px;
    display: flex;
    flex-direction: column;

    :deep(.el-table) {
      flex: 1;
    }
  }

  .page-memory-card {
    height: 300px;
    display: flex;
    flex-direction: column;

    .page-memory-list {
      flex: 1;
      overflow-y: auto;
    }
  }

  .issues-card {
    height: 300px;
    display: flex;
    flex-direction: column;

    :deep(.el-card__body) {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      padding: 12px;
    }

    .issues-scroll {
      flex: 1;
      min-height: 0;
    }

    .issues-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .issue-item {
      padding: 10px 12px;
      background: var(--bg-primary);
      border-radius: 10px;
      border: 1px solid var(--border-color);
      border-left: 4px solid var(--border-color);
      transition: transform 0.2s ease;
      position: relative;

      &:hover {
        transform: translateX(4px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &.danger {
        border-left-color: var(--el-color-danger);
      }

      &.warning {
        border-left-color: var(--el-color-warning);
      }

      &.info {
        border-left-color: var(--el-color-info);
      }

      .issue-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;

        .priority-tag {
          flex-shrink: 0;
        }

        .issue-title {
          font-size: 13px;
          font-weight: 500;
          color: var(--text-primary);
        }
      }

      .issue-location {
        font-size: 11px;
        color: var(--text-muted);
        margin-bottom: 4px;
        font-family: monospace;
      }

      .issue-row {
        font-size: 11px;
        color: var(--text-secondary);
        line-height: 1.4;
        margin-bottom: 3px;

        .issue-label {
          color: var(--text-muted);
          margin-right: 4px;
        }

        .issue-solution {
          color: var(--el-color-success);
        }
      }
    }
  }

  .ops-card,
  .video-db-card {
    flex-shrink: 0;

    .ops-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .op-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      padding: 12px;
      background: var(--bg-primary);
      border-radius: 10px;
      border: 1px solid var(--border-color);
      border-left: 3px solid var(--border-color);
      transition: transform 0.2s ease;
      position: relative;

      &:hover {
        transform: translateY(-2px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &.danger-op {
        border-left-color: var(--el-color-danger);
        background: var(--bg-primary);
      }

      .op-info {
        flex: 1;
        min-width: 0;

        .op-name {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          font-weight: 500;
          color: var(--text-primary);
          margin-bottom: 2px;
        }

        .op-desc {
          font-size: 11px;
          color: var(--text-secondary);
          margin-bottom: 2px;
          line-height: 1.4;
        }

        .op-perf {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 10px;
          color: var(--text-muted);
        }
      }
    }

    .strategy-section {
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid var(--border-color);

      h4 {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 10px 0;
        font-size: 13px;
        color: var(--text-primary);
      }

      .strategy-list {
        display: flex;
        flex-direction: column;
        gap: 5px;

        .strategy-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: var(--text-secondary);
          padding: 3px 0;
        }
      }
    }
  }
}


</style>
