<script setup lang="ts">
import { ref, onMounted, computed, watch, nextTick, onUnmounted, onActivated, onDeactivated } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute } from 'vue-router'
import { useNpkStore } from '@/stores/npk'
import { Download, FolderOpened, Delete, Search, Picture, Folder, Switch, Sunny } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { albumApi, batchApi, toolsApi } from '@/api/index'
import { renderImageToCanvas } from '@/utils/canvas'

const { t } = useI18n()
const route = useRoute()
const npkStore = useNpkStore()

const exportFormat = ref('png')
const exportQuality = ref(100)
const exportSize = ref('original')
const customWidth = ref(0)
const customHeight = ref(0)
const selectedItems = ref<any[]>([])
const exporting = ref(false)
const exportProgress = ref(0)

// 搜索相关
const npkSearchQuery = ref('')
const imgSearchQuery = ref('')
const selectedNpk = ref<string>('')
const selectedAlbums = ref<string[]>([])

// 步骤控制
const currentStep = ref<'select-npk' | 'select-album'>('select-npk')

// 画布预览相关
const previewItem = ref<any>(null)
const previewLoading = ref(false)
const previewUrl = ref('')
const frameList = ref<any[]>([])
const frameListLoading = ref(false)
const selectedFrameIndex = ref<number>(0)
const albumVersion = ref<string>('')
const previewCanvas = ref<HTMLCanvasElement | null>(null)
const removeBlackBg = ref(false)
const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto')

function toggleCanvasBgMode() {
  if (canvasBgMode.value === 'auto') {
    canvasBgMode.value = 'light'
  } else if (canvasBgMode.value === 'light') {
    canvasBgMode.value = 'dark'
  } else {
    canvasBgMode.value = 'light'
  }
}

// 选择 Albums 步骤的预览（临时项，用于右侧画布预览）
const tempPreviewItem = ref<any>(null)

// 版本转换相关
const convertSourceDir = ref('')
const convertTargetVersion = ref<string>('V2')
const convertOutputFormat = ref<string>('npk')
const converting = ref(false)
const convertProgress = ref(0)
const convertStatus = ref('')
const convertTotal = ref(0)
const convertCompleted = ref(0)
const convertSkipped = ref(0)
const convertTaskId = ref('')
const sourceDirInput = ref<HTMLInputElement | null>(null)
const selectedImgFiles = ref<File[]>([])

// 轮询取消信号
let exportCancelled = false
let convertCancelled = false

onMounted(async () => {
  // 初始化只执行一次
})

onActivated(async () => {
  // 重置取消标志
  exportCancelled = false
  convertCancelled = false
  
  // 获取路由参数
  const queryNpk = route.query.npk as string
  
  // 如果有参数，保持选中状态
  if (queryNpk) {
    await handleRouteQuery()
    return
  }
  
  // 没有参数时，清除选中状态（返回页面时）
  clearSelection()
  
  // 处理路由参数（此时应该没有参数了）
  await handleRouteQuery()
})

// 清除所有选中状态
function clearSelection() {
  selectedNpk.value = ''
  selectedAlbums.value = []
  currentStep.value = 'select-npk'
  previewItem.value = null
  previewUrl.value = ''
  frameList.value = []
  selectedFrameIndex.value = 0
  albumVersion.value = ''
  tempPreviewItem.value = null
  npkStore.clearCurrent()
}

onDeactivated(() => {
  // 页面失活时取消轮询任务
  exportCancelled = true
  convertCancelled = true
})

onUnmounted(() => {
  // 清理状态
})

// 监听路由参数变化
watch(() => route.query, async () => {
  await handleRouteQuery()
}, { deep: true })

// 处理路由查询参数
async function handleRouteQuery() {
  const npkName = route.query.npk as string
  const albumPath = route.query.album as string

  if (npkName && npkStore.npkFiles.length > 0) {
    // 自动选择 NPK
    const npkExists = npkStore.npkFiles.some(n => n.name === npkName)
    if (npkExists) {
      selectedNpk.value = npkName
      await npkStore.fetchNpkInfo(npkName)
      tempPreviewItem.value = null
      currentStep.value = 'select-album'

      // 如果还指定了 album，自动选中并加载预览
      if (albumPath && npkStore.currentAlbums.length > 0) {
        const albumExists = npkStore.currentAlbums.some(a => a.path === albumPath)
        if (albumExists) {
          selectedAlbums.value = [albumPath]
          // 加载预览
          onAlbumClick(albumPath)
          ElMessage.success(t('batchExport.autoSelected', { npk: npkName, album: albumPath.split('/').pop() }))
        }
      }
    }
  }
}

// 过滤后的 NPK 列表
const filteredNpkList = computed(() => {
  if (!npkSearchQuery.value) return npkStore.npkFiles
  const query = npkSearchQuery.value.toLowerCase()
  return npkStore.npkFiles.filter(npk => npk.name.toLowerCase().includes(query))
})

// 过滤后的 Albums 列表
const filteredAlbums = computed(() => {
  if (!selectedNpk.value || !npkStore.currentAlbums) return []
  if (!imgSearchQuery.value) return npkStore.currentAlbums
  const query = imgSearchQuery.value.toLowerCase()
  return npkStore.currentAlbums.filter(album =>
    album.name.toLowerCase().includes(query) || album.path.toLowerCase().includes(query)
  )
})

// 选择 NPK
async function selectNpk(npkName: string) {
  selectedNpk.value = npkName
  await npkStore.fetchNpkInfo(npkName)
  selectedAlbums.value = []
  tempPreviewItem.value = null
  currentStep.value = 'select-album'
}

function backToSelectNpk() {
  currentStep.value = 'select-npk'
  selectedAlbums.value = []
  tempPreviewItem.value = null
}

// 切换 Album 选择状态
function toggleAlbumSelection(albumPath: string) {
  const index = selectedAlbums.value.indexOf(albumPath)
  if (index > -1) {
    selectedAlbums.value.splice(index, 1)
  } else {
    selectedAlbums.value.push(albumPath)
  }
}

// 点击 Album 项时在右侧画布预览
function onAlbumClick(albumPath: string) {
  const albumInfo = npkStore.currentAlbums.find(a => a.path === albumPath)
  tempPreviewItem.value = {
    npk: selectedNpk.value,
    album: albumPath,
    albumName: albumInfo?.name || albumPath,
    count: albumInfo?.sprite_count || 0
  }
  selectPreviewItem(tempPreviewItem.value)
}

// 确认添加 Albums
function confirmAddAlbums() {
  if (selectedAlbums.value.length === 0) {
    ElMessage.warning(t('batchExport.selectAtLeastOneAlbum'))
    return
  }
  
  const npkName = selectedNpk.value
  let addedCount = 0
  
  for (const albumPath of selectedAlbums.value) {
    const albumInfo = npkStore.currentAlbums.find(a => a.path === albumPath)
    const exists = selectedItems.value.some(item => item.npk === npkName && item.album === albumPath)
    if (!exists) {
      selectedItems.value.push({
        npk: npkName,
        album: albumPath,
        albumName: albumInfo?.name || albumPath,
        count: albumInfo?.sprite_count || 0,
        indices: []
      })
      addedCount++
    }
  }
  
  if (addedCount > 0) {
    ElMessage.success(t('batchExport.albumsAdded', { count: addedCount }))
  } else {
    ElMessage.info(t('batchExport.albumAlreadyInList'))
  }
  
  // 重置选择状态，返回 NPK 选择界面
  currentStep.value = 'select-npk'
  selectedNpk.value = ''
  selectedAlbums.value = []
  imgSearchQuery.value = ''
  tempPreviewItem.value = null
}

function removeItem(index: number) {
  if (previewItem.value === selectedItems.value[index]) {
    previewItem.value = null
    previewUrl.value = ''
    frameList.value = []
  }
  selectedItems.value.splice(index, 1)
}

function clearAll() {
  selectedItems.value = []
  previewItem.value = null
  previewUrl.value = ''
  frameList.value = []
}

// 点击已选列表中的 Album，加载画布预览和帧列表
async function selectPreviewItem(item: any) {
  previewItem.value = item
  previewLoading.value = true
  frameListLoading.value = true
  try {
    await Promise.all([loadPreview(item), loadFrames(item)])
  } finally {
    previewLoading.value = false
    frameListLoading.value = false
  }
}

async function loadPreview(item: any, frameIndex: number = 0) {
  selectedFrameIndex.value = frameIndex
  const url = `${albumApi.getPreviewUrl(item.npk, item.album)}&frame=${frameIndex}`
  previewUrl.value = url

  // 等待 DOM 更新，确保 canvas 已渲染
  await nextTick()

  // 渲染到 canvas
  if (previewCanvas.value) {
    try {
      await renderImageToCanvas(previewCanvas.value, url, removeBlackBg.value)
    } catch {
      // 如果 canvas 渲染失败，回退到 img 显示
    }
  }
}

// 监听去黑底开关变化
watch(removeBlackBg, async (newVal) => {
  if (previewUrl.value && previewCanvas.value) {
    try {
      await renderImageToCanvas(previewCanvas.value, previewUrl.value, newVal)
    } catch {
      // 忽略错误
    }
  }
})

async function loadFrames(item: any) {
  try {
    const res = await albumApi.getFrames(item.npk, item.album)
    frameList.value = res.data?.frames || []
    albumVersion.value = res.data?.version || ''
  } catch (e: any) {
    frameList.value = []
    albumVersion.value = ''
  }
}

function onFrameClick(row: any) {
  if (previewItem.value) {
    loadPreview(previewItem.value, row.index)
  }
}

async function startExport() {
  if (selectedItems.value.length === 0) {
    ElMessage.warning(t('batchExport.addResourceFirst'))
    return
  }
  // 重置取消标志
  exportCancelled = false
  exporting.value = true
  exportProgress.value = 0
  try {
    const items = selectedItems.value.map(item => ({
      npkName: item.npk,
      albumPath: item.album,
      indices: []
    }))

    // 创建异步导出任务
    const res = await batchApi.export(items, exportFormat.value, exportQuality.value, removeBlackBg.value)
    const taskId = res.data?.task_id
    if (!taskId) {
      throw new Error(t('batchExport.noTaskId'))
    }

    ElMessage.info(t('batchExport.exportTaskCreated'))

    // 轮询任务状态
    const pollInterval = 1000
    const maxPolls = 300 // 最多等待 5 分钟
    for (let i = 0; i < maxPolls; i++) {
      // 检查是否被取消
      if (exportCancelled) {
        ElMessage.info(t('batchExport.exportCancelled'))
        return
      }
      
      await new Promise(resolve => setTimeout(resolve, pollInterval))

      const statusRes = await batchApi.getStatus(taskId)
      const task = statusRes.data
      if (!task) break

      if (task.total > 0) {
        exportProgress.value = Math.round((task.completed / task.total) * 100)
      }

      if (task.status === 'completed') {
        // 检查是否有多个压缩包
        if (task.result?.files && task.result.files.length > 0) {
          // 多个文件，逐个下载
          let downloadedCount = 0
          const totalFiles = task.result.files.length
          
          for (const fileUrl of task.result.files) {
            // fileUrl 是 "/api/batch/download/..." 格式
            const link = document.createElement('a')
            link.href = fileUrl
            document.body.appendChild(link)
            link.click()
            document.body.removeChild(link)
            
            downloadedCount++
            // 稍微延迟避免浏览器阻止多个下载
            if (downloadedCount < totalFiles) {
              await new Promise(resolve => setTimeout(resolve, 500))
            }
          }
          ElMessage.success(t('batchExport.exportComplete'))
        } else {
          // 单个文件（兼容旧版本）
          const downloadUrl = batchApi.getDownloadUrl(taskId)
          const link = document.createElement('a')
          link.href = downloadUrl
          document.body.appendChild(link)
          link.click()
          document.body.removeChild(link)
          ElMessage.success(t('batchExport.exportComplete'))
        }
        exportProgress.value = 100
        return
      }

      if (task.status === 'failed') {
        throw new Error(task.error || t('batchExport.exportFailed'))
      }
    }

    throw new Error(t('batchExport.exportTimeout'))
  } catch (e: any) {
    ElMessage.error(t('batchExport.exportFailed') + ': ' + (e.message || ''))
  } finally {
    exporting.value = false
  }
}

// 选择源文件夹
function selectSourceDir() {
  sourceDirInput.value?.click()
}

function onSourceDirChange(e: Event) {
  const input = e.target as HTMLInputElement
  if (input.files && input.files.length > 0) {
    const files = Array.from(input.files)
    // 过滤只保留 .npk 文件
    const npkFiles = files.filter(f => f.name.toLowerCase().endsWith('.npk'))
    if (npkFiles.length === 0) {
      ElMessage.warning(t('batchExport.noNpkFilesInFolder'))
      return
    }
    selectedImgFiles.value = npkFiles
    const firstFile = input.files[0]
    const relativePath = firstFile.webkitRelativePath || ''
    convertSourceDir.value = relativePath.split('/')[0] || t('batchExport.folderSelected')
  }
}

// 开始版本转换
async function startConvert() {
  if (selectedImgFiles.value.length === 0) {
    ElMessage.warning(t('batchExport.selectFolderWithNpk'))
    return
  }
  
  // 重置取消标志
  convertCancelled = false
  converting.value = true
  convertProgress.value = 0
  convertStatus.value = t('batchExport.statusUploading')
  convertTotal.value = 0
  convertCompleted.value = 0
  convertTaskId.value = ''
  
  try {
    const res = await toolsApi.convertUpload(selectedImgFiles.value, convertTargetVersion.value, convertOutputFormat.value) as any
    const taskId = res.data?.task_id
    if (!taskId) {
      throw new Error(t('batchExport.noTaskId'))
    }
    
    convertTaskId.value = taskId
    convertTotal.value = res.data?.total || 0
    convertStatus.value = t('batchExport.statusStartConvert')
    
    // 轮询任务状态
    const pollInterval = 500
    const maxPolls = 1200 // 最多等待 10 分钟
    for (let i = 0; i < maxPolls; i++) {
      // 检查是否被取消
      if (convertCancelled) {
        ElMessage.info(t('batchExport.convertCancelled'))
        return
      }
      
      await new Promise(resolve => setTimeout(resolve, pollInterval))
      
      const statusRes = await toolsApi.getConvertStatus(taskId)
      const task = statusRes.data
      if (!task) break
      
      convertTotal.value = task.total || 0
      convertCompleted.value = task.completed || 0
      convertStatus.value = task.status_text || t('batchExport.statusProcessing')
      convertSkipped.value = task.skipped || 0
      
      if (task.total > 0) {
        convertProgress.value = Math.round((task.completed / task.total) * 100)
      }
      
      if (task.status === 'completed') {
        ElMessage.success(t('batchExport.convertComplete'))
        convertProgress.value = 100
        // 自动下载 ZIP
        downloadConvertResult(taskId)
        return
      }
      
      if (task.status === 'failed') {
        throw new Error(task.error || t('batchExport.convertFailed'))
      }
    }
    
    throw new Error(t('batchExport.convertTimeout'))
  } catch (e: any) {
    ElMessage.error(t('batchExport.convertFailed') + ': ' + (e.message || ''))
    convertStatus.value = t('batchExport.statusFailed')
  } finally {
    converting.value = false
  }
}

// 下载转换结果 ZIP
function downloadConvertResult(taskId: string) {
  const url = toolsApi.getConvertDownloadUrl(taskId)
  const a = document.createElement('a')
  a.href = url
  a.download = `converted_${convertTargetVersion.value}.zip`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}
</script>

<template>
  <div class="batch-export">
    <div class="page-header">
      <h2 class="page-title">{{ t('batchExport.title') }}</h2>
    </div>

    <el-row :gutter="16">
      <!-- 左侧: 导出设置 + 版本转换 -->
      <el-col :span="5">
        <el-card class="list-card left-settings-card">
          <template #header><span>{{ t('batchExport.exportSettings') }}</span></template>
          <div class="settings-container">
            <!-- 上半部分: 缩小的导出设置 -->
            <div class="export-settings-section">
              <el-form label-position="top" size="small">
                <el-form-item :label="t('batchExport.format')">
                  <el-select v-model="exportFormat" style="width: 100%">
                    <el-option label="PNG" value="png" />
                    <el-option label="JPEG" value="jpg" />
                    <el-option label="WebP" value="webp" />
                    <el-option :label="t('batchExport.gifOption')" value="gif" />
                    <el-option :label="t('batchExport.imgOption')" value="img" />
                  </el-select>
                </el-form-item>
                <el-form-item v-if="exportFormat !== 'gif' && exportFormat !== 'img'" :label="t('batchExport.quality')">
                  <div class="quality-control">
                    <el-input-number v-model="exportQuality" :min="1" :max="100" :step="1" style="width: 100px" />
                    <span class="quality-value">{{ exportQuality }}%</span>
                  </div>
                </el-form-item>
                <el-form-item v-if="exportFormat !== 'gif' && exportFormat !== 'img'" :label="t('batchExport.size')">
                  <el-select v-model="exportSize" style="width: 100%">
                    <el-option :label="t('batchExport.originalSize')" value="original" />
                    <el-option :label="t('batchExport.custom')" value="custom" />
                    <el-option label="50%" value="50" />
                    <el-option label="25%" value="25" />
                  </el-select>
                </el-form-item>
                <el-form-item v-if="exportSize === 'custom' && exportFormat !== 'gif' && exportFormat !== 'img'" :label="t('batchExport.custom')">
                  <el-row :gutter="8">
                    <el-col :span="12"><el-input v-model.number="customWidth" :placeholder="t('batchExport.width')" /></el-col>
                    <el-col :span="12"><el-input v-model.number="customHeight" :placeholder="t('batchExport.height')" /></el-col>
                  </el-row>
                </el-form-item>
                <el-form-item v-if="exportFormat === 'gif'">
                  <div class="gif-tip">{{ t('batchExport.gifTip') }}</div>
                </el-form-item>
                <el-form-item v-if="exportFormat === 'img'">
                  <div class="gif-tip">{{ t('batchExport.imgTip') }}</div>
                </el-form-item>
              </el-form>
            </div>
            
            <!-- 分隔线 -->
            <div class="section-divider"></div>
            
            <!-- 下半部分: 版本转换 -->
            <div class="convert-section">
              <div class="section-title">
                <el-icon><Switch /></el-icon>
                <span>{{ t('batchExport.versionConvert') }}</span>
              </div>
              <el-form label-position="top" size="small">
                <!-- 隐藏的文件夹选择 input -->
                <input
                  ref="sourceDirInput"
                  type="file"
                  webkitdirectory
                  directory
                  style="display: none"
                  @change="onSourceDirChange"
                />
                <el-form-item :label="t('batchExport.sourceFolder')">
                  <el-input
                    v-model="convertSourceDir"
                    :placeholder="t('batchExport.convertSourcePlaceholder')"
                    readonly
                  >
                    <template #append>
                      <el-button :icon="Folder" @click="selectSourceDir">{{ t('batchExport.browse') }}</el-button>
                    </template>
                  </el-input>
                  <div v-if="selectedImgFiles.length > 0" class="file-count-tip">
                    {{ t('batchExport.fileCountTip', { count: selectedImgFiles.length }) }}
                  </div>
                </el-form-item>
                <el-form-item :label="t('batchExport.targetVersion')">
                  <el-select v-model="convertTargetVersion" style="width: 100%">
                    <el-option label="V2 (ARGB 8888)" value="V2" />
                  </el-select>
                  <div style="font-size: 11px; color: var(--el-text-color-secondary); margin-top: 4px;">
                    {{ t('batchExport.convertV2Hint') }}
                  </div>
                </el-form-item>
                <el-form-item>
                  <el-button
                    type="primary"
                    :icon="Switch"
                    :loading="converting"
                    :disabled="selectedImgFiles.length === 0"
                    style="width: 100%"
                    @click="startConvert"
                  >
                    {{ t('batchExport.startConvert') }}
                  </el-button>
                </el-form-item>
                <el-form-item v-if="converting || convertProgress > 0">
                  <div class="convert-progress">
                    <el-progress :percentage="convertProgress" :stroke-width="8" />
                    <div class="convert-status">
                      <span>{{ convertStatus }}</span>
                      <span v-if="convertTotal > 0">({{ convertCompleted }} / {{ convertTotal }})</span>
                      <span v-if="convertSkipped > 0" style="color: var(--el-color-warning); margin-left: 8px;">{{ t('batchExport.convertSkipped', { count: convertSkipped }) }}</span>
                    </div>
                  </div>
                </el-form-item>
              </el-form>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 中间: 选择资源 -->
      <el-col :span="7">
        <el-card class="list-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('batchExport.selectResources') }} ({{ selectedItems.length }})</span>
              <div>
                <el-button v-if="selectedItems.length > 0" size="small" @click="clearAll">{{ t('batchExport.clear') }}</el-button>
                <el-button type="primary" :icon="FolderOpened" size="small" @click="currentStep = 'select-npk'">{{ t('batchExport.add') }}</el-button>
              </div>
            </div>
          </template>

          <!-- 步骤 1: 选择 NPK -->
          <div v-if="currentStep === 'select-npk'" class="step-content">
            <div class="search-box">
              <el-input v-model="npkSearchQuery" :placeholder="t('batchExport.searchNpk')" :prefix-icon="Search" clearable size="small" />
            </div>
            <el-scrollbar class="step-scrollbar">
              <div class="item-list">
                <div
                  v-for="npk in filteredNpkList"
                  :key="npk.name"
                  class="list-item"
                  @click="selectNpk(npk.name)"
                >
                  <el-icon><FolderOpened /></el-icon>
                  <span class="item-name">{{ npk.name }}</span>
                  <span class="item-count">{{ npk.album_count }}</span>
                </div>
              </div>
                <div v-if="filteredNpkList.length === 0" class="empty-tip">{{ t('batchExport.noNpkFiles') }}</div>
            </el-scrollbar>
          </div>

          <!-- 步骤 2: 选择 Albums（带预览） -->
          <div v-else-if="currentStep === 'select-album'" class="step-content">
            <div class="step-header">
              <span class="step-title">{{ selectedNpk }}</span>
              <el-button size="small" @click="backToSelectNpk">{{ t('batchExport.back') }}</el-button>
            </div>
            <div class="search-box">
              <el-input v-model="imgSearchQuery" :placeholder="t('batchExport.searchAlbums')" :prefix-icon="Search" clearable size="small" />
            </div>
            <div class="album-actions">
              <el-button size="small" @click="selectedAlbums = filteredAlbums.map(a => a.path)">{{ t('batchExport.selectAll') }}</el-button>
              <el-button size="small" @click="selectedAlbums = []">{{ t('batchExport.clearSelection') }}</el-button>
              <el-tag size="small" type="info">{{ selectedAlbums.length }} / {{ filteredAlbums.length }}</el-tag>
            </div>
            <div class="album-select-area">
              <el-scrollbar class="album-list-scroll">
                <div class="item-list">
                  <div
                    v-for="album in filteredAlbums"
                    :key="album.path"
                    class="list-item"
                    :class="{ selected: selectedAlbums.includes(album.path) }"
                    tabindex="0"
                    @keydown.space.prevent="toggleAlbumSelection(album.path)"
                    @keydown.enter.prevent="toggleAlbumSelection(album.path)"
                  >
                    <input
                      type="checkbox"
                      :checked="selectedAlbums.includes(album.path)"
                      class="item-checkbox"
                      tabindex="-1"
                      @click.stop="toggleAlbumSelection(album.path)"
                    />
                    <span class="item-name" @click.stop="onAlbumClick(album.path)">{{ album.name }}</span>
                    <span class="item-count" @click.stop="onAlbumClick(album.path)">{{ album.sprite_count }}</span>
                  </div>
                </div>
                <div v-if="filteredAlbums.length === 0" class="empty-tip">{{ t('batchExport.noMatchAlbums') }}</div>
              </el-scrollbar>
            </div>
            <div class="step-actions">
              <el-button type="default" size="default" @click="backToSelectNpk">{{ t('common.cancel') }}</el-button>
              <el-button 
                type="primary" 
                size="default"
                :disabled="selectedAlbums.length === 0"
                @click="confirmAddAlbums"
              >
                {{ t('batchExport.add') }} {{ selectedAlbums.length }}
              </el-button>
            </div>
          </div>

          <!-- 已选列表（自定义 div 列表） -->
          <div v-if="selectedItems.length > 0 && currentStep === 'select-npk'" class="selected-section">
            <el-scrollbar class="selected-scroll">
              <div class="item-list">
                <div
                  v-for="(item, index) in selectedItems"
                  :key="item.album"
                  class="list-item"
                  :class="{ active: previewItem === item }"
                  @click="selectPreviewItem(item)"
                >
                  <span class="item-name">{{ item.albumName }}</span>
                  <span class="item-count">{{ item.count }}</span>
                  <el-icon class="item-delete" @click.stop="removeItem(index)"><Delete /></el-icon>
                </div>
              </div>
            </el-scrollbar>
          </div>
          <div v-if="selectedItems.length === 0 && currentStep === 'select-npk'" class="empty-tip">
            {{ t('batchExport.addResourceHint') }}
          </div>

          <div class="export-actions">
            <el-button
              type="primary" :icon="Download" :loading="exporting"
              :disabled="selectedItems.length === 0" size="large" @click="startExport"
            >
              {{ t('batchExport.startExport') }} ({{ selectedItems.length }})
            </el-button>
            <el-progress v-if="exporting" :percentage="exportProgress" :stroke-width="10" style="width: 200px; margin-left: 12px" />
          </div>
        </el-card>
      </el-col>

      <!-- 右侧: 画布预览 + 帧列表 -->
      <el-col :span="12">
        <el-card class="preview-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('batchExport.canvasPreview') }}</span>
              <el-tag v-if="previewItem" size="small" type="info">{{ previewItem.albumName }}</el-tag>
            </div>
          </template>

          <div v-if="!previewItem" class="preview-empty">
            <el-icon :size="48"><Picture /></el-icon>
            <span>{{ t('batchExport.clickAlbumPreview') }}</span>
          </div>

          <div v-else class="preview-content">
            <!-- 去黑底开关 -->
            <div class="preview-toolbar">
              <el-checkbox v-model="removeBlackBg" size="small">{{ t('batchExport.removeBlackBg') }}</el-checkbox>
              <el-button size="small" :icon="Sunny" @click="toggleCanvasBgMode" :title="canvasBgMode === 'auto' ? t('batchExport.bgAuto') : canvasBgMode === 'light' ? t('batchExport.bgLight') : t('batchExport.bgDark')">
                {{ canvasBgMode === 'auto' ? t('batchExport.bgAuto') : canvasBgMode === 'light' ? t('batchExport.bgLight') : t('batchExport.bgDark') }}
              </el-button>
            </div>
            <!-- 画布 -->
            <div class="canvas-container" :class="canvasBgMode" v-loading="previewLoading">
              <canvas v-if="previewUrl" ref="previewCanvas" class="canvas-image"></canvas>
            </div>

            <!-- 帧列表（自定义 div 列表） -->
            <div class="frame-section">
              <div class="frame-section-header">
                <span>{{ t('batchExport.frameList') }}</span>
                <el-tag size="small" v-if="frameList.length > 0">{{ frameList.length }}</el-tag>
              </div>
              <el-scrollbar v-if="frameList.length > 0" class="frame-scroll">
                <div class="frame-list">
                  <div
                    v-for="frame in frameList"
                    :key="frame.index"
                    class="frame-item"
                    :class="{ active: selectedFrameIndex === frame.index }"
                    @click="onFrameClick(frame)"
                  >
                    <span class="frame-number">{{ frame.index }}</span>
                    <template v-if="frame.is_link">
                      <span class="frame-link">
                        LINK
                        <template v-if="frame.link_status === 'normal'"> {{ t('npkManager.linkRef') }}：{{ frame.target_index }}</template>
                        <template v-else-if="frame.link_status === 'null'"> {{ t('npkManager.nullPointer') }}</template>
                        <template v-else-if="frame.link_status === 'circular'"> {{ t('npkManager.circularRef') }}</template>
                        <template v-else> {{ t('npkManager.linkRef') }}：{{ frame.target_index }}</template>
                      </span>
                      <el-tag size="small" :type="frame.link_status === 'normal' ? 'warning' : 'danger'" class="frame-tag">
                        <template v-if="frame.link_status === 'normal'">Link</template>
                        <template v-else-if="frame.link_status === 'null'">Error</template>
                        <template v-else-if="frame.link_status === 'circular'">Circular</template>
                        <template v-else>Link</template>
                      </el-tag>
                    </template>
                    <template v-else>
                      <span class="frame-type">{{ frame.type_name || (albumVersion || 'IMG') }}</span>
                      <span class="frame-pos">{{ frame.x }},{{ frame.y }}</span>
                      <span class="frame-size">{{ frame.width }}×{{ frame.height }}</span>
                      <span class="frame-frame">{{ frame.frame_width }}×{{ frame.frame_height }}</span>
                    </template>
                  </div>
                </div>
              </el-scrollbar>
              <div v-else v-loading="frameListLoading" class="empty-tip" style="padding: 20px">
                {{ frameListLoading ? t('imgDuplicate.loading') : t('batchExport.noFrameData') }}
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.batch-export {
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 0;
  box-sizing: border-box;

  .page-header {
    flex-shrink: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }
  }

  .el-row {
    flex: 1;
    min-height: 0;
    margin: 0;

    .el-col {
      height: 100%;

      .el-card {
        height: 100%;
        display: flex;
        flex-direction: column;

        :deep(.el-card__body) {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
        }
      }
    }
  }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .list-card {
    .search-box {
      margin-bottom: 8px;
      flex-shrink: 0;
    }
  }

  .gif-tip {
    font-size: 12px;
    color: var(--text-secondary);
    line-height: 1.5;
  }

  .quality-control {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .album-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
    flex-shrink: 0;
  }

  // 通用列表样式（与 NpkManager NPK 列表完全一致）
  .item-list {
    display: flex;
    flex-direction: column;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 248, 248, 0.95) 50%, rgba(255, 255, 255, 0.95) 100%);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.6);
    border-radius: 14px;
    padding: 6px;
    position: relative;
    overflow: hidden;

    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
      transition: left 0.5s ease;
      pointer-events: none;
      z-index: 0;
    }

    &:hover::before {
      left: 100%;
    }

    > * {
      position: relative;
      z-index: 1;
    }
  }

  .list-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    margin: 2px 0;
    background: rgba(255, 255, 255, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.4);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);

    &:hover {
      background: rgba(255, 255, 255, 0.85);
      border-color: rgba(251, 113, 133, 0.3);
      transform: translateX(4px);
      box-shadow: 0 4px 16px rgba(251, 113, 133, 0.15), 0 0 20px rgba(251, 113, 133, 0.1);
    }

    // 选中状态（复选框勾选）
    &.selected {
      background: rgba(251, 113, 133, 0.12);
      border-left: 3px solid var(--accent-color);
    }

    // 聚焦状态（键盘导航）
    &:focus {
      outline: none;
      background: var(--bg-tertiary);
      box-shadow: inset 0 0 0 2px rgba(251, 113, 133, 0.5);
    }

    // 活跃状态（点击行预览）
    &.active {
      background: rgba(251, 113, 133, 0.08);

      .item-name {
        color: var(--accent-dark);
        font-weight: 600;
      }
    }

    .item-checkbox {
      flex-shrink: 0;
      width: 16px;
      height: 16px;
      cursor: pointer;
      accent-color: var(--accent-color);
    }

    .item-name {
      flex: 1;
      font-size: 13px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      cursor: pointer;
      display: block;

      &:hover {
        color: var(--accent-color);
      }
    }

    .item-count {
      font-size: 11px;
      color: var(--text-muted);
      flex-shrink: 0;
      margin-left: 8px;
    }

    .item-delete {
      flex-shrink: 0;
      color: var(--text-muted);
      cursor: pointer;

      &:hover {
        color: var(--el-color-danger);
      }
    }
  }

  // 步骤内容
  .step-content {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;

    .step-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
      flex-shrink: 0;

      .step-title {
        font-size: 14px;
        font-weight: 500;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 200px;
      }
    }

    .step-scrollbar {
      flex: 1;
      min-height: 0;
    }
  }

  // 选择 Albums 区域
  .album-select-area {
    flex: 1;
    min-height: 0;
    overflow: hidden;
    position: relative;

    .album-list-scroll {
      height: 100%;
    }
  }

  .step-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px solid var(--border-color);
    flex-shrink: 0;
    position: relative;
    z-index: 10;
  }

  // 已选列表
  .selected-section {
    flex: 1;
    min-height: 0;
    overflow: hidden;

    .selected-scroll {
      height: 100%;
    }
  }

  .export-actions {
    display: flex;
    align-items: center;
    margin-top: auto;
    padding-top: 12px;
    border-top: 1px solid var(--border-color);
    flex-shrink: 0;
  }

  // 画布预览
  .preview-card {
    .preview-empty {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      color: var(--text-muted);
      font-size: 14px;
    }

    .preview-content {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
    }

    .preview-toolbar {
      padding: 8px 0;
      border-bottom: 1px solid var(--border-color);
      margin-bottom: 8px;
    }
  }

  .canvas-container {
    display: flex;
    align-items: center;
    justify-content: center;
    background:
      linear-gradient(45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #fef0f0 75%),
      linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
      #fdf7f7;
    background-size: 16px 16px;
    background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    min-height: 180px;
    max-height: 280px;
    overflow: hidden;
    margin-bottom: 12px;
    flex-shrink: 0;

    .canvas-image {
      max-width: 100%;
      max-height: 280px;
      object-fit: contain;
      image-rendering: pixelated;
    }

    &.light {
      background:
        linear-gradient(45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #fef0f0 75%),
        linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
        #ffffff;
      background-size: 16px 16px;
      background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    }

    &.dark {
      background:
        linear-gradient(45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(-45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #2d1f1f 75%),
        linear-gradient(-45deg, transparent 75%, #2d1f1f 75%),
        #151010;
      background-size: 16px 16px;
      background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
    }
  }

  // 帧列表区域
  .frame-section {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;

    .frame-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 8px;
      font-size: 13px;
      font-weight: 500;
      color: var(--text-primary);
      flex-shrink: 0;
    }

    .frame-scroll {
      flex: 1;
      min-height: 0;
    }
  }

  .frame-list {
    display: flex;
    flex-direction: column;
    gap: 3px;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 248, 248, 0.95) 50%, rgba(255, 255, 255, 0.95) 100%);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.6);
    border-radius: 14px;
    padding: 6px;
    position: relative;
    overflow: hidden;

    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
      transition: left 0.5s ease;
      pointer-events: none;
      z-index: 0;
    }

    &:hover::before {
      left: 100%;
    }

    > * {
      position: relative;
      z-index: 1;
    }
  }

  .frame-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    background: rgba(255, 255, 255, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.4);
    border-radius: 10px;
    cursor: pointer;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

    &:hover {
      border-color: rgba(251, 113, 133, 0.3);
      background: rgba(255, 255, 255, 0.85);
      transform: translateX(2px);
      box-shadow: 0 4px 16px rgba(251, 113, 133, 0.15), 0 0 20px rgba(251, 113, 133, 0.1);
    }

    &.active {
      border-color: rgba(251, 113, 133, 0.5);
      background: rgba(251, 113, 133, 0.12);

      .frame-number {
        color: var(--accent-dark);
        font-weight: 600;
      }
    }

    .frame-number {
      font-size: 12px;
      font-weight: 500;
      color: var(--accent-color);
      min-width: 22px;
      font-family: monospace;
    }

    .frame-link {
      font-size: 11px;
      font-family: monospace;
      white-space: nowrap;
      flex: 1;
    }

    .frame-type {
      font-size: 11px;
      width: 55px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-pos {
      font-size: 11px;
      width: 48px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-size {
      font-size: 11px;
      width: 55px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-frame {
      font-size: 11px;
      width: 55px;
      font-family: monospace;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-detail {
      font-size: 11px;
      color: var(--text-muted);
      white-space: nowrap;
    }

    .frame-tag {
      margin-left: auto;
      flex-shrink: 0;
    }
  }

  .empty-tip {
    text-align: center;
    padding: 30px 20px;
    color: var(--text-muted);
    font-size: 13px;
  }

  // 左侧设置卡片
  .left-settings-card {
    :deep(.el-card__body) {
      padding: 12px;
    }
  }

  .settings-container {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  // 导出设置部分 - 缩小
  .export-settings-section {
    flex-shrink: 0;
    :deep(.el-form-item) {
      margin-bottom: 12px;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }

  // 分隔线
  .section-divider {
    height: 1px;
    background: var(--border-color);
    margin: 16px 0;
    flex-shrink: 0;
  }

  // 版本转换部分
  .convert-section {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
  }

  .section-title {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    font-weight: 500;
    color: var(--text-primary);
    margin-bottom: 12px;
  }

  .file-count-tip {
    font-size: 11px;
    color: var(--el-color-success);
    margin-top: 4px;
  }

  .convert-progress {
    width: 100%;

    .convert-status {
      display: flex;
      justify-content: space-between;
      margin-top: 4px;
      font-size: 11px;
      color: var(--text-muted);
    }
  }
}

html.dark {
  .batch-export {
    .item-list {
      background: linear-gradient(135deg, rgba(30, 18, 18, 0.95) 0%, rgba(40, 25, 25, 0.95) 50%, rgba(30, 18, 18, 0.95) 100%);
      border-color: rgba(80, 60, 60, 0.4);

      &::before {
        background: linear-gradient(90deg, transparent, rgba(251, 113, 133, 0.2), transparent);
      }
    }

    .list-item {
      background: rgba(40, 25, 25, 0.6);
      border-color: rgba(80, 60, 60, 0.4);

      &:hover {
        background: rgba(50, 30, 30, 0.85);
        border-color: rgba(251, 113, 133, 0.5);
        box-shadow: 0 4px 16px rgba(251, 113, 133, 0.2), 0 0 20px rgba(251, 113, 133, 0.15);
      }

      &.selected {
        background: rgba(251, 113, 133, 0.2);
      }

      &.active {
        background: rgba(251, 113, 133, 0.15);
      }
    }

    .frame-list {
      background: linear-gradient(135deg, rgba(30, 18, 18, 0.95) 0%, rgba(40, 25, 25, 0.95) 50%, rgba(30, 18, 18, 0.95) 100%);
      border-color: rgba(80, 60, 60, 0.4);

      &::before {
        background: linear-gradient(90deg, transparent, rgba(251, 113, 133, 0.2), transparent);
      }
    }

    .frame-item {
      background: rgba(40, 25, 25, 0.6);
      border-color: rgba(80, 60, 60, 0.4);

      &:hover {
        background: rgba(50, 30, 30, 0.85);
        border-color: rgba(251, 113, 133, 0.5);
        box-shadow: 0 4px 16px rgba(251, 113, 133, 0.2), 0 0 20px rgba(251, 113, 133, 0.15);
      }
    }
  }
}
</style>
