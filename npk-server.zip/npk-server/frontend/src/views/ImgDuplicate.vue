<script setup lang="ts">
import { ref, watch, onMounted, onUnmounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router'
import { useCacheStore } from '@/stores/cache'
import {
  Search, View, FolderOpened, Picture, Edit, DocumentCopy, VideoPlay, VideoPause, RefreshRight, Sunny, Moon, Monitor
} from '@element-plus/icons-vue'
import { libraryApi, albumApi, imgCacheApi } from '@/api/index'
import TextHighlight from '@/components/TextHighlight.vue'
import { ElMessage } from 'element-plus'
import { renderImageToCanvas } from '@/utils/canvas'
import { debounce } from 'lodash-es'

const { t } = useI18n()
const router = useRouter()
const cacheStore = useCacheStore()

// 防抖搜索
const debouncedFilter = debounce(() => {
  filterGroups()
}, 300)

// 搜索
const searchQuery = ref('')
const loading = ref(false)

// 数据
interface DuplicateGroup {
  album_path: string
  count: number
  items: DuplicateItem[]
}

interface DuplicateItem {
  npk_name: string
  npk_id: number
  album_path: string
  album_name: string
  sprite_count: number
  version: number | string
}

const duplicateGroups = ref<DuplicateGroup[]>([])
const filteredGroups = ref<DuplicateGroup[]>([])
const totalCount = ref(0)
const hasSearched = ref(false)

// 预览相关
const previewItem = ref<DuplicateItem | null>(null)
const previewUrl = ref('')
const previewLoading = ref(false)
const frameList = ref<any[]>([])
const frameListLoading = ref(false)
const selectedFrameIndex = ref<number>(0)
const albumVersion = ref<string>('')
const previewCanvas = ref<HTMLCanvasElement | null>(null)

// 去除黑色背景
const removeBlackBg = ref(false)
const canvasBgMode = ref<'auto' | 'light' | 'dark'>('auto')

function toggleCanvasBgMode() {
  if (canvasBgMode.value === 'auto') {
    canvasBgMode.value = 'light'
  } else if (canvasBgMode.value === 'light') {
    canvasBgMode.value = 'dark'
  } else {
    canvasBgMode.value = 'light'
  }
}

// 帧播放相关
const isPlaying = ref(false)
let playInterval: ReturnType<typeof setInterval> | null = null
const PLAY_INTERVAL = 200 // 0.2s 每帧

// IMG 缓存预加载
const preloadedImgKeys = ref<Set<string>>(new Set())

// 渲染图片到 canvas，可选去除黑色背景
async function renderToCanvas(url: string, removeBlack: boolean) {
  const canvas = previewCanvas.value
  if (!canvas) return

  try {
    await renderImageToCanvas(canvas, url, removeBlack)
  } catch {
    previewUrl.value = ''
  }
}

// 加载重复数据
async function fetchDuplicates() {
  loading.value = true
  hasSearched.value = true
  try {
    const res = await libraryApi.getDuplicates() as any
    const data = res.data || []
    
    // 按 album_path 分组
    const groups: Record<string, DuplicateGroup> = {}
    data.forEach((item: any) => {
      const path = item.album_path || ''
      if (!groups[path]) {
        groups[path] = {
          album_path: path,
          count: 0,
          items: []
        }
      }
      groups[path].items.push({
        npk_name: item.npk_name || '',
        npk_id: item.npk_id || 0,
        album_path: item.album_path || '',
        album_name: item.album_name || '',
        sprite_count: item.sprite_count || 0,
        version: item.version || ''
      })
      groups[path].count++
    })
    
    duplicateGroups.value = Object.values(groups).sort((a, b) => b.count - a.count)
    filterGroups()
    totalCount.value = duplicateGroups.value.length

    // 预加载前3个组的第一个 IMG 缓存
    const topItems = duplicateGroups.value.slice(0, 3).map(g => g.items[0]).filter(Boolean)
    preloadTopResults(topItems)
  } catch (e: any) {
    console.error('Failed to load duplicate data:', e)
    duplicateGroups.value = []
    filteredGroups.value = []
    totalCount.value = 0
  } finally {
    loading.value = false
  }
}

// 过滤分组
function filterGroups() {
  if (!searchQuery.value.trim()) {
    filteredGroups.value = duplicateGroups.value
    return
  }
  const query = searchQuery.value.toLowerCase()
  filteredGroups.value = duplicateGroups.value.filter(group => 
    group.album_path.toLowerCase().includes(query) ||
    group.items.some(item => item.npk_name.toLowerCase().includes(query))
  )
}

// 搜索输入（防抖）
function onSearchInput() {
  debouncedFilter()
}

function onSearchClear() {
  searchQuery.value = ''
  filterGroups()
}

// 预加载前几个搜索结果的 IMG 缓存
async function preloadTopResults(items: DuplicateItem[]) {
  for (const item of items) {
    const key = `${item.npk_name}:${item.album_path}`
    if (!preloadedImgKeys.value.has(key)) {
      try {
        await imgCacheApi.load(item.npk_name, item.album_path)
        preloadedImgKeys.value.add(key)
      } catch (e) {
        console.warn('Preload IMG cache failed:', item.npk_name, item.album_path, e)
      }
    }
  }
}

function locateNpk(npkName: string) {
  router.push({ path: '/npk', query: { name: npkName } })
}

function viewAnimation(item: DuplicateItem) {
  router.push({ path: '/animation', query: { npk: item.npk_name, album: item.album_path } })
}

function editImg(item: DuplicateItem) {
  router.push({ path: '/preview', query: { npk: item.npk_name, album: item.album_path } })
}

// 点击项预览
async function selectPreview(item: DuplicateItem) {
  if (previewItem.value && previewItem.value.album_path === item.album_path && previewItem.value.npk_name === item.npk_name) return
  
  stopFramePlay()
  
  previewItem.value = item
  previewLoading.value = true
  previewUrl.value = ''
  frameListLoading.value = true
  selectedFrameIndex.value = 0

  const key = `${item.npk_name}:${item.album_path}`
  if (!preloadedImgKeys.value.has(key)) {
    try {
      await imgCacheApi.load(item.npk_name, item.album_path)
      preloadedImgKeys.value.add(key)
    } catch (e) {
      console.warn('Preload IMG cache failed:', key, e)
    }
  }

  try {
    const url = `${albumApi.getPreviewUrl(item.npk_name, item.album_path)}&frame=0`
    previewUrl.value = url
    const res = await albumApi.getFrames(item.npk_name, item.album_path)
    frameList.value = res.data?.frames || []
    albumVersion.value = res.data?.version || ''
    setTimeout(() => renderToCanvas(url, removeBlackBg.value), 0)
  } catch {
    frameList.value = []
    albumVersion.value = ''
    previewUrl.value = ''
  } finally {
    previewLoading.value = false
    frameListLoading.value = false
  }
}

function onFrameClick(frame: any) {
  if (previewItem.value) {
    selectedFrameIndex.value = frame.index
    const url = `${albumApi.getPreviewUrl(previewItem.value.npk_name, previewItem.value.album_path)}&frame=${frame.index}`
    previewUrl.value = url
    setTimeout(() => renderToCanvas(url, removeBlackBg.value), 0)
  }
}

// 监听去黑底开关变化
watch(removeBlackBg, (newVal) => {
  if (previewUrl.value) {
    renderToCanvas(previewUrl.value, newVal)
  }
})

// 复制路径到剪贴板
function copyPath() {
  if (!previewItem.value) return
  const path = previewItem.value.album_path
  navigator.clipboard.writeText(path).then(() => {
    ElMessage.success(t('imgDuplicate.pathCopied'))
  }).catch(() => {
    ElMessage.error(t('common.copyFailed'))
  })
}

// 复制 NPK 名到剪贴板
function copyNpkName() {
  if (!previewItem.value) return
  const npkName = previewItem.value.npk_name
  navigator.clipboard.writeText(npkName).then(() => {
    ElMessage.success(t('imgDuplicate.npkNameCopied'))
  }).catch(() => {
    ElMessage.error(t('common.copyFailed'))
  })
}

// 帧播放控制
function toggleFramePlay() {
  if (isPlaying.value) {
    stopFramePlay()
  } else {
    startFramePlay()
  }
}

function startFramePlay() {
  if (frameList.value.length === 0 || !previewItem.value) return
  isPlaying.value = true
  playInterval = setInterval(() => {
    const nextIndex = selectedFrameIndex.value + 1
    if (nextIndex < frameList.value.length) {
      const frame = frameList.value[nextIndex]
      onFrameClick(frame)
    } else {
      const frame = frameList.value[0]
      onFrameClick(frame)
    }
  }, PLAY_INTERVAL)
}

function stopFramePlay() {
  isPlaying.value = false
  if (playInterval) {
    clearInterval(playInterval)
    playInterval = null
  }
}

// 获取版本标签样式类
function getVersionClass(version: number | string): string {
  const versionStr = version ? String(version) : ''
  const normalizedVersion = versionStr.startsWith('V') ? versionStr : `V${versionStr}`
  const versionMap: Record<string, string> = {
    'V1': 'v1',
    'V2': 'v2',
    'V3': 'v3',
    'V4': 'v4',
    'V5': 'v5',
    'V6': 'v6'
  }
  return versionMap[normalizedVersion] || 'other'
}

// 格式化版本显示
function formatVersion(version: number | string): string {
  if (!version && version !== 0) return 'IMG'
  const versionStr = String(version)
  return versionStr.startsWith('V') ? versionStr : `V${versionStr}`
}

// 页面加载时获取重复数据
onMounted(() => {
  fetchDuplicates()
})

// 页面卸载时释放所有预加载的缓存
onUnmounted(() => {
  stopFramePlay()
  for (const key of preloadedImgKeys.value) {
    const [npk, ...pathParts] = key.split(':')
    const path = pathParts.join(':')
    imgCacheApi.release(npk, path).catch(() => {})
  }
  preloadedImgKeys.value.clear()
  // 释放页面缓存
  cacheStore.clearNpkListCache()
  cacheStore.clearAlbumListCache()
})
</script>

<template>
  <div class="library-view">
    <div class="page-header">
      <h2 class="page-title">{{ t('imgDuplicate.title') }}</h2>
      <el-tag type="warning" size="small">{{ totalCount }} {{ t('imgDuplicate.duplicatePaths') }}</el-tag>
    </div>

    <!-- 搜索栏 -->
    <div class="search-bar">
      <el-input
        v-model="searchQuery"
        :placeholder="t('imgDuplicate.searchPlaceholder')"
        :prefix-icon="Search"
        clearable
        @input="onSearchInput"
        @clear="onSearchClear"
      />
      <el-button :icon="RefreshRight" @click="fetchDuplicates" :loading="loading">{{ t('common.refresh') }}</el-button>
    </div>

    <div class="content-wrapper">
    <el-row :gutter="16" class="content-row">
      <!-- 左侧: 重复列表 -->
      <el-col :span="14">
        <el-card class="table-card">
          <template #header>
            <span v-if="hasSearched">{{ t('imgDuplicate.totalDuplicates', { count: filteredGroups.length }) }}</span>
            <span v-else>{{ t('imgDuplicate.loading') }}</span>
          </template>

          <el-scrollbar v-loading="loading" class="result-scroll">
            <div v-if="filteredGroups.length === 0 && !loading" class="empty-tip">
              <p v-if="hasSearched">{{ t('imgDuplicate.noDuplicates') }}</p>
              <p v-else>{{ t('imgDuplicate.loadingData') }}</p>
            </div>
            <div class="result-list">
              <div
                v-for="group in filteredGroups"
                :key="group.album_path"
                class="group-item"
              >
                <!-- 重复路径标题 -->
                <div class="group-header">
                  <TextHighlight :text="group.album_path" :keyword="searchQuery" />
                  <el-tag size="small" type="danger" class="group-count">{{ group.count }} {{ t('imgDuplicate.duplicateCount') }}</el-tag>
                </div>
                
                <!-- 该路径下的所有 NPK -->
                <div class="group-items">
                  <div
                    v-for="item in group.items"
                    :key="item.npk_name + '/' + item.album_path"
                    class="list-item"
                    :class="{ active: previewItem?.npk_name === item.npk_name && previewItem?.album_path === item.album_path }"
                    @click="selectPreview(item)"
                  >
                    <div class="item-row">
                      <div class="item-info">
                        <el-tag size="small" type="info" class="item-npk-tag">{{ item.npk_name }}</el-tag>
                      </div>
                      <el-tag size="small" class="item-tag count-tag">{{ item.sprite_count }} {{ t('imgBrowser.frames') }}</el-tag>
                      <el-tag
                        size="small"
                        :class="['item-tag', 'version-tag', getVersionClass(item.version)]"
                      >
                        {{ formatVersion(item.version) }}
                      </el-tag>
                      <el-button size="small" type="primary" link @click.stop="editImg(item)">
                        <el-icon><Edit /></el-icon>
                      </el-button>
                      <el-button size="small" type="primary" link @click.stop="locateNpk(item.npk_name)">
                        <el-icon><FolderOpened /></el-icon>
                      </el-button>
                      <el-button size="small" type="primary" link @click.stop="viewAnimation(item)">
                        <el-icon><View /></el-icon>
                      </el-button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </el-scrollbar>
        </el-card>
      </el-col>

      <!-- 右侧: 画布预览 + 帧列表 -->
      <el-col :span="10">
        <el-card class="preview-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('imgDuplicate.canvasPreview') }}</span>
            </div>
          </template>

          <div v-if="!previewItem" class="preview-empty">
            <el-icon :size="48"><Picture /></el-icon>
            <span>{{ t('imgDuplicate.clickToPreview') }}</span>
          </div>

          <div v-else class="preview-content">
            <div class="preview-path" v-if="previewItem">
              <div class="path-row">
                <span class="path-label">{{ t('imgDuplicate.pathLabel') }}</span>
                <span class="path-text">{{ previewItem.album_path }}</span>
                <el-button
                  type="primary"
                  link
                  size="small"
                  :icon="DocumentCopy"
                  @click="copyPath"
                  :title="t('imgDuplicate.copyPathTitle')"
                />
              </div>
              <div class="path-row">
                <span class="path-label">{{ t('imgDuplicate.npkLabel') }}</span>
                <span class="path-text">{{ previewItem.npk_name }}</span>
                <el-button
                  type="primary"
                  link
                  size="small"
                  :icon="DocumentCopy"
                  @click="copyNpkName"
                  :title="t('imgDuplicate.copyNpkNameTitle')"
                />
              </div>
              <div class="control-row">
                <el-checkbox v-model="removeBlackBg" size="small">{{ t('imgDuplicate.removeBlackBg') }}</el-checkbox>
                <el-button 
                  size="small" 
                  :icon="canvasBgMode === 'auto' ? Monitor : canvasBgMode === 'light' ? Sunny : Moon" 
                  @click="toggleCanvasBgMode" 
                  :title="canvasBgMode === 'auto' ? t('imgDuplicate.auto') : canvasBgMode === 'light' ? t('imgDuplicate.light') : t('imgDuplicate.dark')"
                />
              </div>
            </div>
            <div class="canvas-container" :class="canvasBgMode" v-loading="previewLoading">
              <canvas v-if="previewUrl" ref="previewCanvas" class="canvas-image"></canvas>
              <div v-if="!previewUrl && !previewLoading && previewItem" class="preview-error">{{ t('imgDuplicate.imageLoadFailed') }}</div>
            </div>

            <div class="frame-section">
              <div class="frame-section-header">
                <div class="frame-header-left">
                  <span>{{ t('imgDuplicate.frameList') }}</span>
                  <el-tag size="small" v-if="frameList.length > 0">{{ frameList.length }}</el-tag>
                </div>
                <el-button
                  v-if="frameList.length > 0"
                  :icon="isPlaying ? VideoPause : VideoPlay"
                  size="small"
                  :type="isPlaying ? 'warning' : 'primary'"
                  @click="toggleFramePlay"
                >
                  {{ isPlaying ? t('common.stop') : t('common.play') }}
                </el-button>
              </div>
              <el-scrollbar v-if="frameList.length > 0" class="frame-scroll">
                <div class="frame-list">
                  <div
                    v-for="frame in frameList"
                    :key="frame.index"
                    class="frame-item"
                    :class="{ active: selectedFrameIndex === frame.index }"
                    @click="onFrameClick(frame)"
                  >
                    <span class="frame-number">{{ frame.index }}</span>
                    <template v-if="frame.is_link">
                      <span class="frame-link">
                        LINK
                        <template v-if="frame.link_status === 'normal'"> {{ t('imgDuplicate.linkRef') }}：{{ frame.target_index }}</template>
                        <template v-else-if="frame.link_status === 'null'"> {{ t('imgDuplicate.nullPointer') }}</template>
                        <template v-else-if="frame.link_status === 'circular'"> {{ t('imgDuplicate.circularRef') }}</template>
                        <template v-else> {{ t('imgDuplicate.linkRef') }}：{{ frame.target_index }}</template>
                      </span>
                      <el-tag size="small" :type="frame.link_status === 'normal' ? 'warning' : 'danger'" class="frame-tag">
                        <template v-if="frame.link_status === 'normal'">Link</template>
                        <template v-else-if="frame.link_status === 'null'">Error</template>
                        <template v-else-if="frame.link_status === 'circular'">Circular</template>
                        <template v-else>Link</template>
                      </el-tag>
                    </template>
                    <template v-else>
                      <span class="frame-type">{{ frame.type_name || (albumVersion || 'IMG') }}</span>
                      <span class="frame-pos">{{ frame.x }},{{ frame.y }}</span>
                      <span class="frame-size">{{ frame.width }}×{{ frame.height }}</span>
                      <span class="frame-frame">{{ frame.frame_width }}×{{ frame.frame_height }}</span>
                    </template>
                  </div>
                </div>
              </el-scrollbar>
              <div v-else v-loading="frameListLoading" class="empty-tip" style="padding: 20px">
                {{ frameListLoading ? t('imgDuplicate.loading') : t('imgDuplicate.noFrameData') }}
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.library-view {
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 0;
  box-sizing: border-box;

  .page-header {
    flex-shrink: 0;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 12px;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }
  }

  .search-bar {
    flex-shrink: 0;
    margin-bottom: 16px;
    display: flex;
    gap: 12px;

    .el-input {
      max-width: 500px;
    }
  }

  .content-wrapper {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
  }

  .content-row {
    flex: 1;
    min-height: 0;
    margin: 0;

    :deep(.el-col) {
      height: 100%;

      .el-card {
        height: 100%;
        display: flex;
        flex-direction: column;

        :deep(.el-card__body) {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
        }
      }
    }
  }

  .table-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    transition: transform 0.2s ease;
    position: relative;

    &:hover {
      transform: translateY(-2px);
      border-color: rgba(251, 113, 133, 0.3);
    }
  }

  .result-scroll {
    flex: 1;
    min-height: 0;

    :deep(.el-scrollbar__wrap) {
      overflow-x: auto !important;
      overflow-y: auto !important;
    }

    :deep(.el-scrollbar__bar.is-horizontal) {
      bottom: 0;
    }

    :deep(.el-scrollbar__thumb) {
      background: var(--bg-tertiary);
    }
  }

  .result-list {
    display: flex;
    flex-direction: column;
    overflow-x: auto;

    &::-webkit-scrollbar {
      height: 4px;
    }
    &::-webkit-scrollbar-thumb {
      background: var(--bg-tertiary);
      border-radius: 2px;
    }
  }

  .group-item {
    border-bottom: 1px solid var(--border-color);
    padding: 8px 0;

    &:last-child {
      border-bottom: none;
    }
  }

  .group-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 4px 12px;
    background: var(--bg-tertiary);
    border-radius: 4px;
    margin-bottom: 4px;
    font-weight: 500;
    color: var(--text-primary);
    font-size: 13px;

    .group-count {
      flex-shrink: 0;
      margin-left: 8px;
    }
  }

  .group-items {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 4px 0;
  }

  .list-item {
    position: relative;
    padding: 12px 16px;
    cursor: pointer;
    transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
    min-width: max-content;
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: 14px;

    &:hover {
      background: var(--bg-secondary);
      border-color: rgba(251, 113, 133, 0.4);
      transform: translateX(6px) translateY(-2px);
    }

    &.active {
      background: rgba(251, 113, 133, 0.12);
      border-color: rgba(251, 113, 133, 0.45);
      border-left: 3px solid var(--accent-color);
      padding-left: 13px;
    }

    .item-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .item-info {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 2px;

      .item-npk-tag {
        font-size: 10px;
        height: auto;
        padding: 1px 4px;
      }
    }

    .item-tag {
      flex-shrink: 0;

      &.count-tag {
        background: rgba(122, 205, 246, 0.15);
        color: var(--accent-color);
        border-color: transparent;
      }

      &.version-tag {
        border-color: transparent;

        &.v1 {
          background: rgba(128, 0, 128, 0.15);
          color: var(--text-secondary);
        }

        &.v2 {
          background: rgba(122, 205, 246, 0.15);
          color: var(--accent-color);
        }

        &.v3 {
          background: rgba(0, 128, 128, 0.15);
          color: var(--text-secondary);
        }

        &.v4 {
          background: rgba(103, 194, 58, 0.15);
          color: var(--text-secondary);
        }

        &.v5 {
          background: rgba(230, 162, 60, 0.15);
          color: var(--accent-color);
        }

        &.v6 {
          background: rgba(245, 108, 108, 0.15);
          color: var(--text-secondary);
        }

        &.other {
          background: rgba(144, 147, 153, 0.15);
          color: var(--text-secondary);
        }
      }
    }
  }

  .preview-card {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    transition: transform 0.2s ease;
    position: relative;

    &:hover {
      transform: translateY(-2px);
      border-color: rgba(251, 113, 133, 0.3);
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .preview-empty {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      color: var(--text-muted);
      font-size: 14px;
    }

    .preview-content {
      flex: 1;
      min-height: 0;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      max-height: calc(100vh - 220px);
    }

    .preview-path {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-bottom: 8px;
      padding: 8px;
      background: var(--bg-tertiary);
      border-radius: 4px;
      border: 1px solid var(--border-color);

      .path-row {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        flex-wrap: wrap;
        width: 100%;

        .path-label {
          font-size: 12px;
          color: var(--text-muted);
          flex-shrink: 0;
          min-width: 40px;
        }

        .path-text {
          font-size: 12px;
          color: var(--text-primary);
          flex: 1;
          min-width: 0;
          word-break: break-all;
          overflow-wrap: break-word;
          font-family: monospace;
        }
      }

      .control-row {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-shrink: 0;
      }
    }
  }

  .canvas-container {
    display: flex;
    align-items: center;
    justify-content: center;
    background:
      linear-gradient(45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
      linear-gradient(45deg, transparent 75%, #fef0f0 75%),
      linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
      #fdf7f7;
    background-size: 20px 20px;
    background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    height: 280px;
    overflow: hidden;
    margin-bottom: 12px;
    flex-shrink: 0;
    position: relative;

    .canvas-image {
      max-width: 100%;
      max-height: 280px;
      object-fit: contain;
      image-rendering: pixelated;
    }

    .preview-error {
      color: var(--el-color-danger);
      font-size: 13px;
    }

    &.light {
      background:
        linear-gradient(45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(-45deg, #fef0f0 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #fef0f0 75%),
        linear-gradient(-45deg, transparent 75%, #fef0f0 75%),
        #ffffff;
      background-size: 20px 20px;
      background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    }

    &.dark {
      background:
        linear-gradient(45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(-45deg, #2d1f1f 25%, transparent 25%),
        linear-gradient(45deg, transparent 75%, #2d1f1f 75%),
        linear-gradient(-45deg, transparent 75%, #2d1f1f 75%),
        #151010;
      background-size: 20px 20px;
      background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
    }
  }

  .frame-section {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    .frame-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 8px;
      font-size: 13px;
      font-weight: 500;
      color: var(--text-primary);
      flex-shrink: 0;

      .frame-header-left {
        display: flex;
        align-items: center;
        gap: 8px;
      }
    }

    .frame-scroll {
      flex: 1;
      min-height: 0;
      overflow-y: auto;
      height: 0;

      :deep(.el-scrollbar) {
        height: 100%;
      }
      :deep(.el-scrollbar__wrap) {
        overflow-y: auto !important;
      }
    }
  }

  .frame-list {
    display: flex;
    flex-direction: column;
    gap: 3px;
    padding-bottom: 8px;
  }

  .frame-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    background: var(--bg-tertiary);
    border-radius: 12px;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.2s ease;
    font-size: 12px;

    &:hover {
      border-color: rgba(251, 113, 133, 0.3);
      background: var(--bg-secondary);
      transform: translateX(2px);
    }

    &.active {
      border-color: rgba(251, 113, 133, 0.5);
      background: rgba(251, 113, 133, 0.12);

      .frame-number {
        color: var(--accent-dark);
        font-weight: 600;
      }
    }

    .frame-number {
      font-size: 12px;
      font-weight: 500;
      color: var(--text-primary);
      min-width: 32px;
    }

    .frame-link {
      font-size: 11px;
      color: var(--text-muted);
    }

    .frame-type {
      font-size: 11px;
      color: var(--text-secondary);
      margin-right: 8px;
    }

    .frame-pos {
      font-size: 11px;
      color: var(--text-muted);
      margin-right: 8px;
    }

    .frame-size {
      font-size: 11px;
      color: var(--text-muted);
    }

    .frame-tag {
      margin-left: auto;
      flex-shrink: 0;
    }
  }

  .empty-tip {
    text-align: center;
    padding: 30px 20px;
    color: var(--text-muted);
    font-size: 13px;
  }
}


</style>
