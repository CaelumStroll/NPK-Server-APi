<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { marked } from 'marked'
import { getDocCategories, getDocById, type DocItem } from '@/docs-config'
const docCategories = computed(() => getDocCategories())
import { Document, Guide, Box, Edit, Search, Clock } from '@element-plus/icons-vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const route = useRoute()
const router = useRouter()

const currentDoc = ref<DocItem | null>(null)
const docContent = ref('')
const loading = ref(false)

const iconMap: Record<string, any> = {
  Guide,
  Box,
  Edit,
  Search,
  Clock,
  Document
}

const selectedDocId = ref('')

const initDoc = async () => {
  const docId = route.query.id as string
  if (docId) {
    await selectDoc(docId)
  } else {
    await selectDoc('quick-start')
  }
}

const selectDoc = async (docId: string) => {
  selectedDocId.value = docId
  const doc = getDocById(docId)
  if (!doc) {
    docContent.value = `# ${t('docView.notFound')}`
    return
  }

  currentDoc.value = doc
  loading.value = true

  try {
    const response = await fetch(`/docs/${doc.file}`)
    const text = await response.text()
    docContent.value = marked(text) as string
  } catch (error) {
    docContent.value = `<h1>${doc.title}</h1><p>${t('docView.loadError')}</p>`
  } finally {
    loading.value = false
  }
}

const handleMenuSelect = (index: string) => {
  router.push({ path: '/docs', query: { id: index } })
}

watch(() => route.query.id, async (newId, oldId) => {
  if (newId && newId !== oldId) {
    await selectDoc(newId as string)
  }
})

onMounted(() => {
  initDoc()
})
</script>

<template>
  <div class="doc-view">
    <aside class="doc-sidebar">
      <div class="sidebar-header">
        <h2 class="sidebar-title">{{ t('docView.title') }}</h2>
      </div>
      <el-menu
        :default-active="selectedDocId"
        class="doc-menu"
        @select="handleMenuSelect"
      >
        <el-sub-menu
          v-for="category in docCategories"
          :key="category.id"
          :index="category.id"
        >
          <template #title>
            <el-icon>
              <component :is="iconMap[category.icon] || Document" />
            </el-icon>
            <span>{{ category.name }}</span>
          </template>
          <el-menu-item
            v-for="doc in category.docs"
            :key="doc.id"
            :index="doc.id"
          >
            <div class="doc-item">
              <span class="doc-title">{{ doc.title }}</span>
              <span v-if="doc.description" class="doc-desc">{{ doc.description }}</span>
            </div>
          </el-menu-item>
        </el-sub-menu>
      </el-menu>
    </aside>

    <main class="doc-main">
      <div v-if="currentDoc" class="doc-header">
        <h1 class="doc-title">{{ currentDoc.title }}</h1>
        <p v-if="currentDoc.description" class="doc-description">{{ currentDoc.description }}</p>
      </div>

      <el-scrollbar class="doc-content-wrapper">
        <div
          v-loading="loading"
          class="doc-content markdown-body"
          v-html="docContent"
        />
      </el-scrollbar>
    </main>
  </div>
</template>

<style lang="scss" scoped>
.doc-view {
  display: flex;
  height: calc(100vh - 120px);
  background: var(--bg-primary);
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid var(--border-color);
}

.doc-sidebar {
  width: 300px;
  min-width: 300px;
  background: var(--bg-secondary);
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .sidebar-header {
    padding: 20px;
    border-bottom: 1px solid var(--border-color);

    .sidebar-title {
      margin: 0;
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary);
    }
  }

  .doc-menu {
    flex: 1;
    overflow-y: auto;
    border-right: none;
    background: transparent;

    :deep(.el-menu) {
      background: transparent;
    }

    :deep(.el-sub-menu__title) {
      color: var(--text-primary);
      font-weight: 500;

      &:hover {
        background: var(--bg-tertiary);
      }
    }

    :deep(.el-menu-item) {
      color: var(--text-secondary);
      background: transparent;
      height: auto;
      padding: 10px 20px 10px 50px;

      &:hover {
        background: var(--bg-tertiary);
        color: var(--text-primary);
      }

      &.is-active {
        background: var(--color-primary-light-9);
        color: var(--color-primary);
        border-right: 3px solid var(--color-primary);
      }
    }
  }

  .doc-item {
    display: flex;
    flex-direction: column;
    gap: 4px;

    .doc-title {
      font-size: 14px;
      font-weight: 500;
    }

    .doc-desc {
      font-size: 12px;
      color: var(--text-muted);
    }
  }
}

.doc-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 30px;
  overflow: hidden;

  .doc-header {
    margin-bottom: 24px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);

    .doc-title {
      margin: 0 0 8px 0;
      font-size: 28px;
      font-weight: 600;
      color: var(--text-primary);
    }

    .doc-description {
      margin: 0;
      font-size: 14px;
      color: var(--text-secondary);
    }
  }

  .doc-content-wrapper {
    flex: 1;
    background: var(--bg-tertiary);
    border-radius: 8px;
    padding: 24px;
  }

  .doc-content {
    line-height: 1.8;
  }
}

.markdown-body {
  color: var(--text-primary);

  :deep(h1) {
    font-size: 32px;
    font-weight: 600;
    margin: 0 0 20px 0;
    padding-bottom: 12px;
    border-bottom: 2px solid var(--border-color);
    color: var(--text-primary);
  }

  :deep(h2) {
    font-size: 24px;
    font-weight: 600;
    margin: 32px 0 16px 0;
    color: var(--text-primary);
  }

  :deep(h3) {
    font-size: 20px;
    font-weight: 600;
    margin: 24px 0 12px 0;
    color: var(--text-primary);
  }

  :deep(h4) {
    font-size: 16px;
    font-weight: 600;
    margin: 20px 0 10px 0;
    color: var(--text-primary);
  }

  :deep(p) {
    margin: 12px 0;
    line-height: 1.8;
    color: var(--text-secondary);
  }

  :deep(ul), :deep(ol) {
    margin: 12px 0;
    padding-left: 24px;
    color: var(--text-secondary);

    li {
      margin: 8px 0;
      line-height: 1.6;
    }
  }

  :deep(code) {
    background: var(--bg-primary);
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.9em;
    color: var(--color-primary);
    border: 1px solid var(--border-color);
  }

  :deep(pre) {
    background: var(--bg-primary);
    padding: 16px;
    border-radius: 8px;
    overflow-x: auto;
    margin: 16px 0;
    border: 1px solid var(--border-color);

    code {
      background: transparent;
      padding: 0;
      border: none;
      color: var(--text-primary);
      font-size: 14px;
      line-height: 1.6;
    }
  }

  :deep(blockquote) {
    margin: 16px 0;
    padding: 12px 20px;
    background: var(--bg-secondary);
    border-left: 4px solid var(--color-primary);
    color: var(--text-secondary);
    border-radius: 0 8px 8px 0;

    p {
      margin: 0;
    }
  }

  :deep(table) {
    width: 100%;
    margin: 16px 0;
    border-collapse: collapse;

    th, td {
      padding: 12px;
      border: 1px solid var(--border-color);
      text-align: left;
    }

    th {
      background: var(--bg-secondary);
      font-weight: 600;
      color: var(--text-primary);
    }

    td {
      color: var(--text-secondary);
    }

    tr:hover {
      background: var(--bg-secondary);
    }
  }

  :deep(a) {
    color: var(--color-primary);
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }

  :deep(img) {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 16px 0;
  }

  :deep(hr) {
    border: none;
    border-top: 1px solid var(--border-color);
    margin: 24px 0;
  }

  :deep(strong) {
    font-weight: 600;
    color: var(--text-primary);
  }

  :deep(em) {
    font-style: italic;
    color: var(--text-secondary);
  }
}
</style>
