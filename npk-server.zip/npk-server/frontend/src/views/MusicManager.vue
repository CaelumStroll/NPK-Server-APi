<script setup lang="ts">
import { ref, onMounted, watch, onUnmounted, nextTick, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { useMusicStore, type MusicFile } from '@/stores/music'
import { musicApi } from '@/api'
import {
  Search, Refresh, VideoPlay, Delete, FolderOpened,
  Folder, ArrowUp, Download, Headset
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const { t } = useI18n()
const musicStore = useMusicStore()

const currentPath = ref('')

const allDirPaths = computed(() => {
  const paths = new Set<string>()
  musicStore.musicFiles.forEach(m => {
    if (m.dir_path) {
      paths.add(m.dir_path)
    }
  })
  return Array.from(paths)
})

const currentSubFolders = computed(() => {
  const subFolders = new Map<string, number>()

  allDirPaths.value.forEach(dir => {
    if (currentPath.value === '') {
      if (!dir.includes('/')) {
        const count = musicStore.musicFiles.filter(m => m.dir_path === dir).length
        subFolders.set(dir, count)
      }
    } else {
      const prefix = currentPath.value + '/'
      if (dir.startsWith(prefix)) {
        const remainder = dir.substring(prefix.length)
        const firstSlash = remainder.indexOf('/')
        if (firstSlash === -1) {
          subFolders.set(remainder, subFolders.get(remainder) || 0 + 1)
        } else {
          const firstFolder = remainder.substring(0, firstSlash)
          subFolders.set(firstFolder, (subFolders.get(firstFolder) || 0) + 1)
        }
      }
    }
  })

  return Array.from(subFolders.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => a.name.localeCompare(b.name))
})

const currentMusic = computed(() => {
  return musicStore.musicFiles.filter(m => m.dir_path === currentPath.value)
})

const currentPathDisplay = computed(() => {
  if (currentPath.value === '') return 'Music'
  return currentPath.value.split('/').pop() || currentPath.value
})

const canGoUp = computed(() => currentPath.value !== '')

function goUp() {
  if (!canGoUp.value) return
  const idx = currentPath.value.lastIndexOf('/')
  currentPath.value = idx === -1 ? '' : currentPath.value.substring(0, idx)
}

function enterFolder(folder: string) {
  currentPath.value = currentPath.value === '' ? folder : `${currentPath.value}/${folder}`
}

const searchQuery = ref('')
const formatFilter = ref('all')
let debounceTimer: ReturnType<typeof setTimeout> | null = null

const filteredMusic = computed(() => {
  const isSearching = searchQuery.value || formatFilter.value !== 'all'
  let result = isSearching ? musicStore.musicFiles : currentMusic.value

  if (searchQuery.value) {
    const q = searchQuery.value.toLowerCase()
    result = result.filter(m => m.name.toLowerCase().includes(q))
  }

  if (formatFilter.value !== 'all') {
    result = result.filter(m => m.format === formatFilter.value)
  }

  return result
})

const selectedMusic = ref<MusicFile[]>([])

const playDialogVisible = ref(false)
const currentPlayingMusic = ref<MusicFile | null>(null)
const audioUrl = ref('')
const audioRef = ref<HTMLAudioElement | null>(null)
const isPlaying = ref(false)
const volume = ref(80)

const operationLoading = ref<string | null>(null)

const convertDialogVisible = ref(false)
const targetFormat = ref('mp3')
const convertingMusic = ref<MusicFile | null>(null)

onMounted(async () => {
  await Promise.all([musicStore.fetchMusic(), musicStore.fetchStats()])
})

onUnmounted(() => {
  if (debounceTimer) clearTimeout(debounceTimer)
  if (audioUrl.value) {
    URL.revokeObjectURL(audioUrl.value)
  }
})

watch([searchQuery, formatFilter], () => {
  if (debounceTimer) clearTimeout(debounceTimer)
  debounceTimer = setTimeout(() => {}, 300)
})

async function handleScan() {
  try {
    await ElMessageBox.confirm(
      t('musicManager.confirmScan'),
      t('musicManager.scanDir'),
      { confirmButtonText: t('common.confirm'), cancelButtonText: t('common.cancel'), type: 'info' }
    )
    operationLoading.value = 'scan'
    try {
      await musicStore.scanMusic()
      ElMessage.success(t('common.scanComplete'))
    } catch (e: any) {
      ElMessage.error(t('common.scanFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

async function handleRefresh() {
  await Promise.all([musicStore.fetchMusic(), musicStore.fetchStats()])
}

function handleSelectionChange(selection: MusicFile[]) {
  selectedMusic.value = selection
}

function handlePlay(music: MusicFile) {
  currentPlayingMusic.value = music
  const streamUrl = musicApi.getStreamUrl(music.id)
  audioUrl.value = streamUrl
  playDialogVisible.value = true
  isPlaying.value = false
  nextTick(() => {
    setTimeout(() => {
      if (audioRef.value) {
        audioRef.value.play().catch(() => {})
      }
    }, 300)
  })
}

function handleDialogClose() {
  if (audioRef.value) {
    audioRef.value.pause()
    audioRef.value.src = ''
  }
  isPlaying.value = false
  currentPlayingMusic.value = null
}

function handleVolumeChange(val: number | number[]) {
  if (audioRef.value) {
    const v = typeof val === 'number' ? val : val[0]
    audioRef.value.volume = v / 100
  }
}

function handleAudioError(e: Event) {
  const audio = e.target as HTMLAudioElement
  if (!audio.src || audio.src === '' || audio.src === window.location.href) {
    return
  }
  console.error('Audio load error:', {
    error: audio.error,
    src: audio.src,
  })
  ElMessage.error(t('common.requestFailed'))
  isPlaying.value = false
}

function handleAudioEnded() {
  isPlaying.value = false
}

function handleDownload(music: MusicFile) {
  const a = document.createElement('a')
  a.href = musicApi.getStreamUrl(music.id)
  a.download = music.name
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

async function handleDelete(music: MusicFile) {
  try {
    const action = await ElMessageBox.confirm(
      t('musicManager.confirmDeleteMusic', { name: music.name }),
      t('common.confirmDelete'),
      {
        confirmButtonText: t('common.confirm'),
        cancelButtonText: t('common.cancel'),
        type: 'warning',
        distinguishCancelAndClose: true
      }
    ).catch((action) => {
      return action
    })

    if (!action) return

    operationLoading.value = `delete-${music.id}`
    try {
      if (action === 'confirm') {
        await musicApi.deleteMusicWithFile(music.id)
        ElMessage.success(t('common.operationSuccess'))
      } else {
        await musicStore.deleteMusic(music.id)
        ElMessage.success(t('common.operationSuccess'))
      }
      await handleRefresh()
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

function openConvertDialog(music: MusicFile) {
  convertingMusic.value = music
  targetFormat.value = 'mp3'
  convertDialogVisible.value = true
}

async function handleConvert() {
  if (!convertingMusic.value) return
  operationLoading.value = `convert-${convertingMusic.value.id}`
  try {
    await musicApi.convert(convertingMusic.value.id, targetFormat.value)
    ElMessage.success(`${t('musicManager.convertedTo')} ${targetFormat.value.toUpperCase()}`)
    convertDialogVisible.value = false
    await handleRefresh()
  } catch (e: any) {
    ElMessage.error(t('musicManager.convertFailed') + ': ' + e.message)
  } finally {
    operationLoading.value = null
  }
}

async function handleBatchDelete() {
  if (selectedMusic.value.length === 0) {
    ElMessage.warning(t('common.warning'))
    return
  }
  try {
    const action = await ElMessageBox.confirm(
      t('musicManager.confirmBatchDelete', { count: selectedMusic.value.length }),
      t('common.confirmDelete'),
      {
        confirmButtonText: t('common.confirm'),
        cancelButtonText: t('common.cancel'),
        type: 'warning',
        distinguishCancelAndClose: true
      }
    ).catch((action) => {
      return action
    })

    if (!action) return

    operationLoading.value = 'batch-delete'
    try {
      const ids = selectedMusic.value.map(m => m.id)
      const deleteFile = action === 'confirm'
      await musicApi.batchDeleteMusic(ids, deleteFile)
      ElMessage.success(t('common.operationSuccess'))
      selectedMusic.value = []
      await handleRefresh()
    } catch (e: any) {
      ElMessage.error(t('common.operationFailed') + ': ' + e.message)
    } finally {
      operationLoading.value = null
    }
  } catch { /* 取消 */ }
}

function formatSize(bytes: number): string {
  if (!bytes || isNaN(bytes)) return '0 B'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB'
  return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB'
}

function formatDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return '00:00'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
}

function formatTotalDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return `0 ${t('musicManager.minutes')}`
  if (seconds < 3600) return Math.floor(seconds / 60) + ` ${t('musicManager.minutes')}`
  const hours = Math.floor(seconds / 3600)
  const mins = Math.floor((seconds % 3600) / 60)
  return `${hours} ${t('musicManager.hours')} ${mins} ${t('musicManager.minutes')}`
}

function formatSampleRate(rate: number): string {
  if (!rate) return '-'
  return (rate / 1000).toFixed(1) + ' kHz'
}

function formatChannels(ch: number): string {
  if (ch === 1) return t('musicManager.mono')
  if (ch === 2) return t('musicManager.stereo')
  if (ch > 2) return t('musicManager.channelCount', { count: ch })
  return '-'
}

const audioFormats = [
  { label: 'MP3', value: 'mp3' },
  { label: 'OGG', value: 'ogg' },
  { label: 'FLAC', value: 'flac' },
  { label: 'WAV', value: 'wav' },
  { label: 'M4A', value: 'm4a' },
  { label: 'AAC', value: 'aac' },
  { label: 'OPUS', value: 'opus' },
  { label: 'WMA', value: 'wma' }
]

const convertFormats = [
  { label: 'MP3', value: 'mp3' },
  { label: 'OGG', value: 'ogg' },
  { label: 'FLAC', value: 'flac' },
  { label: 'WAV', value: 'wav' },
]

</script>

<template>
  <div class="music-manager">
    <!-- 页面标题 -->
    <div class="page-header">
      <h2 class="page-title">{{ t('musicManager.title') }}</h2>
      <div class="header-actions">
        <el-tag v-if="selectedMusic.length > 0" type="info" size="small" effect="dark">
          {{ t('musicManager.selectedCount', { count: selectedMusic.length }) }}
        </el-tag>
        <el-button
          v-if="selectedMusic.length > 0"
          type="danger"
          size="small"
          :loading="operationLoading === 'batch-delete'"
          @click="handleBatchDelete"
        >
          {{ t('musicManager.batchDelete') }}
        </el-button>
        <el-button :icon="Refresh" size="small" :loading="musicStore.loading" @click="handleRefresh">
          {{ t('common.refresh') }}
        </el-button>
      </div>
    </div>

    <!-- 搜索与筛选工具栏 -->
    <div class="toolbar">
      <el-input
        v-model="searchQuery"
        :placeholder="t('musicManager.searchPlaceholder')"
        :prefix-icon="Search"
        clearable
        class="search-input"
      />
      <el-select v-model="formatFilter" :placeholder="t('musicManager.formatFilter')" class="filter-select">
        <el-option :label="t('musicManager.allFormats')" value="all" />
        <el-option v-for="fmt in audioFormats" :key="fmt.value" :label="fmt.label" :value="fmt.value.toUpperCase()" />
      </el-select>
      <el-button
        type="primary"
        :icon="FolderOpened"
        :loading="operationLoading === 'scan'"
        @click="handleScan"
      >
        {{ t('musicManager.scanDir') }}
      </el-button>
    </div>

    <!-- 统计卡片 -->
    <el-row :gutter="16" class="stats-row">
      <el-col :span="8">
        <el-card class="stat-card stat-card--total" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><Headset /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ musicStore.totalCount }}</div>
              <div class="stat-label">{{ t('musicManager.totalFiles') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="stat-card stat-card--size" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><FolderOpened /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ formatSize(musicStore.totalSize) }}</div>
              <div class="stat-label">{{ t('musicManager.totalSize') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="stat-card stat-card--duration" shadow="hover">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon :size="28"><Headset /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ formatTotalDuration(musicStore.totalDuration) }}</div>
              <div class="stat-label">{{ t('musicManager.totalDuration') }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主内容区：左侧文件夹列表 + 右侧音乐列表 -->
    <div class="main-content">
      <!-- 左侧文件夹浏览器 -->
      <div class="folder-sidebar">
        <div class="folder-header">
          <el-icon><FolderOpened /></el-icon>
          <span>{{ currentPathDisplay }}</span>
          <el-button
            v-if="canGoUp"
            type="primary"
            link
            size="small"
            :icon="ArrowUp"
            @click="goUp"
          >
            {{ t('musicManager.goUp') }}
          </el-button>
        </div>
        <div class="folder-list">
          <div
            v-for="folder in currentSubFolders"
            :key="folder.name"
            class="folder-item"
            @click="enterFolder(folder.name)"
          >
            <el-icon><Folder /></el-icon>
            <span class="folder-name">{{ folder.name }}</span>
            <span class="folder-count">({{ folder.count }})</span>
          </div>
          <el-empty v-if="currentSubFolders.length === 0" :description="t('common.noData')" />
        </div>
      </div>

      <!-- 右侧音乐列表 -->
      <el-card class="table-card">
        <el-table
          v-loading="musicStore.loading"
          :data="filteredMusic"
          stripe
          @selection-change="handleSelectionChange"
          class="music-table"
        >
          <el-table-column type="selection" width="50" />

          <el-table-column :label="t('musicManager.fileName')" prop="name" min-width="200" show-overflow-tooltip>
            <template #default="{ row }">
              <div class="filename-cell">
                <span>{{ row.name }}</span>
              </div>
            </template>
          </el-table-column>

          <el-table-column :label="t('musicManager.format')" prop="format" width="80" align="center">
            <template #default="{ row }">
              <el-tag size="small" effect="plain" class="format-tag">
                {{ row.format }}
              </el-tag>
            </template>
          </el-table-column>

          <el-table-column :label="t('musicManager.duration')" prop="duration" width="80" align="center">
            <template #default="{ row }">
              <span class="mono-text">{{ formatDuration(row.duration) }}</span>
            </template>
          </el-table-column>

          <el-table-column :label="t('musicManager.frequency')" prop="sample_rate" width="100" align="center">
            <template #default="{ row }">
              <span class="mono-text">{{ formatSampleRate(row.sample_rate) }}</span>
            </template>
          </el-table-column>

          <el-table-column :label="t('musicManager.size')" prop="size" width="100" align="right">
            <template #default="{ row }">
              <span class="mono-text">{{ formatSize(row.size) }}</span>
            </template>
          </el-table-column>

          <el-table-column :label="t('musicManager.convertFormat')" width="120" align="center">
            <template #default="{ row }">
              <el-button
                type="primary"
                size="small"
                link
                @click="openConvertDialog(row)"
              >
                {{ t('musicManager.convert') }}
              </el-button>
            </template>
          </el-table-column>

          <el-table-column :label="t('musicManager.operation')" width="160" align="center" fixed="right">
            <template #default="{ row }">
              <div class="action-icons">
                <el-button
                  type="primary"
                  :icon="VideoPlay"
                  circle
                  size="small"
                  :title="t('common.play')"
                  @click="handlePlay(row)"
                />
                <el-button
                  type="success"
                  :icon="Download"
                  circle
                  size="small"
                  :title="t('common.download')"
                  @click="handleDownload(row)"
                />
                <el-button
                  type="danger"
                  :icon="Delete"
                  circle
                  size="small"
                  :title="t('common.delete')"
                  :loading="operationLoading === `delete-${row.id}`"
                  @click="handleDelete(row)"
                />
              </div>
            </template>
          </el-table-column>
        </el-table>

        <div class="music-count-info">
          <el-tag type="info" effect="plain">{{ t('musicManager.audioCount', { count: filteredMusic.length }) }}</el-tag>
        </div>
      </el-card>
    </div>

    <!-- 音频播放对话框 -->
    <el-dialog
      v-model="playDialogVisible"
      :title="currentPlayingMusic ? `${t('common.play')}: ${currentPlayingMusic.name}` : t('common.play')"
      width="520px"
      destroy-on-close
      align-center
      @close="handleDialogClose"
      class="play-dialog"
    >
      <div class="player-container">
        <div v-if="currentPlayingMusic" class="music-info-box">
          <div class="music-info-row">
            <span class="info-label">{{ t('musicManager.format') }}:</span>
            <el-tag size="small" effect="plain">{{ currentPlayingMusic.format }}</el-tag>
          </div>
          <div class="music-info-row">
            <span class="info-label">{{ t('musicManager.duration') }}:</span>
            <span>{{ formatDuration(currentPlayingMusic.duration) }}</span>
          </div>
          <div class="music-info-row">
            <span class="info-label">{{ t('musicManager.frequency') }}:</span>
            <span>{{ formatSampleRate(currentPlayingMusic.sample_rate) }}</span>
          </div>
          <div class="music-info-row">
            <span class="info-label">{{ t('musicManager.channel') }}:</span>
            <span>{{ formatChannels(currentPlayingMusic.channels) }}</span>
          </div>
          <div class="music-info-row" v-if="currentPlayingMusic.bitrate">
            <span class="info-label">{{ t('musicManager.bitrate') }}:</span>
            <span>{{ currentPlayingMusic.bitrate }} kbps</span>
          </div>
          <div class="music-info-row">
            <span class="info-label">{{ t('musicManager.size') }}:</span>
            <span>{{ formatSize(currentPlayingMusic.size) }}</span>
          </div>
        </div>

        <div class="audio-player-wrapper">
          <audio
            ref="audioRef"
            :src="audioUrl"
            class="audio-player"
            controls
            preload="auto"
            :volume="volume / 100"
            @play="isPlaying = true"
            @pause="isPlaying = false"
            @ended="handleAudioEnded"
            @error="handleAudioError"
          />
        </div>
      </div>

      <div class="player-controls-bar">
        <div class="volume-control">
          <el-icon :size="16"><Headset /></el-icon>
          <el-slider
            v-model="volume"
            :min="0"
            :max="100"
            :show-tooltip="false"
            size="small"
            style="width: 100px"
            @input="handleVolumeChange"
          />
        </div>
        <el-button
          :icon="Download"
          circle
          size="small"
          :title="t('common.download')"
          @click="handleDownload(currentPlayingMusic!)"
        />
      </div>
    </el-dialog>

    <!-- 格式转换对话框 -->
    <el-dialog
      v-model="convertDialogVisible"
      :title="convertingMusic ? `${t('musicManager.convert')}: ${convertingMusic.name}` : t('musicManager.convertFormat')"
      width="400px"
      align-center
    >
      <div class="convert-dialog-body">
        <div class="convert-info" v-if="convertingMusic">
          <p>{{ t('musicManager.format') }}: <el-tag size="small" effect="plain">{{ convertingMusic.format }}</el-tag></p>
        </div>
        <el-form label-width="80px">
          <el-form-item :label="t('musicManager.targetFormat')">
            <el-select v-model="targetFormat" style="width: 200px">
              <el-option
                v-for="fmt in convertFormats"
                :key="fmt.value"
                :label="fmt.label"
                :value="fmt.value"
                :disabled="!!(convertingMusic && convertingMusic.format && fmt.value === convertingMusic.format.toLowerCase())"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <template #footer>
        <el-button @click="convertDialogVisible = false">{{ t('common.cancel') }}</el-button>
        <el-button
          type="primary"
          :loading="!!(operationLoading && operationLoading.startsWith('convert-'))"
          @click="handleConvert"
        >
          {{ t('musicManager.startConvert') }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.music-manager {
  height: calc(100vh - 90px - 48px);
  display: flex;
  flex-direction: column;

  .page-header {
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-shrink: 0;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
  }

  .toolbar {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
    flex-shrink: 0;

    .search-input {
      width: 260px;
    }

    .filter-select {
      width: 140px;
    }
  }

  .stats-row {
    margin-bottom: 16px;
    flex-shrink: 0;

    .stat-card {
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 16px;
      transition: transform 0.2s ease, border-color 0.2s ease;
      position: relative;
      overflow: hidden;

      &:hover {
        transform: translateY(-2px);
        border-color: rgba(251, 113, 133, 0.3);
      }

      &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        border-radius: 14px 14px 0 0;
      }

      &--total::before {
        background: linear-gradient(90deg, #89b4fa, #74c7ec);
      }

      &--size::before {
        background: linear-gradient(90deg, #a6e3a1, #94e2d5);
      }

      &--duration::before {
        background: linear-gradient(90deg, #cba6f7, #b4befe);
      }

      .stat-content {
        display: flex;
        align-items: center;
        gap: 14px;

        .stat-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .stat-info {
          .stat-value {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          .stat-label {
            font-size: 11px;
            color: var(--text-secondary);
          }
        }
      }
    }

    .stat-card--total .stat-icon {
      background: rgba(137, 180, 250, 0.15);
      color: #89b4fa;
    }

    .stat-card--size .stat-icon {
      background: rgba(166, 227, 161, 0.15);
      color: #a6e3a1;
    }

    .stat-card--duration .stat-icon {
      background: rgba(203, 166, 247, 0.15);
      color: #cba6f7;
    }
  }

  .main-content {
    flex: 1;
    display: flex;
    gap: 16px;
    min-height: 0;
    overflow: hidden;

    .folder-sidebar {
      width: 240px;
      flex-shrink: 0;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      overflow: hidden;

      .folder-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px 16px;
        font-weight: 600;
        font-size: 14px;
        border-bottom: 1px solid var(--border-color);
        background: var(--el-fill-color-light);

        .el-icon {
          font-size: 18px;
          color: var(--el-color-primary);
        }
      }

      .folder-list {
        flex: 1;
        overflow-y: auto;
        padding: 8px;

        .folder-item {
          display: flex;
          align-items: center;
          padding: 10px 12px;
          cursor: pointer;
          transition: background-color 0.2s;
          border-radius: 4px;
          margin: 4px 0;
          border: 1px solid transparent;

          &:hover {
            background-color: var(--el-fill-color-light);
            border-color: var(--el-color-primary-light-5);
          }

          .el-icon {
            margin-right: 8px;
            font-size: 20px;
            color: var(--el-color-warning);
          }

          .folder-name {
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 14px;
            font-weight: 500;
          }

          .folder-count {
            font-size: 11px;
            color: var(--el-text-color-secondary);
            margin-left: 4px;
          }
        }
      }
    }

    .table-card {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
      min-width: 0;
      background: var(--bg-primary);
      border: 1px solid var(--border-color);

      :deep(.el-card__body) {
        flex: 1;
        display: flex;
        flex-direction: column;
        min-height: 0;
        padding: 12px;
      }

      .music-table {
        flex: 1;
        min-height: 0;

        :deep(.el-table__row) {
          transition: background-color 0.2s ease;

          &:hover > td {
            background-color: rgba(137, 180, 250, 0.06) !important;
          }
        }
      }

      .filename-cell {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .format-tag {
        font-family: monospace;
        font-size: 11px;
      }

      .mono-text {
        font-family: monospace;
        font-size: 12px;
      }

      .action-icons {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      }

      .music-count-info {
        display: flex;
        justify-content: flex-end;
        padding-top: 12px;
        flex-shrink: 0;
      }
    }
  }

  .play-dialog {
    :deep(.el-dialog__body) {
      padding: 0 20px 20px;
    }
  }

  .player-container {
    background: var(--bg-secondary);
    border-radius: 8px;
    overflow: hidden;

    .music-info-box {
      padding: 16px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;

      .music-info-row {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;

        .info-label {
          color: var(--text-muted);
          min-width: 50px;
        }
      }
    }

    .audio-player-wrapper {
      padding: 16px;
      background: #f5f7fa;

      .audio-player {
        width: 100%;
        outline: none;
      }
    }
  }

  .player-controls-bar {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    padding: 12px;
    background: var(--bg-secondary, #f5f7fa);
    border-top: 1px solid var(--border-color, #e4e7ed);
    border-radius: 0 0 8px 8px;

    .volume-control {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--text-primary, #303133);
    }
  }

  .convert-dialog-body {
    .convert-info {
      margin-bottom: 16px;
    }
  }
}
</style>
