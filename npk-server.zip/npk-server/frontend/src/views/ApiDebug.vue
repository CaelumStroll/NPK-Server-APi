<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import { Search, Promotion, DocumentCopy, Delete, Timer, Refresh } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'

// API 风险等级
type RiskLevel = 'safe' | 'warning' | 'danger'

interface ApiDef {
  method: string
  path: string
  name: string
  description?: string
  example?: string
  params: any[]
  body?: string
  risk?: RiskLevel
  riskDesc?: string
  // 大数据量性能提示
  perfNote?: string
  perfLevel?: 'good' | 'slow' | 'heavy'
  // 问题分类
  issueTag?: string
  issueDetail?: string
  // API 分组
  group?: string
  // 从路由表获取的原始数据
  fromRouteTable?: boolean
}

const { t } = useI18n()

// ========== 从后端动态获取的 API 列表 ==========
const apiList = ref<ApiDef[]>([])
const routesLoading = ref(false)

// 从 Gin 路由路径中提取参数（如 :name, :index, :id）
function extractPathParams(path: string): { name: string; type: string; required: boolean }[] {
  const params: { name: string; type: string; required: boolean }[] = []
  const regex = /:(\w+)/g
  let match
  while ((match = regex.exec(path)) !== null) {
    params.push({ name: match[1], type: 'string', required: true })
  }
  return params
}

const apiMetadataMap = computed<Record<string, Partial<ApiDef>>>(() => ({
  'GET /api/npk/list': {
    name: t('apiDebug.apis.npkList.name'),
    description: t('apiDebug.apis.npkList.desc'),
    example: 'curl http://localhost:8556/api/npk/list',
    perfNote: t('apiDebug.apis.npkList.perf'), perfLevel: 'slow',
    issueTag: t('apiDebug.apis.npkList.issue'), issueDetail: t('apiDebug.apis.npkList.issueDetail'),
  },
  'GET /api/npk/list/paginated': {
    name: t('apiDebug.apis.npkListPaginated.name'),
    description: t('apiDebug.apis.npkListPaginated.desc'),
    example: 'curl "http://localhost:8556/api/npk/list/paginated?page=1&limit=20&q=sword"',
    perfNote: t('apiDebug.apis.npkListPaginated.perf'), perfLevel: 'good',
    issueTag: t('apiDebug.apis.npkListPaginated.issue'), issueDetail: t('apiDebug.apis.npkListPaginated.issueDetail'),
  },
  'GET /api/npk/:name/info': {
    name: t('apiDebug.apis.npkInfo.name'),
    description: t('apiDebug.apis.npkInfo.desc'),
    example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/info',
    perfLevel: 'good', perfNote: t('apiDebug.apis.npkInfo.perf'),
    issueTag: t('apiDebug.apis.npkInfo.issue'), issueDetail: t('apiDebug.apis.npkInfo.issueDetail'),
  },
  'GET /api/npk/:name/tree': { name: t('apiDebug.apis.npkTree.name'), description: t('apiDebug.apis.npkTree.desc'), example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/tree', perfLevel: 'good' },
  'POST /api/npk/scan': {
    name: t('apiDebug.apis.npkScan.name'),
    description: t('apiDebug.apis.npkScan.desc'),
    example: 'curl -X POST http://localhost:8556/api/npk/scan',
    risk: 'warning', riskDesc: t('apiDebug.apis.npkScan.risk'),
    perfNote: t('apiDebug.apis.npkScan.perf'), perfLevel: 'heavy',
  },
  'POST /api/npk/:name/save': {
    name: t('apiDebug.apis.npkSave.name'),
    description: t('apiDebug.apis.npkSave.desc'),
    example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/save',
    risk: 'warning', riskDesc: t('apiDebug.apis.npkSave.risk'),
    perfNote: t('apiDebug.apis.npkSave.perf'), perfLevel: 'good',
    issueTag: t('apiDebug.apis.npkSave.issue'), issueDetail: t('apiDebug.apis.npkSave.issueDetail'),
  },
  'DELETE /api/npk/:name': { name: t('apiDebug.apis.npkDelete.name'), description: t('apiDebug.apis.npkDelete.desc'), example: 'curl -X DELETE http://localhost:8556/api/npk/sprite_character.NPK', risk: 'danger', riskDesc: t('apiDebug.apis.npkDelete.risk') },
  'GET /api/npk/:name/tags': { name: t('apiDebug.apis.npkGetTags.name'), description: t('apiDebug.apis.npkGetTags.desc'), example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/tags', perfLevel: 'good' },
  'POST /api/npk/:name/tags': { name: t('apiDebug.apis.npkAddTags.name'), description: t('apiDebug.apis.npkAddTags.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/tags -H "Content-Type: application/json" -d \'{"name":"角色","color":"#ff6b6b"}\'', perfLevel: 'good' },
  'DELETE /api/npk/:name/tags/:tagId': { name: t('apiDebug.apis.npkRemoveTag.name'), description: t('apiDebug.apis.npkRemoveTag.desc'), example: 'curl -X DELETE http://localhost:8556/api/npk/sprite_character.NPK/tags/1', perfLevel: 'good' },
  'GET /api/npk/:name/assets': { name: t('apiDebug.apis.assetsList.name'), description: t('apiDebug.apis.assetsList.desc'), example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/assets', perfLevel: 'good' },
  'GET /api/npk/:name/assets/:index': { name: t('apiDebug.apis.assetsDetail.name'), description: t('apiDebug.apis.assetsDetail.desc'), example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/assets/0' },
  'GET /api/npk/:name/assets/:index/image': { name: t('apiDebug.apis.assetsImage.name'), description: t('apiDebug.apis.assetsImage.desc'), example: 'curl "http://localhost:8556/api/npk/sprite_character.NPK/assets/0/image?combined=true"', perfNote: t('apiDebug.apis.assetsImage.perf'), perfLevel: 'good' },
  'GET /api/npk/:name/assets/:index/thumbnail': { name: t('apiDebug.apis.assetsThumbnail.name'), description: t('apiDebug.apis.assetsThumbnail.desc'), example: 'curl "http://localhost:8556/api/npk/sprite_character.NPK/assets/0/thumbnail?size=128"', perfLevel: 'good', perfNote: t('apiDebug.apis.assetsThumbnail.perf') },
  'POST /api/npk/:name/assets/:index/color': { name: t('apiDebug.apis.assetsColor.name'), description: t('apiDebug.apis.assetsColor.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/0/color -H "Content-Type: application/json" -d \'{"fromColor":[255,0,0,255],"toColor":[0,0,255,255],"targetIndex":0}\'', risk: 'warning', riskDesc: t('apiDebug.apis.assetsColor.risk') },
  'PUT /api/npk/:name/album/rename': { name: t('apiDebug.apis.albumRename.name'), description: t('apiDebug.apis.albumRename.desc'), example: 'curl -X PUT http://localhost:8556/api/npk/sprite_character.NPK/album/rename -H "Content-Type: application/json" -d \'{"oldPath":"sprite/character/swordman.img","newPath":"sprite/character/warrior.img"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.albumRename.risk') },
  'DELETE /api/npk/:name/album': { name: t('apiDebug.apis.albumDelete.name'), description: t('apiDebug.apis.albumDelete.desc'), example: 'curl -X DELETE "http://localhost:8556/api/npk/sprite_character.NPK/album?path=sprite/character/swordman.img"', risk: 'danger', riskDesc: t('apiDebug.apis.albumDelete.risk') },
  'POST /api/npk/:name/import-img': { name: t('apiDebug.apis.importImg.name'), description: t('apiDebug.apis.importImg.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/import-img -F "file=@swordman.img" -F "path=sprite/character"', risk: 'warning', riskDesc: t('apiDebug.apis.importImg.risk') },
  'GET /api/npk/frames': { name: t('apiDebug.apis.frames.name'), description: t('apiDebug.apis.frames.desc'), example: 'curl "http://localhost:8556/api/npk/frames?imgId=1"', perfLevel: 'good' },
  'GET /api/npk/preview': { name: t('apiDebug.apis.preview.name'), description: t('apiDebug.apis.preview.desc'), example: 'curl "http://localhost:8556/api/npk/preview?name=sprite_character.NPK&index=0"', perfNote: t('apiDebug.apis.preview.perf') },
  'GET /api/npk/album/export.gif': { name: t('apiDebug.apis.albumExportGif.name'), description: t('apiDebug.apis.albumExportGif.desc'), example: 'curl "http://localhost:8556/api/npk/album/export.gif?name=sprite_character.NPK&index=0&delay=100"', perfNote: t('apiDebug.apis.albumExportGif.perf') },
  'GET /api/npk/:name/album/compare': { name: t('apiDebug.apis.albumCompare.name'), description: t('apiDebug.apis.albumCompare.desc'), example: 'curl "http://localhost:8556/api/npk/sprite_character.NPK/album/compare?indexA=0&indexB=1"' },
  'POST /api/npk/:name/assets/add': { name: t('apiDebug.apis.assetsAdd.name'), description: t('apiDebug.apis.assetsAdd.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/add -H "Content-Type: application/json" -d \'{"index":0}\'', risk: 'warning', riskDesc: t('apiDebug.apis.assetsAdd.risk') },
  'POST /api/npk/:name/assets/:index/replace': { name: t('apiDebug.apis.assetsReplace.name'), description: t('apiDebug.apis.assetsReplace.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/0/replace -F "file=@frame.png"', risk: 'warning', riskDesc: t('apiDebug.apis.assetsReplace.risk') },
  'POST /api/npk/:name/assets/batch-replace': { name: t('apiDebug.apis.assetsBatchReplace.name'), description: t('apiDebug.apis.assetsBatchReplace.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/batch-replace -H "Content-Type: application/json" -d \'{"index":0,"folder":"/path/to/frames"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.assetsBatchReplace.risk') },
  'PUT /api/npk/:name/assets/:index/frame/:fid': { name: t('apiDebug.apis.assetsUpdateFrame.name'), description: t('apiDebug.apis.assetsUpdateFrame.desc'), example: 'curl -X PUT http://localhost:8556/api/npk/sprite_character.NPK/assets/0/frame/0 -H "Content-Type: application/json" -d \'{"posX":10,"posY":20}\'', risk: 'warning', riskDesc: t('apiDebug.apis.assetsUpdateFrame.risk') },
  'DELETE /api/npk/:name/assets/:index': { name: t('apiDebug.apis.assetsDeleteFrame.name'), description: t('apiDebug.apis.assetsDeleteFrame.desc'), example: 'curl -X DELETE "http://localhost:8556/api/npk/sprite_character.NPK/assets/0?frameIndex=5"', risk: 'danger', riskDesc: t('apiDebug.apis.assetsDeleteFrame.risk') },
  'POST /api/npk/:name/assets/:index/clear': { name: t('apiDebug.apis.assetsClear.name'), description: t('apiDebug.apis.assetsClear.desc'), example: 'curl -X POST "http://localhost:8556/api/npk/sprite_character.NPK/assets/0/clear?frameIndex=5"', risk: 'warning', riskDesc: t('apiDebug.apis.assetsClear.risk') },
  'POST /api/npk/:name/assets/:index/reset': { name: t('apiDebug.apis.assetsReset.name'), description: t('apiDebug.apis.assetsReset.desc'), example: 'curl -X POST "http://localhost:8556/api/npk/sprite_character.NPK/assets/0/reset?frameIndex=5"', risk: 'warning', riskDesc: t('apiDebug.apis.assetsReset.risk') },
  'POST /api/npk/:name/assets/:index/trim': { name: t('apiDebug.apis.assetsTrim.name'), description: t('apiDebug.apis.assetsTrim.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/0/trim', perfLevel: 'good', perfNote: t('apiDebug.apis.assetsTrim.perf') },
  'POST /api/npk/:name/assets/:index/canvas': { name: t('apiDebug.apis.assetsCanvas.name'), description: t('apiDebug.apis.assetsCanvas.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/0/canvas -H "Content-Type: application/json" -d \'{"width":512,"height":512}\'', perfLevel: 'good', perfNote: t('apiDebug.apis.assetsCanvas.perf') },
  'GET /api/npk/:name/assets/:index/ani/info': { name: t('apiDebug.apis.aniInfo.name'), description: t('apiDebug.apis.aniInfo.desc'), example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/assets/0/ani/info' },
  'GET /api/npk/:name/assets/:index/ani/frame/:fid': { name: t('apiDebug.apis.aniFrame.name'), description: t('apiDebug.apis.aniFrame.desc'), example: 'curl http://localhost:8556/api/npk/sprite_character.NPK/assets/0/ani/frame/0', perfLevel: 'good', perfNote: t('apiDebug.apis.aniFrame.perf'), issueTag: t('apiDebug.apis.aniFrame.issue'), issueDetail: t('apiDebug.apis.aniFrame.issueDetail') },
  'POST /api/npk/:name/assets/:index/ani/preview': { name: t('apiDebug.apis.aniPreview.name'), description: t('apiDebug.apis.aniPreview.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/0/ani/preview -H "Content-Type: application/json" -d \'{"start":0,"end":10}\'', perfNote: t('apiDebug.apis.aniPreview.perf') },
  'GET /api/npk/:name/assets/:index/ani/export.gif': { name: t('apiDebug.apis.aniExportGif.name'), description: t('apiDebug.apis.aniExportGif.desc'), example: 'curl "http://localhost:8556/api/npk/sprite_character.NPK/assets/0/ani/export.gif?start=0&end=10&delay=100"', perfNote: t('apiDebug.apis.aniExportGif.perf') },
  'GET /api/library/stats': { name: t('apiDebug.apis.libraryStats.name'), description: t('apiDebug.apis.libraryStats.desc'), example: 'curl http://localhost:8556/api/library/stats', perfLevel: 'good', perfNote: t('apiDebug.apis.libraryStats.perf') },
  'GET /api/library/search': { name: t('apiDebug.apis.librarySearch.name'), description: t('apiDebug.apis.librarySearch.desc'), example: 'curl "http://localhost:8556/api/library/search?keyword=sword&page=1&limit=20"', perfLevel: 'good', perfNote: t('apiDebug.apis.librarySearch.perf'), issueTag: t('apiDebug.apis.librarySearch.issue'), issueDetail: t('apiDebug.apis.librarySearch.issueDetail') },
  'GET /api/library/tags': { name: t('apiDebug.apis.libraryTags.name'), description: t('apiDebug.apis.libraryTags.desc'), example: 'curl http://localhost:8556/api/library/tags', perfLevel: 'good' },
  'POST /api/library/tags': { name: t('apiDebug.apis.libraryCreateTag.name'), description: t('apiDebug.apis.libraryCreateTag.desc'), example: 'curl -X POST http://localhost:8556/api/library/tags -H "Content-Type: application/json" -d \'{"name":"武器","color":"#ff6600"}\'', perfLevel: 'good' },
  'PUT /api/library/tags/:id': { name: t('apiDebug.apis.libraryUpdateTag.name'), description: t('apiDebug.apis.libraryUpdateTag.desc'), example: 'curl -X PUT http://localhost:8556/api/library/tags/1 -H "Content-Type: application/json" -d \'{"name":"防具"}\'', perfLevel: 'good' },
  'DELETE /api/library/tags/:id': { name: t('apiDebug.apis.libraryDeleteTag.name'), description: t('apiDebug.apis.libraryDeleteTag.desc'), example: 'curl -X DELETE http://localhost:8556/api/library/tags/1', perfLevel: 'good' },
  'PUT /api/library/assets/:id/tags': { name: t('apiDebug.apis.libraryUpdateAssetTags.name'), description: t('apiDebug.apis.libraryUpdateAssetTags.desc'), example: 'curl -X PUT http://localhost:8556/api/library/assets/1/tags -H "Content-Type: application/json" -d \'{"tagIds":[1,3,5]}\'', perfLevel: 'good' },
  'GET /api/library/search/by-tags': { name: t('apiDebug.apis.librarySearchByTags.name'), description: t('apiDebug.apis.librarySearchByTags.desc'), example: 'curl "http://localhost:8556/api/library/search/by-tags?tagIds=1,3"', perfLevel: 'good' },
  'GET /api/library/folders': { name: t('apiDebug.apis.libraryFolders.name'), description: t('apiDebug.apis.libraryFolders.desc'), example: 'curl http://localhost:8556/api/library/folders', perfLevel: 'good', perfNote: t('apiDebug.apis.libraryFolders.perf'), issueTag: t('apiDebug.apis.libraryFolders.issue'), issueDetail: t('apiDebug.apis.libraryFolders.issueDetail') },
  'GET /api/library/duplicates': { name: t('apiDebug.apis.libraryDuplicates.name'), description: t('apiDebug.apis.libraryDuplicates.desc'), example: 'curl http://localhost:8556/api/library/duplicates', perfLevel: 'good' },
  'POST /api/batch/export': { name: t('apiDebug.apis.batchExport.name'), description: t('apiDebug.apis.batchExport.desc'), example: 'curl -X POST http://localhost:8556/api/batch/export -H "Content-Type: application/json" -d \'{"npkNames":["sprite_character.NPK"],"imgIndices":[0,1,2],"format":"png"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.batchExport.risk'), perfLevel: 'good', perfNote: t('apiDebug.apis.batchExport.perf'), issueTag: t('apiDebug.apis.batchExport.issue'), issueDetail: t('apiDebug.apis.batchExport.issueDetail') },
  'GET /api/batch/status/:taskId': { name: t('apiDebug.apis.batchStatus.name'), description: t('apiDebug.apis.batchStatus.desc'), example: 'curl http://localhost:8556/api/batch/status/abc123', perfLevel: 'good', perfNote: t('apiDebug.apis.batchStatus.perf') },
  'GET /api/batch/download/:taskId': { name: t('apiDebug.apis.batchDownload.name'), description: t('apiDebug.apis.batchDownload.desc'), example: 'curl -O http://localhost:8556/api/batch/download/abc123', perfLevel: 'good', perfNote: t('apiDebug.apis.batchDownload.perf') },
  'GET /api/settings': { name: t('apiDebug.apis.settingsGet.name'), description: t('apiDebug.apis.settingsGet.desc'), example: 'curl http://localhost:8556/api/settings', perfLevel: 'good' },
  'PUT /api/settings': { name: t('apiDebug.apis.settingsUpdate.name'), description: t('apiDebug.apis.settingsUpdate.desc'), example: 'curl -X PUT http://localhost:8556/api/settings -H "Content-Type: application/json" -d \'{"maxCacheSize":500}\'' },
  'POST /api/settings/npk-dir': { name: t('apiDebug.apis.settingsAddDir.name'), description: t('apiDebug.apis.settingsAddDir.desc'), example: 'curl -X POST http://localhost:8556/api/settings/npk-dir -H "Content-Type: application/json" -d \'{"path":"/data/npk2"}\'' },
  'DELETE /api/settings/npk-dir': { name: t('apiDebug.apis.settingsDeleteDir.name'), description: t('apiDebug.apis.settingsDeleteDir.desc'), example: 'curl -X DELETE "http://localhost:8556/api/settings/npk-dir?path=/data/npk2"' },
  'GET /api/db/stats': { name: t('apiDebug.apis.dbStats.name'), description: t('apiDebug.apis.dbStats.desc'), example: 'curl http://localhost:8556/api/db/stats', perfLevel: 'good', perfNote: t('apiDebug.apis.dbStats.perf') },
  'GET /api/db/tables': { name: t('apiDebug.apis.dbTables.name'), description: t('apiDebug.apis.dbTables.desc'), example: 'curl http://localhost:8556/api/db/tables', perfLevel: 'good', perfNote: t('apiDebug.apis.dbTables.perf') },
  'POST /api/db/cleanup': { name: t('apiDebug.apis.dbCleanup.name'), description: t('apiDebug.apis.dbCleanup.desc'), example: 'curl -X POST http://localhost:8556/api/db/cleanup', risk: 'warning', riskDesc: t('apiDebug.apis.dbCleanup.risk'), perfNote: t('apiDebug.apis.dbCleanup.perf') },
  'POST /api/db/compact': { name: t('apiDebug.apis.dbCompact.name'), description: t('apiDebug.apis.dbCompact.desc'), example: 'curl -X POST http://localhost:8556/api/db/compact', risk: 'warning', riskDesc: t('apiDebug.apis.dbCompact.risk'), perfNote: t('apiDebug.apis.dbCompact.perf') },
  'GET /api/db/export': { name: t('apiDebug.apis.dbExport.name'), description: t('apiDebug.apis.dbExport.desc'), example: 'curl http://localhost:8556/api/db/export', perfLevel: 'good', perfNote: t('apiDebug.apis.dbExport.perf'), issueTag: t('apiDebug.apis.dbExport.issue'), issueDetail: t('apiDebug.apis.dbExport.issueDetail') },
  'POST /api/db/rebuild': { name: t('apiDebug.apis.dbRebuild.name'), description: t('apiDebug.apis.dbRebuild.desc'), example: 'curl -X POST http://localhost:8556/api/db/rebuild', risk: 'danger', riskDesc: t('apiDebug.apis.dbRebuild.risk'), perfLevel: 'slow', perfNote: t('apiDebug.apis.dbRebuild.perf'), issueTag: t('apiDebug.apis.dbRebuild.issue'), issueDetail: t('apiDebug.apis.dbRebuild.issueDetail') },
  'POST /api/db/incremental': { name: t('apiDebug.apis.dbIncremental.name'), description: t('apiDebug.apis.dbIncremental.desc'), example: 'curl -X POST http://localhost:8556/api/db/incremental', risk: 'warning', riskDesc: t('apiDebug.apis.dbIncremental.risk'), perfLevel: 'good', perfNote: t('apiDebug.apis.dbIncremental.perf'), issueTag: t('apiDebug.apis.dbIncremental.issue'), issueDetail: t('apiDebug.apis.dbIncremental.issueDetail') },
  'DELETE /api/db/npk/:id': { name: t('apiDebug.apis.dbDeleteNpk.name'), description: t('apiDebug.apis.dbDeleteNpk.desc'), example: 'curl -X DELETE http://localhost:8556/api/db/npk/1', risk: 'warning', riskDesc: t('apiDebug.apis.dbDeleteNpk.risk') },
  'POST /api/cache/img/load': { name: t('apiDebug.apis.cacheLoad.name'), description: t('apiDebug.apis.cacheLoad.desc'), example: 'curl -X POST http://localhost:8556/api/cache/img/load -H "Content-Type: application/json" -d \'{"name":"sprite_character.NPK","index":0}\'', perfLevel: 'slow', perfNote: t('apiDebug.apis.cacheLoad.perf'), issueTag: t('apiDebug.apis.cacheLoad.issue'), issueDetail: t('apiDebug.apis.cacheLoad.issueDetail') },
  'DELETE /api/cache/img/release': { name: t('apiDebug.apis.cacheRelease.name'), description: t('apiDebug.apis.cacheRelease.desc'), example: 'curl -X DELETE http://localhost:8556/api/cache/img/release -H "Content-Type: application/json" -d \'{"name":"sprite_character.NPK","index":0}\'', perfLevel: 'good' },
  'DELETE /api/cache/img/release-all': { name: t('apiDebug.apis.cacheReleaseAll.name'), description: t('apiDebug.apis.cacheReleaseAll.desc'), example: 'curl -X DELETE http://localhost:8556/api/cache/img/release-all', perfLevel: 'good' },
  'GET /api/cache/img/status': { name: t('apiDebug.apis.cacheStatus.name'), description: t('apiDebug.apis.cacheStatus.desc'), example: 'curl http://localhost:8556/api/cache/img/status', perfLevel: 'good', perfNote: t('apiDebug.apis.cacheStatus.perf') },
  'GET /api/external-npk/albums': { name: t('apiDebug.apis.extNpkAlbums.name'), description: t('apiDebug.apis.extNpkAlbums.desc'), example: 'curl http://localhost:8556/api/external-npk/albums', perfLevel: 'good' },
  'POST /api/external-npk/albums': { name: t('apiDebug.apis.extNpkUpload.name'), description: t('apiDebug.apis.extNpkUpload.desc'), example: 'curl -X POST http://localhost:8556/api/external-npk/albums -F "file=@sprite.NPK"', perfLevel: 'good' },
  'GET /api/external-npk/frame': { name: t('apiDebug.apis.extNpkFrame.name'), description: t('apiDebug.apis.extNpkFrame.desc'), example: 'curl "http://localhost:8556/api/external-npk/frame?name=sprite.NPK&index=0&frameIndex=0"', perfLevel: 'good' },
  'GET /api/external-npk/download': { name: t('apiDebug.apis.extNpkDownload.name'), description: t('apiDebug.apis.extNpkDownload.desc'), example: 'curl -O "http://localhost:8556/api/external-npk/download?name=sprite.NPK"', perfLevel: 'good' },
  'GET /api/tools/:name': { name: t('apiDebug.apis.toolsGetFile.name'), description: t('apiDebug.apis.toolsGetFile.desc'), example: 'curl http://localhost:8556/api/tools/town.html', perfLevel: 'good' },
  'GET /api/health': { name: t('apiDebug.apis.health.name'), description: t('apiDebug.apis.health.desc'), example: 'curl http://localhost:8556/api/health', perfLevel: 'good' },
  'GET /api/npks': { name: t('apiDebug.apis.npksCompat.name'), description: t('apiDebug.apis.npksCompat.desc'), example: 'curl http://localhost:8556/api/npks', perfLevel: 'good', perfNote: t('apiDebug.apis.npksCompat.perf') },
  'GET /api/npks/:id/imgs': { name: t('apiDebug.apis.npksImgs.name'), description: t('apiDebug.apis.npksImgs.desc'), example: 'curl http://localhost:8556/api/npks/1/imgs', perfLevel: 'good' },
  'GET /api/npks/:id/frames': { name: t('apiDebug.apis.npksFrames.name'), description: t('apiDebug.apis.npksFrames.desc'), example: 'curl http://localhost:8556/api/npks/1/frames', perfLevel: 'good' },
  'GET /api/frame/by-path': { name: t('apiDebug.apis.frameByPath.name'), description: t('apiDebug.apis.frameByPath.desc'), example: 'curl "http://localhost:8556/api/frame/by-path?path=sprite/character/swordman.img&frame=0"', perfLevel: 'slow', perfNote: t('apiDebug.apis.frameByPath.perf'), issueTag: t('apiDebug.apis.frameByPath.issue'), issueDetail: t('apiDebug.apis.frameByPath.issueDetail') },
  'POST /api/frames/batch': { name: t('apiDebug.apis.framesBatch.name'), description: t('apiDebug.apis.framesBatch.desc'), example: 'curl -X POST http://localhost:8556/api/frames/batch -H "Content-Type: application/json" -d \'{"npkId":1,"imgIndices":[0,1,2]}\'', perfLevel: 'good' },
  'POST /api/frames/album-batch': { name: t('apiDebug.apis.framesAlbumBatch.name'), description: t('apiDebug.apis.framesAlbumBatch.desc'), example: 'curl -X POST http://localhost:8556/api/frames/album-batch -H "Content-Type: application/json" -d \'{"npkName":"sprite_character.NPK","indices":[0,1]}\'', perfLevel: 'good', perfNote: t('apiDebug.apis.framesAlbumBatch.perf') },
  'POST /api/overlay': { name: t('apiDebug.apis.overlay.name'), description: t('apiDebug.apis.overlay.desc'), example: 'curl -X POST http://localhost:8556/api/overlay -H "Content-Type: application/json" -d \'{"layers":[{"path":"bg.png","x":0,"y":0},{"path":"char.png","x":100,"y":50}]}\'', perfLevel: 'good' },
  'POST /api/external-img/upload': { name: t('apiDebug.apis.extImgUpload.name'), description: t('apiDebug.apis.extImgUpload.desc'), example: 'curl -X POST http://localhost:8556/api/external-img/upload -F "file=@swordman.img"', perfLevel: 'good' },
  'GET /api/external-img/info': { name: t('apiDebug.apis.extImgInfo.name'), description: t('apiDebug.apis.extImgInfo.desc'), example: 'curl http://localhost:8556/api/external-img/info', perfLevel: 'good' },
  'GET /api/external-img/frame': { name: t('apiDebug.apis.extImgFrame.name'), description: t('apiDebug.apis.extImgFrame.desc'), example: 'curl "http://localhost:8556/api/external-img/frame?frameIndex=0"', perfLevel: 'good' },
  'GET /api/videos/list': { name: t('apiDebug.apis.videosList.name'), description: t('apiDebug.apis.videosList.desc'), example: 'curl http://localhost:8556/api/videos/list', perfLevel: 'good' },
  'GET /api/videos/stats': { name: t('apiDebug.apis.videosStats.name'), description: t('apiDebug.apis.videosStats.desc'), example: 'curl http://localhost:8556/api/videos/stats', perfLevel: 'good' },
  'GET /api/videos/:id': { name: t('apiDebug.apis.videosDetail.name'), description: t('apiDebug.apis.videosDetail.desc'), example: 'curl http://localhost:8556/api/videos/1', perfLevel: 'good' },
  'POST /api/videos/scan': { name: t('apiDebug.apis.videosScan.name'), description: t('apiDebug.apis.videosScan.desc'), example: 'curl -X POST http://localhost:8556/api/videos/scan', risk: 'warning', riskDesc: t('apiDebug.apis.videosScan.risk'), perfLevel: 'slow' },
  'POST /api/videos/scan-dir': { name: t('apiDebug.apis.videosScanDir.name'), description: t('apiDebug.apis.videosScanDir.desc'), example: 'curl -X POST http://localhost:8556/api/videos/scan-dir -H "Content-Type: application/json" -d \'{"path":"/data/videos"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.videosScanDir.risk'), perfLevel: 'slow' },
  'POST /api/videos/:id/decrypt': { name: t('apiDebug.apis.videosDecrypt.name'), description: t('apiDebug.apis.videosDecrypt.desc'), example: 'curl -X POST http://localhost:8556/api/videos/1/decrypt', risk: 'warning', riskDesc: t('apiDebug.apis.videosDecrypt.risk'), perfLevel: 'slow' },
  'POST /api/videos/:id/encrypt': { name: t('apiDebug.apis.videosEncrypt.name'), description: t('apiDebug.apis.videosEncrypt.desc'), example: 'curl -X POST http://localhost:8556/api/videos/1/encrypt', risk: 'warning', riskDesc: t('apiDebug.apis.videosEncrypt.risk'), perfLevel: 'slow' },
  'DELETE /api/videos/:id': { name: t('apiDebug.apis.videosDelete.name'), description: t('apiDebug.apis.videosDelete.desc'), example: 'curl -X DELETE http://localhost:8556/api/videos/1', risk: 'danger', riskDesc: t('apiDebug.apis.videosDelete.risk') },
  'POST /api/videos/batch-delete': { name: t('apiDebug.apis.videosBatchDelete.name'), description: t('apiDebug.apis.videosBatchDelete.desc'), example: 'curl -X POST http://localhost:8556/api/videos/batch-delete -H "Content-Type: application/json" -d \'{"ids":[1,2,3]}\'', risk: 'danger', riskDesc: t('apiDebug.apis.videosBatchDelete.risk') },
  'GET /api/videos/:id/stream': { name: t('apiDebug.apis.videosStream.name'), description: t('apiDebug.apis.videosStream.desc'), example: 'curl "http://localhost:8556/api/videos/1/stream?resolution=720p"', perfLevel: 'heavy', perfNote: t('apiDebug.apis.videosStream.perf') },
  'GET /api/videos/:id/download': { name: t('apiDebug.apis.videosDownload.name'), description: t('apiDebug.apis.videosDownload.desc'), example: 'curl -O "http://localhost:8556/api/videos/1/download?resolution=1080p"', perfLevel: 'heavy', perfNote: t('apiDebug.apis.videosDownload.perf') },
  'GET /api/videos/play': { name: t('apiDebug.apis.videosPlay.name'), description: t('apiDebug.apis.videosPlay.desc'), example: 'curl "http://localhost:8556/api/videos/play?path=/data/videos/intro.mp4"', perfNote: t('apiDebug.apis.videosPlay.perf') },
  'GET /api/db/videos/stats': { name: t('apiDebug.apis.dbVideosStats.name'), description: t('apiDebug.apis.dbVideosStats.desc'), example: 'curl http://localhost:8556/api/db/videos/stats', perfLevel: 'good' },
  'POST /api/db/videos/cleanup': { name: t('apiDebug.apis.dbVideosCleanup.name'), description: t('apiDebug.apis.dbVideosCleanup.desc'), example: 'curl -X POST http://localhost:8556/api/db/videos/cleanup', risk: 'warning', riskDesc: t('apiDebug.apis.dbVideosCleanup.risk') },
  'POST /api/db/videos/rebuild': { name: t('apiDebug.apis.dbVideosRebuild.name'), description: t('apiDebug.apis.dbVideosRebuild.desc'), example: 'curl -X POST http://localhost:8556/api/db/videos/rebuild', risk: 'danger', riskDesc: t('apiDebug.apis.dbVideosRebuild.risk') },
  'POST /api/db/videos/compact': { name: t('apiDebug.apis.dbVideosCompact.name'), description: t('apiDebug.apis.dbVideosCompact.desc'), example: 'curl -X POST http://localhost:8556/api/db/videos/compact', risk: 'warning', riskDesc: t('apiDebug.apis.dbVideosCompact.risk') },
  'POST /api/npk/:name/assets/add-link': { name: t('apiDebug.apis.assetsAddLink.name'), description: t('apiDebug.apis.assetsAddLink.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/add-link -H "Content-Type: application/json" -d \'{"index":0,"targetIndex":5}\'', risk: 'warning', riskDesc: t('apiDebug.apis.assetsAddLink.risk') },
  'POST /api/npk/:name/assets/batch-import': { name: t('apiDebug.apis.assetsBatchImport.name'), description: t('apiDebug.apis.assetsBatchImport.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/assets/batch-import -F "files=@frame1.png" -F "files=@frame2.png"', risk: 'warning', riskDesc: t('apiDebug.apis.assetsBatchImport.risk') },
  'PUT /api/npk/:name/assets/:index/modify-link': { name: t('apiDebug.apis.assetsModifyLink.name'), description: t('apiDebug.apis.assetsModifyLink.desc'), example: 'curl -X PUT http://localhost:8556/api/npk/sprite_character.NPK/assets/0/modify-link -H "Content-Type: application/json" -d \'{"frameIndex":2,"targetIndex":8}\'', risk: 'warning', riskDesc: t('apiDebug.apis.assetsModifyLink.risk') },
  'GET /api/npk/:name/album/export-coords': { name: t('apiDebug.apis.albumExportCoords.name'), description: t('apiDebug.apis.albumExportCoords.desc'), example: 'curl "http://localhost:8556/api/npk/sprite_character.NPK/album/export-coords?index=0"', perfLevel: 'good', perfNote: t('apiDebug.apis.albumExportCoords.perf') },
  'POST /api/npk/:name/album/import-coords': { name: t('apiDebug.apis.albumImportCoords.name'), description: t('apiDebug.apis.albumImportCoords.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/album/import-coords -F "file=@coords.json"', risk: 'warning', riskDesc: t('apiDebug.apis.albumImportCoords.risk') },
  'POST /api/npk/:name/album/set-target': { name: t('apiDebug.apis.albumSetTarget.name'), description: t('apiDebug.apis.albumSetTarget.desc'), example: 'curl -X POST http://localhost:8556/api/npk/sprite_character.NPK/album/set-target -H "Content-Type: application/json" -d \'{"path":"sprite/character/swordman.img","target":"sprite/character/base.img"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.albumSetTarget.risk') },
  'DELETE /api/npk/:name/album/target': { name: t('apiDebug.apis.albumClearTarget.name'), description: t('apiDebug.apis.albumClearTarget.desc'), example: 'curl -X DELETE "http://localhost:8556/api/npk/sprite_character.NPK/album/target?path=sprite/character/swordman.img"', risk: 'warning', riskDesc: t('apiDebug.apis.albumClearTarget.risk') },
  'GET /api/music/list': { name: t('apiDebug.apis.musicList.name'), description: t('apiDebug.apis.musicList.desc'), example: 'curl "http://localhost:8556/api/music/list?query=bgm&format=mp3"', perfLevel: 'good' },
  'GET /api/music/stats': { name: t('apiDebug.apis.musicStats.name'), description: t('apiDebug.apis.musicStats.desc'), example: 'curl http://localhost:8556/api/music/stats', perfLevel: 'good' },
  'GET /api/music/:id': { name: t('apiDebug.apis.musicDetail.name'), description: t('apiDebug.apis.musicDetail.desc'), example: 'curl http://localhost:8556/api/music/1', perfLevel: 'good' },
  'POST /api/music/scan': { name: t('apiDebug.apis.musicScan.name'), description: t('apiDebug.apis.musicScan.desc'), example: 'curl -X POST http://localhost:8556/api/music/scan -H "Content-Type: application/json" -d \'{"dir":"/data/bgm"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.musicScan.risk'), perfLevel: 'slow' },
  'DELETE /api/music/:id': { name: t('apiDebug.apis.musicDelete.name'), description: t('apiDebug.apis.musicDelete.desc'), example: 'curl -X DELETE "http://localhost:8556/api/music/1?delete_file=true"', risk: 'danger', riskDesc: t('apiDebug.apis.musicDelete.risk') },
  'POST /api/music/batch-delete': { name: t('apiDebug.apis.musicBatchDelete.name'), description: t('apiDebug.apis.musicBatchDelete.desc'), example: 'curl -X POST http://localhost:8556/api/music/batch-delete -H "Content-Type: application/json" -d \'{"ids":[1,2,3],"delete_file":false}\'', risk: 'danger', riskDesc: t('apiDebug.apis.musicBatchDelete.risk') },
  'GET /api/music/:id/stream': { name: t('apiDebug.apis.musicStream.name'), description: t('apiDebug.apis.musicStream.desc'), example: 'curl -H "Range: bytes=0-1048575" http://localhost:8556/api/music/1/stream -o part.mp3', perfLevel: 'good' },
  'POST /api/music/:id/convert': { name: t('apiDebug.apis.musicConvert.name'), description: t('apiDebug.apis.musicConvert.desc'), example: 'curl -X POST http://localhost:8556/api/music/1/convert -H "Content-Type: application/json" -d \'{"target_format":"ogg"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.musicConvert.risk'), perfLevel: 'heavy' },
  'GET /api/db/music/stats': { name: t('apiDebug.apis.dbMusicStats.name'), description: t('apiDebug.apis.dbMusicStats.desc'), example: 'curl http://localhost:8556/api/db/music/stats', perfLevel: 'good' },
  'POST /api/db/music/cleanup': { name: t('apiDebug.apis.dbMusicCleanup.name'), description: t('apiDebug.apis.dbMusicCleanup.desc'), example: 'curl -X POST http://localhost:8556/api/db/music/cleanup', risk: 'warning', riskDesc: t('apiDebug.apis.dbMusicCleanup.risk') },
  'POST /api/db/music/rebuild': { name: t('apiDebug.apis.dbMusicRebuild.name'), description: t('apiDebug.apis.dbMusicRebuild.desc'), example: 'curl -X POST http://localhost:8556/api/db/music/rebuild', risk: 'danger', riskDesc: t('apiDebug.apis.dbMusicRebuild.risk'), perfLevel: 'slow' },
  'POST /api/db/music/compact': { name: t('apiDebug.apis.dbMusicCompact.name'), description: t('apiDebug.apis.dbMusicCompact.desc'), example: 'curl -X POST http://localhost:8556/api/db/music/compact', risk: 'warning', riskDesc: t('apiDebug.apis.dbMusicCompact.risk') },
  'GET /api/soundpacks/list': { name: t('apiDebug.apis.soundpacksList.name'), description: t('apiDebug.apis.soundpacksList.desc'), example: 'curl "http://localhost:8556/api/soundpacks/list?query=sword"', perfLevel: 'good' },
  'GET /api/soundpacks/stats': { name: t('apiDebug.apis.soundpacksStats.name'), description: t('apiDebug.apis.soundpacksStats.desc'), example: 'curl http://localhost:8556/api/soundpacks/stats', perfLevel: 'good' },
  'GET /api/soundpacks/:id': { name: t('apiDebug.apis.soundpacksDetail.name'), description: t('apiDebug.apis.soundpacksDetail.desc'), example: 'curl http://localhost:8556/api/soundpacks/1', perfLevel: 'good' },
  'POST /api/soundpacks/scan': { name: t('apiDebug.apis.soundpacksScan.name'), description: t('apiDebug.apis.soundpacksScan.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/scan -H "Content-Type: application/json" -d \'{"dir":"/data/sound"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksScan.risk'), perfLevel: 'slow' },
  'DELETE /api/soundpacks/:id': { name: t('apiDebug.apis.soundpacksDelete.name'), description: t('apiDebug.apis.soundpacksDelete.desc'), example: 'curl -X DELETE "http://localhost:8556/api/soundpacks/1?delete_file=true"', risk: 'danger', riskDesc: t('apiDebug.apis.soundpacksDelete.risk') },
  'POST /api/soundpacks/batch-delete': { name: t('apiDebug.apis.soundpacksBatchDelete.name'), description: t('apiDebug.apis.soundpacksBatchDelete.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/batch-delete -H "Content-Type: application/json" -d \'{"ids":[1,2]}\'', risk: 'danger', riskDesc: t('apiDebug.apis.soundpacksBatchDelete.risk') },
  'POST /api/soundpacks/:id/decrypt': { name: t('apiDebug.apis.soundpacksDecrypt.name'), description: t('apiDebug.apis.soundpacksDecrypt.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/1/decrypt', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksDecrypt.risk'), perfLevel: 'slow' },
  'GET /api/soundpacks/:id/entries': { name: t('apiDebug.apis.soundpacksEntries.name'), description: t('apiDebug.apis.soundpacksEntries.desc'), example: 'curl http://localhost:8556/api/soundpacks/1/entries', perfLevel: 'good' },
  'GET /api/soundpacks/:id/entries/:eid/stream': { name: t('apiDebug.apis.soundpacksEntryStream.name'), description: t('apiDebug.apis.soundpacksEntryStream.desc'), example: 'curl http://localhost:8556/api/soundpacks/1/entries/5/stream -o hit.ogg', perfLevel: 'good' },
  'GET /api/soundpacks/:id/entries/:eid/download': { name: t('apiDebug.apis.soundpacksEntryDownload.name'), description: t('apiDebug.apis.soundpacksEntryDownload.desc'), example: 'curl -O http://localhost:8556/api/soundpacks/1/entries/5/download', perfLevel: 'good' },
  'GET /api/soundpacks/:id/entries/:eid/convert': { name: t('apiDebug.apis.soundpacksEntryConvert.name'), description: t('apiDebug.apis.soundpacksEntryConvert.desc'), example: 'curl "http://localhost:8556/api/soundpacks/1/entries/5/convert?target_format=wav" -o hit.wav', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksEntryConvert.risk'), perfLevel: 'heavy' },
  'POST /api/soundpacks/:id/entries/import': { name: t('apiDebug.apis.soundpacksEntryImport.name'), description: t('apiDebug.apis.soundpacksEntryImport.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/1/entries/import -F "file=@hit.ogg" -F "entry_path=sound/sword/hit.ogg"', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksEntryImport.risk') },
  'POST /api/soundpacks/:id/entries/batch-export': { name: t('apiDebug.apis.soundpacksEntryBatchExport.name'), description: t('apiDebug.apis.soundpacksEntryBatchExport.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/1/entries/batch-export -H "Content-Type: application/json" -d \'{"entry_ids":[1,5,10]}\'', perfLevel: 'good' },
  'POST /api/soundpacks/:id/entries/batch-import': { name: t('apiDebug.apis.soundpacksEntryBatchImport.name'), description: t('apiDebug.apis.soundpacksEntryBatchImport.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/1/entries/batch-import -F "files=@sound@sword@hit.ogg" -F "files=@sound@sword@slash.ogg"', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksEntryBatchImport.risk') },
  'POST /api/soundpacks/:id/entries/batch-delete': { name: t('apiDebug.apis.soundpacksEntryBatchDelete.name'), description: t('apiDebug.apis.soundpacksEntryBatchDelete.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/1/entries/batch-delete -H "Content-Type: application/json" -d \'{"entry_ids":[1,3,5]}\'', risk: 'danger', riskDesc: t('apiDebug.apis.soundpacksEntryBatchDelete.risk') },
  'PUT /api/soundpacks/:id/entries/:eid/rename': { name: t('apiDebug.apis.soundpacksEntryRename.name'), description: t('apiDebug.apis.soundpacksEntryRename.desc'), example: 'curl -X PUT http://localhost:8556/api/soundpacks/1/entries/5/rename -H "Content-Type: application/json" -d \'{"new_path":"sound/sword/critical_hit.ogg"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksEntryRename.risk') },
  'DELETE /api/soundpacks/:id/entries/:eid': { name: t('apiDebug.apis.soundpacksEntryDelete.name'), description: t('apiDebug.apis.soundpacksEntryDelete.desc'), example: 'curl -X DELETE http://localhost:8556/api/soundpacks/1/entries/5', risk: 'danger', riskDesc: t('apiDebug.apis.soundpacksEntryDelete.risk') },
  'POST /api/soundpacks/:id/rebuild': { name: t('apiDebug.apis.soundpacksRebuild.name'), description: t('apiDebug.apis.soundpacksRebuild.desc'), example: 'curl -X POST http://localhost:8556/api/soundpacks/1/rebuild', risk: 'warning', riskDesc: t('apiDebug.apis.soundpacksRebuild.risk'), perfLevel: 'slow' },
  'GET /api/db/soundpacks/stats': { name: t('apiDebug.apis.dbSoundpacksStats.name'), description: t('apiDebug.apis.dbSoundpacksStats.desc'), example: 'curl http://localhost:8556/api/db/soundpacks/stats', perfLevel: 'good' },
  'POST /api/db/soundpacks/cleanup': { name: t('apiDebug.apis.dbSoundpacksCleanup.name'), description: t('apiDebug.apis.dbSoundpacksCleanup.desc'), example: 'curl -X POST http://localhost:8556/api/db/soundpacks/cleanup', risk: 'warning', riskDesc: t('apiDebug.apis.dbSoundpacksCleanup.risk') },
  'POST /api/db/soundpacks/rebuild': { name: t('apiDebug.apis.dbSoundpacksRebuild.name'), description: t('apiDebug.apis.dbSoundpacksRebuild.desc'), example: 'curl -X POST http://localhost:8556/api/db/soundpacks/rebuild', risk: 'danger', riskDesc: t('apiDebug.apis.dbSoundpacksRebuild.risk'), perfLevel: 'slow' },
  'POST /api/db/soundpacks/compact': { name: t('apiDebug.apis.dbSoundpacksCompact.name'), description: t('apiDebug.apis.dbSoundpacksCompact.desc'), example: 'curl -X POST http://localhost:8556/api/db/soundpacks/compact', risk: 'warning', riskDesc: t('apiDebug.apis.dbSoundpacksCompact.risk') },
  'GET /api/xml-audio/list': { name: t('apiDebug.apis.xmlAudioList.name'), description: t('apiDebug.apis.xmlAudioList.desc'), example: 'curl "http://localhost:8556/api/xml-audio/list?type=music&query=town"', perfLevel: 'good' },
  'GET /api/xml-audio/entry/:type/:id': { name: t('apiDebug.apis.xmlAudioEntry.name'), description: t('apiDebug.apis.xmlAudioEntry.desc'), example: 'curl http://localhost:8556/api/xml-audio/entry/music/5', perfLevel: 'good' },
  'POST /api/xml-audio/entry': { name: t('apiDebug.apis.xmlAudioCreate.name'), description: t('apiDebug.apis.xmlAudioCreate.desc'), example: 'curl -X POST http://localhost:8556/api/xml-audio/entry -H "Content-Type: application/json" -d \'{"type":"music","name":"town","file":"Music/town_bgm.ogg","volume":1.0,"loop":true}\'', risk: 'warning', riskDesc: t('apiDebug.apis.xmlAudioCreate.risk') },
  'DELETE /api/xml-audio/entry/:type/:id': { name: t('apiDebug.apis.xmlAudioDelete.name'), description: t('apiDebug.apis.xmlAudioDelete.desc'), example: 'curl -X DELETE http://localhost:8556/api/xml-audio/entry/effect/3', risk: 'danger', riskDesc: t('apiDebug.apis.xmlAudioDelete.risk') },
  'POST /api/xml-audio/export': { name: t('apiDebug.apis.xmlAudioExport.name'), description: t('apiDebug.apis.xmlAudioExport.desc'), example: 'curl -X POST http://localhost:8556/api/xml-audio/export', risk: 'warning', riskDesc: t('apiDebug.apis.xmlAudioExport.risk') },
  'GET /api/xml-audio/check-missing': { name: t('apiDebug.apis.xmlAudioCheckMissing.name'), description: t('apiDebug.apis.xmlAudioCheckMissing.desc'), example: 'curl http://localhost:8556/api/xml-audio/check-missing', perfLevel: 'good' },
  'POST /api/xml-audio/reload': { name: t('apiDebug.apis.xmlAudioReload.name'), description: t('apiDebug.apis.xmlAudioReload.desc'), example: 'curl -X POST http://localhost:8556/api/xml-audio/reload', risk: 'warning', riskDesc: t('apiDebug.apis.xmlAudioReload.risk') },
  'GET /api/xml-audio/stream': { name: t('apiDebug.apis.xmlAudioStream.name'), description: t('apiDebug.apis.xmlAudioStream.desc'), example: 'curl "http://localhost:8556/api/xml-audio/stream?file=Music/town_bgm.ogg" -o town.ogg', perfLevel: 'good' },
  'POST /api/xml-audio/open': { name: t('apiDebug.apis.xmlAudioOpen.name'), description: t('apiDebug.apis.xmlAudioOpen.desc'), example: 'curl -X POST http://localhost:8556/api/xml-audio/open -H "Content-Type: application/json" -d \'{"path":"/data/sound/audio.xml"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.xmlAudioOpen.risk') },
  'GET /api/xml-audio/list-files': { name: t('apiDebug.apis.xmlAudioListFiles.name'), description: t('apiDebug.apis.xmlAudioListFiles.desc'), example: 'curl "http://localhost:8556/api/xml-audio/list-files?dir=/data/sound"', perfLevel: 'good' },
  'POST /api/tools/convert-upload': {
    name: t('apiDebug.apis.toolsConvertUpload.name'),
    description: t('apiDebug.apis.toolsConvertUpload.desc'),
    example: 'curl -X POST http://localhost:8556/api/tools/convert-upload -F "file=@sprite.img"',
    risk: 'warning', riskDesc: t('apiDebug.apis.toolsConvertUpload.risk'), perfLevel: 'slow',
  },
  'GET /api/tools/convert-download/:taskId': { name: t('apiDebug.apis.toolsConvertDownload.name'), description: t('apiDebug.apis.toolsConvertDownload.desc'), example: 'curl -O http://localhost:8556/api/tools/convert-download/abc123', perfLevel: 'good' },
  'GET /api/tools/convert-status/:taskId': { name: t('apiDebug.apis.toolsConvertStatus.name'), description: t('apiDebug.apis.toolsConvertStatus.desc'), example: 'curl http://localhost:8556/api/tools/convert-status/abc123', perfLevel: 'good' },
  'GET /api/avatars/list': { name: t('apiDebug.apis.avatarsList.name'), description: t('apiDebug.apis.avatarsList.desc'), example: 'curl http://localhost:8556/api/avatars/list', perfLevel: 'good' },
  'POST /api/avatars/upload': { name: t('apiDebug.apis.avatarsUpload.name'), description: t('apiDebug.apis.avatarsUpload.desc'), example: 'curl -X POST http://localhost:8556/api/avatars/upload -F "file=@avatar.png"', perfLevel: 'good' },
  'GET /api/tools/list': { name: t('apiDebug.apis.toolsList.name'), description: t('apiDebug.apis.toolsList.desc'), example: 'curl http://localhost:8556/api/tools/list', perfLevel: 'good' },
  'POST /api/tools/open': { name: t('apiDebug.apis.toolsOpen.name'), description: t('apiDebug.apis.toolsOpen.desc'), example: 'curl -X POST http://localhost:8556/api/tools/open -H "Content-Type: application/json" -d \'{"name":"town.html"}\'', perfLevel: 'good' },
  'POST /api/tools/open-folder': { name: t('apiDebug.apis.toolsOpenFolder.name'), description: t('apiDebug.apis.toolsOpenFolder.desc'), example: 'curl -X POST http://localhost:8556/api/tools/open-folder -H "Content-Type: application/json" -d \'{"path":"/data/npk"}\'', perfLevel: 'good' },
  'GET /api/tools/scan-config': { name: t('apiDebug.apis.toolsScanConfig.name'), description: t('apiDebug.apis.toolsScanConfig.desc'), example: 'curl http://localhost:8556/api/tools/scan-config', perfLevel: 'good' },
  'POST /api/tools/create-config': { name: t('apiDebug.apis.toolsCreateConfig.name'), description: t('apiDebug.apis.toolsCreateConfig.desc'), example: 'curl -X POST http://localhost:8556/api/tools/create-config -H "Content-Type: application/json" -d \'{"path":"/config/theme.json","content":"{\\\"theme\\\":\\\"dark\\\"}"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.toolsCreateConfig.risk') },
  'DELETE /api/tools/delete-config': { name: t('apiDebug.apis.toolsDeleteConfig.name'), description: t('apiDebug.apis.toolsDeleteConfig.desc'), example: 'curl -X DELETE http://localhost:8556/api/tools/delete-config -H "Content-Type: application/json" -d \'{"path":"/config/theme.json"}\'', risk: 'warning', riskDesc: t('apiDebug.apis.toolsDeleteConfig.risk') },
  'GET /api/debug/routes': { name: t('apiDebug.apis.debugRoutes.name'), description: t('apiDebug.apis.debugRoutes.desc'), example: 'curl http://localhost:8556/api/debug/routes', perfLevel: 'good' },
}))

// 根据路径生成可读名称（带中文映射）
function generateApiName(method: string, path: string): string {
  const key = `${method} ${path}`
  const map = apiMetadataMap.value
  if (map[key]) {
    return map[key].name || key
  }
  for (const [mapKey, meta] of Object.entries(map)) {
    const pattern = mapKey.replace(/:\w+/g, '[^/]+')
    const regex = new RegExp(`^${pattern}$`)
    if (regex.test(key)) {
      return meta.name || key
    }
  }
  let cleanPath = path.replace(/^\/api\//, '')
  cleanPath = cleanPath.replace(/\/:\w+/g, '')
  cleanPath = cleanPath.replace(/[/_-]/g, ' ')
  return cleanPath.trim().split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
}

function getApiMetadata(method: string, path: string): Partial<ApiDef> {
  const key = `${method} ${path}`
  const map = apiMetadataMap.value
  if (map[key]) {
    return map[key]
  }
  for (const [mapKey, meta] of Object.entries(map)) {
    const pattern = mapKey.replace(/:\w+/g, '[^/]+')
    const regex = new RegExp(`^${pattern}$`)
    if (regex.test(key)) {
      return meta
    }
  }
  return {}
}

// 将后端路由转换为前端 ApiDef
function routeToApiDef(route: { method: string; path: string; group?: string }): ApiDef {
  // 如果后端没返回 group，根据路径前缀自动推断分组
  const group = route.group || inferApiGroup(route.path)
  const params = extractPathParams(route.path)
  const name = generateApiName(route.method, route.path)
  const metadata = getApiMetadata(route.method, route.path)

  return {
    method: route.method,
    path: route.path,
    name,
    description: metadata.description,
    example: metadata.example,
    params,
    group,
    fromRouteTable: true,
    risk: metadata.risk,
    riskDesc: metadata.riskDesc,
    perfNote: metadata.perfNote,
    perfLevel: metadata.perfLevel,
    issueTag: metadata.issueTag,
    issueDetail: metadata.issueDetail,
  }
}

// 根据路径前缀自动推断 API 分组
function inferApiGroup(path: string): string {
  if (path.startsWith('/api/npk')) return t('apiDebug.groups.npkManage')
  if (path.startsWith('/api/cache')) return t('apiDebug.groups.imgCache')
  if (path.startsWith('/api/library')) return t('apiDebug.groups.library')
  if (path.startsWith('/api/batch')) return t('apiDebug.groups.batch')
  if (path.startsWith('/api/music')) return t('apiDebug.groups.music')
  if (path.startsWith('/api/soundpacks')) return t('apiDebug.groups.soundpacks')
  if (path.startsWith('/api/xml-audio')) return t('apiDebug.groups.xmlAudio')
  if (path.startsWith('/api/videos') || path.startsWith('/api/db/videos')) return t('apiDebug.groups.videos')
  if (path.startsWith('/api/db/music')) return t('apiDebug.groups.dbMusic')
  if (path.startsWith('/api/db/soundpacks')) return t('apiDebug.groups.dbSoundpacks')
  if (path.startsWith('/api/db')) return t('apiDebug.groups.db')
  if (path.startsWith('/api/settings')) return t('apiDebug.groups.settings')
  if (path.startsWith('/api/external')) return t('apiDebug.groups.external')
  if (path.startsWith('/api/tools')) return t('apiDebug.groups.tools')
  if (path.startsWith('/api/avatars')) return t('apiDebug.groups.avatars')
  if (path.startsWith('/api/debug')) return t('apiDebug.groups.debug')
  if (path.startsWith('/api/frame') || path.startsWith('/api/npks') || path.startsWith('/api/overlay')) return t('apiDebug.groups.compat')
  if (path.startsWith('/api/health')) return t('apiDebug.groups.compat')
  if (path.startsWith('/ws')) return t('apiDebug.groups.websocket')
  return t('apiDebug.groups.other')
}

// 从后端加载路由列表
async function loadRoutes() {
  routesLoading.value = true
  try {
    const res = await axios.get('/api/debug/routes')
    const data = res.data
    if (data?.code === 0 && data?.data) {
      // 后端返回 data.data 直接是路由数组 [{method, path}, ...]
      const routesList = Array.isArray(data.data) ? data.data : (data.data.routes || [])
      apiList.value = routesList.map(routeToApiDef)
    } else {
      ElMessage.error(t('common.requestFailed'))
    }
  } catch (e: any) {
    ElMessage.error(t('common.requestFailed') + ': ' + (e.message || ''))
  } finally {
    routesLoading.value = false
  }
}

// 生命周期
onMounted(() => {
  loadRoutes()
})

// API 分组统计
const groupStats = computed(() => {
  const groups: Record<string, number> = {}
  apiList.value.forEach(api => {
    const group = api.group || t('apiDebug.groups.other')
    groups[group] = (groups[group] || 0) + 1
  })
  return Object.entries(groups).sort((a, b) => b[1] - a[1])
})

// 搜索
const searchQuery = ref('')
const selectedGroup = ref<string>('')

const filteredApis = computed(() => {
  let result = apiList.value
  
  // 按分组筛选
  if (selectedGroup.value) {
    result = result.filter(api => api.group === selectedGroup.value)
  }
  
  // 按搜索词筛选
  if (!searchQuery.value) return result
  const query = searchQuery.value.toLowerCase()
  return result.filter(api =>
    api.name.toLowerCase().includes(query) ||
    api.path.toLowerCase().includes(query) ||
    api.method.toLowerCase().includes(query) ||
    (api.issueTag && api.issueTag.toLowerCase().includes(query)) ||
    (api.group && api.group.toLowerCase().includes(query))
  )
})

// 当前选中的 API
const selectedApi = ref<ApiDef | null>(null)
const paramValues = ref<Record<string, any>>({})
const requestBody = ref('')
const responseData = ref<any>(null)
const responseStatus = ref<number>(0)
const loading = ref(false)
const responseTime = ref(0)
const responseSize = ref('')

// 选择 API
function selectApi(api: ApiDef) {
  selectedApi.value = api
  paramValues.value = {}
  requestBody.value = api.body || ''
  responseData.value = null
  responseStatus.value = 0
  responseTime.value = 0
  responseSize.value = ''
}

// 构建请求 URL
function buildUrl(): string {
  if (!selectedApi.value) return ''
  let url = selectedApi.value.path
  for (const param of selectedApi.value.params) {
    // 支持两种路径参数格式：{name} 和 :name
    const placeholder1 = `{${param.name}}`
    const placeholder2 = `:${param.name}`
    if (url.includes(placeholder1)) {
      url = url.replace(placeholder1, paramValues.value[param.name] || '')
    } else if (url.includes(placeholder2)) {
      url = url.replace(placeholder2, paramValues.value[param.name] || '')
    }
  }
  const queryParams: string[] = []
  for (const param of selectedApi.value.params) {
    if (!url.includes(`{${param.name}}`) && paramValues.value[param.name] !== undefined && paramValues.value[param.name] !== '') {
      queryParams.push(`${param.name}=${encodeURIComponent(paramValues.value[param.name])}`)
    }
  }
  if (queryParams.length > 0) {
    url += '?' + queryParams.join('&')
  }
  return url
}

// 格式化响应大小
function formatResponseSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

// 发送请求
async function sendRequest() {
  if (!selectedApi.value) return

  if (selectedApi.value.risk === 'danger') {
    const confirmed = confirm(t('apiDebug.confirmDanger', { desc: selectedApi.value.riskDesc }))
    if (!confirmed) return
  } else if (selectedApi.value.risk === 'warning') {
    const confirmed = confirm(t('apiDebug.confirmWarning', { desc: selectedApi.value.riskDesc }))
    if (!confirmed) return
  }

  loading.value = true
  responseData.value = null
  responseStatus.value = 0
  responseTime.value = 0
  responseSize.value = ''

  const url = buildUrl()
  const method = selectedApi.value.method.toLowerCase() as any
  const startTime = performance.now()

  try {
    const config: any = { method, url, responseType: 'json' }
    if (['post', 'put'].includes(method) && requestBody.value) {
      try {
        config.data = JSON.parse(requestBody.value)
      } catch {
        config.data = requestBody.value
      }
    }
    const res = await axios(config)
    const endTime = performance.now()
    responseTime.value = Math.round(endTime - startTime)
    responseData.value = res.data
    responseStatus.value = res.status
    // 估算响应大小（截断大响应避免内存问题）
    const jsonStr = JSON.stringify(res.data)
    const size = new Blob([jsonStr]).size
    responseSize.value = formatResponseSize(size)
    // 大响应截断显示
    if (size > 1024 * 1024) {
      responseData.value = { _truncated: true, _originalSize: formatResponseSize(size), _message: t('common.responseTooLarge'), _data: jsonStr.slice(0, 5000) + '...' }
    }
    ElMessage.success(t('common.operationSuccess') + ` (${responseTime.value}ms)`)
  } catch (e: any) {
    const endTime = performance.now()
    responseTime.value = Math.round(endTime - startTime)
    responseStatus.value = e.response?.status || 0
    responseData.value = e.response?.data || e.message
    const jsonStr = JSON.stringify(responseData.value)
    responseSize.value = formatResponseSize(new Blob([jsonStr]).size)
    ElMessage.error(t('common.requestFailed') + ` (${responseTime.value}ms): ` + (e.response?.data?.message || e.message))
  } finally {
    loading.value = false
  }
}

// 复制结果
function copyResult() {
  const text = JSON.stringify(responseData.value, null, 2)
  navigator.clipboard.writeText(text)
  ElMessage.success(t('common.copySuccess'))
}

function copyExample(text: string) {
  navigator.clipboard.writeText(text)
  ElMessage.success(t('common.copySuccess'))
}

// 清空结果
function clearResult() {
  responseData.value = null
  responseStatus.value = 0
  responseTime.value = 0
  responseSize.value = ''
}

// 性能等级标签
function getPerfTagType(level?: string): 'success' | 'warning' | 'danger' | 'info' | undefined {
  switch (level) {
    case 'good': return 'success'
    case 'slow': return 'warning'
    case 'heavy': return 'danger'
    default: return undefined
  }
}

function getPerfLabel(level?: string): string {
  switch (level) {
    case 'good': return t('apiDebug.perfLabelGood')
    case 'slow': return t('apiDebug.perfLabelSlow')
    case 'heavy': return t('apiDebug.perfLabelHeavy')
    default: return ''
  }
}

// 问题标签颜色
function getIssueTagType(tag?: string): 'danger' | 'warning' | 'info' | undefined {
  if (!tag) return undefined
  if (tag.includes('P0')) return 'danger'
  if (tag.includes('P1')) return 'warning'
  return 'info'
}

// 统计
const issueStats = computed(() => {
  const p0 = apiList.value.filter(a => a.issueTag?.includes('P0')).length
  const p1 = apiList.value.filter(a => a.issueTag?.includes('P1')).length
  const optimize = apiList.value.filter(a => a.issueTag && !a.issueTag.includes('P0') && !a.issueTag.includes('P1')).length
  const heavy = apiList.value.filter(a => a.perfLevel === 'heavy').length
  const slow = apiList.value.filter(a => a.perfLevel === 'slow').length
  const danger = apiList.value.filter(a => a.risk === 'danger').length
  const warning = apiList.value.filter(a => a.risk === 'warning').length
  return { p0, p1, optimize, heavy, slow, danger, warning, total: apiList.value.length }
})
</script>

<template>
  <div class="api-debug">
    <div class="page-header">
      <h2 class="page-title">{{ t('apiDebug.title') }}</h2>
      <div class="header-tags">
        <el-tag type="info" size="small" effect="plain">{{ t('apiDebug.apiCount', { count: issueStats.total }) }}</el-tag>
        <el-button
          :icon="Refresh"
          size="small"
          :loading="routesLoading"
          @click="loadRoutes"
          circle
          style="margin-left: 4px"
        />
        <el-tag v-if="issueStats.p0 > 0" type="danger" size="small" effect="dark">{{ t('apiDebug.criticalIssues', { count: issueStats.p0 }) }}</el-tag>
        <el-tag v-if="issueStats.p1 > 0" type="warning" size="small" effect="plain">{{ t('apiDebug.p1Issues', { count: issueStats.p1 }) }}</el-tag>
        <el-tag v-if="issueStats.danger > 0" type="danger" size="small" effect="plain">{{ t('apiDebug.dangerOps', { count: issueStats.danger }) }}</el-tag>
        <el-tag v-if="issueStats.warning > 0" type="warning" size="small" effect="plain">{{ t('apiDebug.warningOps', { count: issueStats.warning }) }}</el-tag>
        <el-tag v-if="issueStats.slow > 0 || issueStats.heavy > 0" type="info" size="small" effect="plain">{{ t('apiDebug.slowHeavy', { slow: issueStats.slow, heavy: issueStats.heavy }) }}</el-tag>
      </div>
    </div>

    <!-- 分组筛选 -->
    <div class="group-filter">
      <el-radio-group v-model="selectedGroup" size="small">
        <el-radio-button label="">{{ t('apiDebug.all') }} ({{ issueStats.total }})</el-radio-button>
        <el-radio-button v-for="[group, count] in groupStats" :key="group" :label="group">
          {{ group }} ({{ count }})
        </el-radio-button>
      </el-radio-group>
    </div>

    <el-row :gutter="16" class="content-row">
      <!-- 左侧: API 列表 -->
      <el-col :span="8">
        <el-card class="list-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('apiDebug.apiListTitle') }} ({{ filteredApis.length }})</span>
            </div>
          </template>

          <div class="search-box">
            <el-input
              v-model="searchQuery"
              :placeholder="t('apiDebug.searchPlaceholder')"
              :prefix-icon="Search"
              clearable
              size="small"
            />
          </div>

          <el-scrollbar class="api-list-scroll">
            <div class="api-list">
              <div
                v-for="api in filteredApis"
                :key="api.method + api.path"
                class="api-item"
                :class="{
                  active: selectedApi?.path === api.path && selectedApi?.method === api.method,
                  'risk-warning': api.risk === 'warning',
                  'risk-danger': api.risk === 'danger'
                }"
                @click="selectApi(api)"
              >
                <el-tag
                  :type="api.method === 'GET' ? 'success' : api.method === 'POST' ? 'primary' : api.method === 'DELETE' ? 'danger' : 'warning'"
                  size="small"
                  class="method-tag"
                >
                  {{ api.method }}
                </el-tag>
                <span class="api-name" :title="api.name">{{ api.name }}</span>
                <el-tag v-if="api.perfLevel" :type="getPerfTagType(api.perfLevel)" size="small" class="perf-tag">
                  {{ getPerfLabel(api.perfLevel) }}
                </el-tag>
                <el-tag v-if="api.issueTag" :type="getIssueTagType(api.issueTag)" size="small" class="issue-tag">
                  {{ api.issueTag }}
                </el-tag>
                <el-tag v-if="api.risk === 'danger'" type="danger" size="small" class="risk-tag">{{ t('apiDebug.danger') }}</el-tag>
                <el-tag v-else-if="api.risk === 'warning'" type="warning" size="small" class="risk-tag">{{ t('apiDebug.warning') }}</el-tag>
              </div>
            </div>
          </el-scrollbar>
        </el-card>
      </el-col>

      <!-- 右侧: 调试面板 -->
      <el-col :span="16">
        <el-card class="debug-card">
          <template #header>
            <div class="card-header">
              <span>{{ t('apiDebug.requestDebug') }}</span>
              <div v-if="selectedApi" class="header-tags">
                <el-tag
                  :type="selectedApi.method === 'GET' ? 'success' : selectedApi.method === 'POST' ? 'primary' : selectedApi.method === 'DELETE' ? 'danger' : 'warning'"
                  size="small"
                >
                  {{ selectedApi.method }}
                </el-tag>
                <span class="api-path">{{ selectedApi.path }}</span>
                <el-tag v-if="selectedApi.group" type="info" size="small" effect="plain">
                  {{ selectedApi.group }}
                </el-tag>
                <el-tag v-if="selectedApi.perfLevel" :type="getPerfTagType(selectedApi.perfLevel)" size="small" effect="plain">
                  {{ t('apiDebug.performance') }}: {{ getPerfLabel(selectedApi.perfLevel) }}
                </el-tag>
                <el-tag v-if="selectedApi.issueTag" :type="getIssueTagType(selectedApi.issueTag)" size="small" effect="plain">
                  {{ selectedApi.issueTag }}
                </el-tag>
              </div>
            </div>
          </template>

          <div v-if="!selectedApi" class="empty-tip">
            <div class="guide-header">
              <h3>{{ t('apiDebug.guideTitle') }}</h3>
            </div>
            <div class="guide-content">
              <div class="guide-step">
                <span class="step-num">1</span>
                <div>
                  <strong>{{ t('apiDebug.guideStep1Title') }}</strong>
                  <p>{{ t('apiDebug.guideStep1Desc') }}</p>
                </div>
              </div>
              <div class="guide-step">
                <span class="step-num">2</span>
                <div>
                  <strong>{{ t('apiDebug.guideStep2Title') }}</strong>
                  <p>{{ t('apiDebug.guideStep2Desc') }}</p>
                </div>
              </div>
              <div class="guide-step">
                <span class="step-num">3</span>
                <div>
                  <strong>{{ t('apiDebug.guideStep3Title') }}</strong>
                  <p>{{ t('apiDebug.guideStep3Desc') }}</p>
                </div>
              </div>
              <div class="guide-step">
                <span class="step-num">4</span>
                <div>
                  <strong>{{ t('apiDebug.guideStep4Title') }}</strong>
                  <p>{{ t('apiDebug.guideStep4Desc') }}</p>
                </div>
              </div>
              <el-divider />
              <div class="guide-tags">
                <p><strong>{{ t('apiDebug.tagLegend') }}</strong></p>
                <div class="tag-legend">
                  <div class="legend-item"><el-tag type="success" size="small">{{ t('apiDebug.perfLabelGood') }}</el-tag> {{ t('apiDebug.tagFast') }}</div>
                  <div class="legend-item"><el-tag type="warning" size="small">{{ t('apiDebug.perfLabelSlow') }}</el-tag> {{ t('apiDebug.tagSlow') }}</div>
                  <div class="legend-item"><el-tag type="danger" size="small">{{ t('apiDebug.perfLabelHeavy') }}</el-tag> {{ t('apiDebug.tagHeavy') }}</div>
                  <div class="legend-item"><el-tag type="danger" size="small" effect="dark">{{ t('apiDebug.danger') }}</el-tag> {{ t('apiDebug.tagDanger') }}</div>
                  <div class="legend-item"><el-tag type="warning" size="small" effect="dark">{{ t('apiDebug.warning') }}</el-tag> {{ t('apiDebug.tagWarning') }}</div>
                  <div class="legend-item"><el-tag type="info" size="small">{{ t('apiDebug.apis.npkListPaginated.issue') }}</el-tag> {{ t('apiDebug.tagRecommend') }}</div>
                </div>
              </div>
            </div>
          </div>

          <div v-else class="debug-content">
            <!-- 风险提示 -->
            <el-alert
              v-if="selectedApi.risk && selectedApi.risk !== 'safe'"
              :title="selectedApi.risk === 'danger' ? t('apiDebug.dangerOp') : t('apiDebug.caution')"
              :type="selectedApi.risk === 'danger' ? 'error' : 'warning'"
              :description="selectedApi.riskDesc"
              show-icon
              :closable="false"
              style="margin-bottom: 12px"
            />

            <!-- 性能提示 -->
            <el-alert
              v-if="selectedApi.perfNote"
              :title="t('apiDebug.perfHint')"
              type="info"
              :description="selectedApi.perfNote"
              show-icon
              :closable="false"
              style="margin-bottom: 12px"
            />

            <!-- 优化建议 -->
            <el-alert
              v-if="selectedApi.issueDetail"
              :title="t('apiDebug.optimizeHint') + ': ' + (selectedApi.issueTag || '')"
              :type="selectedApi.issueTag?.includes('P0') ? 'error' : 'warning'"
              :description="selectedApi.issueDetail"
              show-icon
              :closable="false"
              style="margin-bottom: 12px"
            />

            <!-- 接口说明 -->
            <el-alert
              v-if="selectedApi.description"
              :title="t('apiDebug.apiDesc')"
              type="info"
              :description="selectedApi.description"
              show-icon
              :closable="false"
              style="margin-bottom: 12px"
            />

            <!-- 请求示例 -->
            <div v-if="selectedApi.example" class="example-section">
              <h4>{{ t('apiDebug.requestExample') }}</h4>
              <div class="example-code">
                <code>{{ selectedApi.example }}</code>
                <el-button :icon="DocumentCopy" size="small" class="copy-btn" @click="copyExample(selectedApi.example)">{{ t('apiDebug.copy') }}</el-button>
              </div>
            </div>

            <!-- 参数表单 -->
            <div v-if="selectedApi.params.length > 0" class="param-section">
              <h4>{{ t('apiDebug.params') }}</h4>
              <div class="param-list">
                <div v-for="param in selectedApi.params" :key="param.name" class="param-item">
                  <el-input
                    v-model="paramValues[param.name]"
                    :placeholder="param.required ? `${param.name} (${t('apiDebug.required')})` : `${param.name} (${t('apiDebug.optional')})`"
                    size="small"
                  >
                    <template #prepend>{{ param.name }}</template>
                  </el-input>
                </div>
              </div>
            </div>

            <!-- 请求体 -->
            <div v-if="['POST', 'PUT'].includes(selectedApi.method)" class="body-section">
              <h4>{{ t('apiDebug.requestBody') }}</h4>
              <el-input
                v-model="requestBody"
                type="textarea"
                :rows="4"
                :placeholder="t('apiDebug.inputJsonBody')"
              />
            </div>

            <!-- 请求预览 -->
            <div class="preview-section">
              <h4>{{ t('apiDebug.requestPreview') }}</h4>
              <div class="request-preview">
                <code>{{ selectedApi.method }} {{ buildUrl() }}</code>
              </div>
            </div>

            <!-- 操作按钮 -->
            <div class="action-buttons">
              <el-button type="primary" :icon="Promotion" :loading="loading" @click="sendRequest">
                {{ t('apiDebug.sendRequest') }}
              </el-button>
              <el-button :icon="DocumentCopy" @click="copyResult" :disabled="!responseData">{{ t('apiDebug.copyResult') }}</el-button>
              <el-button :icon="Delete" @click="clearResult" :disabled="!responseData">{{ t('apiDebug.clear') }}</el-button>
            </div>

            <!-- 响应结果 -->
            <div v-if="responseData !== null" class="response-section">
              <h4>
                {{ t('apiDebug.responseResult') }}
                <el-tag :type="responseStatus >= 200 && responseStatus < 300 ? 'success' : 'danger'" size="small">
                  {{ responseStatus }}
                </el-tag>
                <span v-if="responseTime > 0" class="response-meta">
                  <el-icon><Timer /></el-icon> {{ responseTime }}ms
                </span>
                <span v-if="responseSize" class="response-meta">
                  {{ responseSize }}
                </span>
              </h4>
              <pre class="response-code">{{ JSON.stringify(responseData, null, 2) }}</pre>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.api-debug {
  height: calc(100vh - 90px);
  display: flex;
  flex-direction: column;

  .page-header {
    margin-bottom: 12px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 12px;

    .page-title {
      margin: 0;
      color: var(--text-primary);
    }

    .header-tags {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
  }

  .group-filter {
    margin-bottom: 12px;
    flex-shrink: 0;
    
    :deep(.el-radio-group) {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }
    
    :deep(.el-radio-button__inner) {
      padding: 6px 12px;
      font-size: 12px;
    }
  }

  .list-card,
  .debug-card {
    background: var(--bg-primary);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);

    &:hover {
      border-color: rgba(251, 113, 133, 0.4);
      box-shadow: 0 8px 32px rgba(251, 113, 133, 0.18),
                  0 4px 16px rgba(251, 113, 133, 0.1);
      transform: translateY(-2px);
    }
  }

  :deep(.el-card__header) {
    background: var(--bg-primary);
  }

  .content-row {
    flex: 1;
    min-height: 0;

    .el-col {
      height: 100%;
    }

    .el-card {
      height: 100%;
      display: flex;
      flex-direction: column;

      :deep(.el-card__body) {
        flex: 1;
        min-height: 0;
        display: flex;
        flex-direction: column;
      }
    }
  }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .header-tags {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;

      .api-path {
        font-size: 13px;
        color: var(--text-secondary);
      }
    }
  }

  .search-box {
    margin-bottom: 12px;
    flex-shrink: 0;
  }

  .api-list-scroll {
    flex: 1;
    min-height: 0;
  }

  .api-list {
    display: flex;
    flex-direction: column;
    gap: 4px;

    .api-item {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 10px 14px;
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      background: var(--bg-tertiary);
      border: 1px solid var(--border-color);
      margin-bottom: 6px;

      &:hover {
        border-color: rgba(251, 113, 133, 0.35);
        transform: translateX(4px);
        box-shadow: 0 4px 16px rgba(251, 113, 133, 0.12);
      }

      &.active {
        background: rgba(251, 113, 133, 0.15);
        border-color: rgba(251, 113, 133, 0.45);
      }

      .method-tag {
        flex-shrink: 0;
        min-width: 50px;
        text-align: center;
      }

      .api-name {
        font-size: 13px;
        color: var(--text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex: 1;
        min-width: 0;
      }

      .perf-tag,
      .issue-tag,
      .risk-tag {
        flex-shrink: 0;
      }

      &.risk-warning {
        border-left: 3px solid var(--el-color-warning);
      }

      &.risk-danger {
        border-left: 3px solid var(--el-color-danger);
      }
    }
  }

  .debug-content {
    display: flex;
    flex-direction: column;
    gap: 16px;
    height: 100%;
    overflow: auto;

    h4 {
      margin: 0 0 8px 0;
      font-size: 14px;
      color: var(--text-primary);
    }
  }

  .param-section {
    .param-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
  }

  .preview-section {
    .request-preview {
      padding: 10px 12px;
      background: var(--bg-tertiary);
      border-radius: 6px;
      font-size: 13px;
      font-family: monospace;
      word-break: break-all;

      code {
        color: var(--text-primary);
      }
    }
  }

  .action-buttons {
    display: flex;
    gap: 8px;
  }

  .response-section {
    h4 {
      display: flex;
      align-items: center;
      gap: 8px;

      .response-meta {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 12px;
        color: var(--text-muted);
        font-weight: normal;
      }
    }

    .response-code {
      padding: 12px;
      background: var(--bg-tertiary);
      border-radius: 6px;
      font-size: 12px;
      font-family: monospace;
      overflow: auto;
      max-height: 300px;
      margin: 0;
      color: var(--text-primary);
    }
  }

  .empty-tip {
    flex: 1;
    display: flex;
    flex-direction: column;
    color: var(--text-muted);
    font-size: 14px;
    overflow-y: auto;

    .guide-header {
      h3 {
        margin: 0 0 16px 0;
        color: var(--text-primary);
        font-size: 18px;
      }
    }

    .guide-content {
      .guide-step {
        display: flex;
        gap: 12px;
        margin-bottom: 16px;
        align-items: flex-start;

        .step-num {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: var(--brand-gradient, linear-gradient(135deg, #667eea 0%, #764ba2 100%));
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 600;
          flex-shrink: 0;
        }

        strong {
          color: var(--text-primary);
          display: block;
          margin-bottom: 2px;
        }

        p {
          margin: 0;
          font-size: 13px;
          line-height: 1.5;
          color: var(--text-muted);

          code {
            background: var(--bg-secondary);
            padding: 1px 6px;
            border-radius: 3px;
            font-size: 12px;
          }
        }
      }

      .guide-tags {
        p {
          margin: 0 0 8px 0;
          color: var(--text-primary);
        }

        .tag-legend {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;

          .legend-item {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 12px;
            color: var(--text-muted);
          }
        }
      }
    }
  }

  .example-section {
    margin-bottom: 12px;

    h4 {
      margin: 0 0 6px 0;
      font-size: 13px;
      color: var(--text-primary);
    }

    .example-code {
      background: var(--bg-secondary, rgba(0,0,0,0.2));
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 10px 12px;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 8px;
      font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
      font-size: 12px;
      color: var(--text-secondary);
      word-break: break-all;
      line-height: 1.6;

      code {
        flex: 1;
        white-space: pre-wrap;
      }

      .copy-btn {
        flex-shrink: 0;
        align-self: center;
      }
    }
  }
}

html.dark {
  .api-debug {
    .list-card,
    .debug-card {
      background: linear-gradient(
        135deg,
        rgba(30, 18, 18, 0.95) 0%,
        rgba(40, 24, 24, 0.95) 50%,
        rgba(30, 18, 18, 0.95) 100%
      );
      border-color: rgba(255, 255, 255, 0.08);

      &::before {
        background: linear-gradient(
          120deg,
          transparent 0%,
          rgba(251, 113, 133, 0.2) 25%,
          rgba(251, 113, 133, 0.3) 50%,
          rgba(251, 113, 133, 0.2) 75%,
          transparent 100%
        );
      }

      &:hover {
        background: linear-gradient(
          135deg,
          rgba(45, 28, 28, 0.98) 0%,
          rgba(55, 35, 35, 0.98) 50%,
          rgba(45, 28, 28, 0.98) 100%
        );
        border-color: rgba(251, 113, 133, 0.25);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
      }
    }

    :deep(.el-card__header) {
      background: linear-gradient(
        135deg,
        rgba(35, 20, 20, 0.98) 0%,
        rgba(45, 28, 28, 0.98) 100%
      );
    }

    .api-item {
      background: linear-gradient(
        135deg,
        rgba(30, 18, 18, 0.7) 0%,
        rgba(40, 24, 24, 0.7) 50%,
        rgba(30, 18, 18, 0.7) 100%
      );
      border-color: rgba(255, 255, 255, 0.06);

      &::before {
        background: linear-gradient(
          120deg,
          transparent 0%,
          rgba(251, 113, 133, 0.15) 25%,
          rgba(251, 113, 133, 0.25) 50%,
          rgba(251, 113, 133, 0.15) 75%,
          transparent 100%
        );
      }

      &:hover {
        background: linear-gradient(
          135deg,
          rgba(45, 28, 28, 0.95) 0%,
          rgba(55, 35, 35, 0.95) 50%,
          rgba(45, 28, 28, 0.95) 100%
        );
        border-color: rgba(251, 113, 133, 0.2);
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
      }

      &.active {
        background: linear-gradient(
          135deg,
          rgba(251, 113, 133, 0.18) 0%,
          rgba(251, 113, 133, 0.12) 50%,
          rgba(251, 113, 133, 0.18) 100%
        );
        border-color: rgba(251, 113, 133, 0.35);
      }
    }

    .request-preview,
    .response-code {
      background: linear-gradient(
        135deg,
        rgba(30, 18, 18, 0.95) 0%,
        rgba(40, 24, 24, 0.95) 50%,
        rgba(30, 18, 18, 0.95) 100%
      );
      border-color: rgba(255, 255, 255, 0.08);
    }
  }
}
</style>
