export type ImgVersion = 1 | 2 | 4 | 5 | 6

export type ColorBits =
  | 0x0e  // ARGB_1555
  | 0x0f  // ARGB_4444
  | 0x10  // ARGB_8888
  | 0x11  // LINK
  | 0x12  // DXT_1
  | 0x13  // DXT_3
  | 0x14  // DXT_5

export type CompressMode =
  | 0x05  // NONE
  | 0x06  // ZLIB
  | 0x07  // DDS_ZLIB

export interface Point {
  x: number
  y: number
}

export interface TextureRect {
  leftUp: Point
  rightDown: Point
  top: number
}

export interface Sprite {
  index: number
  type: ColorBits
  typeName: string
  x: number
  y: number
  originalX?: number
  originalY?: number
  width: number
  height: number
  frameWidth: number
  frameHeight: number
  compressMode: CompressMode
  length: number
  data?: Uint8Array
  textureIndex: number
  textureRect: TextureRect
  targetIndex: number
  isLink?: boolean
  targetValid?: boolean
  linkStatus?: 'normal' | 'null' | 'circular'
  isModified: boolean
  isDeleted: boolean
  isNew: boolean
}

export interface Texture {
  index: number
  type: ColorBits
  typeName: string
  width: number
  height: number
  length: number
  data?: Uint8Array
}

export interface Album {
  path: string
  version: ImgVersion
  sprites: Sprite[]
  textures: Texture[]
  isLoaded: boolean
  isModified: boolean
  hasLinkSprite: boolean
}

export interface Document {
  npkName: string
  albums: Map<string, Album>
  loadedAlbumPaths: string[]
  isModified: boolean
}

export interface NpkItem {
  id: number
  name: string
  path: string
  file_size: number
  img_count?: number
  format_type?: number
  encryption_verified?: boolean
}

export interface AlbumItem {
  id: number
  img_path: string
  frame_count: number
  version?: number
  file_type?: number
  offset?: number
  size?: number
}

export interface FrameItem {
  index: number
  x: number
  y: number
  width: number
  height: number
  frame_width: number
  frame_height: number
  type: number
  type_name: string
  compress: number
  data_size?: number
  texture_index?: number
  texture_rect?: {
    lu_x: number
    lu_y: number
    rd_x: number
    rd_y: number
  }
}

export interface TextureItem {
  index: number
  width: number
  height: number
  type: number
  type_name: string
}

export interface MusicFile {
  id: number
  name: string
  path: string
  dir_path: string
  size: number
  format: string
  duration: number
  sample_rate: number
  channels: number
  bitrate: number
  sha256_hash?: string
  created_at?: string
  updated_at?: string
}

export interface MusicStats {
  total_count: number
  total_size: number
  total_duration: number
}

export interface SoundPackFile {
  id: number
  name: string
  path: string
  dir_path: string
  size: number
  is_encrypted: boolean
  format_type: number
  ogg_count: number
  sha256_hash?: string
  created_at?: string
  updated_at?: string
}

export interface SoundPackEntry {
  id: number
  soundpack_id: number
  entry_path: string
  entry_name: string
  entry_size: number
  entry_offset: number
  ogg_duration: number
  ogg_sample_rate: number
  ogg_channels: number
}

export interface SoundPackStats {
  total_count: number
  total_size: number
  total_ogg_count: number
}