import axios from 'axios'
import type { AxiosInstance, AxiosResponse } from 'axios'
import { ref } from 'vue'
import i18n from '@/language'

const t = (i18n.global as any).t

const baseURL = '/api'

export interface ApiLogEntry {
  id: number
  method: string
  path: string
  status: number
  time: string
  duration: number
  size?: string
  error?: string
  requestData?: unknown
  responseData?: unknown
}

// 响应数据大小限制 (10KB)
const MAX_RESPONSE_SIZE_FOR_LOG = 10 * 1024

const apiLogArray = ref<ApiLogEntry[]>([])
let apiLogId = 0

export function getApiLogs() {
  return apiLogArray.value
}

export function useApiLogs() {
  return apiLogArray
}

export function clearApiLogs(): void {
  apiLogArray.value = []
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

const api: AxiosInstance = axios.create({
  baseURL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

export { api }

api.interceptors.request.use(
  (config) => {
    ;(config as any).metadata = { startTime: Date.now() }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

api.interceptors.response.use(
  (response: AxiosResponse) => {
    const duration = (response.config as any).metadata?.startTime
      ? Date.now() - (response.config as any).metadata.startTime
      : 0
    
    const logEntry: ApiLogEntry = {
      id: ++apiLogId,
      method: response.config.method?.toUpperCase() || 'UNKNOWN',
      path: response.config.url || '',
      status: response.status,
      time: new Date().toLocaleTimeString(),
      duration
    }

    try {
      const dataStr = JSON.stringify(response.data)
      const dataSize = new Blob([dataStr]).size
      logEntry.size = formatSize(dataSize)
      
      // 只在数据大小不超过限制时才保存完整响应
      if (dataSize <= MAX_RESPONSE_SIZE_FOR_LOG) {
        logEntry.responseData = response.data
      } else {
        logEntry.responseData = { 
          truncated: true, 
          message: t('common.responseTooLarge'), 
          size: logEntry.size 
        }
      }
    } catch {}

    if (apiLogArray.value.length >= 100) {
      apiLogArray.value.shift()
    }
    apiLogArray.value.push(logEntry)

    // blob 响应直接返回
    if (response.config.responseType === 'blob') {
      return response
    }

    const data = response.data
    if (data.code !== 0 && data.code !== 202) {
      return Promise.reject(new Error(t('common.requestFailed')))
    }
    return data
  },
  (error) => {
    const duration = error.config?.metadata?.startTime
      ? Date.now() - error.config.metadata.startTime
      : 0

    const logEntry: ApiLogEntry = {
      id: ++apiLogId,
      method: error.config?.method?.toUpperCase() || 'UNKNOWN',
      path: error.config?.url || '',
      status: error.response?.status || 0,
      time: new Date().toLocaleTimeString(),
      duration,
      error: error.response?.data?.message || error.message || 'Network Error'
    }

    if (apiLogArray.value.length >= 100) {
      apiLogArray.value.shift()
    }
    apiLogArray.value.push(logEntry)

    return Promise.reject(new Error(t('common.networkError')))
  }
)

// API 接口

// NPK 管理
export const npkApi = {
  // 获取 NPK 列表（全量）
  list: () => api.get('/npk/list'),

  // 分页获取 NPK 列表（推荐）
  listPaginated: (query?: string, page = 1, size = 50) =>
    api.get('/npk/list/paginated', {
      params: { q: query, page, size }
    }),

  // 获取 NPK 信息（带 LRU 缓存）
  getInfo: (name: string) => api.get(`/npk/${encodeURIComponent(name)}/info`),

  // 扫描目录
  scan: (path?: string) => api.post('/npk/scan', { path }),

  // 保存 NPK
  save: (name: string) => api.post(`/npk/${encodeURIComponent(name)}/save`),

  // 删除 NPK
  delete: (name: string) => api.delete(`/npk/${encodeURIComponent(name)}`),

  // 获取 NPK 下的 Album 列表
  getAlbums: (name: string) => api.get(`/npk/${encodeURIComponent(name)}/assets`),

  // 获取 NPK 的标签
  getTags: (name: string) => api.get(`/npk/${encodeURIComponent(name)}/tags`),

  // 给 NPK 添加标签
  addTag: (name: string, tagId: number) =>
    api.post(`/npk/${encodeURIComponent(name)}/tags`, { tag_id: tagId }),

  // 移除 NPK 的标签
  removeTag: (name: string, tagId: number) =>
    api.delete(`/npk/${encodeURIComponent(name)}/tags/${tagId}`),

  // 设置 IMG 引用目标
  setAlbumTarget: (npkName: string, albumPath: string, targetPath: string) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/album/set-target`, {
      album_path: albumPath,
      target_path: targetPath,
    }),

  // 清除 IMG 引用
  clearAlbumTarget: (npkName: string, albumPath: string) =>
    api.delete(`/npk/${encodeURIComponent(npkName)}/album/target`, {
      data: { album_path: albumPath },
    }),
}

// 资源查询
export const assetApi = {
  // 获取资源列表
  list: (npkName: string, albumPath?: string, page = 1, size = 50) =>
    api.get(`/npk/${encodeURIComponent(npkName)}/assets`, {
      params: { album: albumPath, page, size }
    }),

  // 获取图片 URL
  getImageUrl: (npkName: string, albumPath: string, index: number, width?: number, height?: number, noCompress?: boolean) => {
    const params = new URLSearchParams({ album: albumPath })
    if (width) params.append('w', String(width))
    if (height) params.append('h', String(height))
    if (noCompress) params.append('nocompress', '1')
    return `${baseURL}/npk/${encodeURIComponent(npkName)}/assets/${index}/image?${params}`
  },

  // 获取缩略图 URL
  getThumbnailUrl: (npkName: string, albumPath: string, index: number) =>
    `${baseURL}/npk/${encodeURIComponent(npkName)}/assets/${index}/thumbnail?album=${encodeURIComponent(albumPath)}`,

  // 替换资源
  replace: (npkName: string, albumPath: string, index: number, file: File, colorFormat?: string, autoResize?: boolean) => {
    const formData = new FormData()
    formData.append('file', file)
    if (colorFormat) {
      formData.append('color_format', colorFormat)
    }
    if (autoResize !== undefined) {
      formData.append('auto_resize', String(autoResize))
    }
    return api.post(
      `/npk/${encodeURIComponent(npkName)}/assets/${index}/replace?album=${encodeURIComponent(albumPath)}`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  // 删除资源
  delete: (npkName: string, albumPath: string, index: number) =>
    api.delete(`/npk/${encodeURIComponent(npkName)}/assets/${index}`, {
      params: { album: albumPath }
    }),

  // 更新帧属性
  updateFrame: (npkName: string, albumPath: string, index: number, frameIndex: number, data: { x: number; y: number; width?: number; height?: number; frame_width: number; frame_height: number }) =>
    api.put(`/npk/${encodeURIComponent(npkName)}/assets/${index}/frame/${frameIndex}`, data, {
      params: { album: albumPath }
    }),

  // 添加帧
  addFrame: (npkName: string, albumPath: string, file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post(
      `/npk/${encodeURIComponent(npkName)}/assets/add?album=${encodeURIComponent(albumPath)}`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  // 添加引用帧
  addLinkFrame: (npkName: string, albumPath: string, targetIndex: number, position: string) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/assets/add-link?album=${encodeURIComponent(albumPath)}`, {
      target_index: targetIndex,
      position,
    }),

  // 修改引用帧目标
  modifyLinkTarget: (npkName: string, albumPath: string, spriteIndex: number, newTargetIndex: number) =>
    api.put(`/npk/${encodeURIComponent(npkName)}/assets/${spriteIndex}/modify-link?album=${encodeURIComponent(albumPath)}`, {
      target_index: newTargetIndex,
    }),

  // 裁剪帧的透明边缘
  trimImage: (npkName: string, albumPath: string, index: number) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/assets/${index}/trim?album=${encodeURIComponent(albumPath)}`),

  // 画布化帧
  canvasImage: (npkName: string, albumPath: string, index: number, targetX: number, targetY: number, targetWidth: number, targetHeight: number) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/assets/${index}/canvas?album=${encodeURIComponent(albumPath)}`, {
      targetX,
      targetY,
      targetWidth,
      targetHeight
    }),
}

// 动画接口
export const animationApi = {
  // 获取动画信息
  getInfo: (npkName: string, albumPath: string) =>
    api.get(`/npk/${encodeURIComponent(npkName)}/assets/0/ani/info`, {
      params: { album: albumPath }
    }),

  // 获取动画帧 URL
  getFrameUrl: (npkName: string, albumPath: string, frameIndex: number) =>
    `${baseURL}/npk/${encodeURIComponent(npkName)}/assets/0/ani/frame/${frameIndex}?album=${encodeURIComponent(albumPath)}`,

  // 导出 GIF URL
  getExportGifUrl: (npkName: string, albumPath: string) =>
    `${baseURL}/npk/${encodeURIComponent(npkName)}/assets/0/ani/export.gif?album=${encodeURIComponent(albumPath)}`
}

// IMG 缓存接口
export const imgCacheApi = {
  // 加载 IMG 到内存缓存
  load: (npkName: string, albumPath: string) =>
    api.post('/cache/img/load', {
      npk_name: npkName,
      album_path: albumPath
    }),

  // 释放指定 IMG 缓存
  release: (npkName: string, albumPath: string) =>
    api.delete('/cache/img/release', {
      params: { npk_name: npkName, album_path: albumPath }
    }),

  // 释放全部 IMG 缓存
  releaseAll: () =>
    api.delete('/cache/img/release-all'),

  // 获取缓存状态
  getStatus: () =>
    api.get('/cache/img/status')
}

// Album 帧详情接口
export const albumApi = {
  // 获取 Album 的帧详情列表
  getFrames: (npkName: string, albumPath: string) =>
    api.get('/npk/frames', { params: { npk: npkName, album: albumPath } }),

  // 获取画布预览 URL
  getPreviewUrl: (npkName: string, albumPath: string) =>
    `${baseURL}/npk/preview?npk=${encodeURIComponent(npkName)}&album=${encodeURIComponent(albumPath)}&mode=combined`,

  // 重命名 Album 路径
  rename: (npkName: string, oldPath: string, newPath: string) =>
    api.put(`/npk/${encodeURIComponent(npkName)}/album/rename`, { old_path: oldPath, new_path: newPath }),

  // 对比两个 Album
  compare: (npkName: string, albumPath1: string, albumPath2: string) =>
    api.get(`/npk/${encodeURIComponent(npkName)}/album/compare`, {
      params: { album1: albumPath1, album2: albumPath2 }
    }),

  // 导入外部 IMG 文件
  importImg: (npkName: string, targetPath: string, file: File, replace?: boolean) => {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('path', targetPath)
    if (replace) {
      formData.append('replace', 'true')
    }
    return api.post(
      `/npk/${encodeURIComponent(npkName)}/import-img`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  // 批量替换（文件夹模式，按文件名 0.png, 1.png... 匹配索引）
  batchReplaceFromFolder: (npkName: string, albumPath: string, files: File[], colorFormat?: string, startIndex: number = 0, autoResize?: boolean) => {
    const formData = new FormData()
    formData.append('album', albumPath)
    if (colorFormat) {
      formData.append('color_format', colorFormat)
    }
    formData.append('start_index', String(startIndex))
    if (autoResize !== undefined) {
      formData.append('auto_resize', String(autoResize))
    }
    files.forEach(file => formData.append('files', file))
    return api.post(
      `/npk/${encodeURIComponent(npkName)}/assets/batch-replace`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  // 批量导入帧
  batchImportSprites: (npkName: string, albumPath: string, position: "before" | "after" | "end", currentIndex: number, replaceLinks: boolean, colorFormat: string, files: File[]) => {
    const formData = new FormData()
    formData.append('album', albumPath)
    formData.append('position', position)
    formData.append('current_index', String(currentIndex))
    formData.append('replace_links', String(replaceLinks))
    formData.append('color_format', colorFormat)
    files.forEach(file => formData.append('files', file))
    return api.post(
      `/npk/${encodeURIComponent(npkName)}/assets/batch-import`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  // 删除整个 Album (IMG)
  deleteAlbum: (npkName: string, albumPath: string) =>
    api.delete(`/npk/${encodeURIComponent(npkName)}/album`, {
      params: { path: albumPath }
    }),

  // 清空帧图像（变为全透明）
  clearSpriteImage: (npkName: string, albumPath: string, index: number) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/assets/${index}/clear`, null, {
      params: { album: albumPath }
    }),

  // 重置帧属性（撤回未保存修改）
  resetSprite: (npkName: string, albumPath: string, index: number) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/assets/${index}/reset`, null, {
      params: { album: albumPath }
    }),

  // 获取外部 NPK 文件的 Album 列表（通过路径）
  getExternalNpkAlbums: (npkPath: string) =>
    api.get('/external-npk/albums', { params: { npkPath } }),

  // 上传外部 NPK 文件获取 Album 列表
  uploadExternalNpk: (file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/external-npk/albums', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },

  // 获取外部 NPK 文件的帧图像 URL（路径方式）
  getExternalNpkFrameUrl: (npkPath: string, albumPath: string, frameIndex: number, width?: number, height?: number) => {
    const params = new URLSearchParams({ npkPath, albumPath, frameIndex: String(frameIndex) })
    if (width) params.append('width', String(width))
    if (height) params.append('height', String(height))
    return `${baseURL}/external-npk/frame?${params}`
  },

  // 获取外部 NPK 文件的帧图像 URL（缓存 key 方式）
  getExternalNpkFrameUrlByKey: (key: string, albumPath: string, frameIndex: number, width?: number, height?: number) => {
    const params = new URLSearchParams({ key, albumPath, frameIndex: String(frameIndex) })
    if (width) params.append('width', String(width))
    if (height) params.append('height', String(height))
    return `${baseURL}/external-npk/frame?${params}`
  },
  // 下载编辑后的外部 NPK
  downloadExternalNpkUrl: (key: string) =>
    `${baseURL}/external-npk/download?key=${encodeURIComponent(key)}`,

// 上传外部 IMG 文件
  uploadExternalImg: (file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/external-img/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // 获取外部 IMG 文件的信息
  getExternalImgAlbums: (imgPath: string) =>
    api.get('/external-img/info', { params: { imgPath } }),

  // 获取外部 IMG 文件的帧图像 URL
  getExternalImgFrameUrl: (imgPath: string, frameIndex: number, width?: number, height?: number) => {
    const params = new URLSearchParams({
      imgPath,
      frameIndex: String(frameIndex)
    })
    if (width) params.append('width', String(width))
    if (height) params.append('height', String(height))
    return `${baseURL}/external-img/frame?${params}`
  },

  // 设置 Album Target（引用 IMG）
  setTarget: (npkName: string, albumPath: string, targetPath: string) =>
    api.post(`/npk/${encodeURIComponent(npkName)}/album/set-target`, {
      album_path: albumPath,
      target_path: targetPath
    }),

  // 导出基准坐标
  exportCoords: (npkName: string, albumPath: string) =>
    api.get(`/npk/${encodeURIComponent(npkName)}/album/export-coords`, {
      params: { album: albumPath },
      responseType: 'blob'
    }),

  // 导入基准坐标
  importCoords: (npkName: string, albumPath: string, file: File) => {
    const formData = new FormData()
    formData.append('album', albumPath)
    formData.append('file', file)
    return api.post(
      `/npk/${encodeURIComponent(npkName)}/album/import-coords`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
  },

  // 清除 Album Target
  clearTarget: (npkName: string, albumPath: string) =>
    api.delete(`/npk/${encodeURIComponent(npkName)}/album/target`, {
      data: { album_path: albumPath }
    }),
}

// 资源库接口
export const libraryApi = {
  // 获取统计信息
  getStats: () => api.get('/library/stats'),

  // 搜索
  search: (query: string, type?: string, page = 1, size = 20) =>
    api.get('/library/search', {
      params: { q: query, type, page, size }
    }),

  // 获取文件夹结构
  getFolders: () => api.get('/library/folders'),

  // 获取重复的 Album
  getDuplicates: () => api.get('/library/duplicates')
}

// 批量操作接口
export const batchApi = {
  // 批量导出（异步任务模式）
  export: (items: Array<{ npkName: string; albumPath: string; indices: number[] }>, format = 'png', quality = 90, removeBlack = false) =>
    api.post('/batch/export', { items, format, quality, removeBlack }),

  // 获取导出任务状态
  getStatus: (taskId: string) => api.get(`/batch/status/${taskId}`),

  // 下载导出结果 URL
  getDownloadUrl: (taskId: string) => `${baseURL}/batch/download/${taskId}`
}

// 设置接口
export const settingsApi = {
  // 获取设置
  get: () => api.get('/settings'),

  // 更新设置
  update: (settings: Record<string, unknown>) => api.put('/settings', settings),

  // 添加 NPK 目录
  addNpkDir: (path: string) => api.post('/settings/npk-dir', { path }),

  // 移除 NPK 目录
  removeNpkDir: (path: string) => api.delete('/settings/npk-dir', { data: { path } }),
}

// 数据库管理接口
export const dbApi = {
  // 获取统计信息
  getStats: () => api.get('/db/stats'),

  // 获取表列表
  getTables: () => api.get('/db/tables'),

  // 清理无效数据
  cleanup: () => api.post('/db/cleanup'),

  // 压缩数据库
  compact: () => api.post('/db/compact'),

  // 增量更新
  incremental: () => api.post('/db/incremental'),

  // 导出数据
  export: () => api.get('/db/export'),

  // 重建数据库
  rebuild: () => api.post('/db/rebuild')
}

// 视频数据库管理接口
export const videoDbApi = {
  // 获取视频数据库统计
  getStats: () => api.get('/db/videos/stats'),

  // 清理无效视频记录
  cleanup: () => api.post('/db/videos/cleanup'),

  // 重建视频数据库
  rebuild: () => api.post('/db/videos/rebuild'),

  // 压缩视频数据库
  compact: () => api.post('/db/videos/compact')
}

// 兼容 API（外部文档接口）
export const compatApi = {
  health: () => api.get('/health'),

  listNpks: () => api.get('/npks'),

  listImgs: (npkId: number) => api.get(`/npks/${npkId}/imgs`),

  listFramesByQuery: (npkId: number, imgPath: string) =>
    api.get(`/npks/${npkId}/frames`, { params: { imgPath } }),

  getFrameByPathUrl: (imgPath: string, index = 0, npkName?: string) => {
    const params = new URLSearchParams({ imgPath: String(imgPath), index: String(index) })
    if (npkName) params.append('npk', npkName)
    return `${baseURL}/frame/by-path?${params}`
  },

  batchFrames: (items: Array<{ imgPath: string; frameIndex: number }>) =>
    api.post('/frames/batch', { items }),

  albumBatch: (items: Array<{ imgPath: string; frameIndices?: number[]; npkName?: string }>) =>
    api.post('/frames/album-batch', { items }),

  overlay: (data: {
    width: number
    height: number
    backgroundColor?: string
    globalYOffset?: number
    layers: Array<{ imgPath: string; frameIndex: number; x: number; y: number; opacity?: number }>
  }) => api.post('/overlay', data)
}

// 视频管理接口
export const videoApi = {
  // 获取视频列表（全量）
  list: (query?: string, format?: string, encrypted?: string, page = 1, size = 100000) =>
    api.get('/videos/list', {
      params: { query, format, encrypted, page, size }
    }),

  // 获取视频统计
  getStats: () => api.get('/videos/stats'),

  // 扫描视频目录
  scan: (dir?: string) => api.post('/videos/scan', dir ? { dir } : {}),

  // 扫描指定目录
  scanDir: (dir: string) => api.post('/videos/scan-dir', { dir }),

  // 加密视频
  encrypt: (id: number) => api.post(`/videos/${id}/encrypt`),

  // 解密视频
  decrypt: (id: number) => api.post(`/videos/${id}/decrypt`),

  // 删除视频记录
  deleteVideo: (id: number) => api.delete(`/videos/${id}`),

  // 删除视频（同时删除文件）
  deleteVideoWithFile: (id: number) => api.delete(`/videos/${id}?delete_file=true`),

  // 批量删除视频
  batchDeleteVideos: (ids: number[], deleteFile = true) =>
    api.post('/videos/batch-delete', { ids, delete_file: deleteFile }),

  // 获取视频详情
  get: (id: number) => api.get(`/videos/${id}`),

  // 获取视频流 URL
  getStreamUrl: (id: number, decrypt = false, res = '800x600') => {
    const params = new URLSearchParams()
    if (decrypt) params.append('decrypt', 'true')
    if (res && res !== '800x600') params.append('res', res)
    const query = params.toString()
    return `${baseURL}/videos/${id}/stream${query ? '?' + query : ''}`
  },
  getDownloadUrl: (id: number, decrypt = false, res = '800x600') => {
    const params = new URLSearchParams()
    if (decrypt) params.append('decrypt', 'true')
    // 始终传递 res 参数，确保后端使用正确的分辨率
    if (res) params.append('res', res)
    const query = params.toString()
    return `${baseURL}/videos/${id}/download${query ? '?' + query : ''}`
  },

  // 按路径播放视频
  getPlayUrl: (path: string, decrypt = false) =>
    `${baseURL}/videos/play?path=${encodeURIComponent(path)}${decrypt ? '&decrypt=true' : ''}`,

  // 批量加密
  batchEncrypt: (ids: number[]) => api.post('/videos/batch-encrypt', { ids }),

  // 批量解密
  batchDecrypt: (ids: number[]) => api.post('/videos/batch-decrypt', { ids }),

  // 批量删除
  batchDelete: (ids: number[]) => api.delete('/videos/batch-delete', { data: { ids } }),
}

// 工具箱接口
export const toolsApi = {
  // 版本转换（上传 IMG 文件）
  convertUpload: (files: File[], targetVersion: string, outputFormat = 'img') => {
    const formData = new FormData()
    files.forEach(f => formData.append('files', f))
    formData.append('target_version', targetVersion)
    formData.append('output_format', outputFormat)
    return api.post('/tools/convert-upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 0, // 无超时
    })
  },

  // 获取转换任务状态
  getConvertStatus: (taskId: string) => api.get(`/tools/convert-status/${taskId}`),

  // 下载转换后的 ZIP
  getConvertDownloadUrl: (taskId: string) => `${baseURL}/tools/convert-download/${taskId}`
}

export default api

// 音乐管理接口
export const musicApi = {
  list: (query?: string, format?: string, page = 1, size = 100000) =>
    api.get('/music/list', {
      params: { query, format, page, size }
    }),

  getStats: () => api.get('/music/stats'),

  scan: (dir?: string) => api.post('/music/scan', dir ? { dir } : {}),

  deleteMusic: (id: number) => api.delete(`/music/${id}`),

  deleteMusicWithFile: (id: number) => api.delete(`/music/${id}?delete_file=true`),

  batchDeleteMusic: (ids: number[], deleteFile = true) =>
    api.post('/music/batch-delete', { ids, delete_file: deleteFile }),

  get: (id: number) => api.get(`/music/${id}`),

  getStreamUrl: (id: number) => `${baseURL}/music/${id}/stream`,

  convert: (id: number, targetFormat: string) =>
    api.post(`/music/${id}/convert`, { target_format: targetFormat }),
}

// 音乐数据库管理接口
export const musicDbApi = {
  getStats: () => api.get('/db/music/stats'),

  cleanup: () => api.post('/db/music/cleanup'),

  rebuild: () => api.post('/db/music/rebuild'),

  compact: () => api.post('/db/music/compact'),
}

// 音效包管理接口
export const soundpackApi = {
  list: (query?: string, page = 1, size = 100000) =>
    api.get('/soundpacks/list', { params: { query, page, size } }),

  getStats: () => api.get('/soundpacks/stats'),

  get: (id: number) => api.get(`/soundpacks/${id}`),

  scan: (dir?: string) => api.post('/soundpacks/scan', dir ? { dir } : {}),

  delete: (id: number) => api.delete(`/soundpacks/${id}`),

  deleteWithFile: (id: number) => api.delete(`/soundpacks/${id}?delete_file=true`),

  batchDelete: (ids: number[], deleteFile = true) =>
    api.post('/soundpacks/batch-delete', { ids, delete_file: deleteFile }),

  decrypt: (id: number) => api.post(`/soundpacks/${id}/decrypt`),

  getEntries: (id: number) => api.get(`/soundpacks/${id}/entries`),

  rebuild: (id: number) => api.post(`/soundpacks/${id}/rebuild`),

  getEntryStreamUrl: (soundpackId: number, entryId: number) =>
    `${baseURL}/soundpacks/${soundpackId}/entries/${entryId}/stream`,

  getEntryDownloadUrl: (soundpackId: number, entryId: number) =>
    `${baseURL}/soundpacks/${soundpackId}/entries/${entryId}/download`,

  convertEntry: (soundpackId: number, entryId: number, targetFormat: string) =>
    `${baseURL}/soundpacks/${soundpackId}/entries/${entryId}/convert?target_format=${targetFormat}`,

  importOGG: (soundpackId: number, entryPath: string, file: File) => {
    const formData = new FormData()
    formData.append('entry_path', entryPath)
    formData.append('file', file)
    return api.post(`/soundpacks/${soundpackId}/entries/import`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  renameEntry: (soundpackId: number, entryId: number, newPath: string) =>
    api.put(`/soundpacks/${soundpackId}/entries/${entryId}/rename`, { new_path: newPath }),

  deleteEntry: (soundpackId: number, entryId: number) =>
    api.delete(`/soundpacks/${soundpackId}/entries/${entryId}`),

  batchDeleteEntries: (soundpackId: number, entryIds: number[]) =>
    api.post(`/soundpacks/${soundpackId}/entries/batch-delete`, { entry_ids: entryIds }),

  getBatchExportUrl: (soundpackId: number) =>
    `${baseURL}/soundpacks/${soundpackId}/entries/batch-export`,

  batchImport: (soundpackId: number, files: File[]) => {
    const formData = new FormData()
    files.forEach(f => formData.append('files', f))
    return api.post(`/soundpacks/${soundpackId}/entries/batch-import`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
}

// 音效数据库管理接口
export const soundpackDbApi = {
  getStats: () => api.get('/db/soundpacks/stats'),

  cleanup: () => api.post('/db/soundpacks/cleanup'),

  rebuild: () => api.post('/db/soundpacks/rebuild'),

  compact: () => api.post('/db/soundpacks/compact'),
}

// XML 音频编辑器接口
export const xmlAudioApi = {
  list: (query?: string, type?: string, page = 1, size = 9999, checkMissing = false) =>
    api.get('/xml-audio/list', { params: { query, type, page, size, check_missing: checkMissing ? '1' : undefined } }),

  getEntry: (entryType: string, id: string) =>
    api.get(`/xml-audio/entry/${entryType}/${encodeURIComponent(id)}`),

  saveEntry: (entry: any) =>
    api.post('/xml-audio/entry', entry),

  deleteEntry: (entryType: string, id: string) =>
    api.delete(`/xml-audio/entry/${entryType}/${encodeURIComponent(id)}`),

  reload: () => api.post('/xml-audio/reload'),

  open: (path: string) => api.post('/xml-audio/open', { path }),

  export: () => api.post('/xml-audio/export'),

  checkMissing: () => api.get('/xml-audio/check-missing'),

  listFiles: (dir: string) => api.get('/xml-audio/list-files', { params: { dir } }),

  getStreamUrl: (file: string) =>
    `${baseURL}/xml-audio/stream?file=${encodeURIComponent(file)}`,
}
