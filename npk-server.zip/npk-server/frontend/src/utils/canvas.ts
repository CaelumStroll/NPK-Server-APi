/**
 * Canvas 工具函数
 */

/**
 * 使用 Screen (滤色) 混合模式去除黑色背景
 * @param canvas Canvas 元素
 */
export function removeBlackBackground(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext('2d')
  if (!ctx) return

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
  const data = imageData.data

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i]
    const g = data[i + 1]
    const b = data[i + 2]

    // 计算亮度 (取 RGB 最大值)
    const brightness = Math.max(r, g, b)

    if (brightness === 0) {
      // 纯黑，完全透明
      data[i + 3] = 0
    } else {
      // 根据亮度设置透明度
      // 亮度越高，越不透明
      data[i + 3] = brightness
    }
  }

  ctx.putImageData(imageData, 0, 0)
}

/**
 * 渲染图片到 Canvas，可选去除黑色背景
 * @param canvas Canvas 元素
 * @param url 图片 URL
 * @param removeBlack 是否去除黑色背景
 * @returns { promise: Promise<void>, cancel: () => void }
 */
export function renderImageToCanvas(
  canvas: HTMLCanvasElement,
  url: string,
  removeBlack: boolean = false
): { promise: Promise<void>; cancel: () => void } {
  let canceled = false
  const img = new Image()
  
  const cleanup = () => {
    img.onload = null
    img.onerror = null
    img.src = ''
  }

  const promise = new Promise<void>((resolve, reject) => {
    const ctx = canvas.getContext('2d')
    if (!ctx) {
      cleanup()
      reject(new Error('Cannot get canvas context'))
      return
    }

    img.crossOrigin = 'anonymous'
    img.onload = () => {
      if (canceled) {
        cleanup()
        return
      }
      canvas.width = img.width
      canvas.height = img.height
      ctx.drawImage(img, 0, 0)

      if (removeBlack) {
        removeBlackBackground(canvas)
      }

      cleanup()
      resolve()
    }
    img.onerror = () => {
      cleanup()
      reject(new Error('Image load failed'))
    }
    img.src = url
  })
  
  return {
    promise,
    cancel: () => {
      canceled = true
      cleanup()
    }
  }
}
