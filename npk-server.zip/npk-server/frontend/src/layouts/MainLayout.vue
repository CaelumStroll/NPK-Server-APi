<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import {
  Odometer,
  Folder,
  Picture,
  VideoPlay,
  Grid,
  Download,
  Setting,
  Menu as MenuIcon,
  Coin,
  Monitor,
  FirstAidKit,
  Notebook,
  Sunny,
  Moon,
  Edit,
  Film,
  Headset,
  Service,
  Document
} from '@element-plus/icons-vue'
import { useNpkStore } from '@/stores/npk'
import { useThemeStore, type ThemeMode } from '@/stores/theme'

const { t } = useI18n()
const route = useRoute()
const npkStore = useNpkStore()
const themeStore = useThemeStore()

const STORAGE_KEY = 'npk-sidebar-collapse'

const isCollapse = ref(true)

onMounted(() => {
  const saved = localStorage.getItem(STORAGE_KEY)
  if (saved !== null) {
    isCollapse.value = saved === 'true'
  }
})

const activeMenu = computed(() => route.path)

const menuItems = [
  { path: '/', icon: Odometer, titleKey: 'menu.dashboard' },
  { path: '/npk', icon: Folder, titleKey: 'menu.npkManager' },
  { path: '/browser', icon: Picture, titleKey: 'menu.imgResources' },
  { path: '/animation', icon: VideoPlay, titleKey: 'menu.animation' },
  { path: '/preview', icon: Edit, titleKey: 'menu.imgEdit' },
  { path: '/library', icon: Grid, titleKey: 'menu.imgDuplicate' },
  { path: '/batch', icon: Download, titleKey: 'menu.batchExport' },
  { path: '/database', icon: Coin, titleKey: 'menu.database' },
  { path: '/videos', icon: Film, titleKey: 'menu.videoManager' },
  { path: '/soundpacks', icon: Service, titleKey: 'menu.soundpackManager' },
  { path: '/music', icon: Headset, titleKey: 'menu.musicManager' },
  { path: '/xml-editor', icon: Document, titleKey: 'menu.xmlAudioEditor' },
  { path: '/api-debug', icon: Monitor, titleKey: 'menu.apiDebug' },
  { path: '/tools', icon: FirstAidKit, titleKey: 'menu.tools' },
  { path: '/logs', icon: Notebook, titleKey: 'menu.logs' },
  { path: '/settings', icon: Setting, titleKey: 'menu.settings' }
]

const routeTitle = computed(() => {
  const titleKey = route.meta.titleKey as string
  return titleKey ? t(titleKey) : ''
})

function toggleCollapse() {
  isCollapse.value = !isCollapse.value
  localStorage.setItem(STORAGE_KEY, String(isCollapse.value))
}

function setTheme(mode: ThemeMode) {
  themeStore.setThemeMode(mode)
}
</script>

<template>
  <el-container class="main-layout">
    <el-aside :width="isCollapse ? '64px' : '200px'" class="sidebar" :class="{ 'is-collapse': isCollapse }">
      <div class="logo">
        <svg class="logo-img" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
          <rect x="0" y="0" width="36" height="36" rx="10" fill="var(--logo-bg-color)" />
          <path d="M10 12h16v4H10v-4zm0 6h10v4H10v-4z" fill="var(--logo-icon-color)" />
        </svg>
        <span v-show="!isCollapse" class="logo-text">NPK Manager</span>
      </div>
      
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :collapse-transition="false"
        router
      >
        <el-menu-item v-for="item in menuItems" :key="item.path" :index="item.path">
          <el-icon><component :is="item.icon" /></el-icon>
          <template #title>{{ t(item.titleKey) }}</template>
        </el-menu-item>
      </el-menu>
      
      <div class="sidebar-footer">
        <el-button
          :icon="MenuIcon"
          text
          @click="toggleCollapse"
        >
          <template v-if="!isCollapse">{{ t('common.collapseMenu') }}</template>
        </el-button>
      </div>
    </el-aside>

    <el-container class="main-container">
      <el-header class="header">
        <div class="header-left">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">{{ t('common.home') }}</el-breadcrumb-item>
            <el-breadcrumb-item v-if="routeTitle">
              {{ routeTitle }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="header-right">
          <div class="theme-toggle">
            <el-icon 
              :class="{ active: themeStore.themeMode === 'light' }" 
              @click="setTheme('light')"
              class="theme-icon"
            ><Sunny /></el-icon>
            <span class="divider">|</span>
            <span 
              class="system-text" 
              :class="{ active: themeStore.themeMode === 'system' }"
              @click="setTheme('system')"
            >{{ t('common.system') }}</span>
            <span class="divider">|</span>
            <el-icon 
              :class="{ active: themeStore.themeMode === 'dark' }" 
              @click="setTheme('dark')"
              class="theme-icon"
            ><Moon /></el-icon>
          </div>
          <el-tag type="info">NPK: {{ npkStore.npkCount }}</el-tag>
        </div>
      </el-header>

      <el-main class="main-content">
        <slot></slot>
      </el-main>
    </el-container>
  </el-container>
</template>

<style lang="scss" scoped>
.main-layout {
  height: 100vh;
  background: var(--bg-secondary);
}

.sidebar {
  background: var(--bg-surface);
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  .logo {
    height: 68px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    padding: 0 20px;
    border-bottom: 1px solid var(--border-color);

    .logo-img {
      width: 36px;
      height: 36px;
      box-shadow: var(--shadow-soft);
      transition: all 0.3s ease;
    }

    .logo-text {
      margin-left: 12px;
      font-size: 16px;
      font-weight: 700;
      color: var(--text-primary);
      white-space: nowrap;
      letter-spacing: -0.02em;
    }
  }

  &.is-collapse {
    .logo {
      justify-content: center;
      padding: 0;
      
      .logo-text {
        display: none;
      }
    }
  }

  .el-menu {
    border-right: none;
    flex: 1;
    background: transparent;
    padding: 12px 10px;

    :deep(.el-menu-item) {
      color: var(--text-secondary);
      margin: 4px 0;
      border-radius: 14px;
      height: 46px;
      line-height: 46px;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding-left: 14px !important;
      padding-right: 14px !important;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);

      .el-icon {
        color: var(--text-secondary);
        font-size: 18px;
        margin-right: 12px;
      }

      span {
        flex: 1;
        font-weight: 500;
      }

      &:hover {
        background: var(--bg-tertiary);
        color: var(--accent-color);
        transform: translateX(4px);

        .el-icon {
          color: var(--accent-color);
        }
      }

      &.is-active {
        background: rgba(251, 113, 133, 0.12);
        color: var(--accent-dark);
        box-shadow: none;

        .el-icon {
          color: var(--accent-dark);
        }
      }
    }

    &.el-menu--collapse {
      padding: 12px 8px;
      
      :deep(.el-menu-item) {
        justify-content: center;
        padding-left: 0 !important;
        padding-right: 0 !important;
        border-radius: 12px;

        &:hover {
          transform: scale(1.05);
        }

        .el-icon {
          margin-right: 0;
        }

        span {
          display: none;
        }

        .el-tooltip__trigger,
        .el-menu-tooltip__trigger {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;

          .el-icon {
            margin: 0;
          }
        }
      }
    }
  }

  .sidebar-footer {
    padding: 14px;
    border-top: 1px solid var(--border-color);

    :deep(.el-button) {
      color: var(--text-secondary);
      width: 100%;
      height: 42px;
      padding: 0 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 12px;
      transition: all 0.2s ease;

      .el-icon {
        font-size: 18px;
        flex-shrink: 0;
      }

      span {
        margin-left: 8px;
        font-size: 13px;
        font-weight: 500;
      }

      &:hover {
        color: var(--accent-color);
        background: var(--bg-tertiary);
      }
    }
  }

  &.is-collapse {
    .sidebar-footer {
      padding: 14px 8px;
      
      :deep(.el-button) {
        width: 44px;
        padding: 0;
        margin: 0 auto;
        
        span {
          display: none;
        }
      }
    }
  }
}

.main-container {
  display: flex;
  flex-direction: column;
  background: var(--bg-secondary);
}

.header {
  background: var(--bg-surface);
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  height: 64px;

  .header-left {
    display: flex;
    align-items: center;
  }

  .header-right {
    display: flex;
    align-items: center;
    gap: 16px;
  }

  .theme-toggle {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    background: var(--bg-tertiary);
    border-radius: 20px;
    user-select: none;

    .theme-icon {
      font-size: 14px;
      color: var(--text-muted);
      cursor: pointer;
      padding: 4px;
      border-radius: 6px;
      transition: all 0.2s ease;

      &:hover {
        color: var(--text-primary);
        background: var(--bg-secondary);
      }

      &.active {
        color: var(--accent-color);
      }
    }

    .system-text {
      font-size: 11px;
      color: var(--text-muted);
      cursor: pointer;
      padding: 4px 6px;
      border-radius: 6px;
      transition: all 0.2s ease;
      font-weight: 500;

      &:hover {
        color: var(--text-primary);
        background: var(--bg-secondary);
      }

      &.active {
        color: var(--accent-color);
      }
    }

    .divider {
      color: var(--border-color);
      font-size: 11px;
      font-weight: 300;
    }
  }

  :deep(.el-tag) {
    border-radius: 10px;
    font-size: 13px;
    padding: 6px 14px;
    font-weight: 500;
  }
}

.main-content {
  background: var(--bg-secondary);
  padding: 24px;
  overflow-y: auto;
}
</style>
