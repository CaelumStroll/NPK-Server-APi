# NPK Server 使用指南

## 目录

- [编译指南](#编译指南)
- [快速开始](#快速开始)
- [性能优化 - IMG 缓存池](#性能优化---img-缓存池)
- [API 接口](#api-接口)
- [常见问题](#常见问题)

---

## 编译指南

### Windows 版本

#### 64位版本

```bash
cd npk-server/backend
GOOS=windows GOARCH=amd64 go build -o ../npk-server-win64.exe ./cmd/server
```

#### 32位版本

```bash
cd npk-server/backend
GOOS=windows GOARCH=386 go build -o ../npk-server-win32.exe ./cmd/server
```

### macOS 版本

#### Apple Silicon (M1/M2)

```bash
cd npk-server/backend
GOOS=darwin GOARCH=arm64 go build -o ../npk-server-darwin-arm64 ./cmd/server
```

#### Intel

```bash
cd npk-server/backend
GOOS=darwin GOARCH=amd64 go build -o ../npk-server-darwin-amd64 ./cmd/server
```

### Linux 版本

#### 64位

```bash
cd npk-server/backend
GOOS=linux GOARCH=amd64 go build -o ../npk-server-linux64 ./cmd/server
```

#### 32位

```bash
cd npk-server/backend
GOOS=linux GOARCH=386 go build -o ../npk-server-linux32 ./cmd/server
```

### 编译说明

1. **无需 CGO**: 本项目使用纯 Go 的 SQLite 驱动 (`modernc.org/sqlite`)，编译时无需设置 `CGO_ENABLED=1`
2. **静态链接**: 默认编译为静态可执行文件，可直接复制到目标机器运行
3. **文件位置**: 编译输出到 `npk-server/` 目录

---

## 快速开始

### 1. 准备 NPK 数据

将 DNF 游戏的 NPK 文件放入一个目录，例如：

```
/path/to/dnf-data/
  ├── sprite.npk
  ├── map.npk
  ├── effect.npk
  └── ...
```

### 2. 配置数据库

首次运行会自动创建 SQLite 数据库文件 (`data/npk.db`)。

如需初始化数据库，在配置文件中指定 NPK 目录：

```json
{
  "npk_data_dir": "/path/to/dnf-data",
  "port": 8556,
  "db_path": "./data/npk.db"
}
```

### 3. 运行服务器

#### Windows

双击运行 `npk-server-win64.exe` 或 `npk-server-win32.exe`

或命令行运行：

```bash
./npk-server-win64.exe
```

#### 指定配置

```bash
./npk-server-win64.exe --config=/path/to/config.json
```

### 4. 访问 Web 界面

打开浏览器访问：

```
http://localhost:8556
```

### 5. 使用 town.html 地图预览

1. 将 `town.html` 复制到可访问目录
2. 打开浏览器访问 `town.html`
3. 输入 API 地址：`http://localhost:8556/api`
4. 选择地图文件夹
5. 开始预览

---

## 性能优化 - IMG 缓存池

### 什么是 IMG 缓存池？

IMG 缓存池是一个**按需加载**的内存缓存系统，用于提升图片加载性能。

**核心特性**：
- 按需解码：只在访问图片时才解码，避免一次性加载大量图片导致的卡顿
- 元数据预加载：IMG 的元数据快速加载到内存
- 智能缓存：解码后的图片自动缓存，后续访问零延迟
- LRU 淘汰：内存不足时自动淘汰最久未使用的缓存

### 工作原理

```
首次访问（100帧动画）：
  - 旧方案：解码所有100帧 → 5-10秒，CPU 100%
  - 新方案：只加载元数据 → <100ms，CPU 平滑

后续访问：
  - 直接从缓存读取 → 毫秒级响应
```

### town.html 中的缓存使用

`town.html` 已集成 IMG 缓存功能：

1. **自动预加载**：加载地图时自动将所需的 IMG 加载到缓存
2. **切换地图**：自动释放旧缓存，加载新缓存
3. **页面关闭**：自动释放所有缓存

### 缓存配置

缓存参数在 `npk_service.go` 中设置：

```go
imgCache: cache.NewImgCachePool(
    500,  // 最大内存 500MB
    50,   // 最大条目 50个
    10,   // TTL 10分钟
)
```

### 监控缓存状态

通过 API 查询缓存状态：

```bash
curl http://localhost:8556/api/cache/img/status
```

响应示例：

```json
{
  "code": 0,
  "data": {
    "items": [...],
    "count": 5,
    "total_size_mb": 120.5,
    "max_size_mb": 500,
    "hit_rate": 85.5,
    "hits": 1000,
    "misses": 170,
    "evictions": 5
  }
}
```

---

## API 接口

### 缓存管理

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/cache/img/load` | 加载 IMG 元数据到缓存 |
| DELETE | `/api/cache/img/release` | 释放指定缓存 |
| DELETE | `/api/cache/img/release-all` | 释放全部缓存 |
| GET | `/api/cache/img/status` | 获取缓存状态 |

### 图片加载

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/frame/by-path` | 通过路径获取单张图片 |
| POST | `/api/frames/batch` | 批量获取图片 |

### 健康检查

```bash
curl http://localhost:8556/api/health
```

---

## 常见问题

### Q: 编译时提示 "no Go files"

确保在正确的目录执行编译命令：

```bash
cd npk-server/backend
go build -o ../npk-server ./cmd/server
```

### Q: 运行时提示数据库错误

1. 确保 `data/` 目录存在且有写入权限
2. 检查 `config.json` 中的 `db_path` 配置
3. 首次运行会自动创建数据库

### Q: town.html 加载很慢

1. 检查 NPK 数据目录是否正确配置
2. 查看服务器日志中的缓存命中率
3. 使用 `/api/cache/img/status` 检查缓存状态

### Q: 如何优化大型地图的加载速度？

1. 使用缓存池：切换地图会自动利用缓存
2. 减少同时打开的标签页
3. 关闭不使用的浏览器标签页

### Q: 内存占用过高

1. 缓存池会自动淘汰旧条目
2. 可通过配置减小 `max_size_mb` 参数
3. 使用 `/api/cache/img/release-all` 手动释放缓存

### Q: 如何查看日志？

服务器会输出日志到标准输出：

```bash
./npk-server-win64.exe 2>&1 | tee server.log
```

---

## 技术支持

如有问题，请查看：
- [IMG_CACHE.md](./docs/IMG_CACHE.md) - 缓存池详细文档
- [README.md](./docs/README.md) - 项目说明
- 服务器日志输出

---

## 更新日志

### v2.0 (2024-05-17)

- **性能优化**：IMG 缓存池改为按需解码，避免一次性加载大量图片导致的卡顿
- **内存优化**：内存峰值从 300-500MB 降低到 50-100MB
- **响应速度**：首次加载时间从 15-30 秒降低到 2-3 秒
- **API 增强**：批量接口返回 NPK 名称，便于缓存管理
